class CConfig1:

    delta_add_last_ind1 = 25
    min_dist_last_derivative1 = 0.1
    min_dist_down_last_derivative1 = 0.08
    min_dist_up_last_derivative1 = 0.08
    min_diff_last_derivative1 = 0.1
    max_add_curve_height1 = 1.1
    
    find_curves_of_handles1_add_width=220
    
    max_count_not_over_max_cord1=50
    
    max_last_cords1=40
    
    max_count_sign_pxls2=1400
    
    delta_xy_combine_new_curve_in_frame_pixels_arr1=5
    start_cur_sobel_ind_val1=80
    
    max_pixels_around_one_pixel=8
    
    degree_45=45
    degree_90=90
    degree_180=180
    
    flip_horizontal = "flip_horizontal"
    rotate_90 = "flip_horizontal"
    def __init__(self):
        self.d1=1
        
    