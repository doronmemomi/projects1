from ArrayList import ArrayList
from test1 import test1
from CPolynom2 import CPolynom2
from Dictionary import Dictionary
from bitmap import Bitmap
from CPolynom_curve1 import CPolynom_curve1
from CEdgeDetection1 import CEdgeDetection1
import json
import ast


class CJson1:
    def get_type_of_var1(obj1):
        if isinstance(obj1,Dictionary):
            return "Dictionary"
        
        if isinstance(obj1,ArrayList):
            return "ArrayList"

        if isinstance(obj1,int):
            return "int"
        if isinstance(obj1,float):
            return "float"
        if isinstance(obj1,str):
            return "str"
        
        return ""
    
    def to_json1(obj1):
    
        json_str1:str=""
        if isinstance(obj1,Dictionary):
            dict_obj1:Dictionary=obj1
            
            if json_str1!="":
                json_str1+=","
                

            for key_ind1 in range(0,dict_obj1.count):
                key_str:str=dict_obj1.keys[key_ind1]
                if json_str1!="":
                    json_str1+=","
                json_str1+="\""+str(key_str)+"\":"
                json_str1+=CJson1.to_json1(dict_obj1[key_str])
                if json_str1!="":
                    json_str1+=","
                json_str1+="\""+str(key_str)+"_type1\":\""+CJson1.get_type_of_var1(dict_obj1[key_str])+"\""
                
            json_str1="{"+json_str1+"}"
            
        if isinstance(obj1,ArrayList):
            arr_obj1:ArrayList=obj1

            for ind1 in range(0,arr_obj1.count):

                if json_str1!="":
                    json_str1+=","
                    
                json_str1+=CJson1.to_json1(arr_obj1[ind1])

            json_str1="["+json_str1+"]"
            d1=1

        if isinstance(obj1,float):
            float_obj1:float=obj1
            json_str1+=str(float_obj1)
            
        if isinstance(obj1,int):
            int_obj1:int=obj1
            json_str1+=str(int_obj1)
            
        if isinstance(obj1,str):
            str_obj1:str=obj1
            json_str1+="\""+str(str_obj1)+"\""
            
        return json_str1

    
            
            
    
    def json_to_obj1(json_str1):
        d1=1
        json_obj1=json.loads(json_str1)
        json_dict_obj1=None
        if not (json_str1[0:1]=="[" or json_str1[0:1]=="{"):
            return json_str1
        if isinstance(json_obj1,dict):
            json_dict_obj1=Dictionary()


        if isinstance(json_obj1,list):
            json_dict_obj1=ArrayList()
            for ind1 in range(0,len(list(json_obj1))+1):
                try:
                    str_arr1:str=json.dumps(ast.literal_eval(str(json_obj1[ind1])))
                    json_dict_obj1.Add(CJson1.json_to_obj1(str_arr1))
                except:
                    return json_dict_obj1
                    


        
        while len(json_obj1.keys())>0:
            key_str1=list(json_obj1.keys())[0]
            if not key_str1+"_type1" in json_obj1:
                key_str1=list(json_obj1.keys())[1]

            if key_str1+"_type1" in json_obj1:
                obj_type1=json_obj1[key_str1+"_type1"]
                
                if obj_type1=="Dictionary":
                    dict_obj1:Dictionary=Dictionary()

                if obj_type1=="ArrayList":
                    str_arr1:str=json.dumps(ast.literal_eval(str(json_obj1[key_str1])))
                    dict_obj1:ArrayList=CJson1.json_to_obj1(str_arr1)
                
                if obj_type1=="int":
                    json_dict_obj1[key_str1]=int(json_obj1[key_str1])
                
                
                if obj_type1=="float":
                    json_dict_obj1[key_str1]=float(json_obj1[key_str1])
                    
                del json_obj1[key_str1+"_type1"]
                del json_obj1[key_str1]
                
        return json_obj1
