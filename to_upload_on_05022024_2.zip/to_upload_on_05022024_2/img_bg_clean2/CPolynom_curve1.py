from Dictionary import Dictionary
from CPolynom2 import CPolynom2
from CGlobals1 import CGlobals1
import json
import sys
import os
from bitmap import Bitmap
from ArrayList import ArrayList
import math
from vec_3d1 import vec_3d1
from point_3d1 import point_3d1
import inspect
from CConfig1 import CConfig1
from CMarkingFieldInImageUtils1 import CMarkingFieldInImageUtils1
from CFile1 import CFile1

class CPolynom_curve1:
    def __init__(self):
        
        
        
        self.suffix_path1 = "_find_turn_pixel1"
        self.init_poynom_obj1=CPolynom2()
        
        self.path_of_curve1=CGlobals1.global_path1+CGlobals1.form_obj1.file_name1[0:CGlobals1.form_obj1.file_name1.index("\\")]+"\\195768205504__A_frame4b.txt"
        


        self.assembly_part1:str = "front_frame1"
        
        self.curve_ind3=0


        self.force_compute_derivs1 = True




    def flip_horizontal_cords_xy1(self,cord_xy1, cord_xy2):
        arr1:ArrayList = ArrayList()
        arr1.Add(str(cord_xy1[0]) + "," + str(cord_xy1[1]) + "," + str(cord_xy1[2]))
        arr1.Add(str(cord_xy2[0]) + "," + str(cord_xy2[1]) + "," + str(cord_xy2[2]))





        flip_curve1:ArrayList = self.flip_curve_horizontal1(arr1)

        cord_xy1a = CGlobals1.get_double_cord_xy_in_pixels_arr2(flip_curve1, 0)
        cord_xy2a  = CGlobals1.get_double_cord_xy_in_pixels_arr2(flip_curve1, 1)

        dict_res_ret1:Dictionary = Dictionary()
        dict_res_ret1["cord_xy1"] = cord_xy1a
        dict_res_ret1["cord_xy2"] = cord_xy2a

        return dict_res_ret1







    def rotate_cords_xy1(self,cord_xy1, cord_xy2, angle1:float):
        arr1:ArrayList = ArrayList()
        arr1.Add(str(cord_xy1[0]) + "," + str(cord_xy1[1]) + "," + str(cord_xy1[2]))
        arr1.Add(str(cord_xy2[0]) + "," + str(cord_xy2[1]) + "," + str(cord_xy2[2]))



        vec_3d_obj1:vec_3d1 = vec_3d1()

        vec_3d_obj1.p1 = point_3d1()
        vec_3d_obj1.p1.x1 = cord_xy1[0]
        vec_3d_obj1.p1.y1 = cord_xy1[1]


        vec_3d_obj1.p2 = point_3d1()
        vec_3d_obj1.p2.x1 = cord_xy1[0]
        vec_3d_obj1.p2.y1 = cord_xy1[1]
        vec_3d_obj1.p2.z1 = -10

        rot_curve1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(arr1, vec_3d_obj1, angle1)

        cord_xy1a = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve1, 0)
        cord_xy2a = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve1, 1)

        dict_res_ret1:Dictionary = Dictionary()
        dict_res_ret1["cord_xy1"] = cord_xy1a
        dict_res_ret1["cord_xy2"] = cord_xy2a

        return dict_res_ret1

    



    def get_sqr_of_pixel1(self,cord_xy1, cord_xy2):
        # 0 1
        # 2 3
        if cord_xy1[0] > cord_xy2[0] and cord_xy1[1] > cord_xy2[1]:
            return 0
        elif cord_xy1[0] < cord_xy2[0] and cord_xy1[1] > cord_xy2[1]:
            return 1
        elif cord_xy1[0] > cord_xy2[0] and cord_xy1[1] < cord_xy2[1]:
            return 2
        elif cord_xy1[0] < cord_xy2[0] and cord_xy1[1] < cord_xy2[1]:
            return 3

        return -1








    def flip_curve_vertical1(self,curve_pxl_arr1:ArrayList):
        from CGlobals1 import CGlobals1
        dict_rect1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxl_arr1)
        min_x1:float = dict_rect1["min_x1"]
        max_x1:float = dict_rect1["max_x1"]
        min_y1:float = dict_rect1["min_y1"]
        max_y1:float = dict_rect1["max_y1"]

        center_x1:float = math.floor((min_x1 + max_x1) / 2)
        flip_curve1:ArrayList = ArrayList()

        first_cord_xy1a:ArrayList=ArrayList()
        first_cord_xy1a.arr = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxl_arr1, 0)
        for ind1 in range(0 , curve_pxl_arr1.count ):

            cord_xy1:float = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxl_arr1, ind1)
            new_x1:float = cord_xy1[0]
            if cord_xy1[0] > center_x1:
                new_x1 = center_x1 - math.abs(cord_xy1[0] - center_x1)
            elif cord_xy1[0] < center_x1:
                new_x1 = center_x1 + math.abs(cord_xy1[0] - center_x1)

            if cord_xy1.count == 3:
                flip_curve1.Add(str(new_x1) + "," + str(cord_xy1[1]) + "," + str(cord_xy1[2]))
            else:
                flip_curve1.Add(str(new_x1) + "," + str(cord_xy1[1]))


        return flip_curve1







    def find_45_degree_ind_from_curve_pxl_arr_by_long_seq_45_2(self,curve_pxls_arr1:ArrayList, start_ind1:int, dir1:int):

        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1


        dict_rect1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)




        vec_3d_obj1:vec_3d1 = vec_3d1()
        vec_3d_obj1.p1 = point_3d1()
        vec_3d_obj1.p1.x1 = (dict_rect1["min_x1"] + dict_rect1["max_x1"]) / 2
        vec_3d_obj1.p1.y1 = (dict_rect1["min_y1"] + dict_rect1["max_y1"]) / 2


        vec_3d_obj1.p2 = point_3d1()
        vec_3d_obj1.p2.x1 = (dict_rect1["min_x1"] + dict_rect1["max_x1"]) / 2
        vec_3d_obj1.p2.y1 = (dict_rect1["min_y1"] + dict_rect1["max_y1"]) / 2
        vec_3d_obj1.p2.z1 = -10


        bmp5a:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp5a, (24, 230, 50,0))
        bmp5a.SaveAs(path1 + "\\" + "degree_45_before_rot1.bmp")

        rot_curve_pxls_arr1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(curve_pxls_arr1, vec_3d_obj1, 45 * dir1)


        bmp5b:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(rot_curve_pxls_arr1, bmp5b, (24, 230, 50,0))
        bmp5b.SaveAs(path1 + "\\" + "degree_45_after_rot1.bmp")



        dict_rect2:Dictionary = CGlobals1.form_obj1.macros_obj1.find_double_rect_of_pixels_arr(rot_curve_pxls_arr1)

        cord_x1:float = 9999

        if dir1 == -1:
            cord_x1 = dict_rect2["min_x1"]
        elif dir1 == 1:
            cord_x1 = dict_rect2["max_x1"]

        first_ind1:int = -1
        last_ind1:int = -1

        for i1 in range( 0 , rot_curve_pxls_arr1.count ):
            if CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve_pxls_arr1, i1)[0] == cord_x1:
                if first_ind1 == -1:
                    first_ind1 = i1

                last_ind1 = i1

        bmp5:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(curve_pxls_arr1, bmp5, (24, 230, 50,0))


        CGlobals1.draw_sqr_around_pixels2(bmp5, CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1, first_ind1)[0], CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1, first_ind1)[1], 2, (140, 90, 70,0))
        CGlobals1.draw_sqr_around_pixels2(bmp5, CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1, last_ind1)[0], CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1, last_ind1)[1], 2, (190, 90, 70,0))
        bmp5.SaveAs(path1 + "\\" + "degree_45_1.bmp")


        dict_ret_res1:Dictionary = Dictionary()



        dict_ret_res1["first_ind_derivative_45"] = first_ind1
        dict_ret_res1["last_ind_derivative_45"] = last_ind1


        return dict_ret_res1





    def check_if_45_angle_is_ok(self,curve1:ArrayList, dict_res1:Dictionary):
        if dict_res1["first_ind_derivative_45"] == 0 and dict_res1["last_ind_derivative_45"] == 0 or dict_res1["first_ind_derivative_45"] == dict_res1["last_ind_derivative_45"]:
            return False

        if curve1.count - 1 == dict_res1["first_ind_derivative_45"] or curve1.count - 1 == dict_res1["last_ind_derivative_45"]:
            return False

        return True





    def create_curve_from_polynom1(self,polynom_obj1:CPolynom2, start_x1:float, end_x1:float, len_of_pixels1:int):
        curve_pixels_arr1:ArrayList = ArrayList()
        x_val1:float = start_x1

        add_to_x_val1:float = math.floor(x_val1 + 1) - x_val1
        add_to_x_val1 = 0
        step_x_val1:float = (end_x1 - start_x1) / len_of_pixels1
        x_ind1:int=0
        while x_ind1 <= len_of_pixels1:

            y_val1:float = polynom_obj1.get_y_val1(x_val1)
            curve_pixels_arr1.Add(str(float(x_val1 + add_to_x_val1)) + "," + str(float(y_val1)))
            x_val1 += step_x_val1
            x_ind1 += 1

        return curve_pixels_arr1






    def cut_slice_of_curve_lens1(self):

        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        path_of_curves_inds1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_indexes_ranges1\\"
        CFile1.create_directory(path_of_curves_inds1)
        #todo self.set_cur_path_of_curve1()








        frame_pixels_arr1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(self.path_of_curve1)


        bmp5:Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, (255, 255, 255,0))

        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, (24, 230, 50,0))
        bmp5.SaveAsave(path1 + "\\" + "frame4a.bmp")

        dict_rect_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)


        min_x_top1:int = -1
        max_x_top1:int = -1


        min_x_bottom1:int = -1
        max_x_bottom1:int = -1


        min_y_left1:int = -1
        max_y_left1:int = -1


        min_y_right1:int = -1
        max_y_right1:int= -1



        min_x_top_ind1:int = -1
        max_x_top_ind1:int = -1


        min_x_bottom_ind1:int = -1
        max_x_bottom_ind1:int = -1


        min_y_left_ind1:int = -1
        max_y_left_ind1:int = -1


        min_y_right_ind1:int = -1
        max_y_right_ind1:int = -1



        for i1 in range(0 , frame_pixels_arr1.count ):
            cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(frame_pixels_arr1, i1)
            if int(cord_xy1[1]) == dict_rect_frame1["min_y1"]:
                if min_x_top1 == -1 or min_x_top1 > int(cord_xy1[0]):
                    min_x_top1 = int(cord_xy1[0])

                if max_x_top1 == -1 or max_x_top1 < int(cord_xy1[0]):
                    max_x_top1 = int(cord_xy1[0])


                if min_x_top_ind1 == -1 :
                    min_x_top_ind1 = i1

                max_x_top_ind1 = i1

            if int(cord_xy1[1]) == dict_rect_frame1["max_y1"]:
                if min_x_bottom1 == -1 or min_x_bottom1 > int(cord_xy1[0]):
                    min_x_bottom1 = int(cord_xy1[0])


                if max_x_bottom1 == -1 or max_x_bottom1 < int(cord_xy1[0]):
                    max_x_bottom1 = int(cord_xy1[0])


                if min_x_bottom_ind1 == -1:
                    min_x_bottom_ind1 = i1

                max_x_bottom_ind1 = i1



            if int(cord_xy1[0]) == dict_rect_frame1["min_x1"]:
                if min_y_left1 == -1 or min_y_left1 > int(cord_xy1[1]):
                    min_y_left1 = int(cord_xy1[1])

                if max_y_left1 == -1 or max_y_left1 < int(cord_xy1[1]):
                    max_y_left1 = int(cord_xy1[0])


                if min_y_left_ind1 == -1:
                    min_y_left_ind1 = i1

                max_y_left_ind1 = i1


            if str(cord_xy1[0]) == dict_rect_frame1["max_x1"]:
                if min_y_right1 == -1 or min_y_right1 > int(cord_xy1[1]):
                    min_y_right1 == int(cord_xy1[1])

                if max_y_right1 == -1 or max_y_right1 < int(cord_xy1[1]):
                    max_y_right1 = int(cord_xy1[0])


                if min_y_right_ind1 == -1:
                    min_y_right_ind1 = i1

                max_y_right_ind1 = i1



        for i1 in range( 0 , frame_pixels_arr1.count ):
            cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(frame_pixels_arr1, i1)
            if i1 >= min_x_top_ind1 and i1 <= max_x_top_ind1:

                frame_pixels_arr1[i1] = str(cord_xy1[0]) + "," + str(dict_rect_frame1["min_y1"])

            if i1 >= min_x_bottom_ind1 and i1 <= max_x_bottom_ind1:

                frame_pixels_arr1[i1] = str(cord_xy1[0]) + "," + str(dict_rect_frame1["max_y1"])


            if i1 >= min_y_left_ind1 and i1 <= max_y_left_ind1:
                frame_pixels_arr1[i1] = str(dict_rect_frame1["min_x1"]) + "," + str(int(cord_xy1[1]))


            if i1 >= min_y_right_ind1 and i1 <= max_y_right_ind1:

                frame_pixels_arr1[i1] = str(dict_rect_frame1["max_x1"]) + "," + str(int(cord_xy1[1]))



        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, (255, 255, 255,0))

        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, (24, 230, 50,0))
        bmp5.SaveAse(path1 + "\\" + "frame4a_fix1.bmp")

        path_of_result1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_zoom_" + str(self.curve_zoom1)
        if not CFile1.is_directory_exist(path_of_result1):
            CFile1.create_directory(path_of_result1)

        CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(path_of_result1 + "\\fixed_lens_curve1.txt", frame_pixels_arr1)


        vec_3d_obj2:vec_3d1 = vec_3d1()
        vec_3d_obj2.p1 = point_3d1()
        vec_3d_obj2.p1.x1 = (dict_rect_frame1["min_x1"] + dict_rect_frame1["max_x1"]) / 2
        vec_3d_obj2.p1.y1 = (dict_rect_frame1["min_y1"] + dict_rect_frame1["max_y1"]) / 2


        vec_3d_obj2.p2 = point_3d1()
        vec_3d_obj2.p2.x1 = (dict_rect_frame1["min_x1"] + dict_rect_frame1["max_x1"]) / 2
        vec_3d_obj2.p2.y1 = (dict_rect_frame1["min_y1"] + dict_rect_frame1["max_y1"]) / 2




        if self.suffix_path1 == "_lens_top_1_frame1" or self.suffix_path1 == "_lens_bottom_1_frame1" or self.suffix_path1 == "_lens_left_0_frame1" or suffix_path1 == "_lens_right_0_frame1" or self.suffix_path1 == "_lens_right_1_frame1" or self.suffix_path1 == "_lens_bottom_0_frame1":

            vec_3d_obj2.p2.z1 = -10
            if self.suffix_path1 == "_lens_left_0_frame1":
                frame_pixels_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(frame_pixels_arr1, vec_3d_obj2, 90)


            if self.suffix_path1 == "_lens_right_0_frame1":
                frame_pixels_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(frame_pixels_arr1, vec_3d_obj2, -90)


            if self.suffix_path1 == "_lens_top_1_frame1":
                frame_pixels_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(frame_pixels_arr1, vec_3d_obj2, -90)


            if self.suffix_path1 == "_lens_right_1_frame1" or self.suffix_path1 == "_lens_bottom_0_frame1":
                frame_pixels_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(frame_pixels_arr1, vec_3d_obj2, -180)


            if self.suffix_path1 == "_lens_bottom_1_frame1":
                frame_pixels_arr1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(frame_pixels_arr1, vec_3d_obj2, 90)



            bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, (255, 255, 255,0))

            CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, (24, 230, 50,0))
            bmp5.SaveAs(path1 + "\\" + "frame4b.bmp")


        dict_rect_frame1 = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)


        center_x1:int = int((dict_rect_frame1["min_x1"] + dict_rect_frame1["max_x1"]) / 2)

        ind1:int = 0

        while CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind1)[0] > dict_rect_frame1["min_x1"]:
            ind1 -= 1
            if ind1 < 0:
                ind1 = frame_pixels_arr1.count - 1

        ind1a:int = ind1

        while CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind1a)[0] == dict_rect_frame1["min_x1"]:
            ind1a -= 1
            if ind1a < 0:
                ind1a = frame_pixels_arr1.count - 1



        ind2:int = ind1

        while CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind2)[1] > dict_rect_frame1["min_y1"]:
            ind2 += 1
            if ind2 >= frame_pixels_arr1.count - 1:
                ind2 = 0



        ind2b:int = ind2

        while CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind2b)[1] == dict_rect_frame1["min_y1"]:
            ind2b += 1
            if ind2b >= frame_pixels_arr1.count - 1:
                ind2b = 0


        ind1c:int = int((ind1 + ind1a) / 2)
        ind2c:int = int((ind2 + ind2b) / 2)
        ind2c -= 1


        left_lens_frame1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind1c, ind2c)

        if CGlobals1.get_double_cord_xy_in_pixels_arr2(frame_pixels_arr1, 0)[1] < CGlobals1.get_double_cord_xy_in_pixels_arr2(frame_pixels_arr1, frame_pixels_arr1.Count - 1)[1]:
            left_lens_frame1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind1c, ind2c)

        bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(left_lens_frame1, bmp5, (24, 230, 50,0))

        bmp5.SaveAs(path1 + "\\" + "frame4b_cut1.bmp")




        if CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1, 0)[1] > CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1, left_lens_frame1.Count - 1)[1]:
            left_lens_frame1.Reverse()

        dict_res1:Dictionary  = self.find_45_degree_ind_from_curve_pxl_arr_by_long_seq_45_2(left_lens_frame1, left_lens_frame1.count - 1, -1)



        first_ind_derivative_45_1:int = dict_res1["first_ind_derivative_45"]
        last_ind_derivative_45_1:int = dict_res1["last_ind_derivative_45"]

        left_pxl_ind1:int = int((first_ind_derivative_45_1 + last_ind_derivative_45_1) / 2)



        ind_of_45_1:int = ind2c - left_pxl_ind1

        if CGlobals1.form_obj1.curve_ind1 % 2 == 0:
            ind_of_45_1 += 1

        if CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind1c)[1] < CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind2c)[1]:
            ind_of_45_1 = ind1c - left_pxl_ind1

        cord_xy_45_deg_1 = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind_of_45_1)
        bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(frame_pixels_arr1, bmp5, (24, 230, 50,0))
        CGlobals1.draw_sqr_around_pixels2(bmp5, cord_xy_45_deg_1[0], cord_xy_45_deg_1[1], 2, (124, 230, 50,0))


        bmp5.SaveAs(path1 + "\\" + "frame_deg_45_1.bmp")


        if self.suffix_path1 == "_lens_left_1_frame1" or self.suffix_path1 == "_lens_top_1_frame1" or self.suffix_path1 == "_lens_right_1_frame1" or self.suffix_path1 == "_lens_bottom_1_frame1":

            left_lens_frame1b:ArrayList=None
            left_lens_frame1b = CGlobals1.get_arr_from_ind_to_ind1(left_lens_frame1, left_pxl_ind1, left_lens_frame1.count - 1)

            dict_res_inds1:Dictionary = check_and_fix_curves_inds1(path_of_curves_inds1, ind1c, ind_of_45_1)
            ind1c = dict_res_inds1["start_ind1"]
            ind_of_45_1 = dict_res_inds1["end_ind1"]
            left_lens_frame1c:ArrayList
            left_lens_frame1c = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind1c, ind_of_45_1)
            left_lens_frame1c.Reverse()

            if not dict_res_inds1.ContainsKey("no_save1"):
                 CFile1.write_all_text_to_file( "1",path_of_curves_inds1 + CGlobals1.form_obj1.curve_ind1.ToString() + "_" + ind1c.ToString() + "_" + ind_of_45_1.ToString() + ".ind")



            left_lens_frame1b = left_lens_frame1c
            if CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1, 0)[0] < CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1, left_lens_frame1b.Count - 1)[0]:
                left_lens_frame1b = CGlobals1.get_arr_from_ind_to_ind1(left_lens_frame1, 0, left_pxl_ind1)


            bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(left_lens_frame1b, bmp5, (24, 230, 50,0))

            bmp5.SaveAsave(path1 + "\\" + "frame4d_curve1.bmp")

            vec_3d_obj1:vec_3d1 = vec_3d1()
            vec_3d_obj1.p1 = point_3d1()
            vec_3d_obj1.p1.x1 = CGlobals1.get_cord_xy_in_pixels_arr1(left_lens_frame1b, 0)[0]
            vec_3d_obj1.p1.y1 = CGlobals1.get_cord_xy_in_pixels_arr1(left_lens_frame1b, 0)[1]


            vec_3d_obj1.p2 = point_3d1()
            vec_3d_obj1.p2.x1 = CGlobals1.get_cord_xy_in_pixels_arr1(left_lens_frame1b, 0)[0]
            vec_3d_obj1.p2.y1 = CGlobals1.get_cord_xy_in_pixels_arr1(left_lens_frame1b, 0)[1]
            vec_3d_obj1.p2.z1 = -10


            left_lens_frame1b = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(left_lens_frame1b, vec_3d_obj1, 90)
            left_lens_frame1b = self.flip_curve_vertical1(left_lens_frame1b)


            if CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1b, 0)[0] > CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1b, left_lens_frame1b.count - 1)[0]:
                left_lens_frame1b.Reverse()

            if CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1c, 0)[0] > CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1c, left_lens_frame1c.Count - 1)[0]:
                left_lens_frame1c.Reverse()


            bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(left_lens_frame1b, bmp5, (24, 230, 50,0))

            bmp5.SaveAsave(path1 + "\\" + "frame4d.bmp")

            CFile1.write_all_text_to_file( str(ind_of_45_1),path1 + "\ind_of_start_45_deg1.txt")
            return left_lens_frame1b

        if self.suffix_path1 == "_lens_top_0_frame1" or self.suffix_path1 == "_lens_left_0_frame1" or self.suffix_path1 == "_lens_right_0_frame1" or self.suffix_path1 == "_lens_bottom_0_frame1":
            left_lens_frame1a:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(left_lens_frame1, 0, left_pxl_ind1)

            dict_res_inds1:Dictionary #todo= self.check_and_fix_curves_inds1(path_of_curves_inds1, ind_of_45_1, ind2c)

            ind_of_45_1 = dict_res_inds1["start_ind1"]
            ind2c = dict_res_inds1["end_ind1"]
            left_lens_frame1c:ArrayList=None
            left_lens_frame1c = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind_of_45_1, ind2c)
            left_lens_frame1c.Reverse()
            left_lens_frame1a = left_lens_frame1c
            if not dict_res_inds1.ContainsKey("no_save1"):
                CFile1.write_all_text_to_file( "1",path_of_curves_inds1 + str(CGlobals1.form_obj1.curve_ind1) + "_" + str(ind_of_45_1) + "_" + str(ind2c) + ".ind")



            if CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1, 0)[0] < CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1, left_lens_frame1.Count - 1)[0]:
                left_lens_frame1a = CGlobals1.get_arr_from_ind_to_ind1(left_lens_frame1, left_pxl_ind1, left_lens_frame1.count - 1)


            if CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1a, 0)[0] > CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1a, left_lens_frame1a.count - 1)[0]:
                left_lens_frame1a.Reverse()


            if CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1c, 0)[0] > CGlobals1.get_double_cord_xy_in_pixels_arr2(left_lens_frame1c, left_lens_frame1c.count - 1)[0]:
                left_lens_frame1c.Reverse()


            bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(left_lens_frame1a, bmp5, (24, 230, 50,0))

            bmp5.SaveAs(path1 + "\\" + "frame4e.bmp")

            CFile1.write_all_text_to_file(str(ind_of_45_1),path1 + "\ind_of_start_45_deg1.txt")
            return left_lens_frame1a
        
        






    def get_polinom_size1(self,polynom_results_arr1:ArrayList,max_polynom_index1int=-1):





        if max_polynom_index1 == -1:
            max_polynom_index1 = polynom_results_arr1.count - 1

        total_height1:float = 0
        total_width1:float = 0
        for i1 in range(0 , max_polynom_index1+1):
            polynom_obj1:CPolynom2 = CPolynom2()
            polynom_obj1 = polynom_results_arr1[i1]["polynom_obj1"]
            total_height1 += (abs(polynom_obj1.get_y_val1(float(polynom_results_arr1[i1]["start_x_val1"]))) - abs(polynom_obj1.get_y_val1(Double.Parse(polynom_results_arr1[i1]["end_x_val1"]))))
            total_width1 += (abs(float(polynom_results_arr1[i1]["start_x_val1"])) - abs(float(polynom_results_arr1[i1]["end_x_val1"])))

        dict_res1:Dictionary = Dictionary()

        dict_res1["total_height1"] = total_height1
        dict_res1["total_width1"] = total_width1


        return dict_res1

    def get_polinom_size2(self,polynom_results_arr1:ArrayList,start_polynom_index1:int = -1,  max_polynom_index1:int = -1):




        if max_polynom_index1 == -1:
            max_polynom_index1 = polynom_results_arr1.count - 1

        if start_polynom_index1 == -1:
            start_polynom_index1 = 0

        total_height1:float = 0
        total_width1:float = 0
        for i1 in range(start_polynom_index1 , max_polynom_index1+1):
            polynom_obj1:CPolynom2 = CPolynom2()
            polynom_obj1 = polynom_results_arr1[i1]["polynom_obj1"]
            total_height1 += (abs(polynom_obj1.get_y_val1(float(polynom_results_arr1[i1]["start_x_val1"]))) - abs(polynom_obj1.get_y_val1(float(polynom_results_arr1[i1]["end_x_val1"]))))
            total_width1 += (abs(float(polynom_results_arr1[i1]["start_x_val1"])) - abs(float(polynom_results_arr1[i1]["end_x_val1"])))


        dict_res1:Dictionary = Dictionary()

        dict_res1["total_height1"] = total_height1
        dict_res1["total_width1"] = total_width1


        return dict_res1







    def move_left_botton_curve_to_cord_xy1(self,curve_arr1:ArrayList, left_botton_cord_xy1):
        from CGlobals1 import CGlobals1
        dict_rect1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_arr1)

        new_curve_pxl_arr1:ArrayList = ArrayList()
        

        for i1 in range(0 , curve_arr1.count):
            cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_arr1, i1)
            new_x_val1:float = cord_xy1[0] - dict_rect1["min_x1"] + left_botton_cord_xy1[0]
            new_y_val1:float = cord_xy1[1] - dict_rect1["max_y1"] + left_botton_cord_xy1[1]
            new_curve_pxl_arr1.Add(str(new_x_val1) + "," + str(new_y_val1))

        return new_curve_pxl_arr1







    def rotate_curve_vertical1(self,curve_arr1:ArrayList):
        from CGlobals1 import CGlobals1
        
        dict_rect1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_arr1)
        new_curve_pxl_arr1:ArrayList = ArrayList()

        for i1 in range(0 , curve_arr1.count):
            cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_arr1, i1)
            new_x_val1:float = dict_rect1["max_x1"] - cord_xy1[0] + dict_rect1["min_x1"]
            new_curve_pxl_arr1.Add(str(new_x_val1) + "," + str(cord_xy1[1]))

        return new_curve_pxl_arr1
    
    



    def find_polynom_coefs1(self,init_polynom1:CPolynom2, start_derivative1:float, end_derivative1:float, curve_pxls_arr1:ArrayList, search_mode1:str, dict_prms1:Dictionary):



        log_str1:StringBuilder = StringBuilder()

        last_dict_return_res1:Dictionary()


        height_to_complete1:float = -9999
        width_to_complete1:float = -9999




        if polynom_result_arr1.count > 0:

            #todo dict_res_size1:Dictionary = get_polinom_size1(polynom_result_arr1)
            total_org_height1:float= float(curve_pxls_arr1[0].Split(",")[1]) - float(curve_pxls_arr1[polynom_result_arr1[polynom_result_arr1.count - 1]["last_ind1"]].Split(",")[1])


            cur_height1:float = float(curve_pxls_arr1[0].Split(",")[1]) - float(curve_pxls_arr1[curve_pxls_arr1.count - 1].Split(",")[1])

            if polynom_result_arr1.count - 2 + 1 == last_go_back_ind1 and last_go_back_ind1 > 0:

                total_org_width1:float = float(curve_pxls_arr1[0].Split(",")[0]) - float(curve_pxls_arr1[curve_pxls_arr1.count - 1].Split(",")[0])

                height_to_complete1 = total_org_height1 - dict_res_size1["total_height1"]
                width_to_complete1 = abs(total_org_width1) - abs(dict_res_size1["total_width1"])


        min_add_coef_factor1:float = math.pow(10, -15)

        local_max_loop_count1:int = max_loop_count1

        mode_exp1:str = "mode1"


        if mode_exp1 == "mode1":

            if self.mode_fix_last_pxl1:

                min_add_coef_factor1 = math.pow(10, -15)
                min_min_diff_h1 = math.pow(10, -12)


        if dict_prms1.ContainsKey("max_loop_count1"):
            local_max_loop_count1 = dict_prms1["max_loop_count1"]

        
        dict_rect1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)

        width_of_curve1:float = abs(dict_rect1["max_x1"] - dict_rect1["min_x1"])

        height_of_curve1:float = abs(dict_rect1["max_y1"] - dict_rect1["min_y1"])
        org_height_of_curve1:float = height_of_curve1
        div_last_delta_min_diff_h2:float = 9999

        arr_div_last_delta_min_diff_h2:ArrayList = ArrayList()
        add_height_to_curve1_temp1:float = 0
        if dict_prms1.ContainsKey("add_height_to_curve1"):
            add_height_to_curve1_temp1 = dict_prms1["add_height_to_curve1"]

            log_str1.Append("#add_height_to_curve1=" + str(dict_prms1["add_height_to_curve1"]) + "#")


        add_width_to_curve1_temp1:float=0
        if dict_prms1.ContainsKey("add_width_to_curve1"):
            add_width_to_curve1_temp1 = dict_prms1["add_width_to_curve1"]
            log_str1.Append("#add_width_to_curve1=" + str(dict_prms1["add_width_to_curve1"]) + "#")


        if self.last_go_back_ind1 != -1:
            #todo dict_prms1 = CGlobals1.json_to_dict_prms1(dict_prms1_arr2[polynom_result_arr1.count])


            self.start_derivative1 = self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["end_derivative1"]
        else:
            if self.polynom_result_arr1.count > 0:
                self.start_derivative1 = self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["end_derivative1"]

        if polynom_result_arr1.count > 0:
            dict_prms1["last_delta_height1"] = self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["min_diff_h1"]

 


        dict_prms1["add_height_to_curve1"] = add_height_to_curve1_temp1
        dict_prms1["add_width_to_curve1"] = add_width_to_curve1_temp1
        height_of_curve1 -= dict_prms1["last_delta_height1"]
        height_of_curve1 -= dict_prms1["last_add_height1"]


        log_str1.Append("#last_delta_height1=" + str(dict_prms1["last_delta_height1"]) + "#")
        log_str1.Append("#last_add_height1=" + str(dict_prms1["last_add_height1"]) + "#")
        height_before_change1:float = height_of_curve1
        if dict_prms1.ContainsKey("add_height_to_curve1"):
            height_of_curve1 += dict_prms1("add_height_to_curve1")

        log_str1.Append("#add_height_to_curve1=" + str(dict_prms1["add_height_to_curve1"]) + "#")

        if last_go_back_ind1 != -1:
            height_before_change1 = height_of_curve1

        if dict_prms1.ContainsKey("add_curve_height1"):
            height_of_curve1 += dict_prms1["add_curve_height1"]



        if dict_prms1.ContainsKey("add_width_to_curve1"):
            width_of_curve1 += dict_prms1["add_width_to_curve1"]


        height_of_curve_dest1:float = height_of_curve1
        if self.polynom_result_arr1.count > 0:

            #todo dict_poly_size1:Dictionary = self.get_polinom_size1(self.polynom_result_arr1)
            total_org_height1a:float = float(str(curve_pxls_arr1[0]).Split(",")[1]) - float(curve_pxls_arr1[self.polynom_result_arr1[polynom_result_arr1.count - 1]["last_ind1"].Split(",")[1]])


            cur_height1a:float = float(curve_pxls_arr1[0].Split(",")[1]) - float(curve_pxls_arr1[curve_pxls_arr1.count - 1].Split(",")[1])



        start_ind2:int = start_ind1
        if dict_prms1.ContainsKey("start_ind1") and self.last_go_back_ind1 != -1:
            start_ind2 = dict_prms1["start_ind1"]
        else:
            dict_prms1["start_ind1"] = start_ind1

        last_ind2:int = last_ind1

        if dict_prms1.ContainsKey("last_ind1") and self.last_go_back_ind1 != -1:
            last_ind2 = dict_prms1["last_ind1"]
        else:
            dict_prms1["last_ind1"] = last_ind1


        #todo last_dict_prms_str2 = CGlobals1.dict_prm_to_json_str(dict_prms1)




        init_polynom1.coef_arr1[1] = height_of_curve1 / width_of_curve1 * self.factor_div_prop1
        log_str1.Append("height_of_curve1=" + str(height_of_curve1))
        log_str1.Append("width_of_curve1=" + str(width_of_curve1))
        log_str1.Append("factor_div_prop1=" + str(factor_div_prop1))


        while init_polynom1.coef_arr1[1] > start_derivative1:
            init_polynom1.coef_arr1[1] /= 10

        log_str1.Append("start_derivative1=" + str(start_derivative1))
        log_str1.Append("last_derivate1=" + str(last_derivate1))

        log_str1.Append("init_polynom1.coef_arr1(1)=" + str(init_polynom1.coef_arr1[1]))
        init_polynom1.coef_arr1[2] = start_coef1
        init_polynom1.coef_arr1[3] = start_coef1

        add_coef_factor1:float = 0.1

        coef_ind1:int
        coef_ind2:int
        coef_ind3:int
        coef_ind4:int



        polynoms_res_arr1:ArrayList = ArrayList()

        coef_add_arr1 = [0, 0, 0, 0]
        min_dist_height1:float = 9999999
        min_dist_height2:float = 9999999

        min_dist_height_ind1:int = -1
        min_dist_from_curve1:float = 999999
        polynom_ind1:int = 0
        not_to_stop1:bool=True   
        loop_ind1:int = 0

        last_end_x_polynom1:float = 99

        max_end_x_val1:float = -1
        status1:str=""
        min_dist_diff_height1:float = 999
        min_diff_start_x_val1:float = 999
        padd_start_x_val1:float = 5
        last_min_diff_h1:float = -1
        last_delta_min_diff_h1:float = -1
        last_delta_min_diff_h2:float = 9999
        min_last_diff_h1_and_last_deriv1:float = 9999

        min_last_derivative1:float = 9999

        polynoms_res_arr1 = ArrayList()

        poly_ind1:int

        polynoms_arr1:ArrayList = ArrayList()
        for poly_ind1 in range( 0 , 81+1):
            polynoms_arr1.Add(init_polynom1.clone1())

        create_polynom_objs_count1:int = 0
        org_int_poly1:CPolynom2 = init_polynom1.clone1()
        #todo CGlobals1.add_to_txt_log1("start_find_polynom_coeafs1")

        last_end_x_val1:float = 0
        while not_to_stop1:
            polynoms_res_arr1 = ArrayList()
            min_dist_height_ind1 = -1
            polynom_ind1 = 0
            loop_ind1 += 1


            for coef_ind1 in range(-1 , 1+1):
                for coef_ind2 in range(-1 , 1+1):
                    for coef_ind3 in range(-1 , 1+1):
                        for coef_ind4 in range(-1 , 1+1):

                            polynom_obj1:CPolynom2

                            polynom_obj1 = init_polynom1.clone1()
                            create_polynom_objs_count1 += 1




                            coef_i1:int
                            coef_add_arr1[0] = 0
                            coef_add_arr1[1] = coef_ind2
                            coef_add_arr1[2] = coef_ind3
                            coef_add_arr1[3] = coef_ind4
                            min_coef_val1:float = math.pow(10, -15)
                            is_ok_coefs1:bool = True 
                            for coef_i1 in range(0 , 3+1):
                                polynom_obj1.coef_arr1[coef_i1] = init_polynom1.coef_arr1[coef_i1]


                            for coef_i1 in range( 0 , 3+1):
                                polynom_obj1.coef_arr1[coef_i1] += add_coef_factor1 * coef_add_arr1[coef_i1]
                                if polynom_obj1.coef_arr1[coef_i1] < min_coef_val1 and coef_i1 >= 1:
                                    is_ok_coefs1 = False

                            if is_ok_coefs1:
                                max_dist_from_curve1:float = -1

                                polynom_obj1.create_derivative1()
                                height1:float
                                start_x_val1:float
                                end_x_val1:float

                                end_y1:float
                                start_y1:float

                                if search_mode1 == "search_by_min_end_derivate1":
                                    polynom_obj1.get_derivative1(end_derivative1)

                                if search_mode1 == "only_end_derivate1":
                                    end_x_val1 = polynom_obj1.find_x_by_derivative_val(end_derivative1)
                                    end_y1 = polynom_obj1.get_y_val1(end_x_val1)
                                    start_y1 = polynom_obj1.get_y_val1(end_x_val1 + width_of_curve1)
                                    height1 = math.abs(end_y1 - start_y1)


                                if search_mode1 == "only_start_derivate1":
                                    temp_end_x_val1:float = end_x_val1
                                    end_x_val1a:float = polynom_obj1.find_x_by_derivative_val2(start_derivative1, last_end_x_val1)
                                    end_x_val1 = end_x_val1a
                                    
                                    end_x_val1 = end_x_val1a
                                    if end_x_val1 != CPolynom2.max_end_x_val1:
                                        last_end_x_val1 = end_x_val1

                                    start_y1 = polynom_obj1.get_y_val1(end_x_val1)
                                    end_y1 = polynom_obj1.get_y_val1(end_x_val1 - width_of_curve1)
                                    height1 = math.abs(end_y1 - start_y1)

                                    if max_end_x_val1 == -1:
                                        max_end_x_val1 = math.abs(end_x_val1)
                                    else:
                                        if max_end_x_val1 < math.abs(end_x_val1):
                                            max_end_x_val1 = math.abs(end_x_val1)


                                if search_mode1 == "only_start_derivate_minus1":
                                    end_x_val1 = polynom_obj1.find_x_by_derivative_val(start_derivative1)
                                    start_y1 = polynom_obj1.get_y_val1(end_x_val1)
                                    end_y1 = polynom_obj1.get_y_val1(end_x_val1 + width_of_curve1)
                                    height1 = math.abs(end_y1 - start_y1)

                                    if max_end_x_val1 == -1:
                                        max_end_x_val1 = math.abs(end_x_val1)
                                    else:
                                        if max_end_x_val1 < math.abs(end_x_val1):
                                            max_end_x_val1 = math.abs(end_x_val1)



                                if search_mode1 == "find_start_x_val_more_then_width1":
                                    start_x_val1 = polynom_obj1.find_x_by_derivative_val(start_derivative1)
                                    start_y1 = polynom_obj1.get_y_val1(end_x_val1)
                                    end_y1 = polynom_obj1.get_y_val1(end_x_val1 - width_of_curve1)
                                    height1 = math.abs(end_y1 - start_y1)
                                    diff_width1:float = math.abs(start_x_val1 - padd_start_x_val1 - width_of_curve1)
                                    if min_diff_start_x_val1 > diff_width1:
                                        min_diff_start_x_val1 = diff_width1
                                        min_dist_height_ind1 = polynom_ind1


                                if search_mode1 == "only_end_derivate1" or search_mode1 == "only_start_derivate1" or search_mode1 == "only_start_derivate_minus1":

                                    dist_diff1:float = math.abs(height1 - height_of_curve1)

                                    if polynom_result_arr1.count - 1 == self.last_go_back_ind1 and self.mode_fix_last_pxl1 and self.search_by_zero_last_derivate1:

                                        end_derivative3:float = polynom_obj1.get_derivative1(math.abs(end_x_val1) - width_of_curve1)
                                        if min_last_derivative1 > math.abs(end_derivative3):

                                            min_last_derivative1 = Math.Abs(end_derivative3)

                                        dist_diff1 = math.abs(height1 - height_of_curve1) + math.abs(math.abs(end_derivative3) - math.abs(self.fix_last_derivative_of_curve1))

                                    dist_diff2:float = height1 - height_of_curve1
                                    if math.abs(end_x_val1) < 150000 and (math.abs(end_x_val1) > math.abs(width_of_curve1) or search_mode1 == "only_start_derivate_minus1"):
                                        end_derivate_val1:float = -1

                                        if search_mode1 == "only_end_derivate1":
                                            org_curve1:ArrayList = dict_prms1["org_curve1"]
                                            end_pixel_ind1:Integer = dict_prms1["end_pixel_ind1"]
                                            end_derivate_val1 = polynom_obj1.get_derivative1(end_x_val1)


                                            #todo max_dist_from_curve1 = self.check_curve_with_m1(org_curve1, end_pixel_ind1, end_pixel_ind1 + width_of_curve1, end_pixel_ind1, (end_x_val1 - start_x_val1) / width_of_curve1, end_derivate_val1)


                                        if min_dist_height_ind1 == -1:
                                            if min_dist_height1 > dist_diff1 and (min_dist_from_curve1 > max_dist_from_curve1 or max_dist_from_curve1 <= 0.2):
                                                min_dist_height_ind1 = polynom_ind1
                                                min_dist_diff_height1 = height1 - height_of_curve1
                                                min_dist_from_curve1 = max_dist_from_curve1
                                        else:
                                            if min_dist_height1 > dist_diff1 and (min_dist_from_curve1 > max_dist_from_curve1 or max_dist_from_curve1 <= 0.2):
                                                min_dist_height1 = dist_diff1
                                                min_dist_height2 = dist_diff2
                                                min_dist_height_ind1 = polynom_ind1
                                                min_dist_diff_height1 = height1 - height_of_curve1
                                                min_dist_from_curve1 = max_dist_from_curve1
                                            
                                
                                if end_x_val1 >= width_of_curve1:

                                    polynom_ind1 += 1

                                    dict_polynom_res1:Dictionary


                                    dict_polynom_res1 = Dictionary()

                                    dict_polynom_res1["polynom_obj1"] = polynom_obj1
                                    dict_polynom_res1["min_dist_height1"] = min_dist_height1
                                    dict_polynom_res1["min_dist_height2"] = min_dist_height2
                                    dict_polynom_res1["end_x_val1"] = end_x_val1
                                    dict_polynom_res1["end_y1"] = end_y1
                                    dict_polynom_res1["start_y1"] = start_y1
                                    dict_polynom_res1["max_dist_from_curve1"] = max_dist_from_curve1

                                    polynoms_res_arr1.Add(dict_polynom_res1)
                                    #todo if log_str1.Length < 2000
                                        #todo log_str1.Append(polynom_obj1.get_polynom_vals_str1() "\r\n")

                                

            lop_step1:str=""
            log_str1.Append("#" + str(min_dist_height_ind1) + "#")

            if min_dist_height_ind1 != -1:
                lop_step1 += "step1,"

                dict_polynom_res2:Dictionary = polynoms_res_arr1[min_dist_height_ind1]

                log_str1.Append("#min_dist_height1(" + str(loop_ind1) + ")=" + str(dict_polynom_res2["min_dist_height1"]) + "#")
                log_str1.Append("#min_dist_height2(" + str(loop_ind1) + ")=" + str(dict_polynom_res2["min_dist_height2"]) + "#")


                init_polynom1 = dict_polynom_res2["polynom_obj1"]
                if search_mode1 == "find_start_x_val_more_then_width1":
                    if min_diff_start_x_val1 < math.pow(10, -10):
                        not_to_stop1 = False
                        dict_retutn_res1:Dictionary = Dictionary()
                        dict_retutn_res1["polynom_obj1"] = init_polynom1
                        return dict_retutn_res1
                else:

                    min_diff_h1:float = dict_polynom_res2["min_dist_height1"]
                    min_diff_h2:float = dict_polynom_res2["min_dist_height2"]
                    if last_min_diff_h1 == -1:
                        last_min_diff_h1 = min_diff_h1


                    delta_min_diff_h1:float = math.abs(last_min_diff_h1 - min_diff_h1)

                    last_delta_min_diff_h1 = math.abs(last_min_diff_h1 - min_diff_h1)

                    if last_delta_min_diff_h2 > last_delta_min_diff_h1 and last_delta_min_diff_h1 > 0:
                        div_last_delta_min_diff_h2 = math.abs(last_delta_min_diff_h1 / last_delta_min_diff_h2)
                        arr_div_last_delta_min_diff_h2.Add(div_last_delta_min_diff_h2)
                        last_delta_min_diff_h2 = last_delta_min_diff_h1


                    ok_end_derivative2:str = ""
                    end_derivative3:float = init_polynom1.get_derivative1(dict_polynom_res2["end_x_val1"] - width_of_curve1)


                    last_good_derivative_res1:bool=True  
                    if self.mode_fix_last_pxl1:
                        if self.polynom_result_arr1.count - 1 == self.last_go_back_ind1:
                            if end_derivative3 <= math.pow(10, -7):
                                last_good_derivative_res1 = True
                            else:
                                last_good_derivative_res1 = False

                    to_save_result1:bool=True
                    if self.polynom_result_arr1.count - 1 == self.last_go_back_ind1 and self.mode_fix_last_pxl1:
                        lop_step1 += "step2,"

                        if min_last_derivative1 > math.abs(end_derivative3):

                            min_last_derivative1 = math.abs(end_derivative3)

                        to_save_result1 = True
                        if min_last_diff_h1_and_last_deriv1 == 9999:
                            min_last_diff_h1_and_last_deriv1 = math.abs(min_diff_h1) + math.abs(end_derivative3)
                            to_save_result1 = True   
                        else:
                            if min_last_diff_h1_and_last_deriv1 > math.abs(min_diff_h1) + math.abs(end_derivative3):
                                min_last_diff_h1_and_last_deriv1 = math.abs(min_diff_h1) + math.abs(end_derivative3)
                                to_save_result1 = True

                    if to_save_result1 and (math.abs(min_diff_h1) < 1 or self.mode_fix_last_pixel1):

                        lop_step1 += "step3,"


                        polynom_curve1a:ArrayList
                        last_x_val2a:float = -999
                        if search_mode1 == "only_start_derivate1":
                            #todo polynom_curve1a = self.create_curve_from_polynom1(init_polynom1, dict_polynom_res2["end_x_val1"] - width_of_curve1, dict_polynom_res2["end_x_val1"], width_of_curve1)
                            start_derivative1c:float = init_polynom1.get_derivative1(dict_polynom_res2["end_x_val1"])
                            last_x_val2a = dict_polynom_res2["end_x_val1"] - width_of_curve1
                        elif search_mode1 == "only_start_derivate_minus1":

                            #todo polynom_curve1a = self.create_curve_from_polynom1(init_polynom1, dict_polynom_res2["end_x_val1"], dict_polynom_res2["end_x_val1"] + width_of_curve1, width_of_curve1)
                            last_x_val2a = dict_polynom_res2["end_x_val1"]
                        else:

                            #todo polynom_curve1a = self.create_curve_from_polynom1(init_polynom1, dict_polynom_res2("end_x_val1") + width_of_curve1, dict_polynom_res2("end_x_val1"), width_of_curve1)
                            last_x_val2a = dict_polynom_res2["end_x_val1"]

                        if search_mode1 == "only_start_derivate_minus1":
                            last_x_val2a = dict_polynom_res2["end_x_val1"] + width_of_curve1


                        last_end_x_polynom1 = dict_polynom_res2["end_x_val1"]
                        init_polynom1 = dict_polynom_res2["polynom_obj1"]
                        dict_return_res1:Dictionary = Dictionary()





                        dict_return_res1["dict_polynom_res2"] = dict_polynom_res2

                        dict_return_res1["start_x_val1"] = dict_polynom_res2["end_x_val1"]
                        dict_return_res1["end_x_val1"] = dict_polynom_res2["end_x_val1"] - width_of_curve1
                        dict_return_res1["end_derivative1"] = init_polynom1.get_derivative1(dict_polynom_res2["end_x_val1"] - width_of_curve1)
                        dict_return_res1["start_derivative1"] = init_polynom1.get_derivative1(dict_polynom_res2["end_x_val1"])

                        dict_return_res1["start_derivative_org1"] = start_derivative1



                        dict_return_res1["polynom_obj1"] = init_polynom1
                        dict_return_res1["last_end_x_polynom1"] = last_end_x_polynom1
                        dict_return_res1["min_dist_from_curve1"] = min_dist_from_curve1
                        end_derivative2float = init_polynom1.get_derivative1(last_x_val2a)
                        dict_return_res1["end_derivative2"] = end_derivative2
                        dict_return_res1["polynom_curve1a"] = polynom_curve1a
                        dict_return_res1["curve_pxls_arr1"] = curve_pxls_arr1

                        if (min_diff_h2 < 0):
                            min_diff_h1 *= -1

                        dict_return_res1["min_diff_h1"] = min_diff_h1
                        dict_return_res1["width_of_curve1"] = width_of_curve1
                        dict_return_res1["height_of_curve1"] = height_of_curve1
                        dict_return_res1["search_mode1"] = search_mode1
                        dict_return_res1["min_last_derivative1"] = min_last_derivative1
                        dict_return_res1["min_diff_last_derivative1"] = math.abs(math.abs(self.fix_last_derivative_of_curve1) - math.abs(dict_return_res1["end_derivative1"]))

                        dict_return_res1["org_height_of_curve1"] = org_height_of_curve1
                        dict_return_res1["height_of_curve_dest1"] = height_of_curve_dest1
                        dict_return_res1["last_dict_prms_str2"] = self.last_dict_prms_str2
                        dict_return_res1["start_ind1"] = start_ind2
                        dict_return_res1["last_ind1"] = last_ind2
                        dict_return_res1["local_max_loop_count1"] = local_max_loop_count1
                        dict_return_res1["log_str1"] = str(log_str1)
                        dict_return_res1["add_height_to_curve1"] = str(add_height_to_curve1_temp1)
                        dict_return_res1["add_width_to_curve1"] = str(add_width_to_curve1_temp1)


                        last_dict_return_res1 = dict_return_res1
                        lop_step1 += "step4,"

                    lop_step1 += "step5," + "min_diff_h1=" + str(min_diff_h1) + ","
                    exp_last_min_diff_h1:float = (1 - math.pow(10, -10)) - div_last_delta_min_diff_h2
                    if (math.abs(min_diff_h1) < min_min_diff_h1 or ((loop_ind1 > local_max_loop_count1) or self.add_coef_factor1 < min_add_coef_factor1 or ok_end_derivative2) and (math.abs(min_diff_h1) < 1 or self.mode_fix_last_pixel1)):
                        lop_step1 += "step6,"
                        if math.abs(min_diff_h1) < min_min_diff_h1:
                            last_dict_return_res1["min_diff_h1<min_min_diff_h1"] = True
                            last_dict_return_res1["min_min_diff_h1_val1"] = min_min_diff_h1
                            last_dict_return_res1["min_diff_h1_val1"] = min_diff_h1

                        if loop_ind1 > local_max_loop_count1:
                            last_dict_return_res1["loop_ind1>local_max_loop_count1"] = True


                        if add_coef_factor1 < min_add_coef_factor1:
                            last_dict_return_res1["add_coef_factor1<min_add_coef_factor1"] = True

                        draw_polynoms2:bool=False
                        if draw_polynoms2:
                            #todo CGlobals1.add_to_txt_log1("end_find_polynom_coeafs1")

                            dict_polynom_res2b:Dictionary = last_dict_return_res1["dict_polynom_res2"]
                            polynom_curve1a:ArrayList = last_dict_return_res1["polynom_curve1a"]

                            curve_ind1:int = dict_prms1["curve_ind1"]
                            polynom_curve1a = self.rotate_curve_vertical1(polynom_curve1a)

                            polynom_curve1a = self.move_left_botton_curve_to_cord_xy1(polynom_curve1a, (100, 100))

                            y_val1a:float = init_polynom1.get_y_val1(dict_polynom_res2b["end_x_val1"] + width_of_curve1)
                            y_val2a:float = init_polynom1.get_y_val1(dict_polynom_res2b["end_x_val1"])

                            bmp1a:Bitmap = Bitmap(1500, 1000, (255, 255, 255,0))
                            CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(polynom_curve1a, bmp1a, (200, 30, 70,0))
                            bmp1a.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\c1a_" + str(curve_ind1) + ".bmp")

                            curve_pxls_arr1a:ArrayList = last_dict_return_res1["curve_pxls_arr1"]
                            curve_pxls_arr1a = self.move_left_botton_curve_to_cord_xy1(curve_pxls_arr1a, (100, 105))
                            bmp1b:Bitmap = Bitmap(1500, 1000, (255, 255, 255,0))
                            CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp1a, (40, 40, 250,0))


                            bmp1a.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\c2a_" + str(curve_ind1) + ".bmp")

                        not_to_stop1 = False

                        last_dict_return_res1["loop_ind1"] = loop_ind1
                        last_dict_return_res1["min_add_coef_factor1"] = min_add_coef_factor1
                        last_dict_return_res1["local_max_loop_count1"] = local_max_loop_count1
                        last_dict_return_res1["min_min_diff_h1"] = min_min_diff_h1

                        last_dict_return_res1["add_height_to_curve1"] = dict_prms1["add_height_to_curve1"]
                        last_dict_return_res1["add_width_to_curve1"] = dict_prms1["add_width_to_curve1"]
                        last_dict_return_res1["org_int_poly1"] = org_int_poly1
                        return last_dict_return_res1

            else:
                lop_step1 += "step7,"
                if add_coef_factor1 < min_add_coef_factor1:
                    lop_step1 += "step8,"
                    dict_polynom_res2b:Dictionary
                    if last_dict_return_res1 ==None:
                        dict_return_res1b:Dictionary = Dictionary()
                        dict_return_res1b["error1"] = True
                        dict_return_res1b["min_dist_diff_height1"] = min_dist_diff_height1

                        CGlobals1.add_to_txt_log1("end_find_polynom_coeafs1-err1")

                        return dict_return_res1b

                    try:
                        dict_polynom_res2b = last_dict_return_res1["dict_polynom_res2"]

                    except:

                        dict_return_res1b:Dictionary = Dictionary()
                        dict_return_res1b["error1"] = True
                        dict_return_res1b["min_dist_diff_height1"] = min_dist_diff_height1
                        #todo CGlobals1.add_to_txt_log1("end_find_polynom_coeafs1-err2")
                        return dict_return_res1b
                    



                    #todo CGlobals1.add_to_txt_log1("end_find_polynom_coeafs2")

                    polynom_curve1a:ArrayList = last_dict_return_res1["polynom_curve1a"]
                    curve_ind1:int = dict_prms1["curve_ind1"]
                    polynom_curve1a = self.rotate_curve_vertical1(polynom_curve1a)

                    polynom_curve1a = self.move_left_botton_curve_to_cord_xy1(polynom_curve1a, (100, 100))

                    y_val1a:float = init_polynom1.get_y_val1(dict_polynom_res2b["end_x_val1"] + width_of_curve1)
                    y_val2a:float = init_polynom1.get_y_val1(dict_polynom_res2b["end_x_val1"])

                    bmp1a:Bitmap = Bitmap(1500, 1000, (255, 255, 255,0))
                    CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(polynom_curve1a, bmp1a,(200, 30, 70,0))
                    bmp1a.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\c1a_" + str(curve_ind1) + ".bmp")

                    curve_pxls_arr1a:ArrayList = last_dict_return_res1["curve_pxls_arr1"]
                    curve_pxls_arr1a = self.move_left_botton_curve_to_cord_xy1(curve_pxls_arr1a, (100, 105))
                    bmp1b:Bitmap = Bitmap(1500, 1000, (255, 255, 255,0))
                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp1a, (40, 40, 250,0))


                    bmp1a.Save(CGlobals1.global_path1 + "sobel_pics1\\c2a_" + str(curve_ind1) + ".bmp")

                    last_dict_return_res1["loop_ind1"] = loop_ind1

                    return last_dict_return_res1




                add_coef_factor1 /= 2

            lop_step1 += "step9,"
            if loop_ind1 > local_max_loop_count1 and add_coef_factor1 < min_add_coef_factor1:

                #todo CGlobals1.add_to_txt_log1("end_find_polynom_coeafs3")


                dict_polynom_res2b:Dictionary=None

                try:
                    if last_dict_return_res1==None:
                        dict_polynom_res2b = last_dict_return_res1["dict_polynom_res2"]
                    else:
                        dict_return_res_err1:Dictionary = Dictionary()
                        dict_return_res_err1["error1"] = True
                        dict_return_res_err1["error_type1"]= "loop"
                        dict_return_res_err1["min_dist_diff_height1"] = min_dist_diff_height1
                        return dict_return_res_err1


                except:


                    dict_return_res_err1:Dictionary = Dictionary()
                    dict_return_res_err1["error1"] = True
                    dict_return_res_err1["error_type1"] = "loop"
                    dict_return_res_err1["min_dist_diff_height1"] = min_dist_diff_height1
                    return dict_return_res_err1


                polynom_curve1a:ArrayList = last_dict_return_res1["polynom_curve1a"]
                curve_ind1:int = dict_prms1["curve_ind1"]
                polynom_curve1a = self.rotate_curve_vertical1(polynom_curve1a)

                polynom_curve1a = self.move_left_botton_curve_to_cord_xy1(polynom_curve1a, 100, 100)

                y_val1a:float = init_polynom1.get_y_val1(dict_polynom_res2b["end_x_val1"] + width_of_curve1)
                y_val2a:float = init_polynom1.get_y_val1(dict_polynom_res2b["end_x_val1"])

                bmp1a:Bitmap = Bitmap(1500, 1000, (255, 255, 255,0))
                CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(polynom_curve1a, bmp1a,(200, 30, 70,0))
                bmp1a.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\c1a_" + str(curve_ind1) + ".bmp")

                curve_pxls_arr1a:ArrayList = last_dict_return_res1["curve_pxls_arr1"]
                curve_pxls_arr1a = self.move_left_botton_curve_to_cord_xy1(curve_pxls_arr1a, (100, 105))
                bmp1b:Bitmap = Bitmap(1500, 1000, (255, 255, 255,0))
                CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp1a, (40, 40, 250,0))


                bmp1a.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\c2a_" + str(curve_ind1) + ".bmp")


                last_dict_return_res1["loop_ind1"] = loop_ind1
                return last_dict_return_res1

        polynom_curve1:ArrayList #todo= self.create_curve_from_polynom1(init_polynom1, last_end_x_polynom1 + width_of_curve1, last_end_x_polynom1, width_of_curve1)
        if search_mode1 == "only_start_derivate1":
            #todo polynom_curve1 = self.create_curve_from_polynom1(init_polynom1, last_end_x_polynom1, last_end_x_polynom1 - width_of_curve1, width_of_curve1)
            last_derivative1:float = init_polynom1.get_derivative1(last_end_x_polynom1 - width_of_curve1)

        

        for ind3 in range(0 , polynom_curve1.count ):
            
            polynom_curve1[ind3] = str([300 + ind3]) + "," + str(300 + CGlobals1.get_cord_xy_in_pixels_arr1(polynom_curve1, ind3)[1])

        bmp1:Bitmap = Bitmap(1500, 1000, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(polynom_curve1, bmp1, (200, 30, 70,0))
        bmp1.SaveAs(CGlobals1.global_path1 + "sobel_pics1\c1a.bmp")

        bmp2:Bitmap = Bitmap(1500, 1000, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp2, (200, 30, 70,0))
        bmp2.SaveAsve(CGlobals1.global_path1 + "sobel_pics1\\c1b.bmp")



    def create_result_for_polynom1(self,init_polynom1:CPolynom2, last_end_x_polynom1:float, new_width_of_curve1:int, curve_pxls_arr1:ArrayList):
        dict_return_res1:Dictionary = Dictionary()
        dict_return_res1["polynom_obj1"] = init_polynom1
        dict_return_res1["last_end_x_polynom1"] = last_end_x_polynom1



        end_derivative2:float = init_polynom1.get_derivative1(last_end_x_polynom1 + new_width_of_curve1 + 1)
        dict_return_res1["end_derivative2"] = end_derivative2
        cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
        cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, new_width_of_curve1)
        height_of_new_curve1:int = cord_xy1[1] - cord_xy2[1]

        last_y_val_polynom1:float = init_polynom1.get_y_val1(last_end_x_polynom1)
        start_y_val_polynom1:float = init_polynom1.get_y_val1(last_end_x_polynom1 + new_width_of_curve1)
        height_of_new_polynom1:float = start_y_val_polynom1 - last_y_val_polynom1


        dict_return_res1["min_diff_h1"] = height_of_new_polynom1 - height_of_new_curve1

        dict_return_res1["width_of_curve1"] = new_width_of_curve1


        dict_return_res1["height_of_curve1"] = height_of_new_curve1
        dict_return_res1["search_mode1"] = "only_start_derivate1"
        return dict_return_res1




    def fix_last_pxl_for_gap_equal_zero(self):
        dict_res_ret1:Dictionary = Dictionary()


        ok_last_pxl_point1 :bool=False
        val_treshold1:float=0
        if self.polynom_result_arr1.count:
            if self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["last_ind1"] == self.curve_last_ind1:

                self.results_stack_arr1.clear()
                dict_res_size1a:Dictionary = self.get_polinom_size1(self.polynom_result_arr1)
                dict_res_size1c:Dictionary = self.get_polinom_size2(self.polynom_result_arr1, 0, self.polynom_result_arr1.count - 3)
                dict_res_size1d:Dictionary = self.get_polinom_size2(self.polynom_result_arr1, self.polynom_result_arr1.count - 2, self.polynom_result_arr1.count - 1)


                dict_res_size2c:Dictionary = self.get_polinom_size2(self.polynom_result_arr1, self.polynom_result_arr1.count - 2, self.polynom_result_arr1.count - 2)
                dict_res_size2d:Dictionary = self.get_polinom_size2(self.polynom_result_arr1, self.polynom_result_arr1.count - 1, self.polynom_result_arr1.count - 1)

                total_org_height1:float = float(self.curve_pxls_arr1[0].Split(",")[1]) - float(self.curve_pxls_arr1[self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["last_ind1"]].Split(",")[1])
                try:
                    val_treshold1 = abs(dict_res_size1a["total_height1"] - total_org_height1 - polynom_result_arr1(polynom_result_arr1.Count - 1)("min_diff_h1") - self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["last_delta_height1"])

                except:
                    err1:int = 1



                dict_res_size1b:Dictionary = get_polinom_size1(self.polynom_result_arr1, self.polynom_result_arr1.count - 3)
                #self.check_if_over_total_height()

                min_diff_h1:float = self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["min_diff_h1"]
                min_diff_h2:float = self.polynom_result_arr1[self.polynom_result_arr1.count - 2]["min_diff_h1"]



        found_new_min_value5:str=""




        if self.last_go_back_ind1 != -1:


            #todo self.check_if_over_total_height()
            CGlobals1.add_to_txt_log1("(*)count_loop1_fix_gap_close_to_zore1=" + count_loop1_fix_gap_close_to_zore1.ToString() + ",min_diff_h1(" + polynom_result_arr1.Count.ToString() + ")=" + polynom_result_arr1(polynom_result_arr1.Count - 1)("min_diff_h1").ToString() + ",end_derivative1(" + str(self.polynom_result_arr1.count) + ")=" + str(self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["end_derivative1"]))

            if self.polynom_result_arr1.count - 2 == self.last_go_back_ind1:
                if min_diff_h1_and_derivs_arr1.count == 0:
                    
                    #todo self.last_first_result_poly_3 = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(self.polynom_result_arr1[self.polynom_result_arr1.count - 2]))
                    #todo self.last_first_result_poly_4 = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(self.polynom_result_arr1[self.polynom_result_arr1.count - 1]))
                    d1=1
                
                dict_res_size1d = self.get_polinom_size1(self.polynom_result_arr1)




                total_org_height1:float = float(str(self.curve_pxls_arr1[0]).split(",")[1]) - float(str(self.curve_pxls_arr1[self.curve_pxls_arr1.count - 1]).split(",")[1])
                total_org_width1:float = float(str(self.curve_pxls_arr1[0]).split(",")[0]) - float(str(self.curve_pxls_arr1[self.curve_pxls_arr1.count - 1]).split(",")[0])

                if math.abs(total_org_height1 - dict_res_size1d["total_height1"] + self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["min_diff_h1"] + self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["last_delta_height1"]) > Math.Pow(10, -7) or \
                            math.abs(math.abs(dict_res_size1d["total_width1"]) - math.abs(total_org_width1)) > math.pow(10, -7):
                    
                    dict_res_ret1["finish_gap_zero"] = "wrong"
                    #todo CGlobals1.add_to_txt_log1("error_fix_last_pxl_for_gap_equal_zero")

                #todo CGlobals1.add_to_txt_log1("(**)count_loop1_fix_gap_close_to_zore1=" + str(count_loop1_fix_gap_close_to_zore1) + ",min_diff_h1(" + str(self.polynom_result_arr1.count) + ")=" + str(self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["min_diff_h1"]) + ",end_derivative1(" + str(self.polynom_result_arr1.count) + ")=" + str(self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["end_derivative1"]))
                #todo CGlobals1.add_to_txt_log1("height_of_curve1=" + str(self.polynom_result_arr1[self.polynom_result_arr1.count - 2]["height_of_curve1"]) + ",width_of_curve1=" + str(self.polynom_result_arr1[self.polynom_result_arr1.count - 2]["width_of_curve1"]))
                #todo CGlobals1.add_to_txt_log1("add_curve_height1_factor1=" + str(add_curve_height1_factor1))
                #todo CGlobals1.add_to_txt_log1("min_diff_h1=" + str(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_h1"]) + ",end_derivative1=" + str(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["end_derivative1"]))




                cur_min_value5:float = math.abs(float(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_h1"])) + math.abs(float(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["last_delta_height1"]) + math.abs(float(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_last_derivative1"])))


                #todo CGlobals1.add_to_txt_log2("min_diff_last_derivative1=" + str(float(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_last_derivative1"])) + ",min_diff_h1=" + str(math.abs(float(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_h1"])))

                if math.abs(float(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_last_derivative1"])) < self.min_diff_last_derivative1_treshold1:
                    cur_min_value5 = math.abs(float(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_h1"]) + float(self.polynom_result_arr1[last_go_back_ind1 + 2 - 1]["last_delta_height1"]))
                
                cur_min_value5 = math.abs(float(self.polynom_result_arr1[last_go_back_ind1 + 2 - 1]["min_diff_h1"]) + float(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["last_delta_height1"]))

                cur_min_value5 = math.abs(float(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_h1"])) + math.abs(float(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_last_derivative1"]) - self.cur_last_derivative_of_curve1)
                #todo CGlobals1.add_to_txt_log2("cur_min_value5=" + self(cur_min_value5))
                #todo CGlobals1.add_to_txt_log2("^^^^^^^^^^^^^^^^^^min_min_value5=" + str(min_min_value5))
                #todo CGlobals1.add_to_txt_log2("try_number=" + str(arr_min_diff_h1_and_end_deriv_arr1.count))

                if min_min_value5 > cur_min_value5 and val_treshold1 < math.pow(10, -7):
                    min_min_value5 = cur_min_value5
                    #todo best_result_poly_3 = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(self.polynom_result_arr1[self.polynom_result_arr1.count - 2]])
                    #todo best_result_poly_4 = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(self.polynom_result_arr1[self.polynom_result_arr1.count - 1]))
                    last_min_min_value5_ind1 = min_diff_h1_and_derivs_arr1.count

                    found_new_min_value5 = "yes"
                    #todo CGlobals1.add_to_txt_log2("(min_min_value5>cur_min_value5)min_min_value5=" + str(min_min_value5) + ",add_curve_width1_factor1=" + str(add_curve_width1_factor1))
                    #todo CGlobals1.add_to_txt_log2("min_min_diff_h1=" + str(min_min_diff_h1) + ",max_loop_count1=" + str(max_loop_count1))
                    dict_res_size1:Dictionary = self.get_polinom_size1(self.polynom_result_arr1)
                    #todo CGlobals1.add_to_txt_log2("*****dict_res_size1('total_height1')=" + str(dict_res_size1["total_height1"]))

                    dict_polynoms1["polynom_result_arr1"] = self.polynom_result_arr1.clone()


                    #todo min_dict_polynoms_str1 = CGlobals1.dict_prm_to_json_str(dict_polynoms1)


                    json_str1:str = min_dict_polynoms_str1



                    dict1:Dictionary=None

                    try:
                        
                        dict1 #todo = CGlobals1.json_to_dict_prms1(min_dict_polynoms_str1)

                    except:
                        obj2 #todo = CGlobals1.json_to_dict_prms1(json_str1)
                        




                    polynom_result_arr1c:ArrayList = dict1["polynom_result_arr1"]
                    polynom_curves_arr1c:ArrayList = dict1["polynom_curves_arr1"]

                    frame_pixels_arr1_from_last_ind3:ArrayList = dict1["frame_pixels_arr1_from_last_ind"]


                    dict_print_polynom_res_arr3:ArrayList=None
                    try:
                        only_store_polyonm_res1 = True
                        #todo dict_print_polynom_res_arr3 = print_polynom_results1(polynom_result_arr1c, polynom_curves_arr1c, dict_prms1["curve_ind1"], curve_start_ind1, curve_last_ind1, frame_pixels_arr1_from_last_ind3)
                        only_store_polyonm_res1 = ""
                    except:

                        
                        err:int=1




                    total_curve_height1:float = float(str(dict_print_polynom_res_arr3[0]).split(",")[1]) - float(str(dict_print_polynom_res_arr3[dict_print_polynom_res_arr3.count - 1]).split(",")[1])
                    total_curve_width1:float = float(str(dict_print_polynom_res_arr3[0]).split(",")[0]) - float(str(dict_print_polynom_res_arr3[dict_print_polynom_res_arr3.count - 1]).split(",")[0])

                    total_curve_height1_arr1.Add(total_curve_height1)
                    total_curve_width1_arr1.Add(total_curve_width1)








                if self.max_count_loop1_fix_gap_close_to_zore1 < self.count_loop1_fix_gap_close_to_zore1:
                    ok_last_pxl_point1=True



                if math.abs(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_h1"] + self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["last_delta_height1"]) <= min_diff_h1_treshold1 and math.abs(self.polynom_result_arr1[self.last_go_back_ind1 + 2 - 1]["min_diff_last_derivative1"] - cur_last_derivative_of_curve1) <= min_diff_last_derivative1_treshold1:
                    ok_last_pxl_point1 = True


        if ok_last_pxl_point1:
            json_str1:str = min_dict_polynoms_str1

            path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
            path2:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_poly_curve_" + str(curve_ind3) + ".txt"
            CFile1.write_all_text_to_file(json_str1,path2 )


            dict1:Dictionary=True

            try:
                dict1 #todo= CGlobals1.json_to_dict_prms1(json_str1)
                dict1 #todo = CGlobals1.json_to_dict_prms1(min_dict_polynoms_str1)

            except:
                obj2#todo  = CGlobals1.json_to_dict_prms1(json_str1)




            polynom_result_arr1b:ArrayList = dict1["polynom_result_arr1"]
            polynom_curves_arr1b:ArrayList = dict1["polynom_curves_arr1"]
            dict_prms1["curve_ind1"] = dict1["curve_ind1"]
            curve_start_ind1 = dict1["curve_start_ind1"]
            curve_last_ind1 = dict1["curve_last_ind1"]
            frame_pixels_arr1_from_last_ind:ArrayList = dict1["frame_pixels_arr1_from_last_ind"]


            only_store_polyonm_res1 = True
            dict_print_polynom_res_arr1:ArrayList #todo = self.print_polynom_results1(self.polynom_result_arr1b, polynom_curves_arr1b, dict_prms1("curve_ind1"), curve_start_ind1, curve_last_ind1, frame_pixels_arr1_from_last_ind)

            total_org_height1:float = float(self.curve_pxls_arr1[0].split(",")[1]) - float(self.curve_pxls_arr1[self.curve_pxls_arr1.count - 1].split(",")[1])
            total_org_width1:float = float(self.curve_pxls_arr1[0].split(",")[0]) - float(self.curve_pxls_arr1[self.curve_pxls_arr1.count - 1].split(",")[0])


            total_curve_height1:float = float(dict_print_polynom_res_arr1[0].split(",")[1]) - float(dict_print_polynom_res_arr1[dict_print_polynom_res_arr1.count - 1].split(",")[1])
            total_curve_width1:float = float(dict_print_polynom_res_arr1[0].split(",")[0]) - float(dict_print_polynom_res_arr1[dict_print_polynom_res_arr1.count - 1].split(",")[0])

            if math.abs(math.abs(total_org_height1) - math.abs(total_curve_height1)) > math.pow(10, -7) or math.abs(math.abs(total_org_width1) - math.abs(total_curve_width1)) > math.pow(10, -7):
             
                
                dict_res_ret1["finish_gap_zero"] = "wrong"


            dict_res_ret1["finish_gap_zero"] = "ok"
            dict_res_ret1["min_diff_h1"] = self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["min_diff_h1"]
            return dict_res_ret1



            only_store_polyonm_res1 = ""

        if not ok_last_pxl_point1:

            if not do_fix_last_pixel1 and self.polynom_result_arr1.count > 0:

                if (self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["last_ind1"] == self.curve_last_ind1 or was_error_in_fix_last_pxl1) and not ok_last_pxl_point1:
                    last_add_height_prm1 = self.polynom_result_arr1[self.polynom_result_arr1.count - 2]["last_add_height1"]

                    is_last_sub_curve1 = False
                    mode_fix_last_pixel1 = True
                    if self.last_go_back_ind1 == -1:
                        self.last_go_back_ind1 = self.polynom_result_arr1.count - 2

                        if self.last_go_back_ind1 == 0:
                            last_go_back_ind1_start_ind1 == 0
                            last_go_back_ind1_last_derivative1 == 1


                    min_diff_h1_val1:float = 9999

                    end_derivative1_val1:float = 9999

                    if not was_error_in_fix_last_pxl1:
                        min_diff_h1_val1 = self.polynom_result_arr1[self.last_go_back_ind1 + 1]["min_diff_h1"] + self.polynom_result_arr1[self.last_go_back_ind1 + 1]["last_delta_height1"]
                        end_derivative1_val1 = math.abs(self.polynom_result_arr1[self.last_go_back_ind1 + 1]["min_diff_last_derivative1"] - cur_last_derivative_of_curve1)


                    good_dir1:bool=False
                    if last_min_diff_h1_val1 >= min_diff_h1_val1:
                        last_min_diff_h1_val1 = min_diff_h1_val1




                    if not good_dir1:
                        min_diff_h1_val1 = 9999
                        end_derivative1_val1 = 9999

                    if self.start_fix_last_pixel1:
                        arr_min_diff_h1_and_end_deriv_arr1.Add(math.abs(min_diff_h1_val1) + math.abs(end_derivative1_val1))


                        if not was_error_in_fix_last_pxl1:
                            polynom_result_dir_arr_ind_dicts1[dir_arr_cur_ind1] = self.polynom_result_arr1[self.last_go_back_ind1]

                        arr_min_diff_h1_arr1.Add(math.abs(min_diff_h1_val1))
                        arr_end_deriv_arr1.Add(math.abs(end_derivative1_val1))
                        min_diff_h1_and_derivs_arr1.Add(str(min_diff_h1_val1) + "," + str(end_derivative1_val1))

                    goback_len1:int = 2
                    dict_prms1 #todo = CGlobals1.json_to_dict_prms1(dict_prms1_arr1[self.last_go_back_ind1])

                    add_curve_width1:float = 0.5
                    add_curve_height1:float = -0.25



                    if dir_arr_cur_ind1 == 9:
                        count_loop1_fix_gap_close_to_zore1 += 1


                        
                        ind5:int
                        min_ind5:int = -1
                        min_value5:float = 9999
                        min_value5 = arr_min_diff_h1_and_end_deriv_arr1[0]
                        self.loop_ind_fix_last_pxl1 += 1

                        if min_diff_h_and_deriv1 != min_value5 and min_diff_h_and_deriv1 != 9999:
                            loop_ind_fix_last_err_pxl1 = loop_ind_fix_last_pxl1

                        for ind5 in range(1 , arr_min_diff_h1_and_end_deriv_arr1.count):
                            if min_value5 > arr_min_diff_h1_and_end_deriv_arr1[ind5]:
                                min_value5 = arr_min_diff_h1_and_end_deriv_arr1[ind5]

                                min_ind5 = ind5

                        if min_value5 > min_min_value5:
                            err1:int=1

                        div_min_value1:float = -1
                        new_cur_val1:bool=False
                        if min_diff_h_and_deriv1 == 9999 and min_ind5 != -1:
                            min_diff_h_and_deriv1 = min_value5
                            count_div_step_factor_fix_last_pixel1 = 0
                            best_polynom_3 = self.polynom_result_arr1[self.polynom_result_arr1.count - 2]["polynom_obj1"].clone1()
                            best_polynom_4 = self.polynom_result_arr1[self.polynom_result_arr1.Count - 1]["polynom_obj1"].clone1()
                            new_cur_val1 = True
                        else:
                            if min_diff_h_and_deriv1 > min_value5:

                                div_min_value1 = math.abs(min_value5 / min_diff_h_and_deriv1)
                                min_diff_h_and_deriv1 = min_value5


                                best_polynom_3 = self.polynom_result_arr1[self.polynom_result_arr1.count - 2]["polynom_obj1"].clone1()
                                best_polynom_4 = self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["polynom_obj1"].clone1()

                                count_div_step_factor_fix_last_pixel1 = 0
                                #todo CGlobals1.add_to_txt_log1("min_diff_h_and_deriv1=" +str(min_diff_h_and_deriv1))
                                new_cur_val1 = True

                            else:

                                add_curve_width1_factor1 /= factor_div1
                                add_curve_height1_factor1 /= factor_div1

                                count_div_step_factor_fix_last_pixel1 += 1
                                if count_div_step_factor_fix_last_pixel1 > 1:
                                    if max_loop_count1 < 1500:
                                        max_loop_count1 += 500

                                    if min_min_diff_h1 > math.pow(10, -15):
                                        min_min_diff_h1 /= 10


                            if div_min_value1 > 0.5:

                                if ( not last_change_factor_name1  or last_change_factor_name1 == "max_loop_count1") and min_ind5 == -1:
                                    add_curve_width1_factor1 /= factor_div1
                                    add_curve_height1_factor1 /= factor_div1


                                count_div_step_factor_fix_last_pixel1 += 1

                                if last_change_factor_name1 == "factor_div1":

                                    if max_loop_count1 < 1500:
                                        max_loop_count1 += 500


                                    if min_min_diff_h1 > math.pow(10, -15):
                                        min_min_diff_h1 /= 10


                                #todo CGlobals1.add_to_txt_log1("add_curve_height1_factor1=" + str(add_curve_height1_factor1))


                            if last_change_factor_name1 == "" or last_change_factor_name1 == "max_loop_count1":
                                last_change_factor_name1 = "factor_div1"
                            else:
                                last_change_factor_name1 = "max_loop_count1"

                        if new_cur_val1 and min_ind5 != -1:

                            cur_add_curve_width1 = cur_add_curve_width1 + dir_arr1[min_ind5 * 2] * add_curve_width1_factor1
                            cur_add_curve_height1 = cur_add_curve_height1 + dir_arr1[min_ind5 * 2 + 1] * add_curve_height1_factor1

                            cur_min_diff_h1_val1 = min_diff_h1_val1
                            cur_end_deriv_val1 = end_derivative1_val1

                        add_curve_width1 = cur_add_curve_width1
                        add_curve_height1 = cur_add_curve_height1

                        dir_arr_cur_ind1 = 0
                        arr_min_diff_h1_and_end_deriv_arr1.clear()
                        arr_min_diff_h1_arr1.clear()
                        arr_end_deriv_arr1.clear()
                        min_diff_h1_and_derivs_arr1.clear()



                    add_curve_width1 = cur_add_curve_width1 + dir_arr1[dir_arr_cur_ind1 * 2] * add_curve_width1_factor1
                    add_curve_height1 = cur_add_curve_height1 + dir_arr1[dir_arr_cur_ind1 * 2 + 1] * add_curve_height1_factor1



                    dir_arr_cur_ind1 += 1

                    if dir_arr_cur_ind1 == 1:
                        polynom_result_dir_arr_ind_dicts1.clear()


                    last_add_curve_width1_val1 = add_curve_width1
                    last_add_curve_height1_val1 = add_curve_height1


                    last_min_diff_and_derivs_arr1.Add("add_w1=" + str(last_add_curve_width1_val1) + ",add_h1=" + str(last_add_curve_height1_val1) + ",min_diff_h1=" + str(min_diff_h1_val1) + ",e_d1=" + str(end_derivative1_val1))
                    dict_prms1["add_width_to_curve1"] = add_curve_width1
                    dict_prms1["add_height_to_curve1"] = add_curve_height1

                    last_ind1 = dict_prms1["end_pixel_ind1"]


                    while self.polynom_result_arr1.count > self.last_go_back_ind1:
                        self.polynom_result_arr1.RemoveAt(self.polynom_result_arr1.count - 1)


                    while dict_prms1_arr1.count > (self.last_go_back_ind1 + 1):
                        dict_prms1_arr1.RemoveAt(dict_prms1_arr1.count - 1)


                    dict_res_ret1["dict_res1_error1"] = True

                    try:
                        start_ind1 = self.polynom_result_arr1[self.last_go_back_ind1 - 1]["start_ind1"] - self.go_back_last_ind1



                    except:
                        start_ind1 = self.last_go_back_ind1_start_ind1 - self.go_back_last_ind1



                    clr_ind1:int

                    try:
                        if polynom_result_arr1.count > 0:

                            if polynom_result_arr1.count - 2 == self.last_go_back_ind1:
                                start_ind1 = self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["last_ind1"] - self.go_back_last_ind1
                            else:
                                start_ind1 = self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["last_ind1"]



                    except:
                        err1:int=1





                    self.mode1 = "not_change_height1"
                    self.force_over_dict_res1 = "yes"

                    was_error_in_fix_last_pxl1 = ""

                    self.mode_fix_last_pxl1 = True
                    self.start_fix_last_pixel1 = True
                else:
                    if self.last_go_back_ind1 != -1:

                        if self.mode_fix_last_pixel1:

                            if dict_prms1.ContainsKey("add_width_to_curve1"):

                                if math.abs(dict_prms1["add_width_to_curve1"]) > 0 :
                                    dict_prms1["add_width_to_curve1"] = -dict_prms1["add_width_to_curve1"]

                            if dict_prms1.ContainsKey["add_height_to_curve1"]:

                                if math.abs(dict_prms1["add_height_to_curve1"]) > 0 :
                                    dict_prms1["add_height_to_curve1"] = -dict_prms1["add_height_to_curve1"]

                            force_over_dict_res1 = False

                            dict_res_ret1["dict_res1_error1"]=True


                            if last_ind1 == curve_last_ind1:

                                self.mode1 = "not_change_height1"
                                self.force_over_dict_res1 = True

                                self.was_error_in_fix_last_pxl1 = False

                                self.mode_fix_last_pxl1 = True
        else:
            dict_res_ret1["dict_res1_error1_remove"] =True


        return dict_res_ret1




    def add_polynom_result_to_list1(self,dict_res1:Dictionary):
        if self.dict_prms1.ContainsKey("add_curve_height1"):
            if self.dict_prms1["add_curve_height1"] != 0 :
                last_add_height1 = self.dict_prms1["add_curve_height1"]


            self.dict_prms1.Remove("add_curve_height1")

        try:
            self.last_derivate1 = dict_res1["end_derivative2"]

        except:
            err:int = 1


        try:
            self.last_delta_height1 = dict_res1["min_diff_h1"]

        except:
            err1:int = 1

        self.derivate_arr1.Add(self.last_derivate1)

        try:
            self.polynom_curves_arr1.Add(dict_res1["polynom_curve1a"])

        except:
            self.polynom_curves_arr1.Add(ArrayList())
        
        

        if not self.found_good_derivative_in_more_height1 and self.mode1 == "" or self.add_last_add_height1:
            self.last_add_height1 = 0
            self.dict_prms1["add_curve_height1"] = 0



        if self.last_go_back_ind1 == -1:
            dict_res1["last_add_height1"] = self.last_add_height1
            if self.found_good_derivative_in_more_height1:
                
                dict_res1["last_add_height1"] = dict_prms1["last_add_height1"]
            else:
                
                dict_res1["last_add_height1"] = 0
        else:
            #todo dict_prm4:Dictionary = CGlobals1.json_to_dict_prms1(dict_prms1_arr2(polynom_result_arr1.Count - 1))

            if self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["found_good_derivative_in_more_height1"]:


                self.last_add_height1 = dict_prm4["add_curve_height1"]
                self.dict_prms1["last_add_height1"] = dict_prm4["last_add_height1"]
                dict_res1["last_add_height1"] = dict_prm4["last_add_height1"]

            else:
                self.last_add_height1 = 0
                self.dict_prms1["last_add_height1"] = 0
                dict_res1["last_add_height1"] = 0

        if not dict_res1.ContainsKey("last_delta_height1"):
            dict_res1["last_delta_height1"] = 0


        dict_res1["found_good_derivative_in_more_height1"] = self.found_good_derivative_in_more_height1
        
        #todo CGlobals1.save_dict_prms1(dict_res1, self.path_arr1[self.cur_path_ind1] + "\\result_" + str(polynom_result_arr1.count) + ".json")




        #todo last_dict_prms_str1 = CGlobals1.dict_prm_to_json_str(dict_prms1)


        dict_prms1_arr1.Add(last_dict_prms_str1)
        if dict_prms1_arr2.count < dict_prms1_arr1.count:

            dict_prms1_arr2.Add(dict_res1["last_dict_prms_str2"])


        dict_res1.Remove("last_dict_prms_str2")
        self.polynom_result_arr1.Add(dict_res1)
        #todo dict_res_size4:Dictionary = self.get_polinom_size1(polynom_result_arr1)

        #toso CGlobals1.add_to_txt_log1("add polynom reslut num = " + str(polynom_result_arr1.count))
        width_of_org_curve1:int = CGlobals1.get_cord_xy_in_pixels_arr1(self.curve_pxls_arr1, curve_start_ind1)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(self.curve_pxls_arr1, self.curve_last_ind1)[0]
        
        width_of_cur_curve1:int = CGlobals1.get_cord_xy_in_pixels_arr1(self.curve_pxls_arr1, 0)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(self.curve_pxls_arr1, self.curve_pxls_arr1.Count - 1)[0]

        frame_pixels_arr1_from_last_ind:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1, org_start_ind, self.last_ind1)


        width_of_org_curve2:int = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1_from_last_ind, 0)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1_from_last_ind, frame_pixels_arr1_from_last_ind.count - 1)[0]

        

        dict_polynoms1["polynom_result_arr1"] = polynom_result_arr1
        dict_polynoms1["polynom_curves_arr1"] = polynom_curves_arr1
        dict_polynoms1["curve_ind1"] = self.dict_prms1("curve_ind1")
        dict_polynoms1["curve_start_ind1"] = curve_start_ind1
        dict_polynoms1["curve_last_ind1"] = self.curve_last_ind1
        dict_polynoms1["frame_pixels_arr1_from_last_ind"] = frame_pixels_arr1_from_last_ind












    def compute_m1b(self,slice_curve_pxls_arr1:ArrayList, last_delta_height1:float):
        cord_xy_start1b = CGlobals1.get_cord_xy_in_pixels_arr1(slice_curve_pxls_arr1, 0)
        cord_xy_end1b = CGlobals1.get_cord_xy_in_pixels_arr1(slice_curve_pxls_arr1, slice_curve_pxls_arr1.count - 1)

        m1b:float = -(cord_xy_start1b[1] - cord_xy_end1b[1] - last_delta_height1 - self.last_add_height1) / (cord_xy_start1b[0] - cord_xy_end1b[0])








        return m1b






    def find_last_ind1_with_m1b(self):

        org_max_diff_start_last:int = self.max_diff_start_last

        trace_last_ind_arr1:ArrayList = ArrayList()
        dict_ret_res1:Dictionary = Dictionary()

        dir_add_dec_slice_curve1:int = 1

        not_to_stop_find_last_ind1:bool=True 
        org_last_ind2:int = self.last_ind1

        dict_res1:Dictionary = Dictionary()

        slice_curve_pxls_arr1:ArrayList = ArrayList()

        while not_to_stop_find_last_ind1:


            if self.last_derivate1 >= m1b:
                if not dict_res1.ContainsKey("error1"):
                    if dict_res1.ContainsKey("end_derivative2"):
                        if abs(dict_res1["end_derivative2"] - self.min_last_derivative1) <= self.min_diff_last_derivative1 or self.mode1 == "force_add_height":
                            not_to_stop_find_last_ind1=False

            if not not_to_stop_find_last_ind1:
                dict_ret_res1["slice_curve_pxls_arr1"] = slice_curve_pxls_arr1
                dict_ret_res1["dict_res1"] = dict_res1
                self.max_diff_start_last = self.org_max_diff_start_last
                return dict_ret_res1





            if dict_res1.count > 0:


                if not_to_stop_find_last_ind1:
                    if self.last_ind1 < self.start_ind1 + max_diff_start_last:
                        self.dir_add_dec_slice_curve1 = 1
                        trace_last_ind_arr1.clear()

                    elif dir_add_dec_slice_curve1:

                        dir_add_dec_slice_curve1 = -1
                        if not self.mode_fix_last_pixel1:
                            self.last_ind1 = self.org_last_ind2 + 1

                        
                        trace_last_ind_arr1.clear()
                        self.max_diff_start_last += 10
                    
                if self.last_ind1 <= self.start_ind1 + self.min_diff_start_last:

                    dir_add_dec_slice_curve1 = 1

                    if not mode_fix_last_pixel1:
                        self.last_ind1 = self.org_last_ind2 + 1

                    trace_last_ind_arr1.clear()

            is_end_of_curve1:bool=False
            if not to_stop_find_last_ind1:

                if not (self.mode1 == "not_change_height1" or self.mode_fix_last_pixel1):
                    self.last_ind1 += dir_add_dec_slice_curve1
                
                if (not dict_min_derivative.ContainsKey(self.last_ind1) or self.is_last_sub_curve1) and not self.mode_fix_last_pixel1:
                
                    self.is_end_of_curve1 = True
                    if self.last_ind1 > self.curve_last_ind1:
                        self.last_ind1 = self.curve_last_ind1

                if self.dict_min_derivative(self.last_ind1) <= 0 or self.is_end_of_curve1:
                    

                    if not (self.mode1 == "force_add_height" or self.mode_fix_last_pixel1):
                        self.last_ind1 = self.curve_last_ind1



                if dict_last_inds1.ContainsKey(self.polynom_result_arr1.count) and not self.mode_fix_last_pixel1:
                    self.last_ind1 = dict_last_inds1(self.polynom_result_arr1.Count)


                CGlobals1.add_to_txt_log2("find_last_ind1_with_m1b(last_ind1)=" + str(self.last_ind1))
                trace_last_ind_arr1.Add(self.last_ind1)

                if trace_last_ind_arr1.count > 300:

                    self.was_error_in_fix_last_pxl1 = True
                    dict_res1["error1"] = True
                    dict_ret_res1["slice_curve_pxls_arr1"] = slice_curve_pxls_arr1
                    dict_ret_res1["dict_res1"] = dict_res1

                    return dict_ret_res1

                try:
                    min_last_derivative1 = self.dict_min_derivative(self.last_ind1)

                except:
                    err1:int = 1




                slice_curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(self.curve_pxls_arr1, self.start_ind1, self.last_ind1)
                m1b = self.compute_m1b(slice_curve_pxls_arr1, self.last_delta_height1)
                if self.last_derivate1 >= m1b or self.is_end_of_curve1 or self.mode_fix_last_pixel1:

                    init_poynom_obj1.coef_arr1.clear()

                    init_poynom_obj1.coef_arr1.Add(0)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.coef_arr1.Add(0.00001)
                    init_poynom_obj1.create_derivative1()
                    dict_res1.Remove("error1")

                    
                    
                    dict_prms1["check1"] = True





                    #todo dict_res1 = self.find_polynom_coefs1(init_poynom_obj1, self.last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)

                    if self.last_go_back_ind1 !=-1:
                        try:
                            polynom_obj1:CPolynom2 = dict_res1["polynom_obj1"]
                            h1:float = abs(polynom_obj1.get_y_val1(dict_res1["start_x_val1"]) - polynom_obj1.get_y_val1(dict_res1["end_x_val1"]))
                            #todo dict_res1["total_height1_arr1"] = self.get_polinom_size1(self.polynom_result_arr1)["total_height1"]
                            dict_res1["height_of_polynom2"] = h1


                        except:
                            err1:int=1

                    res_arr1:ArrayList = ArrayList()
                    res_arr1.Add(dict_res1)


                    min_diff_res_arr1:ArrayList = ArrayList()

                    dict_res_temp1:Dictionary = Dictionary()
                    last_min_diff_h1:float=0
                    try:
                        last_min_diff_h1 = abs(dict_res1["min_diff_h1"])

                    except:
                        err1:int = 1

                    if not dict_res1.ContainsKey("error1"):
                        if (self.polynom_result_arr1.count - 1 == self.last_go_back_ind1) and self.last_go_back_ind1!=-1:

                            not_to_stop_find_coefs1:bool=True

                            temp_start_coef1:float = start_coef1
                            start_coef1 =   math.pow(10, -5)
                            if last_good_start_coef1 == -1:
                                last_good_start_coef1 = start_coef1


                            min_diff_h1_val1:float = abs(dict_res1["min_diff_h1"])
                            found_better_min_diff_h1:bool=False   

                            if min_diff_h1_val1 > math.pow(10, -5):


                                while not_to_stop_find_coefs1:

                                    if abs(dict_res1["min_diff_h1"]) > math.pow(10, -5):

                                        self.factor_div_prop1 = 0.95
                                        self.dict_prms1["max_loop_count1"] = 2000
                                        dict_res_temp1 = Dictionary()
                                        #todo dict_res_temp1 = self.find_polynom_coefs1(init_poynom_obj1, self.last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", self.dict_prms1)
                                        res_arr1.Add(dict_res_temp1)

                                        self.factor_div_prop1 = 0.9

                                        polynom_obj_c1:CPolynom2 = init_poynom_obj1.clone1()
                                        dict_prm_str2:str = CGlobals1.dict_prm_to_json_str(self.dict_prms1)
                                        dict_prms3:Dictionary = CGlobals1.json_to_dict_prms1(dict_prm_str2)
                                        last_derivate1_c1:float = self.last_derivate1


                                        if dict_res_temp1.ContainsKey("error1"):
                                            init_poynom_obj1 = CPolynom2()

                                            init_poynom_obj1.coef_arr1.Clear()

                                            init_poynom_obj1.coef_arr1.Add(0)
                                            init_poynom_obj1.coef_arr1.Add(0.0000001)
                                            init_poynom_obj1.coef_arr1.Add(0.0000001)
                                            init_poynom_obj1.coef_arr1.Add(0.0000001)
                                            init_poynom_obj1.create_derivative1()

                                            dict_res_temp1 = self.find_polynom_coefs1(init_poynom_obj1, self.last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms3)



                                        if not dict_res_temp1.ContainsKey("error1"):

                                            if min_diff_res_arr1.count > 0:
                                                if min_diff_res_arr1[min_diff_res_arr1.count - 1] < dict_res_temp1["min_diff_h1"]:
                                                    not_to_stop_find_coefs1 = False   

                                            min_diff_res_arr1.Add(dict_res_temp1["min_diff_h1"])
                                            if last_min_diff_h1 > abs(dict_res_temp1["min_diff_h1"]):

                                                dict_res1 = dict_res_temp1
                                                last_min_diff_h1 = abs(dict_res_temp1["min_diff_h1"])
                                                last_good_start_coef1 = start_coef1
                                                found_better_min_diff_h1 = True
                                        not_to_stop_find_coefs1 = False

                                    if start_coef1 < last_good_start_coef1:
                                        not_to_stop_find_coefs1 = False

                                    start_coef1 /= 10



                            start_coef1 = temp_start_coef1

                            CGlobals1.add_to_txt_log1("found_better_min_diff_h1=" + str(found_better_min_diff_h1))
                            found_better_min_diff_h1 = False



                        self.dict_prms1.Remove("max_loop_count1")

                        if self.polynom_result_arr1.count == 40:

                            self.dict_prms1["add_curve_height1"] = 1.2

                            self.dict_prms1["max_loop_count1"] = 3000
                            #todo dict_res1 = self.find_polynom_coefs1(init_poynom_obj1, self.last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", self.dict_prms1)

                            self.dict_prms1["add_curve_height1"] = 1.4

                            self.dict_prms1["max_loop_count1"] = 3000
                            #todo dict_res1 = self.find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)


                    if dict_res1.ContainsKey("error1"):
                        self.dict_prms1["max_loop_count1"] = max_loop_count1
                        start_coef1 = math.pow(10, -6)
                        factor_div_prop1 = 0.95
                        #todo dict_res1 = self.find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                        start_coef1 = math.pow(10, -5)
                        factor_div_prop1 = 0.9


                        if dict_res1.ContainsKey("error1"):
                            start_coef1 = math.pow(10, -7)
                            factor_div_prop1 = 0.9
                            #todo dict_res1 = self.find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms1)
                            start_coef1 = math.pow(10, -5)
                            factor_div_prop1 = 0.9

                    self.dict_prms1.Remove("check1")

                    if self.mode_fix_last_pxl1:
                        not_to_stop_find_last_ind1 = False

                        if dict_res1.ContainsKey("error1"):

                            was_error_in_fix_last_pxl1 = True
                            CGlobals1.add_to_txt_log1("error1")

            if dict_res1.ContainsKey("error1"):
                not_to_stop_find_last_ind1 = True

        dict_ret_res1["slice_curve_pxls_arr1"] = slice_curve_pxls_arr1
        dict_ret_res1["dict_res1"] = dict_res1
        max_diff_start_last = org_max_diff_start_last
        return dict_ret_res1












    def search_for_last_ind1(self,dict_min_derivative:Dictionary, start_ind1:int, delta_add_last_ind1:int, frame_pixels_arr1:ArrayList, last_delta_height1:float):


        last_ind1:int = self.start_ind1 + self.delta_add_last_ind1
        try:
            start_imd_derivate1 = dict_min_derivative[start_ind1]
        except:
            err1:int=1

        try:
            while start_imd_derivate1 <= dict_min_derivative[last_ind1]:
                self.last_ind1 += 1

        except:
            self.last_ind1 = dict_min_derivative.keys[dict_min_derivative.count - 1]


        curve_pxls_arr1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, start_ind1, last_ind1)


        cord_xy_start1b = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
        cord_xy_end1b  = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.count - 1)

        m1b:float = -(cord_xy_start1b[1] - cord_xy_end1b[1] - self.last_delta_height1) / (cord_xy_start1b[0] - cord_xy_end1b[0])

        while m1b > dict_min_derivative[start_ind1]:
            curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, self.start_ind1, self.last_ind1)


            cord_xy_start1b = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)
            cord_xy_end1b = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, curve_pxls_arr1.count - 1)

            m1b = -(cord_xy_start1b[1] - cord_xy_end1b[1] - self.last_delta_height1) / (cord_xy_start1b[0] - cord_xy_end1b[0])

            if m1b > dict_min_derivative[start_ind1]:
                self.last_ind1 += 1
            
            if self.last_ind1 >= frame_pixels_arr1.count:

                return (frame_pixels_arr1.count - 1)

        if self.last_ind1 >= frame_pixels_arr1.count:
            self.last_ind1 = frame_pixels_arr1.count - 1

        return last_ind1







    def dec_derivatives1(self,dict_min_derivative:Dictionary, dec_factor1:float):

        for deriv_ind1 in range(1 , dict_min_derivative.count):
            dict_min_derivative[dict_min_derivative.keys(deriv_ind1)] *= dec_factor1

        return dict_min_derivative




    def check_dist_curve_with_line_m2(self,org_curve1:ArrayList, start_ind1:int, end_ind1:int, start_measure_ind1:int, step_x1:float, m1:float, do_log1:bool = False):


        start_y_val1:float = 0
        last_ind_polynom_below_curve1:int
        last_ind_polynom_on_curve1:int
        first_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, start_ind1)
        max_dist_curve_above_polynom1:float = -1
        max_dist_curve_on_polynom1:float = -1
        line_curve1:ArrayList = ArrayList()
        curve_pxls1:ArrayList = ArrayList()
        start_delta_x1:int = -9999

        dict_max_y_of_curve1:Dictionary = Dictionary()
        dict_max_y_of_line1:Dictionary = Dictionary()

        dict_rect1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(org_curve1)



        org_curve1 = self.flip_curve_horizontal1(org_curve1)


        max_x1:float = dict_rect1["max_x1"]
        min_y1:float = dict_rect1["min_y1"]
        max_x2:float = dict_rect1["min_x1"] + 25


        start_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, start_ind1)

        if max_x2 == start_cord_xy1[0]:
            max_x2 += 1

        max_y1:float = (max_x1 - start_cord_xy1[0]) * m1 + start_cord_xy1[1]
        max_y2:float = (max_x2 - start_cord_xy1[0]) * m1 + start_cord_xy1[1]

        y_line1a:float = CGlobals1.form_obj1.markingfldimg_obj1.get_line_x_by_y1(m1, start_cord_xy1[1], (max_x1 - start_cord_xy1[0]))




        line_2_pixels:ArrayList = ArrayList()
        vec_3d_obj1:vec_3d1 = vec_3d1()
        vec_3d_obj1.p1 = point_3d1()
        vec_3d_obj1.p1.x1 = start_cord_xy1[0]
        vec_3d_obj1.p1.y1 = start_cord_xy1[1]
        vec_3d_obj1.p1.z1 = 0

        vec_3d_obj1.p2 = point_3d1()
        vec_3d_obj1.p2.x1 = start_cord_xy1[0]
        vec_3d_obj1.p2.y1 = start_cord_xy1[1]
        vec_3d_obj1.p2.z1 = -10

        line_2_pixels.Add(point_3d1(start_cord_xy1[0], start_cord_xy1[1], 0))
        line_2_pixels.Add(point_3d1(max_x2, max_y2, 0))

        line_2_pixels_2:ArrayList = ArrayList()

        line_2_pixels_2.Add(line_2_pixels[0].clone())
        line_2_pixels_2.Add(line_2_pixels[1].clone())
        CGlobals1.form_obj1.markingfldimg_obj1.rotate_3d_points_arr2(line_2_pixels_2, vec_3d_obj1, -90)


        vec_3d_obj2:vec_3d1 = vec_3d1()
        vec_3d_obj2.p1 = line_2_pixels_2[0]
        vec_3d_obj2.p2 = line_2_pixels_2[1]

        vec_3d_obj3:vec_3d1 = vec_3d1()


        dict_line1:Dictionary = vec_3d_obj2.create_2d_line_equ1()

        m_line2:float = (line_2_pixels_2[0].y1 - line_2_pixels_2[1].y1) / (line_2_pixels_2[0].x1 - line_2_pixels_2[1].x1)

        #y=m_line2*x1+b =>b=y-m_line2*x1
        rot_pxl_line1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points_in_double_with_len_limit1(line_2_pixels_2[0].x1, line_2_pixels_2[0].y1, line_2_pixels_2[1].x1, line_2_pixels_2[1].y1, 20)

        m_rot_line1:float = CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, rot_pxl_line1.count - 1)[1] - CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, 0)[1]
        m_rot_line1 /= CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, rot_pxl_line1.count - 1)[0] - CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, 0)[0]


        CGlobals1.form_obj1.markingfldimg_obj1.compute_cut_line_point1(dict_line1["m1"], dict_line1["b1"], m1, start_cord_xy1[1])


        pxls_line_vals1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points_in_double_with_len_limit1(start_cord_xy1[0], start_cord_xy1[1], max_x1, max_y1, 400)
        pxls_line1:ArrayList = ArrayList()
        if do_log1 :
            pxls_line1 = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points_with_len_limit(start_cord_xy1[0], start_cord_xy1[1], max_x1, max_y1, 1000)


        log_img1:bool = True
        bmp1d:Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, (255, 255, 255,0))

        if do_log1:

            CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(org_curve1, bmp1d, (250, 100, 50,0))
            CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pxls_line1, bmp1d, (50, 100, 150,0))
            CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(rot_pxl_line1, bmp1d, (250, 150, 150,0))



            bmp1d.SaveAs(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "log_line1\\line_m3_" + str(m1) + ".bmp")




        dict_line_eqa2:Dictionary = vec_3d_obj3.create_2d_line_equ_from_m1_and_xy_cord((start_cord_xy1[0], start_cord_xy1[1]), m1)


        ind1:int
        start_pxl_line_ind:int = 0

        max_dist_pxl_line_below_curve1:float = -1

        min_dist1:float = -1

        not_to_stop1:bool = True
        ind1 = start_ind1 + start_measure_ind1
        m_dist_line_arr1:ArrayList = ArrayList()
        while not_to_stop1:

            curve_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, ind1)

            dict_line_eqa1:Dictionary = vec_3d_obj3.create_2d_line_equ_from_m1_and_xy_cord((curve_cord_xy1[0], curve_cord_xy1[1]), m_line2)



            dict_cut_cord_xy1:Dictionary = CGlobals1.form_obj1.markingfldimg_obj1.compute_cut_line_point1(dict_line_eqa1["m1"], dict_line_eqa1["b1"], dict_line_eqa2["m1"], dict_line_eqa2["b1"])

            m_dist_line:float = (dict_cut_cord_xy1["y"] - curve_cord_xy1[1]) / abs((dict_cut_cord_xy1["x"] - curve_cord_xy1[0]))
            m_dist_line_arr1.Add(str(m_dist_line) + ",x=>" + str(dict_cut_cord_xy1["x"]) + "," + str(curve_cord_xy1[0]) + ",y=>" + str(dict_cut_cord_xy1["y"]) + "," + str(curve_cord_xy1[1]))
            y_val_line1:float = (curve_cord_xy1[0] - start_cord_xy1[0]) * m1 + start_cord_xy1[1]

            if m_dist_line < 0:
                dist2:float = CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy2((dict_cut_cord_xy1["x"], dict_cut_cord_xy1["y"]), (curve_cord_xy1[0], curve_cord_xy1[1]))

                if min_dist1 < dist2:
                    min_dist1 = dist2

            not_to_stop2:bool = True



            ind1 += 1
            if ind1 >= org_curve1.count - 1:
                not_to_stop1 = False

        return min_dist1














    def compute_derivate_of_pixel_on_curve(self,curve_pxls_arr1:ArrayList, pxl_ind1:int, start_measure_ind1:int,  max_dist_from_curve1:float = 0.05, start_m2:float = 907):

        start_ind2:int = pxl_ind1
        m2:float = self.check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + 100, start_measure_ind1, 1, start_m2)
        add_factor1:float = -1
        eps1:float = pow(10, -10)


        do_log1:str = ""

        while abs(add_factor1) >= eps1 or abs(abs(m2) - max_dist_from_curve1) > eps1:
            m2 = self.check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + 100, start_measure_ind1, 1, start_m2, do_log1)
            if m2 != -1:
                if abs(m2) > max_dist_from_curve1:
                    if add_factor1 < 0:
                        add_factor1 = abs(add_factor1) * 0.5

                else:
                    if add_factor1 > 0:
                        add_factor1 = abs(add_factor1) * -0.5

            else:

                add_factor1 = -abs(add_factor1)


            start_m2 += add_factor1
            if start_m2 < -0.2:
                start_m2 = -0.2



        m2 = self.check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + 100, start_measure_ind1, 1, start_m2, "")

        return start_m2










    def compute_derivative_of_curve2(self,new_curve1:ArrayList, path_to_save:str, dict_res_curve1:Dictionary):

        derivative_dict1:Dictionary = Dictionary()

        pxl_driv_ind1:int = 0
        not_to_stop1:bool = True
        last_derivatives1:float = -9999

        start_measure_ind1:int = 3

        nubmers_of_measure1:int = 9

        max_start_derivateive1 = math.tan(dict_res_curve1["first_derivative1"] * math.pi / 180)


        deriv_arr_str1:str = ""
        start_m2:float = 20

        max_dist_diff1:float = 0.1

        if self.curve_ind3 == 3:

            nubmers_of_measure1 = 5
            start_measure_ind1 = 2
            max_dist_diff1 = 0.01


        if self.curve_ind3 == 8:

            nubmers_of_measure1 = 5
            start_measure_ind1 = 4
            max_dist_diff1 = 0.001
        

        max_diff_angle_from_last:float = 0

        while not_to_stop1:



            derivative1_dict1:Dictionary = Dictionary()
            deriv_ind1:int = 0
            cur_start_measure_ind1:int = start_measure_ind1
            derivative1:float = 0
            for deriv_ind1 in range( cur_start_measure_ind1 , nubmers_of_measure1+1):
                try:
                    derivative1 = self.compute_derivate_of_pixel_on_curve(new_curve1, pxl_driv_ind1, deriv_ind1, max_dist_diff1, start_m2)
                    dummy1=1
                except:
                    derivative1 = last_derivatives1

                if derivative1 > max_start_derivateive1:
                    derivative1 = max_start_derivateive1

                derivative1_dict1[deriv_ind1] = derivative1


            new_start_measure_ind1:int = -1
            for deriv_ind1 in range(1 , derivative1_dict1.count):
                if derivative1_dict1[derivative1_dict1.keys[deriv_ind1 - 1]] != derivative1_dict1[derivative1_dict1.keys[deriv_ind1]]:

                    if new_start_measure_ind1 == -1:
                        new_start_measure_ind1 = derivative1_dict1.keys[deriv_ind1 - 1]




            if new_start_measure_ind1 == -1:
                new_start_measure_ind1 = derivative1_dict1.keys[derivative1_dict1.keys.count - 1]

            start_measure_ind1 = new_start_measure_ind1

            derivative1 = derivative1_dict1[start_measure_ind1]


            if derivative1 < 0:
                derivative1 = 0









            if last_derivatives1 == -9999:
                last_derivatives1 = derivative1
            else:
                if last_derivatives1 < derivative1:

                    if max_diff_angle_from_last < abs(derivative1 - last_derivatives1):
                        max_diff_angle_from_last = abs(derivative1 - last_derivatives1)

                    derivative1 = last_derivatives1
                else:
                    last_derivatives1 = derivative1





            if pxl_driv_ind1 == 0:
                derivative1 = math.tan(dict_res_curve1("first_derivative1") * math.pi / 180)

            derivative_dict1[pxl_driv_ind1] = derivative1

            deriv_arr_str1 += str(pxl_driv_ind1) + "," + str(derivative1) + "#"
            CGlobals1.form_obj1.markingfldimg_obj1.write_all_text_to_file(deriv_arr_str1,path_to_save)

            pxl_driv_ind1 += 1
            if pxl_driv_ind1 >= new_curve1.count - 1:
                not_to_stop1 = False

            if derivative1 <= 0:
                not_to_stop1 = False


        return derivative_dict1














    def clear_curve_by_monotonic_down1(self,curve_pxls_arr1:ArrayList):
        from CGlobals1 import CGlobals1
        
        bmp1:Bitmap = Bitmap(3000, 2000, (255, 255, 255,0))

        last_x_val1:int = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)[0]
        last_y_val1:int = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)[1]
        new_monotonic_curve1:ArrayList = ArrayList()
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp1, (200, 100, 50,0))

        new_monotonic_curve1.Add(curve_pxls_arr1[0])

        for i1 in range(0,curve_pxls_arr1.count):

            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, i1)
            if cord_xy1[0] > last_x_val1:
                if cord_xy1[1] > last_y_val1:
                    cord_xy1[1] = last_y_val1
                elif cord_xy1[1] < last_y_val1:
                    last_y_val1 = cord_xy1[1]

                last_x_val1 = cord_xy1[0]

                new_monotonic_curve1.Add(str(cord_xy1[0]) + "," + str(cord_xy1[1]))

        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(new_monotonic_curve1, bmp1, (20, 10, 50,0))
        bmp1.SaveAsave(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "monotonic1.bmp")
        return new_monotonic_curve1






    def fix_uncomplete_derivativs1(self,derivative_dict1:Dictionary):



        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        new_curve2:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_double_2d_pixels_arr1(path1 + "\\curve1.txt")


        if self.suffix_path1 == "_front_bottom_3_frame1":
            cur_last_derivative_of_curve1 = derivative_dict1(derivative_dict1.Count - 1)
            fix_last_derivative_of_curve1 = 0.33
            
            CGlobals1.form_obj1.markingfldimg_obj1.write_all_text_to_file(str(cur_last_derivative_of_curve1),path1 + "\\last_derivative_of_curve1.txt")
            for deriv_ind1 in range(derivative_dict1.count , new_curve2.count - 1+1):
                derivative_dict1[deriv_ind1] = derivative_dict1[deriv_ind1 - 1]

        else:
            for deriv_ind1 in range(derivative_dict1.count , new_curve2.count - 1+1):
                derivative_dict1[deriv_ind1] = derivative_dict1[deriv_ind1 - 1]

        return derivative_dict1




    def load_derivatives_of_curve1(self,path1:str):


        derivative_dict1:Dictionary = Dictionary()

        if os.path.isfile(path1) == True:

            derivatives_inds_str1:str =CGlobals1.form_obj1.markingfldimg_obj1.read_all_file_text(path1)
            if derivatives_inds_str1 != "":
                last_derivate_more_the_zero1:float = -9999
                derivative_ind1:int
                devivatives_inds1 = derivatives_inds_str1.Split("#")
                derivative_dict1[0] = 1
                for derivative_ind1 in range(1 ,len(devivatives_inds1) - 2+1):
                    derivative_dict1[int(devivatives_inds1[derivative_ind1].Split(",")[0])] = float(devivatives_inds1[derivative_ind1].Split(",")[1])

                    if last_derivate_more_the_zero1 == -9999:

                        last_derivate_more_the_zero1 = float(devivatives_inds1[derivative_ind1].Split(",")[1])
                    else:
                        if float(devivatives_inds1[derivative_ind1].Split(",")[1]) > 0:
                            last_derivate_more_the_zero1 = float(devivatives_inds1[derivative_ind1].Split(",")[1])



            return derivative_dict1




    def find_the_angle_for_turn_curve1(self,curve1:ArrayList):
        cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, curve1.count - 1)

        max_ind_angle1:int = -1
        max_angle1:int = 1



        for i1 in range(1, curve1.count):
            
            
            cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)
            if cord_xy2[0] != cord_xy1[0]:
                angle1:float = abs((math.atan((cord_xy2[1] - cord_xy1[1]) / abs((cord_xy2[0] - cord_xy1[0]))) * 180.0 / math.pi))
                if max_angle1 < angle1:
                    max_angle1 = angle1
                    max_ind_angle1 = i1

        dict_ret_res1:Dictionary = Dictionary()
        dict_ret_res1["max_ind_angle1"] = max_ind_angle1
        dict_ret_res1["max_angle1"] = max_angle1
        return dict_ret_res1













    def get_turn_pxl_point1(self,curve1:ArrayList, dist_treshold1:float):

        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        CGlobals1.delete_files1(path1 + "\\data1\\", "*.*")
        cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, curve1.count - 1)

        turn_log1:bool = False
        max_ind_angle1:int = 0
        max_angle1:float = 1


        vec_3d_obj1:vec_3d1 = vec_3d1()
        curve_rot1:ArrayList=None

        not_to_stop1:bool=True
        curve2:ArrayList = curve1.clone()
        bmp5:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        ind1:int = 1
        last_max_ind_angle1:int = -1
        max_dist_arr1:ArrayList = ArrayList()
        max_angle_ind1_arr1:ArrayList = ArrayList()
        res1_arr1:ArrayList = ArrayList()

        last_max_dist1:float = -1
        last_max_dist_over_1:int = -1
        cord_xy4=None
        while not_to_stop1:

            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve2, 0)
            cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve2, curve2.count - 1)

            vec_3d_obj1.p1 = point_3d1()
            vec_3d_obj1.p1.x1 = cord_xy1[0]
            vec_3d_obj1.p1.y1 = cord_xy1[1]


            vec_3d_obj1.p2 = point_3d1()
            vec_3d_obj1.p2.x1 = cord_xy1[0]
            vec_3d_obj1.p2.y1 = cord_xy1[1]
            vec_3d_obj1.p2.z1 = -10


            dict_ret_res1:Dictionary = self.find_the_angle_for_turn_curve1(curve2)
            curve_rot1 = CMarkingFieldInImageUtils1.rotate_2d_pixels_arr(curve2, vec_3d_obj1, dict_ret_res1["max_angle1"])

            if turn_log1:
                bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, (255, 255, 255,0))
                CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_rot1, bmp5, (24, 230, 50,0))


            ind1 += 1

            max_dist1:float = -1

            for i1 in range(0 , dict_ret_res1["max_ind_angle1"]+1):
                cord_xya = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_rot1, i1)

                if cord_xya[1] > cord_xy1[1]:
                    if max_dist1 < abs(cord_xya[1] - cord_xy1[1]):
                        max_dist1 = abs(cord_xya[1] - cord_xy1[1])


            curve2.RemoveAt(0)

            if abs(last_max_ind_angle1 - dict_ret_res1["max_ind_angle1"]) >= 5:
                last_max_ind_angle1 = -1
            else:
                last_max_ind_angle1 = dict_ret_res1["max_ind_angle1"]




            if max_dist1 != -1:
                to_add1:bool = True
                if max_angle_ind1_arr1.count > 0:

                    avg_delta1:float = 0

                    if max_angle_ind1_arr1.count > 10:
                        for i2 in range( max_angle_ind1_arr1.count - 6 , max_angle_ind1_arr1.count - 2+1):
                            avg_delta1 += abs(max_angle_ind1_arr1[i2] - max_angle_ind1_arr1[i2 + 1])

                        avg_delta1 /= 5

                if to_add1:
                    max_dist_arr1.Add(max_dist1)
                    max_angle_ind1_arr1.Add(dict_ret_res1["max_ind_angle1"])

                    res1_arr1.Add(str(dict_ret_res1["max_ind_angle1"]) + "   ,   " + str(ind1) + "   ,   " + str(max_dist1))


                    last_X_avg_dist1:float=0

                    if max_dist_arr1.count > 10:

                        c3:float = 0
                        for i3 in range( 0 , 6+1):
                            last_X_avg_dist1 += max_dist_arr1[max_dist_arr1.count - 1 - i3]
                            c3 += 1
                        last_X_avg_dist1 /= c3

                    if last_X_avg_dist1 >= 1:

                        last_max_dist_over_1 = ind1
                        cord_xy4 = CGlobals1.get_cord_xy_in_pixels_arr1(curve2, 0)

                        if turn_log1:
                            bmp5.SaveAs(path1 + "\\data1\\" + "frame4a_org1_" + str(ind1) + ".bmp")


            if curve_rot1.count <= 5:
                not_to_stop1 = False



        bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve1, bmp5, (24, 230, 50,0))
        cord_xy3 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, curve1.count - curve2.count)

        ind3:int = last_max_dist_over_1

        if ind3 < 7 or abs(curve1.count - ind3) < 7:
            dict_res_ret2:Dictionary = Dictionary()
            dict_res_ret2["no_turn_pixel"] = True
            return dict_res_ret2

        cord_xy3 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, cord_xy4[2])
        bmp5.SaveAs(path1 + "\\data1\\" + "frame4a_org1__a0.bmp")
        CGlobals1.draw_sqr_around_pixels2(bmp5, cord_xy3[0], cord_xy3[1], 3, (200, 50, 100,0))
        bmp5.SaveAs(path1 + "\\data1\\" + "frame4a_org1__a.bmp")

        dict_res_ret1:Dictionary = Dictionary()
        dict_res_ret1["cord_xy3"] = cord_xy4
        dict_res_ret1["last_max_dist_over_1"] = last_max_dist_over_1
        dict_res_ret1["ind1"] = ind1



        return dict_res_ret1









    def find_turn_pxl_point1(self,curve1:ArrayList):

        cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, curve1.count - 1)

        disty_treshold1:float = 1.2
        dict_res_ret1:Dictionary = self.get_turn_pxl_point1(curve1, disty_treshold1)

        vec_3d_obj1:vec_3d1 = vec_3d1()

        vec_3d_obj1.p1 = point_3d1()
        vec_3d_obj1.p1.x1 = cord_xy1[0]
        vec_3d_obj1.p1.y1 = cord_xy1[1]


        vec_3d_obj1.p2 = point_3d1()
        vec_3d_obj1.p2.x1 = cord_xy1[0]
        vec_3d_obj1.p2.y1 = cord_xy1[1]
        vec_3d_obj1.p2.z1 = -10

        rot_curve1:ArrayList = CMarkingFieldInImageUtils1.rotate_2d_pixels_arr(curve1, vec_3d_obj1, 180)
        rot_curve1.Reverse()
        dict_res_ret2:Dictionary = self.get_turn_pxl_point1(rot_curve1, disty_treshold1)


        cord_xyb = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, int((dict_res_ret1["cord_xy3"][2] + dict_res_ret2["cord_xy3"][2]) / 2))

        turn_pixel_state1:Dictionary = Dictionary()

        turn_pixel_state1["turn_pixel_ind_center1"] = (dict_res_ret1["cord_xy3"][2] + dict_res_ret2["cord_xy3"][2]) / 2
        turn_pixel_state1["turn_pixel_ind1"] = dict_res_ret1["cord_xy3"][2]
        turn_pixel_state1["turn_pixel_ind2"] = dict_res_ret2["cord_xy3"][2]


        cord_xyb1 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, dict_res_ret1["cord_xy3"][2])
        cord_xyb2 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, dict_res_ret2["cord_xy3"][2])

        turn_angle1a:float = math.atan(abs((cord_xyb1[1] - cord_xyb2[1]) / (cord_xyb1[0] - cord_xyb2[0]))) * 180 / math.pi

        if dict_res_ret1["cord_xy3"][2] < turn_pixel_state1["turn_pixel_ind_center1"]:
            cord_xyb1 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, turn_pixel_state1["turn_pixel_ind_center1"] - 7)
            cord_xyb2 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, turn_pixel_state1["turn_pixel_ind_center1"] + 7)

        else:
            cord_xyb1 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, turn_pixel_state1["turn_pixel_ind_center1"] + 3)
            cord_xyb2 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, turn_pixel_state1["turn_pixel_ind_center1"] - 3)

        turn_angle1:float = math.atan(abs((cord_xyb1[1] - cord_xyb2[1]) / (cord_xyb1[0] - cord_xyb2[0]))) * 180 / math.pi

        turn_pixel_state1["turn_angle1"] = turn_angle1

        return turn_pixel_state1





        
        
    def flip_curve_horizontal1(self,curve_pxl_arr1:ArrayList):
        dict_rect1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxl_arr1)
        max_x1:float = dict_rect1["max_x1"]
        min_y1:float = dict_rect1["min_y1"]
        max_y1:float = dict_rect1["max_y1"]

        center_y1:float = math.floor((min_y1 + max_y1) / 2)
        flip_curve1:ArrayList = ArrayList()

        ind1:int
        first_cord_xy1a = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, 0)
        for ind1 in range( 0 , curve_pxl_arr1.count ):
            cord_xy1:ArrayList=ArrayList()
            cord_xy1.arr = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, ind1)
            
            new_y1:int = cord_xy1[1]
            if cord_xy1[1] > center_y1:
                new_y1 = center_y1 - abs(cord_xy1[1] - center_y1)
            elif cord_xy1[1] < center_y1:
                new_y1 = center_y1 + abs(cord_xy1[1] - center_y1)

            if cord_xy1.count == 3:
                flip_curve1.Add(str(cord_xy1[0]) + "," + str(new_y1) + "," + str(cord_xy1[2]))
            else:
                flip_curve1.Add(str(cord_xy1[0]) + "," + str(new_y1))


        return flip_curve1


        
        
    def analize_polynom2(self):
        
            
            
        x5=9
        dict1 =Dictionary()
        dict1["x5"]=98
        locals().update({'x5':97})
        #inspect.currentframe()["x5"]=981
        #sys._getframe(1).f_locals.update(dict1.dict)
        #sys._getframe(1).f_locals.update(dict1.dict)
        inspect.currentframe().f_locals["x5"]=45
        inspect.currentframe().f_back.f_locals["x5"]=11
        x7=inspect.currentframe().f_locals["x5"]

        dict_polynoms1=Dictionary()
        self.init_poynom_obj1.coef_arr1.Add(0)
        self.init_poynom_obj1.coef_arr1.Add(0.9)
        
        self.init_poynom_obj1.coef_arr1.Add(0.00001)
        self.init_poynom_obj1.coef_arr1.Add(0.00001)
        self.init_poynom_obj1.create_derivative1()
        
        
        dict_res1:Dictionary=None
        
        try:        
            dict_res1=self.pre_proccessing_curve2()
            #temp
            return 1
        except:
            raise
        
        
        
        
        
        if dict_res1["derivative_dict1"][dict_res1["derivative_dict1"].count - 1] <= 0:
            dummy1=1
        else:
            if self.cur_dict_slices_curves1["curves_arr2"][self.curve_ind3].ContainsKey("turn_pxl"):


                neightboor_ind_turn_pxl1:int = -1
                if self.cur_dict_slices_curves1["curves_arr2"][self.curve_ind3 - 1].ContainsKey("turn_pxl"):
                    neightboor_ind_turn_pxl1 = self.curve_ind3 - 1

                if self.cur_dict_slices_curves1["curves_arr2"][self.curve_ind3 + 1].ContainsKey("turn_pxl"):
                    neightboor_ind_turn_pxl1 = self.curve_ind3 + 1




                dict_neighrboor_curve1:Dictionary = self.read_json_of_curve_by_ind1(neightboor_ind_turn_pxl1)
                dict_curve_res1:Dictionary = self.cur_dict_slices_curves1["curves_arr2"][neightboor_ind_turn_pxl1]


                last_derivative_of_cur_curve1:float = dict_res1["derivatives_arr1"][dict_res1["derivatives_arr1"].count - 1]
                last_derivative_of_neighrboor_curve1:float = dict_neighrboor_curve1["derivatives_arr1"][dict_neighrboor_curve1["derivatives_arr1"].count - 1]
                cur_last_derivative_of_curve1 = min(last_derivative_of_cur_curve1, last_derivative_of_neighrboor_curve1)
                cur_last_derivative_of_curve1 = max(last_derivative_of_cur_curve1, last_derivative_of_neighrboor_curve1)

                self.add_derivative_by_last_derivative1(dict_res1["derivatives_arr1"], cur_last_derivative_of_curve1)
                dict_res1["derivative_dict1"] = dict_res1["derivatives_arr1"]

                last_derivatives_val_of_curve1 = cur_last_derivative_of_curve1

        self.delta_add_last_ind1 = CConfig1.delta_add_last_ind1
        self.min_dist_last_derivative1 = CConfig1.min_dist_last_derivative1
        self.min_dist_down_last_derivative1 = CConfig1.min_dist_down_last_derivative1
        self.min_dist_up_last_derivative1 = CConfig1.min_dist_up_last_derivative1
        self.min_diff_last_derivative1 = CConfig1.min_diff_last_derivative1
        self.max_add_curve_height1 = CConfig1.max_add_curve_height1






        curve_pxls_arr1 = dict_res1("curve_pxls_arr1")




        dict_min_derivative = dict_res1("derivatives_arr1")






        dict_min_derivative = self.dec_derivatives1(dict_min_derivative, 1)


        bmp5:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp5, (24, 230, 50,0))
        bmp5.SaveAsave(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "cur_curve1.bmp")



        rect_of_curve1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)
        w1:int = abs(rect_of_curve1["max_x1"] - rect_of_curve1["min_x1"]) + 1
        h1:int = abs(rect_of_curve1["max_y1"] - rect_of_curve1["min_y1"]) + 1


        self.last_ind1 = 0

        self.start_ind1 = 0


        self.last_ind1 = self.start_ind1 + self.delta_add_last_ind1

        start_m1:float = 1



        derivate_arr1 = ArrayList()

        dict_rect_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr1)
        do_right_corner1:bool = True


        self.curve_last_ind1 = curve_pxls_arr1.count - 1
        last_derivate1 = dict_min_derivative[start_ind1]


        all_polynom_result_arr1:ArrayList = ArrayList()


        self.dict_prms1["curve_ind1"] = 0
        self.dict_prms1["curve_ind1"] += 1

        dict_res1["error1"] = True
        max_proportion1:float = -1
        dir_add_to_last_ind1:int = 1
        self.last_delta_height1 = 0
        self.last_add_height1 = 0
        last_last_ind1:int = last_ind1


        self.org_start_ind = self.start_ind1



        self.polynom_curves_arr1 = ArrayList()

        m1:float = 99

        self.last_ind1 = self.search_for_last_ind1(self.dict_min_derivative, self.start_ind1, self.delta_add_last_ind1, self.curve_pxls_arr1, self.last_delta_height1)

        count_loop1:int = 0



        self.last_derivate1 = dict_min_derivative(self.start_ind1)






        sum_width_of_cur_curve1:int=0
        str_curve_ind1:str=""
        find_polynom_coefs1_loop1:int=0

        slice_curve_pxls_arr1:ArrayList = ArrayList()



        dict_prms1_arr1 = ArrayList()


        count_go_back1:int=0

        self.last_add_curve_width1_val1 = 9999
        self.last_add_curve_height1_val1 = 9999

        self.last_min_diff_and_derivs_arr1 = ArrayList()


        self.arr_min_diff_h1_and_end_deriv_arr1 = ArrayList()

        self.arr_min_diff_h1_arr1 = ArrayList()
        self.arr_end_deriv_arr1 =  ArrayList()

        self.min_diff_h1_and_derivs_arr1 = ArrayList()



        self.last_min_diff_h1_val1 = 9999
        self.last_end_deriv_val1 = 9999

        self.last_dict_prms_str1 = ""





        self.add_last_add_height1 = ""
        dict_res_stack1c:Dictionary = Dictionary()
        self.was_back1=False
        while dict_res1.ContainsKey("error1"):
            dict_res_stack1c = Dictionary()

            if self.arrive_to_end1 and not self.was_back1:
                self.results_stack_arr1.RemoveAt(self.results_stack_arr1.count - 1)


                dict_res_stack1b:Dictionary = self.results_stack_arr1[self.results_stack_arr1.count - 1]
                #todo dict_polynoms1 = CGlobals1.json_to_dict_prms1(dict_res_stack1b["dict_polynoms1"])

                #todo dict_prms1 = CGlobals1.json_to_dict_prms1(dict_res_stack1b["dict_prms1"])
                self.last_add_height1 = dict_res_stack1b["last_add_height1"]
                self.start_ind1 = dict_res_stack1b["start_ind1"]
                self.last_ind1 = dict_res_stack1b["last_ind1"]
                self.last_derivate1 = dict_res_stack1b["last_derivate1"]

                self.mode_fix_last_pixel1 = dict_res_stack1b["mode_fix_last_pixel1"]



                self.last_go_back_ind1 = dict_res_stack1b["last_go_back_ind1"]
                self.last_delta_height1 = dict_res_stack1b["last_delta_height1"]

                self.found_good_derivative_in_more_height1 = dict_res_stack1b["found_good_derivative_in_more_height1"]
                self.mode1 = dict_res_stack1b["mode1"]

                self.is_last_sub_curve1 = dict_res_stack1b["is_last_sub_curve1"]

                self.force_over_dict_res1 = dict_res_stack1b["force_over_dict_res1"]
                self.min_min_diff_h1 = dict_res_stack1b["min_min_diff_h1"]
                self.mode_fix_last_pxl1 = dict_res_stack1b["mode_fix_last_pxl1"]


                while self.dict_prms1_arr2.count > dict_res_stack1b["dict_prms1_arr2_count"]:
                    self.dict_prms1_arr2.RemoveAt[self.dict_prms1_arr2.count - 1]

                while self.dict_prms1_arr1.count > dict_res_stack1b["dict_prms1_arr1_count"]:
                    self.dict_prms1_arr1.RemoveAt[dict_prms1_arr1.Count - 1]

                while self.polynom_result_arr1.count > dict_res_stack1b["polynom_result_arr1_count"]:
                    self.polynom_result_arr1.RemoveAt[self.polynom_result_arr1.Count - 1]



                self.results_stack_arr1.RemoveAt[self.results_stack_arr1.count - 1]

                self.was_back1 = True





            dict_res_stack1:Dictionary = Dictionary()


            #todo dict_res_stack1["dict_polynoms1"] = CGlobals1.dict_prm_to_json_str(dict_polynoms1)
            #todo dict_res_stack1["dict_prms1"] = CGlobals1.dict_prm_to_json_str(dict_prms1)
            dict_res_stack1["last_add_height1"] = self.last_add_height1

            dict_res_stack1["start_ind1"] = self.start_ind1
            dict_res_stack1["last_ind1"] = self.last_ind1
            dict_res_stack1["last_derivate1"] = self.last_derivate1
            dict_res_stack1["mode_fix_last_pixel1"] = self.mode_fix_last_pixel1

            dict_res_stack1["dict_prms1_arr2_count"] = self.dict_prms1_arr2.count
            dict_res_stack1["dict_prms1_arr1_count"] = self.dict_prms1_arr1.count
            dict_res_stack1["polynom_result_arr1_count"] = self.polynom_result_arr1.count
            dict_res_stack1["last_go_back_ind1"] = self.last_go_back_ind1
            dict_res_stack1["last_delta_height1"] = self.last_delta_height1
            dict_res_stack1["found_good_derivative_in_more_height1"] = self.found_good_derivative_in_more_height1
            dict_res_stack1["mode1"] = self.mode1
            dict_res_stack1["is_last_sub_curve1"] = self.is_last_sub_curve1
            dict_res_stack1["force_over_dict_res1"] = self.force_over_dict_res1
            dict_res_stack1["min_min_diff_h1"] = self.min_min_diff_h1
            dict_res_stack1["mode_fix_last_pxl1"] = self.mode_fix_last_pxl1

            self.count_loop1 += 1
            
            if self.mode_fix_last_pixel1:
                if self.dict_prms1_arr2.count > self.polynom_result_arr1.count:
                    
                    #todo dict_prm4:Dictionary = CGlobals1.json_to_dict_prms1(dict_prms1_arr2[polynom_result_arr1.count])
                    self.start_ind1 = self.dict_prm4["start_ind1"]
                    self.last_ind1 = self.dict_prm4["last_ind1"]

            self.slice_curve_pxls_arr1 = CGlobals1.get_arr_from_ind_to_ind1(self.curve_pxls_arr1, self.start_ind1, self.last_ind1)



            dict_rect1a:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(slice_curve_pxls_arr1)
            proportion1:float = abs(dict_rect1a["min_y1"] - dict_rect1a["max_y1"]) / abs(dict_rect1a["min_x1"] - dict_rect1a["max_x1"])

            m1 = self.dict_min_derivative(self.start_ind1)



            self.min_last_derivative1 = -1
            ind_of_derivative1:int = self.last_ind1
            while not dict_min_derivative.ContainsKey(ind_of_derivative1):
                ind_of_derivative1 -= 1

            min_last_derivative1 = dict_min_derivative[ind_of_derivative1]


            m1b = compute_m1b(slice_curve_pxls_arr1, last_delta_height1)



            found_good_derivative_in_more_height1 = False







            self.dict_prms1["org_curve1"] = curve_pxls_arr1.clone()

            self.dict_prms1["last_delta_height1"] = self.last_delta_height1
            self.dict_prms1["last_add_height1"] = self.last_add_height1
            if not self.dict_prms1.ContainsKey("add_width_to_curve1"):
                self.dict_prms1["add_width_to_curve1"] = 0



            if not self.dict_prms1.ContainsKey("curve_ind1"):

                self.dict_prms1["curve_ind1"] = 0


            dict_res_find_last_ind1_with_m1b:Dictionary = self.find_last_ind1_with_m1b()
            if self.mode_fix_last_pixel1:
                dict_res_find_last_ind1_with_m1b["dict_res1"]["count_loop1"] = self.find_polynom_coefs1_loop1
                self.results_stack_arr1.Add(dict_res_stack1)


                if not dict_res_stack1c_dict1.ContainsKey(self.results_stack_arr1.Count) and (arrive_to_end_ind1 == -1 or results_stack_arr1.count <= arrive_to_end_ind1):
                    #todo dict_res_stack1c["dict_polynoms1"] = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(dict_polynoms1))
                    #todo dict_res_stack1c["dict_prms1"] = CGlobals1.dict_prm_to_json_str(dict_prms1)
                    dict_res_stack1c["last_add_height1"] = self.last_add_height1

                    dict_res_stack1c["start_ind1"] = self.start_ind1
                    dict_res_stack1c["last_ind1"] = self.last_ind1
                    dict_res_stack1c["last_derivate1"] = self.last_derivate1
                    dict_res_stack1c["mode_fix_last_pixel1"] = self.mode_fix_last_pixel1

                    dict_res_stack1c["dict_prms1_arr2_count"] = self.dict_prms1_arr2.count
                    dict_res_stack1c["dict_prms1_arr1_count"] = self.dict_prms1_arr1.count
                    dict_res_stack1c["last_go_back_ind1"] = self.last_go_back_ind1
                    dict_res_stack1c["last_delta_height1"] = self.last_delta_height1
                    dict_res_stack1c["found_good_derivative_in_more_height1"] = self.found_good_derivative_in_more_height1
                    dict_res_stack1c["mode1"] = self.mode1
                    dict_res_stack1c["is_last_sub_curve1"] = self.is_last_sub_curve1
                    #todo dict_res_stack1c["dict_res1"] = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(dict_res_find_last_ind1_with_m1b["dict_res1"]))
                    dict_res_stack1c["force_over_dict_res1"] = self.force_over_dict_res1
                    dict_res_stack1c["min_min_diff_h1"] = self.min_min_diff_h1
                    dict_res_stack1c_dict1[self.results_stack_arr1.count] = self.dict_res_stack1c


                #todo dict_res_stack1["dict_res1"] = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(dict_res_find_last_ind1_with_m1b["dict_res1"]))
                self.add_polynom_result_to_list1(dict_res_find_last_ind1_with_m1b["dict_res1"])
                #todo dict_res_size1:Dictionary = self.get_polinom_size1(polynom_result_arr1)

            self.dict_prms1["end_pixel_ind1"] = self.last_ind1

            force_last_add_height1:float = 0
            force_last_add_height1 = 0

            dict_res1 = dict_res_find_last_ind1_with_m1b["dict_res1"]
            self.slice_curve_pxls_arr1 = dict_res_find_last_ind1_with_m1b["slice_curve_pxls_arr1"]

            if self.mode_fix_last_pixel1:


                if (self.last_derivate1 > m1b or self.last_go_back_ind1 != -1):

                    dict_res1["count_loop1"] = find_polynom_coefs1_loop1
                    find_polynom_coefs1_loop1 += 1
                    all_polynom_result_arr1.Add(dict_res1)

                    if dict_res1.ContainsKey("end_derivative2"):

                        if ((abs(dict_res1["end_derivative2"] - self.min_last_derivative1) > self.min_dist_last_derivative1 or \
                           not ((dict_res1["end_derivative2"] < self.min_last_derivative1 and abs(dict_res1["end_derivative2"] - self.min_last_derivative1) < self.min_dist_down_last_derivative1 or \
                             dict_res1("end_derivative2") > self.min_last_derivative1 and abs(dict_res1["end_derivative2"] - self.min_last_derivative1) < self.min_dist_up_last_derivative1))) or \
                            dict_res1["min_diff_h1"] > 2) and mode1 == "":


                            to_find_derivate_in_polynom:bool=True


                            polynom_obj:CPolynom2 = dict_res1["polynom_obj1"]
                            last_end_x_polynom1:float = dict_res1["last_end_x_polynom1"]
                            width_of_curve1:float = dict_res1["width_of_curve1"]
                            y_val1a:float = polynom_obj.get_y_val1[self.last_end_x_polynom1]
                            y_val1b:float = polynom_obj.get_y_val1[self.last_end_x_polynom1 - self.width_of_curve1]
                            org_min_diff_h1:float = dict_res1["min_diff_h1"]
                            first_ok_x_ind1:int = -1



                            found_ok_polynom1:bool=False
                            dict_prms2:Dictionary = Dictionary()

                            dict_prms2["last_delta_height1"] = dict_prms1["last_delta_height1"]
                            dict_prms2["last_add_height1"] = dict_prms1["last_add_height1"]
                            dict_prms2["curve_ind1"] = dict_prms1["curve_ind1"]
                            dict_prms2["add_width_to_curve1"] = dict_prms1["add_width_to_curve1"]

                            dict_res1b:Dictionary = dict_res1




                            if not ((abs(dict_res1["end_derivative2"] - self.min_last_derivative1) > self.min_dist_last_derivative1) or \
                                ((dict_res1["end_derivative2"] < min_last_derivative1 and abs(dict_res1["end_derivative2"] - self.min_last_derivative1) < self.min_dist_down_last_derivative1 or \
                                dict_res1["end_derivative2"] > min_last_derivative1 and abs(dict_res1["end_derivative2"] - self.min_last_derivative1) < self.min_dist_up_last_derivative1))) and self.first_ok_x_ind1 == -1 :



                                not_to_stop1:bool=True   
                                dict_prms2["add_curve_height1"] = 0
                                last_end_derivative2:float = dict_res1["end_derivative2"]
                                factor_dec_add_height1:float = 0.05
                                last_dir1:int=0
                                last_deriv_val1:float = -1
                                loop_num3:int = 0
                                
                                while not_to_stop1:
                                    loop_num3 += 1

                                    if dict_res1b["end_derivative2"] > self.min_last_derivative1:
                                        if last_dir1 == 0:
                                            last_dir1 = -1
                                        elif last_dir1 == 1:
                                            self.factor_dec_add_height1 /= 2

                                        dict_prms2["add_curve_height1"] -= factor_dec_add_height1

                                    else:
                                        if last_dir1 == 0:
                                            last_dir1 = 1
                                        elif last_dir1 == -1:
                                            self.factor_dec_add_height1 /= 2


                                        dict_prms2["add_curve_height1"] += factor_dec_add_height1



                                    if force_last_add_height1 != 0:
                                        dict_prms2["add_curve_height1"] = force_last_add_height1

                                    dict_prms2["check1"] = True



                                    #todo dict_res1b = self.find_polynom_coefs1(init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms2)


                                    if dict_res1b.ContainsKey("error1"):
                                        start_coef1 = math.pow(10, -7)
                                        dict_res1b = self.find_polynom_coefs1(self.init_poynom_obj1, last_derivate1, 99, slice_curve_pxls_arr1, "only_start_derivate1", dict_prms2)
                                        start_coef1 = math.pow(10, -5)



                                    dict_prms2.Remove("check1")
                                    dict_res1b["start_ind1"] = start_ind1
                                    dict_res1b["last_ind1"] = last_ind1
                                    dict_res1b["count_loop1"] = find_polynom_coefs1_loop1
                                    find_polynom_coefs1_loop1 += 1
                                    all_polynom_result_arr1.Add(dict_res1b)

                                    if dict_res1b.ContainsKey("end_derivative2"):

                                        if ((dict_res1b["end_derivative2"] < self.min_last_derivative1 and abs(dict_res1b["end_derivative2"] - self.min_last_derivative1) < self.min_dist_down_last_derivative1 or \
                                                dict_res1b["end_derivative2"] > self.min_last_derivative1 and abs(dict_res1b["end_derivative2"] - self.min_last_derivative1) < self.min_dist_up_last_derivative1) or force_over_dict_res1 or force_last_add_height1 != 0) and first_ok_x_ind1 == -1:





                                            polynom_obj2:CPolynom2 = dict_res1b["polynom_obj1"]
                                            h3:float = polynom_obj2.get_y_val1(dict_res1b["start_x_val1"]) - polynom_obj2.get_y_val1(dict_res1b["end_x_val1"])
                                            dict_res1 = dict_res1b
                                            to_stop1 = 1
                                            found_ok_polynom1 = True

                                            found_good_derivative_in_more_height1=True
                                            
                                            dict_prms1["add_curve_height1"] = dict_prms2["add_curve_height1"]



                                        else:
                                            if abs(dict_prms2["add_curve_height1"]) >= self.max_add_curve_height1:
                                                not_to_stop1 = False
                                            
                                        last_end_derivative2 = dict_res1b("end_derivative2")
                                    else:
                                        not_to_stop1 = False





                    if dict_res1.ContainsKey("error1"):
                        self.last_ind1 += self.dir_add_to_last_ind1 * 10
                        if self.last_ind1 >= self.curve_last_ind1:
                            self.last_ind1 = self.curve_last_ind1

                        #todo CGlobals1.add_to_txt_log2("(1)start_ind1=" + start_ind1.ToString() + ",last_ind1=" + str(last_ind1) + ",curve_last_ind1=" + str(curve_last_ind1))
                    elif not ((dict_res1["end_derivative2"] < self.min_last_derivative1 and abs(dict_res1["end_derivative2"] - self.min_last_derivative1) < self.min_dist_down_last_derivative1 or \
                            dict_res1["end_derivative2"] > self.min_last_derivative1 and abs(dict_res1["end_derivative2"] - self.min_last_derivative1) < self.min_dist_up_last_derivative1)) and not force_over_dict_res1 and force_last_add_height1 == 0:

                        self.last_ind1 += self.dir_add_to_last_ind1 * 1
                        if self.last_ind1 >= self.curve_last_ind1:
                            self.last_ind1 = self.curve_last_ind1
                            self.dir_add_to_last_ind1 = -1

                        dict_res1["error1"] = True
                        #todo CGlobals1.add_to_txt_log2("(2)start_ind1=" + str(start_ind1) + ",last_ind1=" + str(last_ind1) + ",curve_last_ind1=" + str(curve_last_ind1))
                    else:

                        self.results_stack_arr1.Add(dict_res_stack1)

                        if not self.dict_res_stack1c_dict1.ContainsKey(self.results_stack_arr1.Count) and (arrive_to_end_ind1 == -1 or self.results_stack_arr1.Count <= self.arrive_to_end_ind1):
                            #todo dict_res_stack1c["dict_polynoms1"] = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(dict_polynoms1))

                            #todo dict_res_stack1c["dict_prms1"] = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(dict_prms1))
                            dict_res_stack1c["last_add_height1"] = self.last_add_height1

                            dict_res_stack1c["start_ind1"] = self.start_ind1
                            dict_res_stack1c["last_ind1"] = self.last_ind1
                            dict_res_stack1c["last_derivate1"] = self.last_derivate1
                            dict_res_stack1c["mode_fix_last_pixel1"] = self.mode_fix_last_pixel1

                            dict_res_stack1c["dict_prms1_arr2_count"] = self.dict_prms1_arr2.Count
                            dict_res_stack1c["dict_prms1_arr1_count"] = self.dict_prms1_arr1.Count
                            dict_res_stack1c["last_go_back_ind1"] = self.last_go_back_ind1
                            dict_res_stack1c["last_delta_height1"] = self.last_delta_height1
                            dict_res_stack1c["found_good_derivative_in_more_height1"] = self.found_good_derivative_in_more_height1
                            dict_res_stack1c["mode1"] = self.mode1
                            dict_res_stack1c["is_last_sub_curve1"] = self.is_last_sub_curve1
                            dict_res_stack1c["min_min_diff_h1"] = self.min_min_diff_h1

                            #todo dict_res_stack1c["dict_res1"] = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(dict_res1))
                            self.dict_res_stack1c_dict1[self.results_stack_arr1.count] = dict_res_stack1c


                        #todo dict_res_stack1["dict_res1"] = CGlobals1.json_to_dict_prms1(CGlobals1.dict_prm_to_json_str(dict_res1))

                        #todo self.add_polynom_result_to_list1(dict_res1)



                        if self.last_ind1 < self.curve_last_ind1:
                            dict_res1["error1"] = True
                            self.start_ind1 = self.last_ind1
                            try:
                                self.last_ind1 = self.search_for_last_ind1(dict_min_derivative, self.start_ind1, self.delta_add_last_ind1, curve_pxls_arr1, self.last_delta_height1)
                                dummy2:int=1
                            except:
                                
                                self.last_ind1 = self.search_for_last_ind1(dict_min_derivative, start_ind1, delta_add_last_ind1, curve_pxls_arr1, last_delta_height1)
                                dummy2:int=1
                                
                            try:
                                if dict_min_derivative[self.last_ind1] <= self.last_derivatives_val_of_curve1:
                                    end_of_curve1:bool=True  
                                    self.last_ind1 = self.curve_last_ind1


                                    if not self.mode_fix_last_pxl1:

                                        
                                        self.mode1 = "not_change_height1"
                                        self.force_over_dict_res1=True

                                        self.was_error_in_fix_last_pxl1 = False

                                        self.mode_fix_last_pxl1=True  
                                        self.mode_fix_last_pixel1 = True



                                

                            except:
                                err1:int=1

                            
                            self.last_last_ind1 = self.last_ind1
                            if self.last_ind1 >= self.curve_last_ind1:
                                self.last_ind1 = self.curve_last_ind1
                                is_last_sub_curve1 = True

                            
                            max_proportion1 = -1

                        self.dict_prms1["curve_ind1"] += 1

                    self.last_ind1 += self.dir_add_to_last_ind1 * 10


                if self.last_ind1 < self.start_ind1 + self.max_diff_start_last:
                    self.last_ind1 = self.last_last_ind1
                    self.dir_add_to_last_ind1 = 1

                if self.last_ind1 > self.curve_last_ind1:
                    self.last_ind1 = self.curve_last_ind1
                    dict_res1.Remove("error1")

                if self.dict_last_inds1.ContainsKey(self.polynom_result_arr1.count):
                    self.last_ind1 = self.dict_last_inds1[self.polynom_result_arr1.count]
                    

            if self.polynom_result_arr1.count > 0:
                if self.polynom_result_arr1[self.polynom_result_arr1.Count - 1]["last_ind1"] >= self.curve_last_ind1:
                    dict_res1["error1"] = True
                    if not self.arrive_to_end1:
                        arrive_to_end_ind1 = self.polynom_result_arr1.count

                if not self.arrive_to_end1:
                    #todo dict_res_gap_equal_zero1 = self.fix_last_pxl_for_gap_equal_zero()
                    dummy1:int=1


                if self.dict_res_gap_equal_zero1.ContainsKey("dict_res1_error1"):
                    dict_res1["error1"] = True

                if self.dict_res_gap_equal_zero1.ContainsKey("dict_res1_error1_remove"):
                    dict_res1.Remove("error1")




                if self.polynom_result_arr1[self.polynom_result_arr1.count - 1]["last_ind1"] < self.curve_last_ind1:
                    dict_res1["error1"] = True
            else:
                dict_res1["error1"] = True


        if not self.dict_res_gap_equal_zero1.ContainsKey("finish_gap_zero"):

            #todo CGlobals1.add_to_txt_log1("error2_finish_gap_zero")
            dummy2:int=1





























        
        
        
    def pre_proccessing_curve2(self):
        dict_ret_res2:Dictionary = Dictionary()
        
        if os.path.isfile(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_json_of_curves_slices1.txt") == True:
             str_json3 = CGlobals1.form_obj1.markingfldimg_obj1.read_all_file_text(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_json_of_curves_slices1.txt")
             json_obj1=json.loads(str_json3)
             
             for key in json_obj1.keys():
                 
                dict_json3=Dictionary()
        
        
        
        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        
        new_curve1:ArrayList=None
        dict_res_curve1:Dictionary=None
        if self.assembly_part1 == "lens1":
            #todo new_curve1 = cut_slice_of_curve_lens1()
            dummy1=1
        else:
        
            dict_slices_curves1:Dictionary = self.get_slices_of_curves1()
            #temp
            return 1
            
            cur_dict_slices_curves1 = dict_slices_curves1
            dict_res_curve1 = dict_slices_curves1["curves_arr2"][self.curve_ind3]

            dict_ret_res2["dict_res_curve1"] = dict_res_curve1
            new_curve1 = dict_res_curve1("cur_curve1")


            start_ind1b:int = CGlobals1.get_cord_xy_in_pixels_arr1(new_curve1, 0)[2]
            end_ind1b:int = CGlobals1.get_cord_xy_in_pixels_arr1(new_curve1, new_curve1.count - 1)[2]
            path_of_curves_inds1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame_curve_indexes_ranges1\\"
            CGlobals1.form_obj1.markingfldimg_obj1.write_all_text_to_file("1",path_of_curves_inds1 + str(CGlobals1.form_obj1.curve_ind1) + "_" + str(start_ind1b) + "_" + str(end_ind1b) + ".ind")




        dict_rect_new_curve1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(new_curve1)

        derivative_dict1:Dictionary = Dictionary()
        if os.path.isfile(path1 + "\\derivs1.txt") and not self.force_compute_derivs1:

            derivative_dict1 = self.load_derivatives_of_curve1(path1 + "\\derivs1.txt")


            new_curve2:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_double_2d_pixels_arr1(path1 + "\\curve1.txt")


            dict_rect_new_curve2:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(new_curve2)



            self.fix_uncomplete_derivativs1(derivative_dict1)



            dict_ret_res3:Dictionary = Dictionary()
            dict_ret_res3["derivatives_arr1"] = derivative_dict1
            dict_ret_res3["curve_pxls_arr1"] = new_curve2
            if self.suffix_path1 == "_front_bottom_4_frame1" :
                cur_last_derivative_of_curve1 = float(CGlobals1.form_obj1.markingfldimg_obj1.read_all_file_text(path_arr1[CGlobals1.form_obj1.inds_orders_arr1[CGlobals1.form_obj1.curve_ind1 - 1]] + "\\last_derivative_of_curve1.txt"))
                derivative_dict1[derivative_dict1.count - 1] = cur_last_derivative_of_curve1





            return dict_ret_res3





        if self.only_cut_silce1:
            return -2
            

        rect_of_curve1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(new_curve1)
        w1:int = abs(rect_of_curve1["max_x1"] - rect_of_curve1["min_x1"]) + 1
        h1:int = abs(rect_of_curve1["max_y1"] - rect_of_curve1["min_y1"]) + 1




        bmp5a:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(new_curve1, bmp5a, (24, 230, 50,0))
        bmp5a.SaveAs(path1 + "\\" + "before_close_hole1.bmp")

        dict_ret_res2["before_close_hole1"] = new_curve1.Clone()
        if self.curve_ind3 != 1:



            new_curve1 = CGlobals1.form_obj1.markingfldimg_obj1.find_hole_in_curve_by_max_width_and_min_deep1(new_curve1, 3, 100, 0.05, 0.05)
            dict_ret_res2["close_hole1a"] = new_curve1.Clone()
            bmp5a = CGlobals1.create_fill_bitmap(4000, 3000, (255, 255, 255,0))
            CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(new_curve1, bmp5a, (24, 230, 50,0))
            bmp5a.SaveAsave(path1 + "\\" + "close_hole1a.bmp")

            dict_res3:Dictionary = CMarkingFieldInImageUtils1.complete_uncomplete_pixels_curve_with_lines(CGlobals1.form_obj1.markingfldimg_obj1, new_curve1)


            new_curve1 = dict_res3["new_complete_curve1"]



        if dict_res_curve1["last_derivative1"] == 90:
            cur_last_derivative_of_curve1 = 0
        else:
            cur_last_derivative_of_curve1 = math.tan(dict_res_curve1["last_derivative1"] * math.pi / 180)

        bmp5:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(new_curve1, bmp5, (24, 230, 50,0))
        bmp5.SaveAsave(path1 + "\\" + "close_hole1b.bmp")
        dict_ret_res2["close_hole1b"] = new_curve1.Clone()

        new_curve1 = self.clear_curve_by_monotonic_down1(new_curve1)
        dict_ret_res2["clear_monotonic1"] = new_curve1.Clone()
        CGlobals1.global_vars_dict1["crop_bmp2_path1"] = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg"




        bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(new_curve1, bmp5, (24, 230, 50,0))
        CGlobals1.draw_sqr_around_pixels2(bmp5, CGlobals1.get_cord_xy_in_pixels_arr1(new_curve1, 0)(0), CGlobals1.get_cord_xy_in_pixels_arr1(new_curve1, 0)[1], 2, (255, 100, 40,0))
        bmp5.SaveAsve(path1 + "\\" + "monotonic_down1.bmp")


        not_to_stop1:bool = True


        CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(path1 + "\curve1.txt", new_curve1)

        derivative_dict1 = self.compute_derivative_of_curve2(new_curve1, path1 + "\\derivs1.txt", dict_res_curve1)



        self.fix_uncomplete_derivativs1(derivative_dict1)



        dict_ret_res2["derivative_dict1"] = CGlobals1.dict_type_Int32_Double_to_str(derivative_dict1)





        dict_ret_res2["curve_pxls_arr1"] = new_curve1



        #todo json_curve_str1:str = CGlobals1.dict_prm_to_json_str(dict_ret_res2)
        dict_ret_res2["derivative_dict1"] = derivative_dict1
        dict_ret_res2["derivatives_arr1"] = derivative_dict1
        #todo CGlobals1.form_obj1.markingfldimg_obj1.write_all_text_to_file(json_curve_str1,CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_json_" + str(self.curve_ind3) + ".txt")

        return dict_ret_res2


            
    
    
    def get_slices_of_curves1(self):
        
        
        path1=CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        bmp5=Bitmap(4000, 3000,(255,255,255,0))



        frame_pixels_arr1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(self.path_of_curve1)
        
        
        
        dict_rect_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)
        
        
        
        center_x1:int = (dict_rect_frame1["min_x1"] + dict_rect_frame1["max_x1"]) / 2

        ind1:int = 0

        while CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind1)[0] < center_x1:
            ind1 += 1
        
        


        ind2:int = ind1 + 2

        while CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind2)[0] > center_x1:
            ind2 += 1
        
        
        right_frame1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind1, ind2)
        
        
        
        if CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, 0)[1] > CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, right_frame1.count - 1)[1]:
            right_frame1.Reverse()


        first_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, 0)
        last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, right_frame1.count - 1)
        
        
        
        right_frame1.Insert(0, str(first_cord_xy1[0] - 1) + "," + str(first_cord_xy1[1]))
        right_frame1.Insert(0, str(first_cord_xy1[0] - 2) + "," + str(first_cord_xy1[1]))

        right_frame1.Add(str(last_cord_xy1[0] - 1) + "," + str(last_cord_xy1[1]))
        right_frame1.Add(str(last_cord_xy1[0] - 2) + "," + str(last_cord_xy1[1]))
        
        
        
        for i1 in range (0,right_frame1.count):
            right_frame1[i1] = right_frame1[i1] + "," + str(i1)


        cut_pxl_ind_arr1= ArrayList()
        dict_pxls_details1 =  Dictionary()
        

        dict_pxls_details1[2] = Dictionary()
        dict_pxls_details1[2]["pixel_kind1"] = "first_pixel"
        dict_pxls_details1[2]["pixel_ind1"] = 1
        dict_pxls_details1[2]["pixel_ind2"] = 0
        dict_pxls_details1[2]["angle1"] = 90

        dict_pxls_details1[right_frame1.count - 3] = Dictionary()
        dict_pxls_details1[right_frame1.count - 3]["pixel_kind1"] = "last_pixel"
        dict_pxls_details1[right_frame1.count - 3]["pixel_ind1"] = right_frame1.count - 2
        dict_pxls_details1[right_frame1.count - 3]["pixel_ind2"] = right_frame1.count - 1
        dict_pxls_details1[right_frame1.count - 3]["angle1"] = 90
        
        
        
        dict_state1:Dictionary
        curve1:ArrayList
        sqr_num1_ind1:int
        
        
        for sqr_num1_ind1 in range(1,5):
            
            sqr_num1 = str(sqr_num1_ind1)
            if sqr_num1 == "1":
                


                dict_rect_right_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1, True)
                center_min_y1:int = int((dict_rect_right_frame1["inds_of_min_y1"][0] + dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count - 1]) / 2)
                center_max_y1:int = int((dict_rect_right_frame1["inds_of_max_y1"][0] + dict_rect_right_frame1["inds_of_max_y1"][dict_rect_right_frame1["inds_of_max_y1"].count - 1]) / 2)
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]] = Dictionary()
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["pixel_kind1"] = "top_pixel"
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["angle1"] = 90
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["pixel_ind1"] = dict_rect_right_frame1["inds_of_min_y1"][0]
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["pixel_ind2"] = dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count - 1]

                curve1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, 0, center_min_y1)
                dict_state1 = self.build_state_of_sqr_curve1(curve1)
            
            
            
            if sqr_num1 == "2":
                right_frame2:ArrayList = right_frame1.clone()
                right_frame2.Reverse()
                dict_rect_right_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame2, True)
                center_min_y1:int = int((dict_rect_right_frame1["inds_of_min_y1"][0] + dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count - 1]) / 2)
                center_max_y1:int = int((dict_rect_right_frame1["inds_of_max_y1"][0] + dict_rect_right_frame1["inds_of_max_y1"][dict_rect_right_frame1["inds_of_max_y1"].count - 1]) / 2)


                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, center_max_y1)[2]] = Dictionary()
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, center_max_y1)[2]]["pixel_kind1"] = "bottom_pixel"
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, center_max_y1)[2]]["angle1"] = 90
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, center_max_y1)[2]]["pixel_ind1"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, dict_rect_right_frame1["inds_of_max_y1"][0])[2]
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, center_max_y1)[2]]["pixel_ind2"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, dict_rect_right_frame1["inds_of_max_y1"][dict_rect_right_frame1["inds_of_max_y1"].count - 1])[2]




                curve1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame2, 0, center_max_y1)


                dict_state1 = self.build_state_of_sqr_curve1(curve1)




            if sqr_num1 == "3":

                dict_rect_right_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1, True)
                center_min_y1:int =int((dict_rect_right_frame1["inds_of_min_y1"][0] + dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count - 1]) / 2)
                center_max_y1:int =int( (dict_rect_right_frame1["inds_of_max_y1"][0] + dict_rect_right_frame1["inds_of_max_y1"][dict_rect_right_frame1["inds_of_max_y1"].count - 1]) / 2)
                center_max_x1:int =int( (dict_rect_right_frame1["inds_of_max_x1"][0] + dict_rect_right_frame1["inds_of_max_x1"][dict_rect_right_frame1["inds_of_max_x1"].count - 1]) / 2)


                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]] = Dictionary()
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_kind1"] = "right_pixel"
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["angle1"]= 180

                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_ind1"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, dict_rect_right_frame1["inds_of_max_x1"][0])[2]
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_ind2"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, dict_rect_right_frame1["inds_of_max_x1"][dict_rect_right_frame1["inds_of_max_x1"].count - 1])[2]



                curve1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, center_min_y1, center_max_x1)

                dict_state1 = self.build_state_of_sqr_curve1(curve1)

            if sqr_num1 == "4":

                dict_rect_right_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1, True)
                center_min_y1:int = int((dict_rect_right_frame1["inds_of_min_y1"][0] + dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count - 1]) / 2)
                center_max_y1:int = int((dict_rect_right_frame1["inds_of_max_y1"][0] + dict_rect_right_frame1["inds_of_max_y1"][dict_rect_right_frame1["inds_of_max_y1"].count - 1]) / 2)
                center_max_x1:int = int((dict_rect_right_frame1["inds_of_max_x1"][0] + dict_rect_right_frame1["inds_of_max_x1"][dict_rect_right_frame1["inds_of_max_x1"].count - 1]) / 2)


                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]] = Dictionary()
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_kind1"] = "right_pixel"
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["angle1"] = 180

                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_ind1"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, dict_rect_right_frame1["inds_of_max_x1"][0])[2]
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_ind2"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, dict_rect_right_frame1["inds_of_max_x1"][dict_rect_right_frame1["inds_of_max_x1"].count - 1])[2]


                curve1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, center_max_x1, center_max_y1)

                dict_state1 = self.build_state_of_sqr_curve1(curve1)









            bmp5.SaveAs(path1 + "\\" + "frame4a_org1" + sqr_num1 + ".bmp")



            new_curve1:ArrayList=None
            new_curve2:ArrayList=None




            if dict_state1.ContainsKey("has_turn1") == True:
                bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
                CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve1, bmp5, (150, 40, 250,0))
                bmp5.SaveAs(path1 + "\\" + "frame4a_turn_" + sqr_num1 + ".bmp")

                if dict_state1["start_with1"] == "above":
                    curve1 = self.flip_curve_horizontal1(curve1)

                dict_state1["turn_pixel_state1"] = self.find_turn_pxl_point1(curve1)
                dict_pxls_details1[dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]] = Dictionary()

                dict_pxls_details1[dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]]["turn_pxl"] = True
                dict_pxls_details1[dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]]["turn_pixel_ind1"] = dict_state1["turn_pixel_state1"]["turn_pixel_ind1"]
                dict_pxls_details1[dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]]["turn_pixel_ind2"] = dict_state1["turn_pixel_state1"]["turn_pixel_ind2"]

                dict_pxls_details1[dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]]["angle1"] = dict_state1["turn_pixel_state1"]["turn_angle1"]


                turn_pixel_ind_center1:int = dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]


                new_curve1 = CGlobals1.get_arr_from_ind_to_ind_by_3_ind1(curve1, CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)[2], turn_pixel_ind_center1)
                new_curve2 = CGlobals1.get_arr_from_ind_to_ind_by_3_ind1(curve1, CGlobals1.get_cord_xy_in_pixels_arr1(curve1, curve1.count - 1)[2], turn_pixel_ind_center1)

                dict_state1["curves_arr1"] = ArrayList()
                dict_state1["curves_arr1"].Add(new_curve1)
                dict_state1["curves_arr1"].Add(new_curve2)

            else:
                dict_state1["curves_arr1"] = ArrayList()
                new_curve1 = curve1.clone()
                dict_state1["curves_arr1"].Add(new_curve1)






            #temp
            return 3

            for curve_ind1 in range(0 , dict_state1["curves_arr1"].count):
                cur_curve1:ArrayList = dict_state1["curves_arr1"][curve_ind1].clone()

                bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))


                cut_pxl_ind_arr1.Add(CGlobals1.get_cord_xy_in_pixels_arr1(cur_curve1, 0)[2])
                cut_pxl_ind_arr1.Add(CGlobals1.get_cord_xy_in_pixels_arr1(cur_curve1, cur_curve1.count - 1)[2])

                dict_res1:Dictionary  = self.find_45_degree_ind_from_curve_pxl_arr_by_long_seq_45_2(cur_curve1, cur_curve1.Count - 1, 1)
                if not self.check_if_45_angle_is_ok(cur_curve1, dict_res1):
                    cur_curve1 = self.flip_curve_horizontal1(cur_curve1)
                    dict_res1  = self.find_45_degree_ind_from_curve_pxl_arr_by_long_seq_45_2(cur_curve1, cur_curve1.Count - 1, 1)

                if not self.check_if_45_angle_is_ok(cur_curve1, dict_res1):
                    cur_curve1 = self.flip_curve_horizontal1(cur_curve1)
                    cur_curve1 = self.flip_curve_vertical1(cur_curve1)
                    cur_curve1.Reverse()
                    dict_res1 = self.find_45_degree_ind_from_curve_pxl_arr_by_long_seq_45_2(cur_curve1, cur_curve1.Count - 1, 1)

                cord_xybf = CGlobals1.get_cord_xy_in_pixels_arr1(cur_curve1, (dict_res1["first_ind_derivative_45"] + dict_res1["last_ind_derivative_45"]) / 2)
                if self.check_if_45_angle_is_ok(cur_curve1, dict_res1):

                    CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(cur_curve1, bmp5, (150, 40, 250,0))
                    bmp5.SaveAs(path1 + "\\" + "frame4a_turn_curve_" + str(curve_ind1) + ".bmp")

                    cut_pxl_ind_arr1.Add(cord_xybf[2])

                    dict_pxls_details1[cord_xybf[2]] = Dictionary()
                    dict_pxls_details1[cord_xybf[2]]["pixel_kind1"] = "angle_45"
                    dict_pxls_details1[cord_xybf[2]]["angle1"] = 45

                    dict_pxls_details1[cord_xybf[2]]["pixel_ind1"] = CGlobals1.get_cord_xy_in_pixels_arr1(cur_curve1, dict_res1["first_ind_derivative_45"])[2]
                    dict_pxls_details1[cord_xybf[2]]["pixel_ind2"] = CGlobals1.get_cord_xy_in_pixels_arr1(cur_curve1, dict_res1["last_ind_derivative_45"])[2]




        sorted1 = dict_pxls_details1.sort_by_key()

        dict_pxls_details1 = sorted1


        curves_arr2:ArrayList = ArrayList()

        for i4 in range(0, dict_pxls_details1.keys+1):
            dict_curve1:Dictionary = Dictionary()
            dict_curve1["index1"]= i4
            dict_curve1["first_pixel1"] = dict_pxls_details1.keys[i4]
            dict_curve1["last_pixel1"] = dict_pxls_details1.keys[i4 + 1]
            dict_curve1["first_pixel_derivative1"] = dict_pxls_details1[dict_pxls_details1.keys[i4]]["angle1"]
            dict_curve1["last_pixel_derivative1"] = dict_pxls_details1[dict_pxls_details1.keys[i4 + 1]]["angle1"]
            if dict_pxls_details1[dict_pxls_details1.keys[i4 + 1]].ContainsKey("turn_pxl"):

                dict_curve1["turn_pxl"] = True
                turn_pxl_ind1:int = dict_pxls_details1[dict_pxls_details1.keys[i4 + 1]]["turn_pixel_ind1"]
                turn_pxl_ind2:int = dict_pxls_details1[dict_pxls_details1.keys[i4 + 1]]["turn_pixel_ind2"]
                if turn_pxl_ind1 >= dict_pxls_details1.keys[i4] and dict_pxls_details1.keys[i4 + 1] >= turn_pxl_ind1:
                    dict_curve1["pxl_ind_2_1"] = turn_pxl_ind1
                    dict_curve1["pxl_ind_2_2"] = turn_pxl_ind2

                if turn_pxl_ind2 >= dict_pxls_details1.keys[i4] and dict_pxls_details1.keys[i4 + 1] >= turn_pxl_ind2:
                    dict_curve1["pxl_ind_2_1"] = turn_pxl_ind2
                    dict_curve1["pxl_ind_2_2"] = turn_pxl_ind1

            if dict_pxls_details1[dict_pxls_details1.keys[i4]].ContainsKey("turn_pxl"):

                dict_curve1["turn_pxl"] = True
                turn_pxl_ind1:int = dict_pxls_details1[dict_pxls_details1.keys[i4]]["turn_pixel_ind1"]
                turn_pxl_ind2:int = dict_pxls_details1[dict_pxls_details1.keys[i4]]["turn_pixel_ind2"]
                if turn_pxl_ind1 >= dict_pxls_details1.keys[i4] and dict_pxls_details1.keys[i4 + 1] >= turn_pxl_ind1:
                    dict_curve1["pxl_ind_1_1"] = turn_pxl_ind1
                    dict_curve1["pxl_ind_1_2"] = turn_pxl_ind2

                if turn_pxl_ind2 >= dict_pxls_details1.keys[i4] and dict_pxls_details1.keys[i4 + 1] >= turn_pxl_ind2:
                    dict_curve1["pxl_ind_1_1"] = turn_pxl_ind2
                    dict_curve1["pxl_ind_1_2"] = turn_pxl_ind1


            if dict_pxls_details1[dict_pxls_details1.keys[i4]].ContainsKey("pixel_kind1"):
                pixel_ind1:int = dict_pxls_details1[dict_pxls_details1.keys[i4]]["pixel_ind1"]
                pixel_ind2:int = dict_pxls_details1[dict_pxls_details1.keys[i4]]["pixel_ind2"]

                if dict_pxls_details1[dict_pxls_details1.keys[i4]]["pixel_kind1"] == "first_pixel":
                    dict_curve1["pxl_ind_1_1"] = pixel_ind1
                    dict_curve1["pxl_ind_1_2"] = pixel_ind2

                elif dict_pxls_details1[dict_pxls_details1.keys[i4]]["pixel_kind1"] == "last_pixel":
                    dict_curve1["pxl_ind_1_1"] = pixel_ind1
                    dict_curve1["pxl_ind_1_2"] = pixel_ind2


                else:
                    if pixel_ind1 >= dict_pxls_details1.keys[i4] and dict_pxls_details1.keys[i4 + 1] >= pixel_ind1:
                        dict_curve1["pxl_ind_1_1"] = pixel_ind1
                        dict_curve1["pxl_ind_1_2"] = pixel_ind2

                    if pixel_ind2 >= dict_pxls_details1.keys[i4] and dict_pxls_details1.Keys[i4 + 1] >= pixel_ind2:
                        dict_curve1["pxl_ind_1_1"] = pixel_ind2
                        dict_curve1["pxl_ind_1_2"] = pixel_ind1


            if dict_pxls_details1[dict_pxls_details1.keys[i4 + 1]].ContainsKey("pixel_kind1"):
                pixel_ind1:int = dict_pxls_details1[dict_pxls_details1.keys[i4 + 1]]["pixel_ind1"]
                pixel_ind2:int = dict_pxls_details1[dict_pxls_details1.keys[i4 + 1]]["pixel_ind2"]

                if dict_pxls_details1[dict_pxls_details1.keys[i4 + 1]]["pixel_kind1"] == "first_pixel":
                    dict_curve1["pxl_ind_2_1"] = pixel_ind1
                    dict_curve1["pxl_ind_2_2"] = pixel_ind2

                elif dict_pxls_details1[dict_pxls_details1.keys[i4 + 1]]["pixel_kind1"] == "last_pixel":
                    dict_curve1["pxl_ind_2_1"] = pixel_ind1
                    dict_curve1["pxl_ind_2_2"] = pixel_ind2


                elif pixel_ind1 >= dict_pxls_details1.keys[i4] and dict_pxls_details1.keys[i4 + 1] >= pixel_ind1:
                    dict_curve1["pxl_ind_2_1"] = pixel_ind1
                    dict_curve1["pxl_ind_2_2"] = pixel_ind2
                
                if pixel_ind2 >= dict_pxls_details1.keys[i4] and dict_pxls_details1.keys[i4 + 1] >= pixel_ind2:
                    dict_curve1["pxl_ind_2_1"] = pixel_ind2
                    dict_curve1["pxl_ind_2_2"] = pixel_ind1

            self.analize_pixel_curve1(dict_curve1, right_frame1)
            curves_arr2.Add(dict_curve1)

        bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(right_frame1, bmp5, (24, 230, 50,0))
        for i4 in range( 0 , cut_pxl_ind_arr1.count):
            cord_xybf = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(right_frame1, cut_pxl_ind_arr1[i4])

            CGlobals1.draw_sqr_around_pixels2(bmp5, cord_xybf[0], cord_xybf[1], 0, (150, 40, 250,0))


        bmp5.SaveAs(path1 + "\\" + "frame4a_cut_pxls1.bmp")

        dict_curves1:Dictionary = Dictionary()
        dict_curves1["curves_arr2"] = curves_arr2

        #todo str_json2 As String = CGlobals1.dict_prm_to_json_str(dict_curves1)
        #todo Dim dict_json2 As Dictionary(Of String, Object) = CGlobals1.json_to_dict_prms1(str_json2)

        CFile1.write_all_text_to_file( str_json2,CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_json_of_curves_slices1.txt")

        return dict_json2







            
            
    
    
    
    
    
    def build_state_of_sqr_curve1(self,curve1:ArrayList):
        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        if not CFile1.is_directory_exist(path1):
            CFile1.create_directory(path1)
        if not CFile1.is_directory_exist(path1+"\\data1"):
            CFile1.create_directory(path1+"\\data1")
            
        bmp5:Bitmap =Bitmap(4000,3000,(255,255,255,0))

        cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, 0)
        cord_xy2 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, curve1.count - 1)


        if cord_xy1[0] < cord_xy2[0]:
            cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, curve1.count - 1)
            cord_xy2 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, 0)

        angle1 = math.atan((cord_xy2[1] - cord_xy1[1]) / abs((cord_xy2[0] - cord_xy1[0]))) * 180.0 / math.pi


        vec_3d_obj1= vec_3d1()
        vec_3d_obj1.p1 = point_3d1()
        vec_3d_obj1.p1.x1 = cord_xy1[0]
        vec_3d_obj1.p1.y1 = cord_xy1[1]


        vec_3d_obj1.p2 = point_3d1()
        vec_3d_obj1.p2.x1 = cord_xy1[0]
        vec_3d_obj1.p2.y1 = cord_xy1[1]
        vec_3d_obj1.p2.z1 = -10

        rot_curve1:ArrayList = CMarkingFieldInImageUtils1.rotate_2d_pixels_arr(curve1, vec_3d_obj1, angle1)
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(rot_curve1, bmp5, (24, 230, 50,0))

        bmp5.SaveAs(path1 +  "\\curve1_state1.bmp")

        

        dist_above1:float = 0
        dist_below1:float = 0
        start_with1:str = ""
        for i1 in range(1,rot_curve1.count):
            cord_xy3 = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve1, i1)
            if cord_xy3[1] > cord_xy1[1]:
                if dist_below1 < abs(cord_xy3[1] - cord_xy1[1]):
                    dist_below1 = abs(cord_xy3[1] - cord_xy1[1])
                    if start_with1 == "":
                        start_with1 = "below"

            if cord_xy3[1] < cord_xy1[1]:

                if dist_above1 < abs(cord_xy3[1] - cord_xy1[1]):
                    dist_above1 = abs(cord_xy3[1] - cord_xy1[1])
                    if start_with1 == "":
                        start_with1 = "above"



        dict_state1:Dictionary = Dictionary()
        if dist_below1 > 1 and dist_above1 > 1:
            dict_state1["has_turn1"] =True
            dict_state1["start_with1"] = start_with1


        return dict_state1



