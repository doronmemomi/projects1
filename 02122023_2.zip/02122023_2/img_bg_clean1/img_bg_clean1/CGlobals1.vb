﻿Imports System.IO

Imports System.Text.Json


Public Class CGlobals1

    Public Shared flip_horizontal As String = "flip_horizontal"
    Public Shared rotate_90 As String = "flip_horizontal"


    Public Shared merge_2_slice_curve1_count1 As Integer = 0

    Public Shared debug_str1 As String = "819,324"
    Public Shared debug_int1 As Integer = 23
    Public Shared min_slice_len_added1 As Integer = 15

    Public Shared poly_dec_add_range_factor1 As Double = 1
    Public Shared max_pixels_arr_length1 As Integer = -1
    Public Shared dict_sobel_pixels As Dictionary(Of Double, ArrayList) = New Dictionary(Of Double, ArrayList)
    Public Shared current_sobel_threshold As Integer
    Public Shared last_sobel_threshold As Integer
    Public Shared current_bmp1 As Bitmap

    Public Shared dir_arr1 As Integer(,) = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}}
    Public Shared dir_arr1_rev As Integer(,) = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}, {-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}}
    Public Shared dir_arr2 As Integer(,) = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}}

    Public Shared dir_arr4 As Integer(,) = {{-2, -2}, {-1, -2}, {0, -2}, {1, -2}, {2, -2}, {2, -1}, {2, 0}, {2, 1}, {2, 2}, {1, 2}, {0, 2}, {-1, 2}, {-2, 2}, {-2, 1}, {-2, 0}, {-2, -1}}
    Public Shared dir_arr3 As Integer(,) = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}}

    Public Shared global_vars_dict1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

    Public Shared global_suffix_file_name1 As String = ""
    Public Shared global_path1 As String = "D:\\glass_pics1\\"
    Public Shared sobel_pics_path1 As String = "sobel_pics1\\"
    Public Shared path_of_sobel_cache1 As String = "D:\\glass_pics1\\"

    Public Shared dict_3d_pnts_arrs1 As Dictionary(Of String, ArrayList) = New Dictionary(Of String, ArrayList)

    Public Shared current_start_x1 As Double
    Public Shared current_start_y1 As Double
    Public Shared dir_x1_to_sobel As Double
    Public Shared dir_m1_to_sobel As Double

    Public Shared step_num1 As Integer = 0
    Public Shared max_sobel_length_bmp1 As Bitmap

    Public Shared current_max_arr_sobel As ArrayList

    Public Shared max_dist_between_sobel_line1 As Double = 1 'המרחק המינימלי בין 2 היקפים של סובלים סמוכים שמביא לעצירה
    Public Shared min_pixel_arr_count1 As Integer = 200 'האורך המינימלי של ההיקף שעוברים על הסובל
    Public Shared min_pixel_x1 As Integer = -1 'האורך המינימלי של ההיקף שעוברים על הסובל
    Public Shared max_pixel_x1 As Integer = -1 'האורך המינימלי של ההיקף שעוברים על הסובל

    Public Shared ind1 As Integer = 0

    Public Shared last_dict_sobel_line_pixels1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
    Public Shared max_count_pixels1 As Integer = -1
    Public Shared max_last_index_all_exist_in_prev_pixels1 As Integer = -1

    Public Shared current_max_sobel_ind1 As Integer = -1


    Public Shared form_obj1 As Form1
    Public Shared dict_mono_colors1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

    Public Shared some_max_diff_val1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
    Public Shared Function clear_all_caches1()
        dict_sobel_pixels.Clear()
        global_vars_dict1.Clear()
        last_dict_sobel_line_pixels1.Clear()
    End Function
    Public Shared Function update_label_progress(str1 As String)
        form_obj1.lbl_progress1.Text = str1
        Application.DoEvents()
    End Function

    Public Shared Function compare_colors1(color1 As Color, color2 As Color)
        If color1.R = color2.R And color1.G = color2.G And color1.B = color2.B Then
            Return 1
        End If

        Return 0
    End Function

    Public Shared Function copy_bitmap1(bmp1 As Bitmap)
        Dim bmp2 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim gr As Graphics = Graphics.FromImage(bmp2)

        ' Get source and destination rectangles.
        'Dim fr_rect As New Rectangle(0, 0, 70, 50)
        Dim fr_rect As New Rectangle(0, 0, bmp1.Width, bmp1.Height)
        Dim to_rect As New Rectangle(0, 0, bmp2.Width, bmp2.Height)

        ' Draw from the source to the destination.
        gr.DrawImage(bmp1, to_rect, fr_rect, GraphicsUnit.Pixel)


        Return bmp2
    End Function

    Public Shared Function crop_bitmap(src_bmp1 As Bitmap, x_in_src1 As Integer, y_in_src1 As Integer, w_in_src1 As Integer, h_in_src1 As Integer)

        Dim bmp2 As Bitmap = New Bitmap(w_in_src1, h_in_src1)
        Dim gr As Graphics = Graphics.FromImage(bmp2)

        ' Get source and destination rectangles.
        'Dim fr_rect As New Rectangle(0, 0, 70, 50)
        Dim to_rect As New Rectangle(0, 0, w_in_src1, h_in_src1)
        Dim fr_rect As New Rectangle(x_in_src1, y_in_src1, w_in_src1, h_in_src1)

        ' Draw from the source to the destination.
        gr.DrawImage(src_bmp1, to_rect, fr_rect, GraphicsUnit.Pixel)


        Return bmp2
    End Function
    Public Shared Function copy_bitmap_2_bitmap1(src_bmp1 As Bitmap, trgt_bmp1 As Bitmap, x_in_trgt1 As Integer, y_in_trgt1 As Integer)

        'Dim bmp2 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim gr As Graphics = Graphics.FromImage(src_bmp1)

        ' Get source and destination rectangles.
        'Dim fr_rect As New Rectangle(0, 0, 70, 50)
        Dim to_rect As New Rectangle(x_in_trgt1, y_in_trgt1, src_bmp1.Width, src_bmp1.Height)
        Dim fr_rect As New Rectangle(0, 0, src_bmp1.Width, src_bmp1.Height)

        ' Draw from the source to the destination.
        gr.DrawImage(trgt_bmp1, to_rect, fr_rect, GraphicsUnit.Pixel)


        Return src_bmp1
    End Function

    Public Shared Function save_pxl_arr_log1(pxls_arr1 As ArrayList, path_of_log_bmp1 As String)
        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_arr1, bmp1, Color.FromArgb(24, 230, 50))
        bmp1.Save(path_of_log_bmp1)
        Return bmp1
    End Function
    Public Shared Function create_fill_bitmap(w1 As Integer, h1 As Integer, fill_color1 As Color)
        Dim bmp1 As Bitmap = New Bitmap(w1, h1)

        Dim x1 As Integer
        Dim y1 As Integer



        Dim gfx As Graphics = Graphics.FromImage(bmp1)
        Dim brush As SolidBrush = New SolidBrush(fill_color1)
        gfx.FillRectangle(brush, 0, 0, w1, h1)
        Return bmp1

    End Function

    Public Function remove_item_by_val_in_arr1(arr1 As ArrayList, item_val_to_remove1 As String)
        Dim i1 As Integer = arr1.Count
        While i1 >= 0
            If arr1(i1) = item_val_to_remove1 Then
                arr1.RemoveAt(i1)
            Else
                i1 -= 1
            End If
        End While
    End Function

    Public Shared Function get_cord_xy_in_pixels_arr1(pixels_arr1 As ArrayList, cord_ind1 As Integer)
        Dim x1 As Integer = Double.Parse(pixels_arr1(cord_ind1).ToString().Split(",")(0))
        Dim y1 As Integer = Double.Parse(pixels_arr1(cord_ind1).ToString().Split(",")(1))
        If pixels_arr1(cord_ind1).ToString().Split(",").Count = 3 Then
            Dim z1 As Integer = Double.Parse(pixels_arr1(cord_ind1).ToString().Split(",")(2))
            Return {x1, y1, z1}

        End If
        Return {x1, y1}
    End Function
    Public Shared Function get_cord_xy_in_pixels_arr_by_3_cord1(pixels_arr1 As ArrayList, cord_ind1 As Integer)

        Dim i1 As Integer

        For i1 = 0 To pixels_arr1.Count - 1
            Dim x1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(0))
            Dim y1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(1))

            Dim z1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(2))
            If z1 = cord_ind1 Then
                Return {x1, y1, z1}

            End If

        Next

    End Function
    Public Shared Function get_double_cord_xy_in_pixels_arr2(pixels_arr1 As ArrayList, cord_ind1 As Integer)
        Dim x1 As Double = Double.Parse(pixels_arr1(cord_ind1).ToString().Split(",")(0))
        Dim y1 As Double = Double.Parse(pixels_arr1(cord_ind1).ToString().Split(",")(1))
        If pixels_arr1(cord_ind1).ToString().Split(",").Count = 3 Then
            Dim z1 As Double = Double.Parse(pixels_arr1(cord_ind1).ToString().Split(",")(2))
            Return {x1, y1, z1}
        End If
        Return {x1, y1}
    End Function
    Public Shared Function get_min_value_in_arraylist1(arr1 As ArrayList, Optional abs_value1 As Boolean = False)
        Dim i1 As Integer
        If arr1.Count <= 0 Then
            Return Nothing
        End If
        Dim min_value1 As Double = arr1(0)
        If abs_value1 = True Then
            min_value1 = Math.Abs(arr1(0))
        End If
        For i1 = 1 To arr1.Count - 1
            If abs_value1 = True Then
                If min_value1 > Math.Abs(arr1(i1)) Then
                    min_value1 = Math.Abs(arr1(i1))
                End If
            Else
                If min_value1 > arr1(i1) Then
                    min_value1 = arr1(i1)
                End If

            End If
        Next

        Return min_value1
    End Function


    Public Shared Function get_max_value_in_arraylist1(arr1 As ArrayList, Optional abs_value1 As Boolean = False)
        Dim i1 As Integer
        If arr1.Count <= 0 Then
            Return Nothing
        End If
        Dim max_value1 As Double = arr1(0)
        If abs_value1 = True Then
            max_value1 = Math.Abs(arr1(0))
        End If
        For i1 = 1 To arr1.Count - 1
            If abs_value1 = True Then
                If max_value1 < Math.Abs(arr1(i1)) Then
                    max_value1 = Math.Abs(arr1(i1))
                End If
            Else
                If max_value1 > arr1(i1) Then
                    max_value1 = arr1(i1)
                End If

            End If
        Next

        Return max_value1
    End Function


    Public Shared Function count_value_in_arraylist1(arr1 As ArrayList, min_value1 As Double, max_value1 As Double)
        Dim i1 As Integer
        Dim count_value1 As Integer = 0
        If arr1.Count <= 0 Then
            Return 0
        End If


        For i1 = 0 To arr1.Count - 1
            If arr1(i1) >= min_value1 And arr1(i1) <= max_value1 Then
                count_value1 += 1
            End If

        Next

        Return count_value1
    End Function

    Public Shared Function find_max_seq_that_val_between1(arr1 As ArrayList, min_value1 As Double, max_value1 As Double)

        Dim ind1 As Integer
        ind1 = 0
        Dim to_stop1 As Integer = 0
        Dim seq_arr1 As ArrayList = New ArrayList()
        If arr1.Count <= 20 Then
            Return seq_arr1
        End If
        While to_stop1 = 0

            While arr1(ind1) < min_value1 Or arr1(ind1) > max_value1 And ind1 < arr1.Count - 2

                ind1 += 1

                If ind1 >= arr1.Count - 1 Then
                    to_stop1 = 1
                    Return seq_arr1
                End If


            End While
            Dim ind2 As Integer = ind1
            While arr1(ind2) >= min_value1 And arr1(ind2) <= max_value1 And ind2 < arr1.Count - 2
                ind2 += 1
                If ind1 >= arr1.Count - 1 Then
                    to_stop1 = 1
                    Return seq_arr1
                End If
            End While
            seq_arr1.Add(ind1.ToString() + "," + ind2.ToString())
            ind1 = ind2

            If ind1 >= arr1.Count - 2 Then
                to_stop1 = 1
            End If

        End While
        Return seq_arr1

    End Function

    Public Shared Function sord_dict_by_key2(dict_obj1 As Object)
        'Dim sorted1 = From pair In dict_obj1
        'Order By pair.Value
        'Dim sortedDictionary1 = sorted1.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        'dict_max_right_len1 = sortedDictionary1

    End Function


    Public Shared Function draw_sqr_around_pixels(bmp1 As Bitmap, x1 As Integer, y1 As Integer, sqr_radius1 As Integer, color1 As Color)
        Dim x1a As Integer
        Dim y1a As Integer
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        For x1a = x1 - sqr_radius1 To x1 + sqr_radius1
            For y1a = y1 - sqr_radius1 To y1 + sqr_radius1
                copy_bmp1.SetPixel(x1a, y1a, color1)
            Next

        Next

        Return copy_bmp1
    End Function

    Public Shared Function draw_sqr_around_pixels2(ByRef bmp1 As Bitmap, x1 As Integer, y1 As Integer, sqr_radius1 As Integer, color1 As Color)
        Dim x1a As Integer
        Dim y1a As Integer

        For x1a = x1 - sqr_radius1 To x1 + sqr_radius1
            For y1a = y1 - sqr_radius1 To y1 + sqr_radius1
                Try
                    bmp1.SetPixel(x1a, y1a, color1)

                Catch ex As Exception

                End Try
            Next

        Next

        Return bmp1
    End Function

    Public Shared Function add_to_dict1(arr1 As ArrayList)
        Dim dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim i1 As Integer

        For i1 = 0 To arr1.Count - 1
            dict1(arr1(i1)) = i1
        Next

        Return dict1
    End Function

    Public Shared Function arr_xy_to_dict2(arr1 As ArrayList)
        Dim dict1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim i1 As Integer

        For i1 = 0 To arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, i1)
            dict1(cord_xy1(0)) = cord_xy1(1)
        Next

        Return dict1
    End Function

    Public Shared Function dict_keys_to_arr1(dict_keys1 As Dictionary(Of String, Integer))

        Dim i1 As Integer
        Dim new_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To dict_keys1.Keys.Count - 1
            new_arr1.Add(dict_keys1.Keys(i1))
        Next

        Return new_arr1
    End Function


    Public Shared Function convert_2darr_to_3d_arr(arr_2d As ArrayList)
        Dim i1 As Integer

        Dim new_3d_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To arr_2d.Count - 1
            Dim point_3d_obj1 As point_3d1 = New point_3d1()
            point_3d_obj1.x1 = Double.Parse(arr_2d(i1).ToString().Split(",")(0).ToString())
            point_3d_obj1.y1 = Double.Parse(arr_2d(i1).ToString().Split(",")(1).ToString())
            point_3d_obj1.z1 = 0
            new_3d_arr1.Add(point_3d_obj1)

        Next
        Return new_3d_arr1
    End Function


    Public Shared Function get_arr_from_ind_to_ind1(arr1 As ArrayList, start_ind1 As Integer, end_ind1 As Integer)
        Dim new_arr1 As ArrayList = New ArrayList()
        If start_ind1 <= end_ind1 Then
            Dim i1 As Integer = start_ind1

            For i1 = start_ind1 To Math.Min(end_ind1, arr1.Count - 1)
                new_arr1.Add(arr1(i1))

            Next

        End If


        If end_ind1 < start_ind1 Then

            For i1 = start_ind1 To arr1.Count - 1
                new_arr1.Add(arr1(i1))

            Next


            For i1 = 0 To Math.Min(end_ind1, arr1.Count - 1) 'end_ind1
                new_arr1.Add(arr1(i1))

            Next

        End If

        Return new_arr1

    End Function


    Public Shared Function get_arr_from_ind_to_ind_by_3_ind1(arr1 As ArrayList, start_ind_3ind1 As Integer, end_ind_3ind1 As Integer)
        Dim new_arr1 As ArrayList = New ArrayList()


        Dim i1 As Integer

        For i1 = 0 To arr1.Count - 1
            Dim cord_xy3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, i1)
            If cord_xy3(2) >= start_ind_3ind1 And cord_xy3(2) <= end_ind_3ind1 Or cord_xy3(2) <= start_ind_3ind1 And cord_xy3(2) >= end_ind_3ind1 Then
                new_arr1.Add(arr1(i1))
            End If

        Next


        Return new_arr1

    End Function
    Public Shared Function add_val_to_pxls_arr1(pxls_arr1 As ArrayList, add_x1 As Integer, add_y1 As Integer)
        Dim i1 As Integer
        Dim new_pxls_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To pxls_arr1.Count - 1
            Dim cord_xy1 As Integer() = get_cord_xy_in_pixels_arr1(pxls_arr1, i1)
            cord_xy1(0) += add_x1
            cord_xy1(1) += add_y1
            new_pxls_arr1.Add(cord_xy1(0).ToString() + "," + cord_xy1(1).ToString())
        Next

        Return new_pxls_arr1
    End Function


    Public Shared Function read_int_if_exist(key_path1 As String, ByRef key_val1 As Integer)
        If System.IO.File.Exists(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt") Then
            key_val1 = Integer.Parse(System.IO.File.ReadAllText(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt"))
            Return key_val1
        End If
    End Function

    Public Shared Function write_int1(key_path1 As String, key_val1 As Integer)
        System.IO.File.WriteAllText(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt", key_val1.ToString())
        'If System.IO.File.Exists(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt") Then
        'Dim val1 As Integer = Integer.Parse(System.IO.File.ReadAllText(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt"))
        'Return val1
        'End If
    End Function

    Public Shared Function conv_2d_arr_to_2d_cords_dict1(arr1 As ArrayList)
        Dim i1 As Integer
        Dim dict_cords1 As Dictionary(Of Integer, Integer()) = New Dictionary(Of Integer, Integer())
        For i1 = 0 To arr1.Count - 1
            dict_cords1(i1) = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, i1)
        Next

        Return dict_cords1
    End Function

    Public Shared Function is_pixels_arr_overlap_pixels_dict1(pixels_arr1 As ArrayList, pixels_dict As Dictionary(Of String, Integer))
        For i1 = 0 To pixels_arr1.Count - 1
            If pixels_dict.ContainsKey(pixels_arr1(i1)) = True Then
                Return 1
            End If
        Next

        Return 0
    End Function



    Public Shared Function delete_files1(path1 As String, pattern1 As String)
        Try
            Dim files1 As String() = System.IO.Directory.GetFiles(path1, pattern1)

            Dim i1 As Integer

            For i1 = 0 To files1.Length - 1
                System.IO.File.Delete(files1(i1))
            Next

        Catch ex As Exception

        End Try
    End Function
    Public Shared Function json_to_array1(json_str1 As String)
        Dim json_obj1 As System.Text.Json.JsonDocument
        Dim arr_res1 As ArrayList = New ArrayList()

        Try
            json_obj1 = System.Text.Json.JsonDocument.Parse(json_str1)
            Dim arr1 As ArrayList = System.Text.Json.JsonSerializer.Deserialize(Of ArrayList)(json_obj1)
            Dim i1 As Integer

            For i1 = 0 To arr1.Count - 1

                arr_res1.Add(json_to_dict_prms1(arr1(i1).ToString()))
            Next
        Catch ex As Exception

        End Try

        Return arr_res1
    End Function

    Public Shared Function arr_to_json1(arr1 As ArrayList)
        Dim geresh1 As String = Chr(34)
        Dim i1 As Integer
        Dim json_str1 As String = ""

        For i1 = 0 To arr1.Count - 1
            If json_str1 <> "" Then
                json_str1 += ","
            End If
            Dim type1 As String = arr1(i1).GetType().ToString()
            If type1.Contains("ArrayList") = True Then



                json_str1 += arr_to_json1(arr1)

            ElseIf type1.Contains("dict1") = True Then

                json_str1 += dict_prm_to_json_str(arr1(i1))
            Else

                json_str1 += geresh1 + arr1(i1).ToString() + geresh1
                'arr_res1.Add(arr1(i1))
            End If
        Next
        json_str1 = "[" + json_str1 + "]"

        Return json_str1
    End Function

    Public Shared Function check_if_str_is_json(json_str1 As String)
        Dim json_obj1 As System.Text.Json.JsonDocument
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        Try


            Try
                If json_str1.Contains("[") = True Or json_str1.Contains("]") = True Or json_str1.Contains("{") = True Or json_str1.Contains("}") = True Then
                Else
                    Return "no"

                End If


                json_obj1 = System.Text.Json.JsonDocument.Parse(json_str1)
                Return "yes"
            Catch ex As Exception
                Return "no"
            End Try
        Catch ex As Exception
            Return "no"
        End Try
    End Function
    Public Shared Function json_to_dict_prms1(json_str1 As String)
        Dim json_obj1 As System.Text.Json.JsonDocument
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        json_str1 = json_str1.Replace(Chr(13), "")
        json_str1 = json_str1.Replace(Chr(10), "")
        Try
            Try
                If json_str1.Contains("[") = True Or json_str1.Contains("]") = True Or json_str1.Contains("{") = True Or json_str1.Contains("}") = True Then
                Else
                    Return json_str1

                End If

                json_obj1 = System.Text.Json.JsonDocument.Parse(json_str1)
            Catch ex As Exception
                Return json_str1
            End Try


            Dim dict1 As Dictionary(Of String, Object)
            Try
                If json_obj1.RootElement.ValueKind.ToString().Contains("Object") = True Then
                    dict1 = System.Text.Json.JsonSerializer.Deserialize(Of Dictionary(Of String, Object))(json_obj1)

                End If



                If json_obj1.RootElement.ValueKind.ToString().Contains("Array") = True Then

                    Try



                        Dim arr1 As ArrayList
                        arr1 = System.Text.Json.JsonSerializer.Deserialize(Of ArrayList)(json_obj1)
                        'json_to_array1(dict1(dict1.Keys(0)).ToString())
                        Dim d17 As Integer = 4

                        Dim arr_res1 As ArrayList = New ArrayList()

                        Dim i4 As Integer

                        For i4 = 0 To arr1.Count - 1
                            arr_res1.Add(arr1(i4).ToString())
                        Next

                        Return arr_res1

                    Catch ex1 As Exception
                        Return json_str1
                    End Try
                End If

            Catch ex As Exception
                Try



                    Dim arr1 As ArrayList
                    arr1 = System.Text.Json.JsonSerializer.Deserialize(Of ArrayList)(json_obj1)
                    'json_to_array1(dict1(dict1.Keys(0)).ToString())
                    Dim d17 As Integer = 4

                    Dim arr_res1 As ArrayList = New ArrayList()

                    Dim i4 As Integer

                    For i4 = 0 To arr1.Count - 1
                        arr_res1.Add(arr1(i4).ToString())
                    Next

                    Return arr_res1

                Catch ex1 As Exception
                    Return json_str1
                End Try

            End Try


            'Dim dict2 As Dictionary(Of String, String) = System.Text.Json.JsonSerializer.Deserialize(Of Dictionary(Of String, String))(json_obj1)

            Dim i1 As Integer


            While dict1.Keys.Count > 0
                If dict1.ContainsKey(dict1.Keys(0) + "_type1") Then
                    Dim type1 As String = dict1(dict1.Keys(0) + "_type1").ToString()

                    If type1.ToLower() = "dict1" Then
                        dict_res1(dict1.Keys(0)) = json_to_dict_prms1(dict1(dict1.Keys(0)).ToString())
                    End If
                    If type1.ToLower() = "array1" Then
                        dict_res1(dict1.Keys(0)) = json_to_array1(dict1(dict1.Keys(0)).ToString())

                    End If
                    If type1.ToLower() = "system.double" Then
                        dict_res1(dict1.Keys(0)) = Double.Parse(dict1(dict1.Keys(0)).ToString())
                    End If
                    If type1.ToLower() = "system.string" Then
                        dict_res1(dict1.Keys(0)) = dict1(dict1.Keys(0)).ToString()
                    End If
                    If type1.ToLower() = "system.integer" Then
                        dict_res1(dict1.Keys(0)) = Integer.Parse(dict1(dict1.Keys(0)).ToString())
                    End If
                    If type1.ToLower() = "system.int32" Then
                        dict_res1(dict1.Keys(0)) = Integer.Parse(dict1(dict1.Keys(0)).ToString())
                    End If

                    If type1.ToLower() = "img_bg_clean1.cpolynom2" Then
                        Dim json_obj2 As System.Text.Json.JsonDocument
                        Dim dict2 As Dictionary(Of String, Object)
                        json_obj2 = System.Text.Json.JsonDocument.Parse(dict1(dict1.Keys(0)).ToString())
                        dict2 = System.Text.Json.JsonSerializer.Deserialize(Of Dictionary(Of String, Object))(json_obj2)

                        Dim polynom_obj2 As CPolynom2 = New CPolynom2()
                        polynom_obj2.coef_arr1 = json_to_array1(dict2("coefs").ToString())

                        Dim coef_ind1 As Integer

                        For coef_ind1 = 0 To polynom_obj2.coef_arr1.Count - 1
                            polynom_obj2.coef_arr1(coef_ind1) = Double.Parse(polynom_obj2.coef_arr1(coef_ind1).ToString())
                        Next
                        dict_res1(dict1.Keys(0)) = polynom_obj2
                    End If


                    Dim key1 As String = dict1.Keys(0)
                    dict1.Remove(key1)
                    dict1.Remove(key1 + "_type1")
                End If
            End While

            'Dim str1 As String = json_obj1.RootElement.GetProperty("error1").GetString()

            'If str1.Trim() = "yes" Then
            'Dim d3 As Integer = 1
            'End If
            'Dim str1 As String = json_ele_obj1(0).GetRawText()
            Dim d1 As Integer = 1
        Catch ex As Exception
            Dim d1 As Integer = 1
        End Try

        Return dict_res1
    End Function
    Public Shared Function save_dict_prms1(dict_prm1 As Dictionary(Of String, Object), path_to_save1 As String)


        'json_to_dict_prms1(json_str1)

        System.IO.File.WriteAllText(path_to_save1, CGlobals1.dict_prm_to_json_str(dict_prm1))

    End Function



    Public Shared Function obj_to_json_str1(obj1 As Object, obj_name1 As String)
        Dim i1 As Integer
        Dim geresh_str1 As String = Chr(34)
        Dim geresh1 As String = Chr(34)
        Dim json_str1 As String = ""
        Dim type1 As String = obj1.GetType.ToString()

        If obj_name1 = "dict_polynom_res2" Then
            Dim d5 As Integer = 7
        End If

        If type1.Contains("ArrayList") = True Then
            Dim arr1 As ArrayList = obj1
            If json_str1 <> "" Then
                json_str1 += ","
            End If

            Dim i2 As Integer

            For i2 = 0 To arr1.Count - 1

                If i2 > 0 Then
                    json_str1 += ","

                End If
                json_str1 += dict_prm_to_json_str(arr1(i2))
            Next
            json_str1 += geresh1 + obj_name1 + "_type1" + geresh1 + ":" + geresh1 + "array1" + geresh1

        ElseIf type1.Contains("img_bg_clean1.CPolynom2") = True Then
            If json_str1 <> "" Then
                json_str1 += ","
            End If
            json_str1 += geresh1 + obj_name1 + geresh1 + ":{" + CType(obj1, CPolynom2).get_polynom_json_str1() + "}" + ","
            json_str1 += geresh1 + obj_name1 + "_type1" + geresh1 + ":" + geresh1 + obj1.ToString() + geresh1
        ElseIf type1.Contains("Dictionary") = True Then
            If json_str1 <> "" Then
                json_str1 += ","
            End If
            json_str1 += geresh1 + obj_name1 + geresh1 + ":" + dict_prm_to_json_str(obj1) + ","
            json_str1 += geresh1 + obj_name1 + "_type1" + geresh1 + ":" + geresh1 + "dict1" + geresh1

            Dim d14 As Integer = 1

            'save_dict_prms1(dict_prm1(dict_prm1.Keys(i1)))
        ElseIf type1 = "System.Double" Or type1 = "System.String" Or type1 = "System.Integer" Or type1 = "System.Int32" Then
            If json_str1 <> "" Then
                json_str1 += ","
            End If
            json_str1 += geresh1 + obj_name1 + geresh1 + ":" + geresh1 + obj_to_json_str1 + geresh1
            If json_str1 <> "" Then
                json_str1 += ","
            End If
            json_str1 += geresh1 + obj_name1 + "_type1" + geresh1 + ":" + geresh1 + obj_to_json_str1 + geresh1
        End If
        Dim d1 As Integer = 1

    End Function
    Public Shared Function dict_prm_to_json_str(dict_prm1 As Dictionary(Of String, Object))
        Dim i1 As Integer
        Dim geresh_str1 As String = Chr(34)
        Dim geresh1 As String = Chr(34)
        Dim json_str1 As String = ""
        For i1 = 0 To dict_prm1.Keys.Count - 1
            Dim type1 As String = dict_prm1(dict_prm1.Keys(i1)).GetType.ToString()
            If dict_prm1.Keys(i1).ToString() = "derivative_dict1" Then
                Dim d2 As Integer = 3
            End If
            If type1.Contains("ArrayList") = True Then

                If json_str1 <> "" Then
                    json_str1 += ","
                End If

                Dim arr1 As ArrayList = dict_prm1(dict_prm1.Keys(i1))


                json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + geresh1 + ":["

                Dim i2 As Integer

                For i2 = 0 To arr1.Count - 1

                    If i2 > 0 Then
                        json_str1 += ","

                    End If

                    If arr1(i2).GetType().ToString().Contains("Dictionary") = True Then
                        If json_str1 <> "" Then
                            'json_str1 += ","
                        End If
                        json_str1 += dict_prm_to_json_str(arr1(i2))
                    ElseIf arr1(i2).GetType().ToString().Contains("ArrayList") = True Then

                        json_str1 += arr_to_json1(arr1(i2))

                        'json_str1 += "{" + geresh1 + "arr_" + i2.ToString() + geresh1 + ":" + arr_to_json1(arr1(i2)) + ","
                        'json_str1 += geresh1 + "arr_" + i2.ToString() + "_type1" + geresh1 + ":" + geresh1 + "array1" + geresh1 + "}"
                    Else

                        json_str1 += geresh1 + arr1(i2).ToString() + geresh1
                    End If

                Next

                json_str1 += "],"
                json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + "_type1" + geresh1 + ":" + geresh1 + "array1" + geresh1

            ElseIf type1.Contains("img_bg_clean1.CPolynom2") = True Then
                If json_str1 <> "" Then
                    json_str1 += ","
                End If
                json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + geresh1 + ":{" + CType(dict_prm1(dict_prm1.Keys(i1)), CPolynom2).get_polynom_json_str1() + "}" + ","
                json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + "_type1" + geresh1 + ":" + geresh1 + dict_prm1(dict_prm1.Keys(i1)).GetType().ToString() + geresh1
            ElseIf type1.Contains("Dictionary") = True Then
                If json_str1 <> "" Then
                    json_str1 += ","
                End If

                json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + geresh1 + ":" + dict_prm_to_json_str(dict_prm1(dict_prm1.Keys(i1))) + ","
                    json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + "_type1" + geresh1 + ":" + geresh1 + "dict1" + geresh1

                    Dim d14 As Integer = 1

                    'save_dict_prms1(dict_prm1(dict_prm1.Keys(i1)))
                ElseIf type1 = "System.Double" Or type1 = "System.String" Or type1 = "System.Integer" Or type1 = "System.Int32" Then
                If json_str1 <> "" Then
                    json_str1 += ","
                End If
                If check_if_str_is_json(dict_prm1(dict_prm1.Keys(i1)).ToString()) = "yes" Then
                    json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + geresh1 + ":" + dict_prm1(dict_prm1.Keys(i1)).ToString()

                Else
                    json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + geresh1 + ":" + geresh1 + dict_prm1(dict_prm1.Keys(i1)).ToString() + geresh1

                End If

                If json_str1 <> "" Then
                    json_str1 += ","
                End If
                json_str1 += geresh1 + dict_prm1.Keys(i1).ToString() + "_type1" + geresh1 + ":" + geresh1 + dict_prm1(dict_prm1.Keys(i1)).GetType().ToString() + geresh1
            End If
            Dim d1 As Integer = 1
        Next
        'json_str1 = "{" + geresh1 + "root1" + geresh1 + ":{" + json_str1 + "}}"
        json_str1 = "{" + json_str1 + "}"

        Return json_str1
    End Function


    Public Shared Function dict_type_Int32_Double_to_str(dict1 As Dictionary(Of Integer, Double))
        Dim i1 As Integer

        Dim str1 As String = ""

        For i1 = 0 To dict1.Keys.Count - 1
            If str1 <> "" Then
                str1 += "#"

            End If
            str1 += dict1.Keys(i1).ToString() + "," + dict1(dict1.Keys(i1)).ToString()
        Next

        Return str1
    End Function

    Public Shared Function str_to_type_Int32_Double(str1 As String)
        Dim dict1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim i1 As Integer


        Dim arr_str1 As String() = str1.Split("#")

        For i1 = 0 To arr_str1.Count - 1
            dict1(Integer.Parse(arr_str1(i1).Split(",")(0))) = Double.Parse(arr_str1(i1).Split(",")(1))

        Next

        Return dict1
    End Function


    Public Shared Function zoom_curve1(curve_pxls_arr1 As ArrayList, mul_factor1 As Double)
        Dim i1 As Integer
        Dim new_curve_pxls_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To curve_pxls_arr1.Count - 1
            new_curve_pxls_arr1.Add((CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1, i1)(0) * mul_factor1).ToString() + "," + (CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_pxls_arr1, i1)(1) * mul_factor1).ToString())
        Next

        Return new_curve_pxls_arr1
    End Function


    Public Shared Function add_to_txt_log1(msg_str1 As String)
        CGlobals1.form_obj1.txtbox_log1.Text = msg_str1 + Chr(13) + Chr(10) + CGlobals1.form_obj1.txtbox_log1.Text
        Application.DoEvents()
    End Function

    Public Shared Function add_to_txt_log2(msg_str1 As String)
        CGlobals1.form_obj1.txtbox_log2.Text = msg_str1 + Chr(13) + Chr(10) + CGlobals1.form_obj1.txtbox_log2.Text
        Application.DoEvents()
    End Function

    Public Shared Function get_current_glass_folder1()
        Dim path1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1

        Dim path2 As String = path1.Substring(0, path1.LastIndexOf("\"))
        Return path2
    End Function

    Public Shared Function create_folder1(path1 As String)
        If System.IO.Directory.Exists(path1) = False Then
            System.IO.Directory.CreateDirectory(path1)
            Return 1
        End If
        Return 0
    End Function


    Public Shared Function add_arraylist_to_arraylist1(array_list1 As ArrayList, add_array_list1 As ArrayList)
        Dim i1 As Integer
        Dim new_array_list1 As ArrayList = array_list1.Clone()
        For i1 = 0 To add_array_list1.Count - 1
            new_array_list1.Add(add_array_list1(i1))
        Next

        Return new_array_list1
    End Function





    Public Shared Function copy1_bitmap2(bmp1 As Bitmap)
        Dim bmp2 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim gr As Graphics = Graphics.FromImage(bmp2)

        ' Get source and destination rectangles.
        'Dim fr_rect As New Rectangle(0, 0, 70, 50)
        Dim fr_rect As New Rectangle(0, 0, bmp1.Width, bmp1.Height)
        Dim to_rect As New Rectangle(0, 0, bmp2.Width, bmp2.Height)

        ' Draw from the source to the destination.



        Return bmp2
    End Function


    Public Function find_max_sobel_length1(start_x1 As Integer, start_y1 As Integer)
        Dim dict_res1 As Dictionary(Of String, Object)


        Dim start_store1 As String = ""


        'Dim cord1 As Integer() = find_start_point3(Me.bmp_current_sobel)
        'x_start2 = cord1(0)
        'y_start2 = cord1(1)



        Dim dict_result1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        'set_pixels_arr_and_save1(pixels_around_sobel_arr1, Me.bmp_current_sobel, CGlobals1.global_path1 + "\sobel_pics1\pixels2.jpg")
        Try
            'Me.bmp_current_sobel.Save(CGlobals1.global_path1 + "\sobel_pics1\to_find_line1_" + CGlobals1.step_num1.ToString() + ".jpg")

        Catch ex As Exception

        End Try
        'dict_res1 = next_pixels_loop3(Me.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1, Nothing)




        Dim dict_res2 As Dictionary(Of String, Object) '= next_pixels_loop3(Me.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1_rev, Nothing)

        dict_result1("pixels_around_sobel_arr1") = dict_res1
        dict_result1("pixels_around_sobel_arr1_rev") = dict_res2



        Return dict_result1

    End Function

    Public Function get_degree_2_value_y(y_val1 As Double)
        'Dim y_val1 As Double = coef_arr1(0) * Math.Pow(x_val1, 2) + coef_arr1(1)
        'Math.Pow(x_val1, 2)=(y_val1- coef_arr1(1))/ coef_arr1(0)

        Dim x_val1 As Double = Math.Pow((y_val1), 1)
        Dim dict_x_val1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_x_val1("x_val1") = x_val1
        dict_x_val1("x_val2") = -x_val1
        Return dict_x_val1
    End Function


    Public Function get_color1(ByRef bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        'Dim mono_color1 As Double = (CType(bmp1.GetPixel(x1, y1).R, Double) + CType(bmp1.GetPixel(x1, y1).G, Double) + CType(bmp1.GetPixel(x1, y1).B, Double)) / 3 ' * 0.3333
        'Dim color1 As Color = Color.FromArgb(255, 255, 255) ' bmp1.GetPixel(x1, y1)
        Dim key1 As String = x1.ToString() + "," + y1.ToString()

        Dim color1 As Color = bmp1.GetPixel(x1, y1)
        Dim mono_color1 As Integer = (0.3 * color1.R + 0.59 * color1.G + 0.11 * color1.B)
        'dict_mono_colors2(key1) = mono_color1
        Return mono_color1
    End Function



    Public Function combine_new_curve_in_frame_pixels_arr1(new_curve1 As ArrayList, frame_pixel_arr1 As ArrayList)
        Dim i1 As Integer
        Dim dict_new_curve1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(new_curve1)
        Dim min_dist_arr1 As ArrayList = New ArrayList()

        Dim first_cord_ind1 As Integer = -1
        Dim first_min_dist1 As Double = 99
        Dim lock_first_min_dist1 As Integer = 0


        Dim second_cord_ind1 As Integer = -1
        Dim second_min_dist1 As Double = 99
        Dim lock_second_min_dist1 As Integer = 0

        Dim last_min_dist_x1 As Integer = -1
        Dim last_min_dist_y1 As Integer = -1


        For i1 = 0 To frame_pixel_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixel_arr1, i1)
            Dim x1 As Integer
            Dim y1 As Integer
            Dim min_dist_x1 As Integer = -1
            Dim min_dist_y1 As Integer = -1
            Dim min_dist1 As Double = 99
            Dim delta_xy1 As Integer = 5
            For x1 = cord_xy1(0) - delta_xy1 To cord_xy1(0) + delta_xy1
                For y1 = cord_xy1(1) - delta_xy1 To cord_xy1(1) + delta_xy1
                    If dict_new_curve1.ContainsKey(x1.ToString() + "," + y1.ToString()) = True Then
                        Dim dist1 As Double = CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy1(New Integer() {x1, y1}, cord_xy1)
                        If dist1 < min_dist1 Then
                            min_dist1 = dist1
                            min_dist_x1 = x1
                            min_dist_y1 = y1
                        End If
                    End If
                Next

            Next

            If first_min_dist1 < min_dist1 And lock_first_min_dist1 = 0 Then
                lock_first_min_dist1 = 1

            End If

            If first_min_dist1 > min_dist1 And lock_first_min_dist1 = 0 Then
                first_min_dist1 = min_dist1
                first_cord_ind1 = i1
                last_min_dist_x1 = min_dist_x1
                last_min_dist_y1 = min_dist_y1
            End If



            If min_dist1 < 6 Then
                min_dist_arr1.Add(i1.ToString() + "," + min_dist1.ToString() + "#" + min_dist_x1.ToString() + "," + min_dist_y1.ToString() + "#" + frame_pixel_arr1(i1))
            End If

        Next
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res1("first_cord_ind1") = first_cord_ind1
        dict_res1("last_min_dist_x1") = last_min_dist_x1
        dict_res1("last_min_dist_y1") = last_min_dist_y1

        Return dict_res1

    End Function


    Public Function get_min_value1(arr1 As ArrayList, Optional abs_value1 As Boolean = False)
        Dim i1 As Integer
        If arr1.Count <= 0 Then
            Return Nothing
        End If
        Dim min_value1 As Double = arr1(0)

        For i1 = 1 To arr1.Count - 1
            If abs_value1 = True Then
                If min_value1 > Math.Abs(arr1(i1)) Then
                    min_value1 = Math.Abs(arr1(i1))
                End If
            Else

                If min_value1 > arr1(i1) Then
                    min_value1 = arr1(i1)
                End If

            End If
        Next

        Return min_value1
    End Function


    Public Function find_x_by_derivative_val2(derivative_val1 As Double, start_x_val1 As Double)
        Dim x_val1 As Double = start_x_val1

        Dim to_stop1 As Integer = 0
        Dim add_x_val1 As Double = 1
        Dim factor_add_x_val1 As Double = 1
        Dim last_dir1 As Integer = -1
        Dim deriv_val1 As Double

        Dim count_loop1 As Integer = 0


        While to_stop1 = 0
            deriv_val1 = x_val1
            If deriv_val1 < derivative_val1 Then
                x_val1 += factor_add_x_val1
                If last_dir1 = -1 Then
                    factor_add_x_val1 /= 2

                End If
                last_dir1 = 1
            Else
                While (Math.Abs(x_val1) - factor_add_x_val1) <= 0

                    factor_add_x_val1 /= 2
                End While
                x_val1 -= factor_add_x_val1
                If last_dir1 = 1 Then
                    factor_add_x_val1 /= 2

                End If
                last_dir1 = -1
            End If
            If factor_add_x_val1 < Math.Pow(10, -12) Then
                to_stop1 = 1
            End If

            count_loop1 += 1

            If count_loop1 > 99999 Then
                to_stop1 = 1
            End If
        End While


        Return x_val1
    End Function

    Public Function first_session(curve_pxls1 As ArrayList, pxls_line1 As ArrayList)
        Dim curve_pxls1_xy_dict1 As Dictionary(Of Integer, Integer) = CGlobals1.arr_xy_to_dict2(curve_pxls1)
        Dim pxls_line1_xy_dict1 As Dictionary(Of Integer, Integer) = CGlobals1.arr_xy_to_dict2(pxls_line1)

        Dim i1 As Integer = 0
        Dim to_stop1 As Integer = 0
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        While to_stop1 = 0
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, i1)

            If curve_pxls1_xy_dict1(cord_xy1(0)) - 1 = cord_xy1(1) Then
                to_stop1 = 1

            End If
            If curve_pxls1_xy_dict1(cord_xy1(0)) = cord_xy1(1) Then
                to_stop1 = 1
                dict_res1("res1") = "overlap_failed1"

                Return dict_res1
            End If
            i1 += 1

        End While
        to_stop1 = 0
        While to_stop1 = 0
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, i1)

            If curve_pxls1_xy_dict1(cord_xy1(0)) - 1 < cord_xy1(1) Then
                to_stop1 = 1

            End If

            i1 += 1

        End While

    End Function
End Class
