﻿Imports System.Runtime.Intrinsics.X86

Public Class CEdgeDetection1

    'E:\memomi_folder1\glass_pics_8\980376449

    Public Function find_nearest_slice_curve1(cur_cords_dict1 As Dictionary(Of String, Object), slices_curves1 As ArrayList)


        Dim i1 As Integer
        Dim max_len1 As Integer = -1
        Dim max_len_ind1 As Integer = -1
        Dim was_compare1 As Integer = 0
        For i1 = 0 To slices_curves1.Count - 1


            Dim to_compare1 As Integer = compare_sqrs_of_cords1(cur_cords_dict1("dict_sqrs_of_cords1"), slices_curves1(i1)("dict_sqrs_of_cords1"))

            If to_compare1 = 1 Then
                was_compare1 = 1
                Dim dict_ret_res1 As Dictionary(Of String, Object) = check_if_overlap_pixel1(cur_cords_dict1("cords_dict1"), slices_curves1(i1)("cords_dict1"), 3)

                If dict_ret_res1("min_cord_ind1") <> -1 Then
                    If max_len1 < slices_curves1(i1)("cords_dict1").count Then
                        max_len1 = slices_curves1(i1)("cords_dict1").count
                        max_len_ind1 = i1
                    End If
                End If
            Else
                If was_compare1 = 1 Then
                    i1 = slices_curves1.Count
                End If
            End If




        Next


        Return max_len1

    End Function


    Public Function check_connectivity_between_slice_curves1(slice_curves_arr1 As ArrayList, slice_curves_arr2 As ArrayList, cur_slices_curves1 As ArrayList)

        Dim i1 As Integer = 0
        Dim i2 As Integer = 0


        Dim to_stop1 As Integer = 0
        Dim to_stop2 As Integer = 0


        Dim first_cord1_ind1 As Integer = -1
        Dim second_cord1_ind1 As Integer = -1


        Dim max_first_cord2_ind1 As Integer
        Dim max_second_cord2_ind1 As Integer

        Dim max_diff_dist_cord1 As Integer = -1


        Dim dict_cache_overlaps1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim dict_cache_overlaps2 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)

        While to_stop1 = 0
            Dim dict_cords1 As Dictionary(Of String, Integer) = slice_curves_arr1(i1)("cords_dict1")

            i2 = 0
            to_stop2 = 0
            second_cord1_ind1 = -1
            While to_stop2 = 0
                Dim dict_cords2 As Dictionary(Of String, Integer) = slice_curves_arr2(i2)("cords_dict1")

                Dim to_compare1 As Integer = 1 'compare_sqrs_of_cords1(slice_curves_arr1(i1)("dict_sqrs_of_cords1"), slice_curves_arr2(i2)("dict_sqrs_of_cords1"))


                If to_compare1 = 1 Then


                    Dim len1 As Integer = -1
                    If dict_cache_overlaps1.ContainsKey(i1) Then
                        len1 = dict_cache_overlaps1(i1)
                    Else
                        len1 = find_nearest_slice_curve1(slice_curves_arr1(i1), cur_slices_curves1)
                        dict_cache_overlaps1(i1) = len1
                    End If
                    Dim len2 As Integer = -1

                    If dict_cache_overlaps2.ContainsKey(i2) Then
                        len2 = dict_cache_overlaps2(i2)
                    Else
                        len2 = find_nearest_slice_curve1(slice_curves_arr2(i2), cur_slices_curves1)
                        dict_cache_overlaps2(i2) = len2
                    End If



                    If len1 > 20 And len2 > 20 Then




                        Dim dict_ret_res1 As Dictionary(Of String, Object) = check_if_overlap_pixel1(dict_cords1, dict_cords2, 8)
                        If dict_ret_res1("min_cord_ind1") <> -1 Then
                            If first_cord1_ind1 <> -1 And second_cord1_ind1 <> -1 Then
                                Dim diff_dist_cords1 As Integer = Math.Abs(Math.Abs(first_cord1_ind1 - i1) - Math.Abs(second_cord1_ind1 - i2))
                                If diff_dist_cords1 > 15 Then

                                    If max_diff_dist_cord1 < diff_dist_cords1 Then
                                        max_diff_dist_cord1 = diff_dist_cords1
                                        max_first_cord2_ind1 = second_cord1_ind1
                                        max_second_cord2_ind1 = i2
                                    End If
                                    Dim err1 As String = "yes"
                                End If

                                first_cord1_ind1 = i1
                                second_cord1_ind1 = i2
                            Else
                                first_cord1_ind1 = i1
                                second_cord1_ind1 = i2
                                'to_stop2 = 1

                            End If
                        Else
                            'first_cord1_ind1 = -1
                            'first_cord2_ind1 = -1
                        End If

                    End If


                    i2 += 1

                    If i2 >= slice_curves_arr2.Count - 1 Then
                        to_stop2 = 1

                    End If
                End If
            End While

            i1 += 1

            If i1 >= slice_curves_arr1.Count - 1 Then
                to_stop1 = 1

            End If
        End While
        'max_first_cord2_ind1 = i2
        'max_second_cord2_ind1 = second_cord1_ind1

        If max_diff_dist_cord1 <> -1 Then

            Dim slice_curve_to_del1 As ArrayList = slice_curves_arr2.Clone()

            For ind3 = max_first_cord2_ind1 To max_second_cord2_ind1
                slice_curves_arr2.RemoveAt(max_first_cord2_ind1)
            Next




            If True Then



                While slice_curve_to_del1.Count > max_second_cord2_ind1
                    Try
                        slice_curve_to_del1.RemoveAt(slice_curve_to_del1.Count - 1)

                    Catch ex As Exception

                    End Try
                End While


                For ind3 = 0 To max_first_cord2_ind1
                    Try
                        slice_curve_to_del1.RemoveAt(0)

                    Catch ex As Exception

                    End Try
                Next
            End If

            save_slices_curves_in_bmp1(slice_curve_to_del1, CGlobals1.global_path1 + "sobel_pics1\slice_curve_to_del2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")



        End If

        'For i1 = 0 To slice_curves_arr1.Count - 1

        'Next
    End Function


    Public Function check_connectivity_between_pixels1(sobel_res1 As Dictionary(Of String, Object), sobel_res2 As Dictionary(Of String, Object))
        Dim arr1 As ArrayList = sobel_res1("arr1")
        Dim arr2 As ArrayList = sobel_res2("arr1")


        Dim dict1 As Dictionary(Of String, Integer) = sobel_res1("dict1")
        Dim dict2 As Dictionary(Of String, Integer) = sobel_res2("dict1")

        Dim dict_wrong_connectivity1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        Dim ind1 As Integer


        For ind1 = 0 To arr1.Count - 2
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, ind1)
            Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, ind1 + 1)

            Dim x1 As Integer
            Dim y1 As Integer





            Dim ind_of_first1 As Integer = -1
            Dim ind_of_second1 As Integer = -1

            If dict2.ContainsKey((cord_xy1(0) + 0).ToString() + "," + (cord_xy1(1) + 0).ToString()) = True Then
                ind_of_first1 = dict2((cord_xy1(0) + 0).ToString() + "," + (cord_xy1(1) + 0).ToString())
            End If

            If dict2.ContainsKey((cord_xy2(0) + 0).ToString() + "," + (cord_xy2(1) + 0).ToString()) = True Then
                ind_of_second1 = dict2((cord_xy2(0) + 0).ToString() + "," + (cord_xy2(1) + 0).ToString())
            End If


            If ind_of_first1 = -1 Then
                For x1 = -1 To 1
                    For y1 = -1 To 1
                        If dict2.ContainsKey((cord_xy1(0) + x1).ToString() + "," + (cord_xy1(1) + y1).ToString()) = True Then
                            ind_of_first1 = dict2((cord_xy1(0) + x1).ToString() + "," + (cord_xy1(1) + y1).ToString())
                        End If
                    Next

                Next

            End If

            If ind_of_second1 = -1 Then
                For x1 = -1 To 1
                    For y1 = -1 To 1
                        If dict2.ContainsKey((cord_xy2(0) + x1).ToString() + "," + (cord_xy2(1) + y1).ToString()) = True Then
                            ind_of_second1 = dict2((cord_xy2(0) + x1).ToString() + "," + (cord_xy2(1) + y1).ToString())
                        End If
                    Next

                Next

            End If

            If Math.Abs(ind_of_first1 - ind_of_second1) > 15 And ind_of_first1 <> -1 And ind_of_second1 <> -1 Then
                Dim wrond_connectivity1 As String = "yes"
                dict_wrong_connectivity1(ind_of_first1.ToString() + "," + ind_of_second1.ToString()) = 1
            End If
        Next

        Return dict_wrong_connectivity1
    End Function



    Public Function print_slices_curve1(slices_curves_arr1 As ArrayList, sobel_ind1 As Integer)
        Dim i1 As Integer
        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))


        Dim last_dict_angles1 As Dictionary(Of Double, Integer) = Nothing
        Dim r1 As Integer = 100
        Dim g1 As Integer = 100
        Dim b1 As Integer = 100

        Dim last_end_angle1 As Double = -999
        Dim last_cord_xy1 As Double()
        For i1 = 0 To slices_curves_arr1.Count - 1
            Dim dict_slice_curve1 As Dictionary(Of String, Object) = slices_curves_arr1(i1)
            Dim cords_arr1 As ArrayList = dict_slice_curve1("cords_arr1")
            'dict_slice_curve1("cords_dict1") = CGlobals1.add_to_dict1(cords_arr1)
            Dim dict_angles1 As Dictionary(Of Double, Integer) = dict_slice_curve1("dict_angles1")

            'Dim start_angle1 As Double = dict_slice_curve1("start_angle1")
            'Dim last_angle1 As Double = dict_slice_curve1("last_angle1")

            Dim connect_slices1 As String = ""


            If i1 > 0 And last_cord_xy1 IsNot Nothing Then
                'Dim angle1 As Double = get_angle1(CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, cords_arr1.Count - 2), CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, cords_arr1.Count - 2))
                If cords_arr1.Count > 0 Then

                    Dim start_angle1 As Double = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1(last_cord_xy1, CGlobals1.get_double_cord_xy_in_pixels_arr2(cords_arr1, 0))

                    If Math.Abs(start_angle1 - last_end_angle1) <= 45 Then
                        connect_slices1 = "yes"
                    End If

                    If Math.Abs(start_angle1 - last_end_angle1) = 315 Then
                        connect_slices1 = "yes"
                    End If
                End If

            End If



            If connect_slices1 = "" Then


                r1 += 50
                g1 -= 70
                b1 += 20

                If r1 > 255 Then
                    r1 = 0
                End If

                If g1 > 255 Then
                    g1 = 0
                End If

                If b1 > 255 Then
                    b1 = 0
                End If


                If r1 < 0 Then
                    r1 = 255
                End If

                If g1 < 0 Then
                    g1 = 255
                End If

                If b1 < 0 Then
                    b1 = 255
                End If

            End If

            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(cords_arr1, bmp5, Color.FromArgb(r1, g1, b1))

            last_dict_angles1 = dict_angles1
            If cords_arr1.Count > 1 Then
                last_end_angle1 = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1(CGlobals1.get_double_cord_xy_in_pixels_arr2(cords_arr1, cords_arr1.Count - 2), CGlobals1.get_double_cord_xy_in_pixels_arr2(cords_arr1, cords_arr1.Count - 1))
                last_cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(cords_arr1, cords_arr1.Count - 1)
            Else
                last_cord_xy1 = Nothing
            End If
        Next




        bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\curve_no_noise3_" + sobel_ind1.ToString() + ".bmp")

    End Function


    Public Function check_if_trend_without_noise(curve_pixels_arr1 As ArrayList, sobel_ind1 As Integer)
        Dim i1 As Integer
        Dim trend_x1 As Integer = 0
        Dim trend_y1 As Integer = 0

        Dim angle_treshold1 As Double = 45
        Dim last_trend_x1 As Integer = 0
        Dim last_trend_y1 As Integer = 0

        Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, 0)
        Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, 1)

        Dim angle1 As Double = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1(New Double() {cord_xy1(0), cord_xy1(1)}, New Double() {cord_xy2(0), cord_xy2(1)})
        Dim add_angle1 As Double = 0
        If angle1 < 90 Then
            add_angle1 = 90
        End If

        If angle1 > 270 Then
            add_angle1 = -90
        End If

        angle1 += add_angle1

        Dim min_angle1 As Double = 999
        Dim max_angle1 As Double = -999
        If min_angle1 > angle1 Then
            min_angle1 = angle1
        End If


        If max_angle1 < angle1 Then
            max_angle1 = angle1
        End If


        Dim to_stop1 As Integer = 0
        Dim cords_arr1 As ArrayList = New ArrayList()


        Dim to_stop2 As Integer = 0

        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))


        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp5, Color.FromArgb(24, 20, 50))


        Dim r1 As Integer = 100
        Dim g1 As Integer = 150
        Dim b1 As Integer = 200

        i1 = 1
        'i1 = 2500
        'i1 = 1700

        CGlobals1.draw_sqr_around_pixels(bmp5, CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)(0), CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)(1), 2, Color.FromArgb(200, 50, 150))
        Dim angles_arr1 As ArrayList = New ArrayList()

        Dim slice_curve_without_noise_arr1 As ArrayList = New ArrayList()
        Dim last_org_angles1 As Double = -999
        Dim start_angle1 As Double = -999
        Dim last_angle1 As Double = -999
        While to_stop2 = 0
            to_stop1 = 0
            Dim dict_angles1 As Dictionary(Of Double, Integer) = New Dictionary(Of Double, Integer)

            If last_org_angles1 <> -999 Then
                dict_angles1(last_org_angles1) = dict_angles1.Count
                cords_arr1.Add(curve_pixels_arr1(i1))
                last_org_angles1 = -999
            End If

            While to_stop1 = 0





                cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)
                cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1 + 1)
                angle1 = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1(New Double() {cord_xy1(0), cord_xy1(1)}, New Double() {cord_xy2(0), cord_xy2(1)})

                Dim org_angle1 As Double = angle1

                If start_angle1 = -999 Then
                    start_angle1 = org_angle1
                End If

                angle1 += add_angle1
                If angle1 > 360 Then
                    angle1 = angle1 - 360
                End If
                Dim angle_minus1 As Double = -(360 - angle1)
                If Math.Abs(Math.Abs(angle_minus1) - min_angle1) < Math.Abs(Math.Abs(angle1) - max_angle1) Then
                    'min_angle1 = angle_minus1
                Else


                End If
                If min_angle1 > angle1 Then
                    min_angle1 = angle1
                End If


                If max_angle1 < angle1 Then
                    max_angle1 = angle1
                End If
                angles_arr1.Add("angle1=" + angle1.ToString() + ",min_angle1=" + min_angle1.ToString() + ",max_angle1=" + max_angle1.ToString() + "add_angle1=" + add_angle1.ToString())

                i1 += 1
                If Math.Abs(min_angle1 - max_angle1) > angle_treshold1 Or i1 >= curve_pixels_arr1.Count - 2 Then
                    last_org_angles1 = org_angle1
                    to_stop1 = 1



                    'to_stop2 = 1


                    angle1 = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1(New Double() {cord_xy1(0), cord_xy1(1)}, New Double() {cord_xy2(0), cord_xy2(1)})


                    If angle1 < 90 Then
                        add_angle1 = 90
                    End If
                    If angle1 > 270 Then
                        add_angle1 = -90
                    End If
                    angle1 += add_angle1


                    min_angle1 = 999
                    max_angle1 = -999
                    If min_angle1 > angle1 Then
                        min_angle1 = angle1
                    End If


                    If max_angle1 < angle1 Then
                        max_angle1 = angle1
                    End If



                Else

                    dict_angles1(org_angle1) = dict_angles1.Count
                    cords_arr1.Add(curve_pixels_arr1(i1))
                    last_angle1 = org_angle1
                End If


                If i1 >= curve_pixels_arr1.Count - 2 Then
                    to_stop2 = 1
                End If


            End While

            r1 += 50
            g1 -= 70
            b1 += 20

            If r1 > 255 Then
                r1 = 0
            End If

            If g1 > 255 Then
                g1 = 0
            End If

            If b1 > 255 Then
                b1 = 0
            End If


            If r1 < 0 Then
                r1 = 255
            End If

            If g1 < 0 Then
                g1 = 255
            End If

            If b1 < 0 Then
                b1 = 255
            End If


            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(cords_arr1, bmp5, Color.FromArgb(r1, g1, b1))


            'bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\slices1\curve_no_noise1_" + sobel_ind1.ToString() + "_" + angle_treshold1.ToString() + "_" + slice_curve_without_noise_arr1.Count.ToString() + ".bmp")


            Dim dict_slice_curve1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
            dict_slice_curve1("cords_arr1") = cords_arr1
            dict_slice_curve1("dict_sqrs_of_cords1") = get_sqrs_of_cords1(cords_arr1)

            dict_slice_curve1("cords_dict1") = CGlobals1.add_to_dict1(cords_arr1)
            dict_slice_curve1("dict_angles1") = dict_angles1
            dict_slice_curve1("last_angle1") = last_angle1
            dict_slice_curve1("start_angle1") = start_angle1

            start_angle1 = -999

            slice_curve_without_noise_arr1.Add(dict_slice_curve1)
            dict_angles1 = New Dictionary(Of Double, Integer)
            cords_arr1 = New ArrayList()




        End While





        bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\curve_no_noise1_" + sobel_ind1.ToString() + "_" + angle_treshold1.ToString() + ".bmp")

        Return slice_curve_without_noise_arr1
    End Function












    Public Function count_neighboors_with_less_diff1(ByRef bmp_max_diff1 As Bitmap, cord_xy1 As Integer())

        If CGlobals1.some_max_diff_val1.ContainsKey(cord_xy1(0).ToString() + "," + cord_xy1(1).ToString()) = True Then
            Return CGlobals1.some_max_diff_val1(cord_xy1(0).ToString() + "," + cord_xy1(1).ToString())
        End If
        Dim some_max_diff1 As Double = 0
        Dim padding_search1 As Integer = 1
        For x1 = -padding_search1 To padding_search1
            For y1 = -padding_search1 To padding_search1
                Dim cur_x1 As Integer = cord_xy1(0) + x1
                Dim cur_y1 As Integer = cord_xy1(1) + y1

                If cur_x1 > 0 And cur_y1 > 0 And cur_x1 < (bmp_max_diff1.Width - 1) And cur_y1 < (bmp_max_diff1.Height - 1) Then
                    Try
                        'count_search1 += 1
                        Dim color2 As Color = bmp_max_diff1.GetPixel(cord_xy1(0) + x1, cord_xy1(1) + y1)
                        'dict_colors1(x1.ToString() + "," + y1.ToString()) = color2.R
                        some_max_diff1 += color2.R


                    Catch ex As Exception
                        Dim err1 As String = "yes"
                    End Try
                End If

            Next

        Next

        CGlobals1.some_max_diff_val1(cord_xy1(0).ToString() + "," + cord_xy1(1).ToString()) = some_max_diff1

        Return some_max_diff1
    End Function
    Public Function get_count_pixels_slice_of_curve_contain_in_slice_of_curve1(slice_of_curve1 As Dictionary(Of String, Object), contain_slice_of_curve1 As Dictionary(Of String, Object), pad1 As Integer)
        Dim cords_arr1 As ArrayList = slice_of_curve1("cords_arr1")
        Dim contain_cords_arr1 As ArrayList = contain_slice_of_curve1("cords_arr1")

        Dim dict_cords1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(cords_arr1)
        Dim dict_contained_cords1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim i1 As Integer

        Dim count_cords_exist1 As Integer = 0
        Dim count_cords_seq_exist1 As Integer = 0


        For i1 = pad1 To contain_cords_arr1.Count - pad1


            Dim x1 As Integer
            Dim y1 As Integer
            Dim exist_in_current_slice2 As String = "no"

            For x1 = -pad1 To pad1
                For y1 = -pad1 To pad1
                    Dim key1 As String = (CGlobals1.get_cord_xy_in_pixels_arr1(contain_cords_arr1, i1)(0) + x1).ToString() + "," + (CGlobals1.get_cord_xy_in_pixels_arr1(contain_cords_arr1, i1)(1) + y1).ToString()

                    If dict_cords1.ContainsKey(key1) = True Then
                        exist_in_current_slice2 = "yes"

                    End If
                Next
            Next

            If exist_in_current_slice2 = "yes" Then
                dict_contained_cords1(contain_cords_arr1(i1)) = 1
                count_cords_exist1 += 1
                count_cords_seq_exist1 += 1
            Else
                count_cords_seq_exist1 = 0
            End If

        Next

        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res1("count_cords_exist1") = count_cords_exist1
        dict_res1("count_cords_seq_exist1") = count_cords_seq_exist1
        dict_res1("dict_contained_cords1") = dict_contained_cords1

        Return dict_res1
    End Function
    Public Function compare_slice_curves_arr2(slice_curve_arr2 As ArrayList, slice_curve_arr1 As ArrayList)

        Dim i1 As Integer

        Dim max_cords_len_val1 As Integer = -1
        Dim max_cords_len_ind1 As Integer = -1
        For i1 = 0 To slice_curve_arr1.Count - 1
            Dim dict_slice_curve1 As Dictionary(Of String, Object) = slice_curve_arr1(i1)
            Dim cords_arr1 As ArrayList = dict_slice_curve1("cords_arr1")
            If max_cords_len_val1 < cords_arr1.Count Then
                max_cords_len_val1 = cords_arr1.Count
                max_cords_len_ind1 = i1
            End If
        Next

        Dim cords_arr2 As ArrayList = slice_curve_arr1(max_cords_len_ind1)("cords_arr1")
        'Dim cords_arr1 As ArrayList = dict_slice_curve1("cords_arr1")

        Dim max_overlap_slice2_val1 As Integer = -1
        Dim max_overlap_slice2_ind1 As Integer = -1

        For i1 = 0 To slice_curve_arr2.Count - 1
            Dim dict_slice_curve1 As Dictionary(Of String, Object) = slice_curve_arr2(i1)
            Dim cords_arr1 As ArrayList = dict_slice_curve1("cords_arr1")
            Dim dict_cords1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(cords_arr1)

            Dim i2 As Integer
            Dim all_cords_exist_in_current_slice2 As String = "yes"
            Dim count_cords_exist1 As Integer = 0
            For i2 = 0 To cords_arr2.Count - 1
                Dim x1 As Integer
                Dim y1 As Integer
                Dim exist_in_current_slice2 As String = "no"
                Dim pad1 As Integer = 4
                For x1 = -pad1 To pad1
                    For y1 = -pad1 To pad1
                        Dim key1 As String = (CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr2, i2)(0) + x1).ToString() + "," + (CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr2, i2)(1) + y1).ToString()

                        If dict_cords1.ContainsKey(key1) = True Then
                            exist_in_current_slice2 = "yes"
                            count_cords_exist1 += 1
                        End If
                    Next
                Next

                If count_cords_exist1 > max_overlap_slice2_val1 Then
                    max_overlap_slice2_val1 = count_cords_exist1
                    max_overlap_slice2_ind1 = i1
                End If
                If exist_in_current_slice2 = "no" Then
                    all_cords_exist_in_current_slice2 = "no"
                Else
                    Dim d1 As Integer = 1
                End If
            Next


        Next

    End Function


    Public Function order_slices_curves_arr(slice_curve_arr1 As ArrayList)

        Dim new_slice_curve_arr1 As ArrayList = New ArrayList()
        Dim dict_slice_inds1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)


        Dim i2 As Integer

        For i2 = 0 To slice_curve_arr1.Count - 1

            Dim i1 As Integer
            Dim min_cords_len_val1 As Integer = 99999
            Dim min_cords_len_ind1 As Integer = -1
            For i1 = 0 To slice_curve_arr1.Count - 1
                If dict_slice_inds1.ContainsKey(i1) = False Then
                    Dim dict_slice_curve1 As Dictionary(Of String, Object) = slice_curve_arr1(i1)
                    Dim cords_arr2 As ArrayList = dict_slice_curve1("cords_arr1")
                    If min_cords_len_val1 > cords_arr2.Count Then
                        min_cords_len_val1 = cords_arr2.Count
                        min_cords_len_ind1 = i1

                    End If
                End If
            Next
            dict_slice_inds1(min_cords_len_ind1) = 1
            new_slice_curve_arr1.Add(slice_curve_arr1(min_cords_len_ind1))
        Next

        Return new_slice_curve_arr1

    End Function


    Public Function merge_slices_arr1(slices_arr1 As ArrayList)
        Dim i1 As Integer
        Dim i2 As Integer

        For i1 = 0 To slices_arr1.Count - 1
            For i2 = 0 To slices_arr1.Count - 1
                If i1 <> i2 Then

                    Dim dict_res1 As Dictionary(Of String, Object) = get_count_pixels_slice_of_curve_contain_in_slice_of_curve1(slices_arr1(i1), slices_arr1(i2), 0)

                    Dim count_contained1 As Integer = dict_res1("count_cords_seq_exist1")

                    If count_contained1 > 1 Then
                        Dim d1 As Integer = 1
                    End If
                End If

            Next

        Next
    End Function

    Public Function get_sqr_of_cord1(x_cord1 As Integer, y_cord1 As Integer)

        Dim x_sqr1 As Integer = x_cord1 / 40
        Dim y_sqr1 As Integer = y_cord1 / 40

        Return x_sqr1.ToString() + "_" + y_sqr1.ToString()
    End Function

    Public Function get_sqrs_of_cords1(cords_arr1 As ArrayList)
        Dim i1 As Integer
        Dim dict_sqrs_cords1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        For i1 = 0 To cords_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, i1)
            Dim x1 As Integer
            Dim y1 As Integer

            For x1 = -1 To 1
                For y1 = -1 To 1
                    dict_sqrs_cords1(get_sqr_of_cord1(cord_xy1(0) + x1, cord_xy1(1) + y1)) = dict_sqrs_cords1.Count

                Next

            Next
        Next

        If dict_sqrs_cords1.Count > 1 Then
            Dim d1 As Integer = 1
        End If
        Return dict_sqrs_cords1
    End Function

    Public Function compare_sqrs_of_cords1(dict_sqrs_cords1 As Dictionary(Of String, Integer), dict_sqrs_cords2 As Dictionary(Of String, Integer))
        Dim i1 As Integer

        For i1 = 0 To dict_sqrs_cords1.Keys.Count - 1
            If dict_sqrs_cords2.ContainsKey(dict_sqrs_cords1.Keys(i1)) Then
                Return 1
            End If
        Next

        Return 0
    End Function


    Public Function add_slice_curves_that_part_is_not_in_curves(add_slice_curve_arr1 As ArrayList, slice_curve_arr2 As ArrayList, sobel_ind1 As Integer)

        Dim add_order_slice_curve_arr1 As ArrayList = order_slices_curves_arr(add_slice_curve_arr1)
        Dim order_slice_curve_arr2 As ArrayList = order_slices_curves_arr(slice_curve_arr2)
        Dim new_order_slice_curve_arr1 As ArrayList = New ArrayList()

        Dim dict_inds1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim dict_inds2 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim dict_inds2_contatined_partially As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim i1 As Integer
        Dim i2 As Integer
        Dim min_slice_len1 As Integer = 30
        'Dim min_slice_len2 As Integer = 50
        'Dim min_slice_len3 As Integer = 20
        For i1 = add_order_slice_curve_arr1.Count - 1 To 0 Step -1
            Dim is_contained1 As String = ""
            If CType(add_order_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey(CGlobals1.debug_str1) = True Then
                If sobel_ind1 = CGlobals1.debug_int1 Then
                    Dim d2 As Integer = 1
                End If

            End If

            If CType(add_order_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer)).Count > min_slice_len1 Then


                Dim cords_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

                For i2 = 0 To CType(add_order_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer)).Count - 1
                    cords_dict1(CType(add_order_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer)).Keys(i2)) = 1
                Next

                Dim count_slices_contain1 As Integer = 0
                Dim sum_len_slice_contain1 As Integer = 0
                Dim sum_pixels_contained1 As Integer = 0
                'Dim cords_dict1 As Dictionary(Of String, Integer) = CType(order_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer))
                For i2 = order_slice_curve_arr2.Count - 1 To 0 Step -1



                    Dim to_compare1 As Integer = compare_sqrs_of_cords1(add_order_slice_curve_arr1(i1)("dict_sqrs_of_cords1"), order_slice_curve_arr2(i2)("dict_sqrs_of_cords1"))
                    If to_compare1 = 1 Then



                        If CType(order_slice_curve_arr2(i2)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey(CGlobals1.debug_str1) = True And sobel_ind1 = 33 Then
                            Dim d3 As Integer = 1
                        End If

                        Dim dict_res1 As Dictionary(Of String, Object) = Nothing

                        If order_slice_curve_arr2(i2)("cords_arr1").count > min_slice_len1 Then


                            dict_res1 = get_count_pixels_slice_of_curve_contain_in_slice_of_curve1(order_slice_curve_arr2(i2), add_order_slice_curve_arr1(i1), 3)

                            Dim dict_contained_cords1 As Dictionary(Of String, Integer) = dict_res1("dict_contained_cords1")

                            Dim i3 As Integer



                            'If dict_contained_cords1.Count > min_slice_len2 Then
                            If dict_contained_cords1.Count > min_slice_len1 Then
                                sum_len_slice_contain1 += order_slice_curve_arr2(i2)("cords_dict1").count
                                count_slices_contain1 += 1
                                dict_inds2_contatined_partially(i2) = 1
                                For i3 = 0 To dict_contained_cords1.Count - 1
                                    If cords_dict1(dict_contained_cords1.Keys(i3)) = 1 Then
                                        sum_pixels_contained1 += 1
                                    End If
                                    cords_dict1(dict_contained_cords1.Keys(i3)) = 2
                                Next
                            End If
                        End If
                        'order_slice_curve_arr1(i1)("cords_arr1").count > min_slice_len1 And

                        Dim d1 As Integer = 1
                    End If
                Next



                If sum_pixels_contained1 < cords_dict1.Count * 0.2 Then
                    dict_inds1(i1) = 1
                End If
            End If
        Next
        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        Dim bmp6 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        Dim r1 As Integer = 0
        Dim g1 As Integer = 0
        Dim b1 As Integer = 0

        'For i1 = 0 To order_slice_curve_arr2.Count - 1
        'new_order_slice_curve_arr1.Add(order_slice_curve_arr2(i1))

        'Next

        For i1 = 0 To slice_curve_arr2.Count - 1
            new_order_slice_curve_arr1.Add(slice_curve_arr2(i1))

        Next


        'Return new_order_slice_curve_arr1

        For i1 = 0 To dict_inds1.Count - 1
            new_order_slice_curve_arr1.Add(add_order_slice_curve_arr1(dict_inds1.Keys(i1)))


            Dim curve_pixels_arr1 As ArrayList = new_order_slice_curve_arr1(new_order_slice_curve_arr1.Count - 1)("cords_arr1")


            r1 += 50
            g1 -= 70
            b1 += 20

            If r1 > 255 Then
                r1 = 0
            End If

            If g1 > 255 Then
                g1 = 0
            End If

            If b1 > 255 Then
                b1 = 0
            End If


            If r1 < 0 Then
                r1 = 255
            End If

            If g1 < 0 Then
                g1 = 255
            End If

            If b1 < 0 Then
                b1 = 255
            End If


            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp5, Color.FromArgb(r1, g1, b1))

            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp6, Color.FromArgb(124, 20, 50))
        Next



        bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\curve_no_noise4b_" + sobel_ind1.ToString() + ".bmp")
        bmp6.Save(CGlobals1.global_path1 + "sobel_pics1\curve_no_noise5b_" + sobel_ind1.ToString() + ".bmp")

        new_order_slice_curve_arr1 = order_slices_curves_arr(new_order_slice_curve_arr1)
        Return new_order_slice_curve_arr1
    End Function

    Public Function create_bmp_from_slices_curves_arr1(slices_curves_arr1 As ArrayList, add_x1 As Integer, add_y1 As Integer, ByRef bmp5 As Bitmap)

        Dim r1 As Integer = 0
        Dim g1 As Integer = 0
        Dim b1 As Integer = 0


        Dim i1 As Integer

        For i1 = 0 To slices_curves_arr1.Count - 1
            Dim curve_pixels_arr1 As ArrayList = slices_curves_arr1(i1)("cords_arr1")



            r1 += 50
            g1 -= 70
            b1 += 20

            If r1 > 255 Then
                r1 = 0
            End If

            If g1 > 255 Then
                g1 = 0
            End If

            If b1 > 255 Then
                b1 = 0
            End If


            If r1 < 0 Then
                r1 = 255
            End If

            If g1 < 0 Then
                g1 = 255
            End If

            If b1 < 0 Then
                b1 = 255
            End If

            Dim i2 As Integer
            Dim curve_pixels_arr2 As ArrayList = New ArrayList()

            For i2 = 0 To curve_pixels_arr1.Count - 1
                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i2)
                curve_pixels_arr2.Add((cord_xy1(0) + add_x1).ToString() + "," + (cord_xy1(1) + add_y1).ToString())

            Next
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr2, bmp5, Color.FromArgb(r1, g1, b1))


        Next


        Return bmp5
    End Function

    Public Function merge_connect_slices_of_curves1(slice_curve_arr1 As ArrayList)
        Dim i1 As Integer
        Dim i2 As Integer
        Dim dict_connected_slices_curves1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        For i1 = 0 To slice_curve_arr1.Count - 1
            For i2 = 0 To slice_curve_arr1.Count - 1
                If i1 <> i2 And dict_connected_slices_curves1.ContainsKey(i1.ToString() + "_" + i2.ToString()) = False Then

                    Dim cord_ind1 As Integer
                    For cord_ind1 = 0 To CType(slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer)).Keys.Count - 1
                        Dim cord_xy1 As String() = CType(slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer)).Keys(cord_ind1).Split(",")
                        Dim x1 As Integer = Integer.Parse(cord_xy1(0))
                        Dim y1 As Integer = Integer.Parse(cord_xy1(1))
                        Dim x2 As Integer
                        Dim y2 As Integer

                        For x2 = x1 - 1 To x1 + 1
                            For y2 = y1 - 1 To y1 + 1
                                If CType(slice_curve_arr1(i2)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey(x2.ToString() + "," + y2.ToString()) = True Then
                                    dict_connected_slices_curves1(i1.ToString() + "_" + i2.ToString()) = 1
                                End If

                            Next

                        Next



                    Next

                End If
            Next
        Next

        Return dict_connected_slices_curves1
    End Function


    Public Function add_slices_of_curve_when_no_curves(cur_slice_curve_arr1 As ArrayList, add_slice_curve_arr2 As ArrayList, sobel_ind1 As Integer)
        Dim i1 As Integer
        Dim i2 As Integer


        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(2000, 1500, Color.FromArgb(255, 255, 255))

        Dim connected_slices_curves1 As ArrayList = New ArrayList()

        Dim max_cur_cords_dict_ind1 As Integer = -1
        Dim min_add_cords_dict_ind1 As Integer = -1
        Dim add_slice_curve_ind2 As Integer = -1
        For i1 = 0 To cur_slice_curve_arr1.Count - 1
            Dim cur_cords_dict1 As Dictionary(Of String, Integer) = CType(cur_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer))
            For i2 = 0 To add_slice_curve_arr2.Count - 1


                Dim add_cords_dict2 As Dictionary(Of String, Integer) = CType(add_slice_curve_arr2(i2)("cords_dict1"), Dictionary(Of String, Integer))
                If add_cords_dict2.Count > 20 Then
                    Dim cord_ind1 As Integer

                    For cord_ind1 = 0 To add_cords_dict2.Count - 1
                        If cur_cords_dict1.ContainsKey(add_cords_dict2.Keys(cord_ind1)) = True Then
                            If max_cur_cords_dict_ind1 = -1 Then
                                max_cur_cords_dict_ind1 = cur_cords_dict1(add_cords_dict2.Keys(cord_ind1))
                                add_slice_curve_ind2 = i2
                            Else
                                If max_cur_cords_dict_ind1 < cur_cords_dict1(add_cords_dict2.Keys(cord_ind1)) Then
                                    max_cur_cords_dict_ind1 = cur_cords_dict1(add_cords_dict2.Keys(cord_ind1))
                                    add_slice_curve_ind2 = i2
                                End If
                            End If

                            If min_add_cords_dict_ind1 = -1 Then
                                min_add_cords_dict_ind1 = add_cords_dict2.Keys(cord_ind1)
                            Else
                                If min_add_cords_dict_ind1 < add_cords_dict2.Keys(cord_ind1) Then
                                    min_add_cords_dict_ind1 = add_cords_dict2.Keys(cord_ind1)
                                End If
                            End If
                        End If
                    Next
                End If


            Next

            Dim d1 As Integer = 1
        Next


    End Function
    Public Function connect_slices_curves_by_new_slices_curves1(slice_curve_arr1 As ArrayList, slice_curve_arr2 As ArrayList, sobel_ind1 As Integer)
        Dim i1 As Integer
        Dim i2 As Integer


        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(2000, 1500, Color.FromArgb(255, 255, 255))

        Dim connected_slices_curves1 As ArrayList = New ArrayList()


        For i1 = 0 To slice_curve_arr1.Count - 1
            Dim cords_dict1 As Dictionary(Of String, Integer) = CType(slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer))
            If cords_dict1.Count > 30 Then

                Dim start_slice_ind1 As Integer = -1
                Dim end_slice_ind1 As Integer = -1
                For i2 = 0 To slice_curve_arr2.Count - 1
                    Dim cords_dict2 As Dictionary(Of String, Integer) = CType(slice_curve_arr2(i2)("cords_dict1"), Dictionary(Of String, Integer))
                    If cords_dict2.Count > 20 Then

                        Dim cord_ind1 As Integer

                        For cord_ind1 = 0 To cords_dict2.Count - 1
                            If cords_dict1.ContainsKey(cords_dict2.Keys(cord_ind1)) = True Then
                                If start_slice_ind1 = -1 Then
                                    start_slice_ind1 = i2
                                End If
                            End If
                        Next
                    End If

                Next


                For i2 = start_slice_ind1 + 1 To slice_curve_arr2.Count - 1
                    Dim cords_dict2 As Dictionary(Of String, Integer) = CType(slice_curve_arr2(i2)("cords_dict1"), Dictionary(Of String, Integer))
                    If cords_dict2.Count > 20 Then
                        Dim cord_ind1 As Integer

                        For cord_ind1 = 0 To cords_dict2.Count - 1
                            If cords_dict1.ContainsKey(cords_dict2.Keys(cord_ind1)) = True Then
                                If end_slice_ind1 = -1 Then
                                    end_slice_ind1 = i2
                                End If
                            End If
                        Next
                    End If
                Next

                If start_slice_ind1 <> -1 And end_slice_ind1 <> -1 Then
                    Dim d1 As Integer = 1
                    Dim new_slices_arr1 As ArrayList = New ArrayList()
                    new_slices_arr1.Add(slice_curve_arr2(start_slice_ind1))
                    new_slices_arr1.Add(slice_curve_arr2(end_slice_ind1))
                    new_slices_arr1.Add(slice_curve_arr1(i1))
                    connected_slices_curves1.Add(slice_curve_arr2(start_slice_ind1))
                    connected_slices_curves1.Add(slice_curve_arr2(end_slice_ind1))
                    connected_slices_curves1.Add(slice_curve_arr1(i1))
                    create_bmp_from_slices_curves_arr1(new_slices_arr1, 0, 0, bmp5)

                End If
            End If

        Next

        bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\bmp_connected1_" + sobel_ind1.ToString() + ".bmp")


        Return connected_slices_curves1
    End Function

    Public Function try_to_merge_slices_curves1(slices_curves_arr1 As ArrayList, ind1 As Integer, ind2 As Integer)


        If ind1 = 9 Then
            Dim d1 As Integer = 1
        End If
        Dim angle_treshold1 As Double = 45

        Dim arr1 As ArrayList = slices_curves_arr1(ind1)("cords_arr1")
        Dim arr2 As ArrayList = slices_curves_arr1(ind2)("cords_arr1")

        If arr1.Count <= 1 And arr2.Count <= 1 Then
            Return Nothing
        End If
        Dim arr3 As ArrayList = CGlobals1.add_arraylist_to_arraylist1(arr1, arr2)



        Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr3, 0)
        Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr3, 1)

        Dim err1 As Integer = 0


        Dim min_angle1 As Double = 999
        Dim max_angle1 As Double = -999
        Dim angle1 As Double = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1(New Double() {cord_xy1(0), cord_xy1(1)}, New Double() {cord_xy2(0), cord_xy2(1)})
        Dim add_angle1 As Double = 0
        If angle1 < 90 Then
            add_angle1 = 90
        End If

        If angle1 > 270 Then
            add_angle1 = -90
        End If

        angle1 += add_angle1

        If min_angle1 > angle1 Then
            min_angle1 = angle1
        End If


        If max_angle1 < angle1 Then
            max_angle1 = angle1
        End If

        Dim i1 As Integer

        For i1 = 1 To arr3.Count - 2

            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(arr3, i1)
            cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(arr3, i1 + 1)

            angle1 = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1(New Double() {cord_xy1(0), cord_xy1(1)}, New Double() {cord_xy2(0), cord_xy2(1)})
            angle1 += add_angle1


            If min_angle1 > angle1 Then
                min_angle1 = angle1
            End If


            If max_angle1 < angle1 Then
                max_angle1 = angle1
            End If


            If Math.Abs(min_angle1 - max_angle1) > angle_treshold1 Then
                err1 = 1
            End If
        Next
        Dim dict_slice_curve1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        Dim res1 As Integer = check_if_dist_over_then1(arr3, 3)
        If err1 = 0 And res1 = 1 Then
            Dim d1 As Integer = 1

            dict_slice_curve1("cords_arr1") = arr3

            dict_slice_curve1("dict_sqrs_of_cords1") = get_sqrs_of_cords1(arr3)

            dict_slice_curve1("cords_dict1") = CGlobals1.add_to_dict1(arr3)


            Return dict_slice_curve1
        End If

        Return Nothing
    End Function


    Public Function add_slices_curves_where_no_slices_curves2(cur_silces_curves1 As ArrayList, add_slices_curves1 As ArrayList)
        Dim i1 As Integer
        Dim i2 As Integer

        For i1 = 0 To cur_silces_curves1.Count - 1

            Dim cords_arr1 As ArrayList = cur_silces_curves1(i1)("cords_arr1")
            Dim cords_arr2 As ArrayList = cur_silces_curves1(i1 + 1)("cords_arr1")
            Dim last_cord1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, cords_arr1.Count - 1)
            Dim start_cord1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr2, 0)
            Dim dist1 As Double = CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy1(last_cord1, start_cord1)
            If dist1 > 5 Then
                For i2 = 0 To add_slices_curves1.Count - 1

                Next
            End If
        Next
    End Function


    Public Function add_slices_curves_that_connected_to_slices_curves1(cur_silces_curves1 As ArrayList, add_slices_curves1 As ArrayList)
        Dim i1 As Integer
        Dim i2 As Integer

    End Function


    Public Function merge_2_slice_curve1(curve_silce1 As Dictionary(Of String, Object), curve_silce2 As Dictionary(Of String, Object), merge_cord1 As Integer(), min_len1 As Integer)
        CGlobals1.merge_2_slice_curve1_count1 += 1

        If CGlobals1.merge_2_slice_curve1_count1 = 3 Then
            Dim d123 As Integer = 1
        End If


        If CType(curve_silce1("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey("295,80") Or CType(curve_silce2("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey("295,80") Then
            Dim d3 As Integer = 1
        End If

        Dim dict_res1 As Dictionary(Of String, Object) = check_if_overlap_pixel1(curve_silce1("cords_dict1"), curve_silce2("cords_dict1"), 1)

        If dict_res1("min_cord_ind1") = -1 Then
            Return Nothing
        End If
        If curve_silce1("cords_dict1").count < 20 Or curve_silce2("cords_dict1").count < 20 Then
            Return Nothing
        End If

        Dim cord_xy1 As Integer()
        Dim cord_xy2 As Integer()

        Try
            cord_xy1 = dict_res1("cord_con_dict1_xy1")
            cord_xy2 = dict_res1("cord_con_dict2_xy1")

        Catch ex As Exception
            Dim err1 As Integer = 1
        End Try




        Dim to_stop1 As Integer = 0
        Dim new_cords_arr1 As ArrayList = New ArrayList()
        Dim cord_ind1 As Integer = 0
        While to_stop1 = 0
            Try
                new_cords_arr1.Add(curve_silce1("cords_arr1")(cord_ind1))

            Catch ex As Exception
                Dim err1 As Integer = 1
                Dim dict_res2 As Dictionary(Of String, Object) = check_if_overlap_pixel1(curve_silce1("cords_dict1"), curve_silce2("cords_dict1"), 1)
            End Try


            If curve_silce1("cords_arr1")(cord_ind1) = cord_xy1(0).ToString() + "," + cord_xy1(1).ToString() Then
                to_stop1 = 1
            Else
                cord_ind1 += 1
            End If

        End While
        check_if_dist_over_then1(new_cords_arr1, 1.415)
        to_stop1 = 0
        cord_ind1 = 0
        While to_stop1 = 0
            Try

                If curve_silce2("cords_arr1")(cord_ind1) = cord_xy2(0).ToString() + "," + cord_xy2(1).ToString() Then
                    to_stop1 = 1
                Else
                    cord_ind1 += 1
                End If

            Catch ex As Exception
                Dim err1 As Integer = 1
                'Dim dict_res2 As Dictionary(Of String, Object) = check_if_overlap_pixel1(curve_silce1("cords_dict1"), curve_silce2("cords_dict1"), 1)
            End Try

        End While
        check_if_dist_over_then1(new_cords_arr1, 1.415)
        to_stop1 = 0
        While to_stop1 = 0

            If cord_ind1 > curve_silce2("cords_arr1").count - 1 Then
                to_stop1 = 1
            Else
                new_cords_arr1.Add(curve_silce2("cords_arr1")(cord_ind1))
                cord_ind1 += 1
            End If

        End While




        check_if_dist_over_then1(new_cords_arr1, 1.415)

        Dim new_slice_curve_result1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        If new_cords_arr1.Count > min_len1 Then

            new_slice_curve_result1("cords_arr1") = new_cords_arr1

            new_slice_curve_result1("dict_sqrs_of_cords1") = get_sqrs_of_cords1(new_cords_arr1)

            new_slice_curve_result1("cords_dict1") = CGlobals1.add_to_dict1(new_cords_arr1)
            Return new_slice_curve_result1
        End If

        Return Nothing
    End Function


    Public Function check_if_dist_over_then1(new_cords_arr1 As ArrayList, max_dist1 As Double)
        Dim i1 As Integer

        For i1 = 0 To new_cords_arr1.Count - 2
            Dim cord_xya1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_cords_arr1, i1)
            Dim cord_xya2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_cords_arr1, i1 + 1)

            If CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy1(cord_xya1, cord_xya2) > max_dist1 Then
                Dim err1 As Integer = 1

                Return -1
            End If
        Next

        Return 1
    End Function
    Public Function check_if_overlap_pixel1(cords_dict1 As Dictionary(Of String, Integer), cords_dict2 As Dictionary(Of String, Integer), pad1 As Integer)

        Dim to_stop3 As Integer = 0
        Dim exist_overlap_slice_curve1 As String = ""
        Dim cord_ind1 As Integer = 0
        Dim min_cord_ind1 As Integer = 0
        Dim min_dist_cord1 As Double = 99

        Dim cord_con_dict1_xy1(2) As Integer
        Dim cord_con_dict2_xy1(2) As Integer

        While to_stop3 = 0



            Dim x1 As Integer
            Dim y1 As Integer

            Dim cord_xy_str1 As String() = cords_dict1.Keys(cord_ind1).Split(",")
            Dim cord_xy1(2) As Integer
            cord_xy1(0) = Integer.Parse(cord_xy_str1(0))
            cord_xy1(1) = Integer.Parse(cord_xy_str1(1))

            Dim cord_xy2(2) As Integer

            For x1 = -pad1 To pad1
                For y1 = -pad1 To pad1
                    cord_xy2(0) = cord_xy1(0) + x1
                    cord_xy2(1) = cord_xy1(1) + y1
                    If cords_dict2.ContainsKey(cord_xy2(0).ToString() + "," + cord_xy2(1).ToString()) = True Then

                        If min_dist_cord1 > (Math.Abs(x1) + Math.Abs(y1)) Or min_dist_cord1 = 99 Then
                            min_dist_cord1 = (Math.Abs(x1) + Math.Abs(y1))

                            min_cord_ind1 = cord_ind1

                            cord_con_dict1_xy1(0) = cord_xy1(0)
                            cord_con_dict1_xy1(1) = cord_xy1(1)

                            cord_con_dict2_xy1(0) = cord_xy2(0)
                            cord_con_dict2_xy1(1) = cord_xy2(1)

                        End If
                        'to_stop3 = 1
                        exist_overlap_slice_curve1 = "yes"

                    End If
                Next

            Next
            cord_ind1 += 1
            If cord_ind1 > cords_dict1.Count - 1 Then
                to_stop3 = 1
            End If
        End While

        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        If exist_overlap_slice_curve1 = "yes" Then
            dict_ret_res1("min_cord_ind1") = min_cord_ind1
            dict_ret_res1("cord_con_dict1_xy1") = cord_con_dict1_xy1
            dict_ret_res1("cord_con_dict2_xy1") = cord_con_dict2_xy1
        Else
            dict_ret_res1("min_cord_ind1") = -1
        End If

        Return dict_ret_res1

    End Function


    Public Function find_next_cur_overlap_slice_curve1(cur_silces_curves1 As ArrayList, add_slices_curves1 As ArrayList, connect_type1 As String, cur_overlap_slice_ind1 As Integer, add_overlap_slice_ind1 As Integer)

        Dim last_cur_overlap_slice_ind2 As Integer = -1
        Dim cur_overlap_slice_ind2 As Integer = cur_overlap_slice_ind1
        If connect_type1 = "start" Then
            'cur_overlap_slice_ind2 += 1
        Else
            'cur_overlap_slice_ind2 -= 1
        End If

        If cur_overlap_slice_ind2 < 0 Then
            cur_overlap_slice_ind2 = cur_silces_curves1.Count - 1

        End If

        If cur_overlap_slice_ind2 > cur_silces_curves1.Count - 1 Then
            cur_overlap_slice_ind2 = 0

        End If

        Dim to_stop1 As Integer = 0
        While to_stop1 = 0

            Dim cords_dict1 As Dictionary(Of String, Integer) = cur_silces_curves1(cur_overlap_slice_ind2)("cords_dict1")
            Dim cords_dict2 As Dictionary(Of String, Integer) = add_slices_curves1(add_overlap_slice_ind1)("cords_dict1")


            'find_next_cur_overlap_slice_curve1(cur_silces_curves1, add_slices_curves1, connect_type1, cur_overlap_slice_ind1, add_overlap_slice_ind1)
            Dim cord_ind2 As Integer





            Dim dict_ret_res1 As Dictionary(Of String, Object) = check_if_overlap_pixel1(cords_dict1, cords_dict2, 1)



            If dict_ret_res1("min_cord_ind1") <> -1 Then
                last_cur_overlap_slice_ind2 = cur_overlap_slice_ind2

            End If
            If dict_ret_res1("min_cord_ind1") = -1 And last_cur_overlap_slice_ind2 <> -1 Then
                to_stop1 = 1
            End If

            If to_stop1 = 0 Then
                If connect_type1 = "start" Then
                    cur_overlap_slice_ind2 += 1
                Else
                    cur_overlap_slice_ind2 -= 1
                End If

                If cur_overlap_slice_ind2 < 0 Then
                    cur_overlap_slice_ind2 = cur_silces_curves1.Count - 1

                End If

                If cur_overlap_slice_ind2 > cur_silces_curves1.Count - 1 Then
                    cur_overlap_slice_ind2 = 0

                End If

            End If



            If cur_overlap_slice_ind1 = cur_overlap_slice_ind2 Then
                to_stop1 = 1
            End If

        End While

        If last_cur_overlap_slice_ind2 = cur_overlap_slice_ind1 Then
            Return -1
        End If

        Return last_cur_overlap_slice_ind2
    End Function
    Public Function add_slices_curves_where_overlaps_slices_curves1(cur_silces_curves1 As ArrayList, add_slices_curves1 As ArrayList, connect_type1 As String)
        Dim i1 As Integer
        Dim i2 As Integer

        i1 = 0
        i2 = 0

        Dim to_stop1 As Integer = 0
        Dim first_cur_overlap_slice_ind1 As Integer = -1
        Dim last_cur_overlap_slice_ind1 As Integer = -1
        Dim add_overlap_slice_ind1 As Integer = -1
        While to_stop1 = 0

            If CType(cur_silces_curves1(i1)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey("295,80") Then
                Dim d3 As Integer = 1
            End If
            Dim cords_arr1 As ArrayList = cur_silces_curves1(i1)("cords_arr1")

                Dim cords_arr2 As ArrayList = cur_silces_curves1(i1 + 1)("cords_arr1")

            'הקורדינטה האחרונה של החתיכה הראשונה של הרצץ הקיים
            Dim last_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, cords_arr1.Count - 1)
            'הקורדינטה הראשונה של החתיכה השניה של הרצץ הקיים
            Dim first_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr2, 0)

            Dim dist1 As Double = CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy1(last_cord_xy1, first_cord_xy1)

            'Dim connect_type1 As String = "end"
            'connect_type1 = "start"
            Dim round2 As String = ""
            'אם המרחק בים החתיכה הראשונה להבאה גדול מ 5
            If dist1 > 5 Then
                Dim exist_overlap_slice_curve1 As String = ""
                Dim last_ind_overlap_slice_curve1 As Integer = -1
                Dim to_stop2 As Integer = 0
                i2 = 0

                While to_stop2 = 0


                    Dim to_compare1 As Integer = compare_sqrs_of_cords1(cur_silces_curves1(i1)("dict_sqrs_of_cords1"), add_slices_curves1(i2)("dict_sqrs_of_cords1"))

                    If to_compare1 = 1 Then
                        Dim cords_dict1 As Dictionary(Of String, Integer) = cur_silces_curves1(i1)("cords_dict1")
                        Dim cords_dict2 As Dictionary(Of String, Integer) = add_slices_curves1(i2)("cords_dict1")




                        Dim cord_ind1 As Integer = 0

                        Dim to_stop3 As Integer = 0
                        If cords_dict2.Count < 20 Then
                            to_stop3 = 1
                        End If

                        Dim dict_res1 As Dictionary(Of String, Object) = check_if_overlap_pixel1(cords_dict1, cords_dict2, 1)


                        If dict_res1("min_cord_ind1") <> -1 Then
                            If connect_type1 = "start" Then
                                last_ind_overlap_slice_curve1 = i2
                                first_cur_overlap_slice_ind1 = i1
                                add_overlap_slice_ind1 = i2
                                exist_overlap_slice_curve1 = "yes"
                            End If

                            If connect_type1 = "end" Then
                                If round2 = "yes" And last_ind_overlap_slice_curve1 = -1 Then
                                    last_ind_overlap_slice_curve1 = i2


                                    last_cur_overlap_slice_ind1 = i1
                                    add_overlap_slice_ind1 = i2

                                    exist_overlap_slice_curve1 = "yes"

                                End If
                            End If
                        End If
                    End If
                    i2 += 1
                    If i2 >= add_slices_curves1.Count - 2 Then

                        If connect_type1 = "end" And round2 = "" Then
                            round2 = "yes"
                            i2 = 0
                        Else
                            If connect_type1 = "end" Then
                                Dim d4 As Integer = 5
                            End If
                            to_stop2 = 1
                        End If

                    End If

                End While

                If exist_overlap_slice_curve1 = "yes" Then
                    Dim d1 As Integer = 1
                    If connect_type1 = "end" Then
                        Dim d4 As Integer = 5
                    End If
                    Dim last_overlap_cur_slice_curve1 As Integer = -1
                    Dim ind_overlap_cur_slice_curve1 As Integer = i1 + 1

                    If connect_type1 = "end" Then
                        ind_overlap_cur_slice_curve1 = i1 - 1
                        If ind_overlap_cur_slice_curve1 < 0 Then
                            ind_overlap_cur_slice_curve1 = cur_silces_curves1.Count - 1
                        End If
                    End If

                    Dim to_stop4 As Integer = 0
                    Dim cur_overlap_slice_ind1 As Integer = first_cur_overlap_slice_ind1

                    If connect_type1 = "end" Then
                        cur_overlap_slice_ind1 = last_cur_overlap_slice_ind1
                    End If

                    If connect_type1 = "start" Then
                        If cur_overlap_slice_ind1 = 1 Then
                            Dim d4 As Integer = 1
                        End If
                    End If



                    Dim next_overlap_slice_curve1 As Integer = find_next_cur_overlap_slice_curve1(cur_silces_curves1, add_slices_curves1, connect_type1, cur_overlap_slice_ind1, add_overlap_slice_ind1)






                    If next_overlap_slice_curve1 = -1 Then

                        Dim dict_res1 As Dictionary(Of String, Object) = Nothing
                        If connect_type1 = "start" Then
                            dict_res1 = merge_2_slice_curve1(cur_silces_curves1(i1), add_slices_curves1(add_overlap_slice_ind1), New Integer() {1, 1}, cur_silces_curves1(i1)("cords_dict1").count)

                        End If
                        'first_cur_overlap_slice_ind1
                        If connect_type1 = "end" Then
                            dict_res1 = merge_2_slice_curve1(add_slices_curves1(add_overlap_slice_ind1), cur_silces_curves1(i1), New Integer() {1, 1}, cur_silces_curves1(i1)("cords_dict1").count)

                        End If

                        If dict_res1 IsNot Nothing Then
                            cur_silces_curves1(i1) = dict_res1
                        Else
                            'Dim dict_res1b As Dictionary(Of String, Object) = merge_2_slice_curve1(cur_silces_curves1(i1), add_slices_curves1(last_ind_overlap_slice_curve1), New Integer() {1, 1}, cur_silces_curves1(i1)("cords_dict1").count)
                        End If


                    Else


                        Dim delete_slices_curves1 As String = ""
                        Dim start_ind_to_del1 As Integer = -1
                        Dim end_ind_to_del1 As Integer = -1
                        Dim dict_res2 As Dictionary(Of String, Object) = Nothing
                        If connect_type1 = "start" Then

                            dict_res2 = merge_2_slice_curve1(cur_silces_curves1(i1), add_slices_curves1(add_overlap_slice_ind1), New Integer() {1, 1}, cur_silces_curves1(i1)("cords_dict1").count)

                            If dict_res2 IsNot Nothing Then


                                Dim was_error1 As String = ""
                                Try
                                    dict_res2 = merge_2_slice_curve1(dict_res2, cur_silces_curves1(next_overlap_slice_curve1), New Integer() {1, 1}, cur_silces_curves1(i1)("cords_dict1").count)

                                Catch ex As Exception
                                    was_error1 = "yes"
                                End Try
                                If dict_res2 IsNot Nothing And was_error1 = "" Then
                                    delete_slices_curves1 = "yes"
                                    start_ind_to_del1 = i1
                                    end_ind_to_del1 = next_overlap_slice_curve1
                                End If
                            Else
                                Dim d17 As Integer = 4
                                dict_res2 = merge_2_slice_curve1(add_slices_curves1(add_overlap_slice_ind1), cur_silces_curves1(next_overlap_slice_curve1), New Integer() {1, 1}, cur_silces_curves1(i1)("cords_dict1").count)
                            End If


                            If dict_res2 IsNot Nothing Then
                                cur_silces_curves1(i1) = dict_res2
                            End If
                        End If

                        If connect_type1 = "end" Then

                            dict_res2 = merge_2_slice_curve1(add_slices_curves1(add_overlap_slice_ind1), cur_silces_curves1(i1), New Integer() {1, 1}, cur_silces_curves1(i1)("cords_dict1").count)

                            If dict_res2 IsNot Nothing Then

                                Dim was_error1 As String = ""
                                Try
                                    dict_res2 = merge_2_slice_curve1(dict_res2, add_slices_curves1(last_cur_overlap_slice_ind1), New Integer() {1, 1}, cur_silces_curves1(i1)("cords_dict1").count)

                                Catch ex As Exception
                                    was_error1 = "yes"

                                End Try
                                If dict_res2 IsNot Nothing And was_error1 = "" Then
                                    delete_slices_curves1 = "yes"
                                    start_ind_to_del1 = next_overlap_slice_curve1
                                    end_ind_to_del1 = i1
                                End If
                            Else
                                Dim d17 As Integer = 4
                                dict_res2 = merge_2_slice_curve1(cur_silces_curves1(next_overlap_slice_curve1), add_slices_curves1(add_overlap_slice_ind1), New Integer() {1, 1}, cur_silces_curves1(i1)("cords_dict1").count)

                            End If


                            If dict_res2 IsNot Nothing Then
                                cur_silces_curves1(i1) = dict_res2
                            End If
                        End If

                        If delete_slices_curves1 = "yes" Then
                            i1 = -1
                            If connect_type1 = "start" Or connect_type1 = "end" Then
                                Dim ind_del1 As Integer

                                If start_ind_to_del1 < end_ind_to_del1 Then
                                    For ind_del1 = start_ind_to_del1 + 1 To end_ind_to_del1
                                        cur_silces_curves1.RemoveAt(start_ind_to_del1 + 1)
                                    Next
                                Else
                                    For ind_del1 = start_ind_to_del1 + 1 To cur_silces_curves1.Count - 1
                                        cur_silces_curves1.RemoveAt(start_ind_to_del1 + 1)
                                    Next

                                    For ind_del1 = 0 To end_ind_to_del1
                                        cur_silces_curves1.RemoveAt(0)
                                    Next

                                End If


                            End If
                        End If
                    End If



                End If


            End If


            i1 += 1
            If i1 >= cur_silces_curves1.Count - 2 Then
                to_stop1 = 1

            End If


        End While
        For i1 = 0 To cur_silces_curves1.Count - 1

        Next


        Return cur_silces_curves1
    End Function
    Public Function get_ref_index_of_slice_curve(cur_silces_curves1 As ArrayList, add_slices_curves1 As ArrayList, cur_index1 As Integer)
        Dim i1 As Integer

        i1 = cur_index1 - 1
        Dim i2 As Integer = 0
        Dim to_stop1 As Integer = 0
        Dim found_start_index1 As Integer = -1
        While to_stop1 = 0

            For i2 = 0 To cur_silces_curves1.Count - 1


                Dim to_compare1 As Integer = 0

                Try
                    to_compare1 = compare_sqrs_of_cords1(add_slices_curves1(i1)("dict_sqrs_of_cords1"), cur_silces_curves1(i2)("dict_sqrs_of_cords1"))
                Catch ex As Exception
                    Dim err1 As String = "2"
                End Try

                If to_compare1 = 1 Then

                    Dim dict_res1 As Dictionary(Of String, Object) = check_if_overlap_pixel1(add_slices_curves1(i1)("cords_dict1"), cur_silces_curves1(i2)("cords_dict1"), 3)

                    If dict_res1("min_cord_ind1") <> -1 And found_start_index1 = -1 Then
                        to_stop1 = 1
                        found_start_index1 = i2
                    End If

                End If

            Next

            i1 -= 1
            If i1 < 0 Then
                to_stop1 = 1
            End If

        End While

        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_ret_res1("found_start_index1") = found_start_index1

        Return dict_ret_res1
    End Function
    Public Function add_slices_curves_where_no_slices_curves1(cur_silces_curves1 As ArrayList, add_slices_curves1 As ArrayList)
        Dim i1 As Integer
        Dim i2 As Integer


        Dim new_slices_curves_arr1 As ArrayList = New ArrayList()
        new_slices_curves_arr1 = CGlobals1.add_arraylist_to_arraylist1(new_slices_curves_arr1, cur_silces_curves1)
        For i1 = 0 To add_slices_curves1.Count - 1

            If add_slices_curves1(i1)("cords_arr1").count > 20 Then


                Dim contained_in_cur_slices_curves1 As String = ""
                Dim cords_arr1 As ArrayList = add_slices_curves1(i1)("cords_arr1")
                Dim to_stop1 As Integer = 0
                i2 = 0
                While to_stop1 = 0


                    Dim dict_ret_res1 As Dictionary(Of String, Object) = check_if_overlap_pixel1(add_slices_curves1(i1)("cords_dict1"), new_slices_curves_arr1(i2)("cords_dict1"), 3)

                    If dict_ret_res1("min_cord_ind1") <> -1 Then
                        contained_in_cur_slices_curves1 = "yes"
                        to_stop1 = 1
                    Else
                        i2 += 1

                    End If


                    If i2 >= new_slices_curves_arr1.Count - 1 Then
                        to_stop1 = 1
                    End If
                End While

                If contained_in_cur_slices_curves1 = "" Then
                    Dim dict_ret_res1 As Dictionary(Of String, Object) = get_ref_index_of_slice_curve(new_slices_curves_arr1, add_slices_curves1, i1)
                    If dict_ret_res1("found_start_index1") <> -1 Then
                        Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_slices_curves_arr1(dict_ret_res1("found_start_index1"))("cords_arr1"), new_slices_curves_arr1(dict_ret_res1("found_start_index1"))("cords_arr1").count - 1)
                        Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(add_slices_curves1(i1)("cords_arr1"), 0)
                        'If CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy1(cord_xy1, cord_xy2) < 10 Then
                        new_slices_curves_arr1.Insert(dict_ret_res1("found_start_index1") + 1, add_slices_curves1(i1))

                        'End If
                    End If

                End If
            End If
        Next

        Return new_slices_curves_arr1
    End Function

    Public Function replace_slices_curves_with_bigger_and_conatain_slices_curves1(cur_silces_curves1 As ArrayList, add_slices_curves1 As ArrayList, sobel_ind1 As Integer)
        Dim i1 As Integer
        Dim i2 As Integer
        Dim pad_contain_dist1 As Integer = 5
        Dim dict_inds1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim dict_inds2 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)


        For i1 = cur_silces_curves1.Count - 1 To 0 Step -1

            If sobel_ind1 = 17 Then
                If CType(cur_silces_curves1(i1)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey("85,46") = True Then
                    Dim המחשd1 As Integer = 1
                End If

            End If
            Dim is_contained1 As String = ""
            For i2 = add_slices_curves1.Count - 1 To 0 Step -1

                If add_slices_curves1(i2)("cords_arr1").count > cur_silces_curves1(i1)("cords_arr1").count + pad_contain_dist1 * 2 Then


                    Dim to_compare1 As Integer = compare_sqrs_of_cords1(cur_silces_curves1(i1)("dict_sqrs_of_cords1"), add_slices_curves1(i2)("dict_sqrs_of_cords1"))
                    If to_compare1 = 1 Then
                        Dim dict_res1 As Dictionary(Of String, Object) = get_count_pixels_slice_of_curve_contain_in_slice_of_curve1(cur_silces_curves1(i1), add_slices_curves1(i2), pad_contain_dist1)

                        Dim dict_contained_cords1 As Dictionary(Of String, Integer) = dict_res1("dict_contained_cords1")
                        Dim count_cords_seq_exist1 As Integer = dict_res1("count_cords_seq_exist1")

                        Dim i3 As Integer



                        'If dict_contained_cords1.Count > min_slice_len2 Then
                        If count_cords_seq_exist1 >= cur_silces_curves1(i1)("cords_arr1").count Then
                            dict_inds2(i2) = 1
                            If i1 = 53 And sobel_ind1 = 17 Then
                                Dim d1 As Integer = 5
                            End If
                            is_contained1 = "yes"
                        End If
                    End If



                End If
            Next
            If is_contained1 = "" Then
                dict_inds1(i1) = 1

            End If

        Next

        Dim new_slice_curve_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To dict_inds1.Count - 1
            Try


                If cur_silces_curves1(dict_inds1.Keys(i1))("cords_arr1").count > 20 Then
                    new_slice_curve_arr1.Add(cur_silces_curves1(dict_inds1.Keys(i1)))
                End If




            Catch ex As Exception
                Dim d1 As Integer = 1
            End Try

        Next

        If False Then
            For i1 = 0 To dict_inds2.Count - 1
                Try
                    If add_slices_curves1(dict_inds1.Keys(i1))("cords_arr1").count > 10 Then
                        new_slice_curve_arr1.Add(add_slices_curves1(dict_inds2.Keys(i2)))
                    End If

                Catch ex As Exception
                    Dim d1 As Integer = 1
                End Try

            Next

        End If

        For i1 = 0 To dict_inds2.Count - 1
            Try
                If add_slices_curves1(dict_inds2.Keys(i1))("cords_arr1").count > 20 Then
                    new_slice_curve_arr1.Add(add_slices_curves1(dict_inds2.Keys(i1)))
                End If

            Catch ex As Exception
                Dim d1 As Integer = 1
            End Try

        Next


        Return new_slice_curve_arr1
    End Function



    Public Function save_slices_curves_in_bmps2(slices_curves_arr1 As ArrayList, path_of_bmp1 As String)
        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(2700, 1800, Color.FromArgb(255, 255, 255))
        Dim r1 As Integer = 0
        Dim g1 As Integer = 0
        Dim b1 As Integer = 0
        CGlobals1.min_slice_len_added1 = 99999




        For i1 = 0 To slices_curves_arr1.Count - 1

            bmp5 = CGlobals1.create_fill_bitmap(2700, 1800, Color.FromArgb(255, 255, 255))

            Dim curve_pixels_arr1 As ArrayList = slices_curves_arr1(i1)("cords_arr1")
            r1 += 50
            g1 -= 70
            b1 += 20

            If r1 > 255 Then
                r1 = 0
            End If

            If g1 > 255 Then
                g1 = 0
            End If

            If b1 > 255 Then
                b1 = 0
            End If


            If r1 < 0 Then
                r1 = 255
            End If

            If g1 < 0 Then
                g1 = 255
            End If

            If b1 < 0 Then
                b1 = 255
            End If


            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp5, Color.FromArgb(r1, g1, b1))

            bmp5.Save(path_of_bmp1 + "slice_" + i1.ToString() + ".bmp")

        Next




    End Function


    Public Function save_slices_curves_in_bmp1(slices_curves_arr1 As ArrayList, path_of_bmp1 As String)
        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(2700, 1800, Color.FromArgb(255, 255, 255))
        Dim r1 As Integer = 0
        Dim g1 As Integer = 0
        Dim b1 As Integer = 0
        CGlobals1.min_slice_len_added1 = 99999




        For i1 = 0 To slices_curves_arr1.Count - 1
            Dim curve_pixels_arr1 As ArrayList = slices_curves_arr1(i1)("cords_arr1")
            r1 += 50
            g1 -= 70
            b1 += 20

            If r1 > 255 Then
                r1 = 0
            End If

            If g1 > 255 Then
                g1 = 0
            End If

            If b1 > 255 Then
                b1 = 0
            End If


            If r1 < 0 Then
                r1 = 255
            End If

            If g1 < 0 Then
                g1 = 255
            End If

            If b1 < 0 Then
                b1 = 255
            End If


            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp5, Color.FromArgb(r1, g1, b1))

        Next
        bmp5.Save(path_of_bmp1)



    End Function

    Public Function compare_slice_curves_arr4(slice_curve_arr1 As ArrayList, slice_curve_arr2 As ArrayList, sobel_ind1 As Integer)

        Dim order_slice_curve_arr1 As ArrayList = order_slices_curves_arr(slice_curve_arr1)
        Dim order_slice_curve_arr2 As ArrayList = order_slices_curves_arr(slice_curve_arr2)
        Dim new_order_slice_curve_arr1 As ArrayList = New ArrayList()

        Dim dict_inds1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim dict_inds2 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim dict_inds2_contatined_partially As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim i1 As Integer
        Dim i2 As Integer
        Dim min_slice_len1 As Integer = 10
        Dim min_slice_len2 As Integer = CGlobals1.min_slice_len_added1
        Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(2000, 1500, Color.FromArgb(255, 255, 255))


        Dim bmp_before1 As Bitmap = create_bmp_from_slices_curves_arr1(slice_curve_arr1, 0, 0, bmp5)
        Dim bmp_before2 As Bitmap = create_bmp_from_slices_curves_arr1(slice_curve_arr1, 15, 15, bmp5)
        'Dim min_slice_len3 As Integer = 20
        For i1 = order_slice_curve_arr1.Count - 1 To 0 Step -1
            Dim is_contained1 As String = ""
            If CType(order_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey(CGlobals1.debug_str1) = True Then
                If sobel_ind1 = CGlobals1.debug_int1 Then
                    Dim d2 As Integer = 1
                End If

            End If

            Dim cords_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

            For i2 = 0 To CType(order_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer)).Count - 1
                cords_dict1(CType(order_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer)).Keys(i2)) = 1
            Next

            Dim count_slices_contain1 As Integer = 0
            Dim sum_len_slice_contain1 As Integer = 0
            'Dim cords_dict1 As Dictionary(Of String, Integer) = CType(order_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer))
            For i2 = order_slice_curve_arr2.Count - 1 To 0 Step -1

                Dim to_compare1 As Integer = compare_sqrs_of_cords1(order_slice_curve_arr1(i1)("dict_sqrs_of_cords1"), order_slice_curve_arr2(i2)("dict_sqrs_of_cords1"))
                If to_compare1 = 1 Then

                    If CType(order_slice_curve_arr2(i2)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey(CGlobals1.debug_str1) = True And sobel_ind1 = 33 Then
                        Dim d3 As Integer = 1
                    End If

                    Dim dict_res1 As Dictionary(Of String, Object) = Nothing

                    If order_slice_curve_arr2(i2)("cords_arr1").count > min_slice_len1 And False Then


                        dict_res1 = get_count_pixels_slice_of_curve_contain_in_slice_of_curve1(order_slice_curve_arr2(i2), order_slice_curve_arr1(i1), 15)

                        Dim dict_contained_cords1 As Dictionary(Of String, Integer) = dict_res1("dict_contained_cords1")

                        Dim i3 As Integer



                        'If dict_contained_cords1.Count > min_slice_len2 Then
                        If dict_contained_cords1.Count > min_slice_len1 Then
                            sum_len_slice_contain1 += order_slice_curve_arr2(i2)("cords_dict1").count
                            count_slices_contain1 += 1
                            dict_inds2_contatined_partially(i2) = 1
                            For i3 = 0 To dict_contained_cords1.Count - 1
                                cords_dict1(dict_contained_cords1.Keys(i3)) = 2
                            Next
                        End If
                    End If
                    'order_slice_curve_arr1(i1)("cords_arr1").count > min_slice_len1 And
                    If order_slice_curve_arr2(i2)("cords_arr1").count > min_slice_len2 Then
                        If dict_res1 Is Nothing Then
                            dict_res1 = get_count_pixels_slice_of_curve_contain_in_slice_of_curve1(order_slice_curve_arr2(i2), order_slice_curve_arr1(i1), 2)
                        End If
                        'dict_res1("count_cords_exist1") = count_cords_exist1
                        Dim count_contained1 As Integer = dict_res1("count_cords_seq_exist1")


                        'Dim count_contained1 As Integer = get_count_pixels_slice_of_curve_contain_in_slice_of_curve1(order_slice_curve_arr2(i2), order_slice_curve_arr1(i1), 4)
                        Dim cords_arr1 As ArrayList = order_slice_curve_arr1(i1)("cords_arr1")
                        If count_contained1 > cords_arr1.Count * 1 Then
                            Dim d2 As Integer = 1
                            is_contained1 = "yes"
                            dict_inds2(i2) = 1
                            'new_order_slice_curve_arr1.Add(order_slice_curve_arr2(i2))
                        End If
                    End If
                    Dim d1 As Integer = 1
                End If

            Next


            If cords_dict1.ContainsValue(1) = False Then 'And count_slices_contain1 < 4 And sum_len_slice_contain1 > min_slice_len2 Then
                is_contained1 = "yes"

                For i2 = 0 To dict_inds2_contatined_partially.Count - 1
                    dict_inds2(dict_inds2_contatined_partially.Keys(i2)) = 1
                Next
            End If

            'dict_inds1.ContainsKey(i1) = False And
            If CType(order_slice_curve_arr1(i1)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey("150,30") = True And sobel_ind1 = 21 Then
                Dim d1 As Integer = 3
            End If


            If is_contained1 = "" And order_slice_curve_arr1(i1)("cords_arr1").count > min_slice_len2 Then
                dict_inds1(i1) = 1

            End If

        Next
        'Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        Dim bmp6 As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        Dim r1 As Integer = 0
        Dim g1 As Integer = 0
        Dim b1 As Integer = 0
        CGlobals1.min_slice_len_added1 = 99999




        For i1 = 0 To dict_inds1.Count - 1
            new_order_slice_curve_arr1.Add(order_slice_curve_arr1(dict_inds1.Keys(i1)))


            Dim curve_pixels_arr1 As ArrayList = new_order_slice_curve_arr1(new_order_slice_curve_arr1.Count - 1)("cords_arr1")
            If CGlobals1.min_slice_len_added1 > curve_pixels_arr1.Count Then
                CGlobals1.min_slice_len_added1 = curve_pixels_arr1.Count
            End If

            r1 += 50
            g1 -= 70
            b1 += 20

            If r1 > 255 Then
                r1 = 0
            End If

            If g1 > 255 Then
                g1 = 0
            End If

            If b1 > 255 Then
                b1 = 0
            End If


            If r1 < 0 Then
                r1 = 255
            End If

            If g1 < 0 Then
                g1 = 255
            End If

            If b1 < 0 Then
                b1 = 255
            End If


            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp5, Color.FromArgb(r1, g1, b1))

            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp6, Color.FromArgb(124, 20, 50))
        Next

        For i2 = 0 To dict_inds2.Count - 1
            new_order_slice_curve_arr1.Add(order_slice_curve_arr2(dict_inds2.Keys(i2)))

            Dim curve_pixels_arr1 As ArrayList = new_order_slice_curve_arr1(new_order_slice_curve_arr1.Count - 1)("cords_arr1")


            If CGlobals1.min_slice_len_added1 > curve_pixels_arr1.Count Then
                CGlobals1.min_slice_len_added1 = curve_pixels_arr1.Count
            End If


            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp5, Color.FromArgb(124, 20, 50))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp6, Color.FromArgb(124, 20, 50))

        Next

        bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\curve_no_noise4_" + sobel_ind1.ToString() + ".bmp")
        bmp6.Save(CGlobals1.global_path1 + "sobel_pics1\curve_no_noise5_" + sobel_ind1.ToString() + ".bmp")


        Dim bmp_after1 As Bitmap = create_bmp_from_slices_curves_arr1(new_order_slice_curve_arr1, 30, 30, bmp5)
        bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\bmp_after1_" + sobel_ind1.ToString() + ".bmp")
        'bmp_before1.Save(CGlobals1.global_path1 + "sobel_pics1\bmp_before1_" + sobel_ind1.ToString() + ".bmp")
        'bmp_before2.Save(CGlobals1.global_path1 + "sobel_pics1\bmp_before2_" + sobel_ind1.ToString() + ".bmp")
        'bmp_after1.Save(CGlobals1.global_path1 + "sobel_pics1\bmp_after1_" + sobel_ind1.ToString() + ".bmp")
        new_order_slice_curve_arr1 = order_slices_curves_arr(new_order_slice_curve_arr1)
        Return new_order_slice_curve_arr1
    End Function
    Public Function compare_slice_curves_arr3(slice_curve_arr2 As ArrayList, slice_curve_arr1 As ArrayList)

        Dim i1 As Integer
        Dim i3 As Integer
        Dim max_cords_len_val1 As Integer = -1
        Dim max_cords_len_ind1 As Integer = -1
        Dim not_contained_curves1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)

        'slice_curve_arr1 = order_slices_curves_arr(slice_curve_arr1)
        For i3 = 0 To slice_curve_arr1.Count - 1
            Dim dict_slice_curve3 As Dictionary(Of String, Object) = slice_curve_arr1(i3)
            Dim cords_arr2 As ArrayList = dict_slice_curve3("cords_arr1")



            'Dim cords_arr2 As ArrayList = slice_curve_arr1(max_cords_len_ind1)("cords_arr1")
            'Dim cords_arr1 As ArrayList = dict_slice_curve1("cords_arr1")

            Dim max_overlap_slice2_val1 As Integer = -1
            Dim max_overlap_slice2_ind1 As Integer = -1

            For i1 = 0 To slice_curve_arr2.Count - 1
                Dim dict_slice_curve1 As Dictionary(Of String, Object) = slice_curve_arr2(i1)
                Dim cords_arr1 As ArrayList = dict_slice_curve1("cords_arr1")
                Dim dict_cords1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(cords_arr1)

                Dim i2 As Integer
                Dim all_cords_exist_in_current_slice2 As String = "yes"
                Dim count_cords_exist1 As Integer = 0
                For i2 = 0 To cords_arr2.Count - 1
                    Dim x1 As Integer
                    Dim y1 As Integer
                    Dim exist_in_current_slice2 As String = "no"
                    Dim pad1 As Integer = 4
                    For x1 = -pad1 To pad1
                        For y1 = -pad1 To pad1
                            Dim key1 As String = (CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr2, i2)(0) + x1).ToString() + "," + (CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr2, i2)(1) + y1).ToString()

                            If dict_cords1.ContainsKey(key1) = True Then
                                exist_in_current_slice2 = "yes"
                                count_cords_exist1 += 1
                            End If
                        Next
                    Next

                    If count_cords_exist1 > max_overlap_slice2_val1 Then
                        max_overlap_slice2_val1 = count_cords_exist1
                        max_overlap_slice2_ind1 = i1
                    End If
                    If exist_in_current_slice2 = "no" Then
                        all_cords_exist_in_current_slice2 = "no"
                        not_contained_curves1(i3) = 1
                    Else
                        Dim d1 As Integer = 1
                    End If
                Next


            Next


        Next
    End Function
    Public Function compare_slice_curves_arr1(slice_curve_arr2 As ArrayList, slice_curve_arr1 As ArrayList)

        Dim i1 As Integer
        Dim i2 As Integer

        Dim dict_contains_slices1 As Dictionary(Of Integer, Object) = New Dictionary(Of Integer, Object)


        Dim dict_min_contains_slices1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim dict_max_contains_slices1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        Dim dict_min_max_contains_slices1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)

        For i1 = 0 To slice_curve_arr1.Count - 1
            Dim dict_slice_curve1 As Dictionary(Of String, Object) = slice_curve_arr1(i1)
            Dim cords_arr1 As ArrayList = dict_slice_curve1("cords_arr1")

            If cords_arr1.Count > 0 Then
                Dim found1 As Integer = 0
                Dim found2 As Integer = 0

                Dim start_cord1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, 0)
                Dim end_cord1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, cords_arr1.Count - 1)

                Dim x1 As Integer
                Dim y1 As Integer
                Dim contain_slice_curves1 As ArrayList = New ArrayList()

                For i2 = 0 To slice_curve_arr2.Count - 1
                    Dim cords_dict1 As Dictionary(Of String, Integer) = CType(slice_curve_arr2(i2), Dictionary(Of String, Object))("cords_dict1")
                    For x1 = -7 To 7
                        For y1 = -7 To 7
                            Dim cord_str1 As String = (start_cord1(0) + x1).ToString() + "," + (start_cord1(1) + y1).ToString()
                            Dim cord_str2 As String = (end_cord1(0) + x1).ToString() + "," + (end_cord1(1) + y1).ToString()


                            If cords_dict1.ContainsKey(cord_str1) Then
                                found1 = 1
                            End If
                            If cords_dict1.ContainsKey(cord_str2) Then
                                found2 = 1
                            End If



                        Next

                    Next
                    If cords_arr1.Count > cords_dict1.Count And cords_dict1.Count > 0 And (found1 = 1 Or found2 = 1) Then

                        If dict_contains_slices1.ContainsKey(i2) = False Then
                            dict_contains_slices1(i2) = New Dictionary(Of Integer, Integer)
                        End If
                        CType(dict_contains_slices1(i2), Dictionary(Of Integer, Integer))(i1) = 1


                        If dict_min_contains_slices1.ContainsKey(i2) = False Then
                            dict_min_contains_slices1(i2) = i1
                        Else
                            If dict_min_contains_slices1(i2) > i1 Then
                                dict_min_contains_slices1(i2) = i1

                            End If
                        End If


                        If dict_max_contains_slices1.ContainsKey(i2) = False Then
                            dict_max_contains_slices1(i2) = i1
                        Else
                            If dict_max_contains_slices1(i2) < i1 Then
                                dict_max_contains_slices1(i2) = i1

                            End If
                        End If


                        dict_min_max_contains_slices1(i2) = Math.Abs(dict_max_contains_slices1(i2) - dict_min_contains_slices1(i2))
                        'dict_contains_slices1(i2) = contain_slice_curves1
                        'contain_slice_curves1.Add(i2)
                        'Dim d2 As Integer = 1
                    End If

                    found1 = 0
                    found2 = 0
                Next
                'If cords_arr1.Count > cords_dict1.Count And cords_dict1.Count > 0 And (found1 = 1 And found2 = 1) Then
                If (found1 = 1 And found2 = 1) Then
                    'contain_slice_curves1.Add(i1)

                    Dim d2 As Integer = 1
                End If
                Dim d1 As Integer = 1
            End If
            'dict_contains_slices1(i2) = contain_slice_curves1
            'contain_slice_curves1 = New Dictionary(Of String, Object)
        Next

        Return dict_contains_slices1
        'dict_curve1("cords_arr1")
    End Function


    Public Function check_if_can_merge_slices_curves3(slices_curves_arr1 As ArrayList)

        Dim dict_slices_curves1 As Dictionary(Of Integer, Object) = New Dictionary(Of Integer, Object)

        Dim i1 As Integer

        For i1 = 0 To slices_curves_arr1.Count - 1
            dict_slices_curves1(i1) = slices_curves_arr1(i1)
        Next
        Dim res_slices_curves_arr1 As ArrayList = New ArrayList()

        Dim res_slices_curves_arr2 As ArrayList = New ArrayList()
        Dim res_slices_curves_arr3 As ArrayList = New ArrayList()

        Dim ind1 As Integer
        Dim ind2 As Integer

        Dim found_merge1 As Integer = 1
        Dim count_merged1 As Integer = 0
        While found_merge1 = 1
            found_merge1 = 0
            ind1 = 0
            Dim to_stop1 As Integer = 0
            While to_stop1 = 0



                Try

                    If CType(slices_curves_arr1(ind1)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey("620,27") = True Then
                        Dim d1 As Integer = 2
                    End If

                Catch ex As Exception

                End Try

                Dim to_stop2 As Integer = 0
                ind2 = 0
                While to_stop2 = 0

                    If ind1 <> ind2 Then
                        Dim to_compare1 As Integer = 0

                        Try
                            to_compare1 = compare_sqrs_of_cords1(dict_slices_curves1(ind1)("dict_sqrs_of_cords1"), dict_slices_curves1(ind2)("dict_sqrs_of_cords1"))
                        Catch ex As Exception

                        End Try


                        If to_compare1 = 1 Then
                            If CType(dict_slices_curves1(ind2)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey("290,80") = True Then
                                Dim d2 As Integer = 1
                            End If
                            'Dim min_len1 As Integer = Math.Max(dict_slices_curves1(ind1)("dict_sqrs_of_cords1").count, dict_slices_curves1(ind2)("dict_sqrs_of_cords1").count)
                            Dim min_len1 As Integer = Math.Max(dict_slices_curves1(ind1)("cords_dict1").count, dict_slices_curves1(ind2)("cords_dict1").count)
                            Dim res_slice1 As Dictionary(Of String, Object) = Nothing
                            If ind1 < ind2 Then
                                res_slice1 = merge_2_slice_curve1(dict_slices_curves1(ind1), dict_slices_curves1(ind2), New Integer() {0, 0}, min_len1)
                            Else
                                res_slice1 = merge_2_slice_curve1(dict_slices_curves1(ind2), dict_slices_curves1(ind1), New Integer() {0, 0}, min_len1)
                            End If

                            Dim do_debug1 As Integer = 0
                            If do_debug1 = 1 Then
                                If ind1 < ind2 Then
                                    res_slice1 = merge_2_slice_curve1(dict_slices_curves1(ind1), dict_slices_curves1(ind2), New Integer() {0, 0}, min_len1)
                                Else
                                    res_slice1 = merge_2_slice_curve1(dict_slices_curves1(ind2), dict_slices_curves1(ind1), New Integer() {0, 0}, min_len1)
                                End If
                            End If
                            If res_slice1 IsNot Nothing Then

                                res_slices_curves_arr1.Add(res_slice1)

                                res_slices_curves_arr2.Add(dict_slices_curves1(ind1))
                                res_slices_curves_arr3.Add(dict_slices_curves1(ind2))
                                count_merged1 += 1
                                If Math.Abs(ind1 - ind2) > 1 Then
                                    Dim d3 As Integer = 4
                                End If

                                dict_slices_curves1(ind1) = res_slice1
                                dict_slices_curves1.Remove(ind2)



                                to_stop1 = 1
                                to_stop2 = 1
                                found_merge1 = 1

                            End If
                        End If

                    End If
                    ind2 += 1

                    If ind2 >= dict_slices_curves1.Count - 1 Then
                        to_stop2 = 1
                    End If
                End While
                'For ind2 = 0 To slices_curves_arr1.Count - 1

                'Next
                ind1 += 1

                If ind1 >= dict_slices_curves1.Count - 1 Then
                    to_stop1 = 1
                End If
            End While
        End While

        save_slices_curves_in_bmp1(res_slices_curves_arr1, CGlobals1.global_path1 + "sobel_pics1\merged_res1_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
        save_slices_curves_in_bmp1(res_slices_curves_arr2, CGlobals1.global_path1 + "sobel_pics1\merged_res2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
        save_slices_curves_in_bmp1(res_slices_curves_arr3, CGlobals1.global_path1 + "sobel_pics1\merged_res3_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")


        Dim res_slices_curves_arr4 As ArrayList = New ArrayList()

        For i1 = 0 To dict_slices_curves1.Count - 1

            'dict_slices_curves1(i1) = slices_curves_arr1(i1)
            res_slices_curves_arr4.Add(dict_slices_curves1(dict_slices_curves1.Keys(i1)))
        Next


        Return res_slices_curves_arr4
    End Function




    Public Function check_if_can_merge_slices_curves2(slices_curves_arr1 As ArrayList)


        Dim res_slices_curves_arr1 As ArrayList = New ArrayList()

        Dim ind1 As Integer
        Dim ind2 As Integer

        Dim found_merge1 As Integer = 1
        Dim count_merged1 As Integer = 0
        While found_merge1 = 1
            found_merge1 = 0
            ind1 = 0
            Dim to_stop1 As Integer = 0
            While to_stop1 = 0



                Try

                    If CType(slices_curves_arr1(ind1)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey("620,27") = True Then
                        Dim d1 As Integer = 2
                    End If

                Catch ex As Exception

                End Try

                Dim to_stop2 As Integer = 0
                ind2 = 0
                While to_stop2 = 0

                    If ind1 <> ind2 Then
                        Dim to_compare1 As Integer = 0

                        Try
                            to_compare1 = compare_sqrs_of_cords1(slices_curves_arr1(ind1)("dict_sqrs_of_cords1"), slices_curves_arr1(ind2)("dict_sqrs_of_cords1"))
                        Catch ex As Exception

                        End Try


                        If to_compare1 = 1 Then

                            Dim min_len1 As Integer = Math.Max(slices_curves_arr1(ind1)("dict_sqrs_of_cords1").count, slices_curves_arr1(ind2)("dict_sqrs_of_cords1").count)
                            Dim res_slice1 As Dictionary(Of String, Object) = Nothing
                            If ind1 < ind2 Then
                                res_slice1 = merge_2_slice_curve1(slices_curves_arr1(ind1), slices_curves_arr1(ind2), New Integer() {0, 0}, min_len1)
                            Else
                                res_slice1 = merge_2_slice_curve1(slices_curves_arr1(ind2), slices_curves_arr1(ind1), New Integer() {0, 0}, min_len1)
                            End If

                            Dim do_debug1 As Integer = 0
                            If do_debug1 = 1 Then
                                If ind1 < ind2 Then
                                    res_slice1 = merge_2_slice_curve1(slices_curves_arr1(ind1), slices_curves_arr1(ind2), New Integer() {0, 0}, min_len1)
                                Else
                                    res_slice1 = merge_2_slice_curve1(slices_curves_arr1(ind2), slices_curves_arr1(ind1), New Integer() {0, 0}, min_len1)
                                End If
                            End If
                            If res_slice1 IsNot Nothing Then

                                res_slices_curves_arr1.Add(res_slice1)
                                count_merged1 += 1
                                If Math.Abs(ind1 - ind2) > 1 Then
                                    Dim d3 As Integer = 4
                                End If
                                If ind1 < ind2 Then

                                    If ind2 = slices_curves_arr1.Count - 1 And ind1 < ind2 Then
                                        slices_curves_arr1(ind1) = res_slice1
                                        slices_curves_arr1.RemoveAt(ind2)
                                    Else
                                        slices_curves_arr1(ind1) = res_slice1

                                        slices_curves_arr1.RemoveAt(ind2)

                                    End If






                                Else

                                    If ind1 = slices_curves_arr1.Count - 1 And ind2 < ind1 Then
                                        slices_curves_arr1(ind2) = res_slice1

                                        slices_curves_arr1.RemoveAt(ind1)
                                    Else
                                        slices_curves_arr1(ind2) = res_slice1

                                        slices_curves_arr1.RemoveAt(ind1)

                                    End If

                                End If
                                to_stop1 = 1
                                to_stop2 = 1
                                found_merge1 = 1

                            End If
                        End If

                    End If
                    ind2 += 1

                    If ind2 >= slices_curves_arr1.Count - 1 Then
                        to_stop2 = 1
                    End If
                End While
                'For ind2 = 0 To slices_curves_arr1.Count - 1

                'Next
                ind1 += 1

                If ind1 >= slices_curves_arr1.Count - 1 Then
                    to_stop1 = 1
                End If
            End While
        End While

        save_slices_curves_in_bmp1(res_slices_curves_arr1, CGlobals1.global_path1 + "sobel_pics1\merged_res2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")


        Return slices_curves_arr1
    End Function



    Public Function check_if_can_merge_slices_curves1(slices_curves_arr1 As ArrayList)

        Dim ind1 As Integer
        Dim ind2 As Integer

        Dim found_merge1 As Integer = 1

        While found_merge1 = 1
            found_merge1 = 0
            For ind1 = 0 To slices_curves_arr1.Count - 1

                Try

                    If CType(slices_curves_arr1(ind1)("cords_dict1"), Dictionary(Of String, Integer)).ContainsKey("620,27") = True Then
                        Dim d1 As Integer = 2
                    End If

                Catch ex As Exception

                End Try

                Dim to_stop1 As Integer = 0
                ind2 = 0
                While to_stop1 = 0

                    If ind1 <> ind2 Then
                        Dim to_compare1 As Integer = 0

                        Try
                            to_compare1 = compare_sqrs_of_cords1(slices_curves_arr1(ind1)("dict_sqrs_of_cords1"), slices_curves_arr1(ind2)("dict_sqrs_of_cords1"))
                        Catch ex As Exception

                        End Try


                        If to_compare1 = 1 Then

                            Dim min_len1 As Integer = Math.Max(slices_curves_arr1(ind1)("dict_sqrs_of_cords1").count, slices_curves_arr1(ind2)("dict_sqrs_of_cords1").count)
                            Dim res_slice1 As Dictionary(Of String, Object) = Nothing
                            If ind1 < ind2 Then
                                res_slice1 = merge_2_slice_curve1(slices_curves_arr1(ind1), slices_curves_arr1(ind2), New Integer() {0, 0}, min_len1)
                            Else
                                res_slice1 = merge_2_slice_curve1(slices_curves_arr1(ind2), slices_curves_arr1(ind1), New Integer() {0, 0}, min_len1)
                            End If

                            Dim do_debug1 As Integer = 0
                            If do_debug1 = 1 Then
                                If ind1 < ind2 Then
                                    res_slice1 = merge_2_slice_curve1(slices_curves_arr1(ind1), slices_curves_arr1(ind2), New Integer() {0, 0}, min_len1)
                                Else
                                    res_slice1 = merge_2_slice_curve1(slices_curves_arr1(ind2), slices_curves_arr1(ind1), New Integer() {0, 0}, min_len1)
                                End If
                            End If
                            If res_slice1 IsNot Nothing Then


                                If ind1 < ind2 Then

                                    If ind2 = slices_curves_arr1.Count - 1 And ind1 < ind2 Then
                                        slices_curves_arr1(ind1) = res_slice1
                                        slices_curves_arr1.RemoveAt(ind2)
                                    Else
                                        slices_curves_arr1(ind1) = res_slice1

                                        slices_curves_arr1.RemoveAt(ind2)

                                    End If






                                Else

                                    If ind1 = slices_curves_arr1.Count - 1 And ind2 < ind1 Then
                                        slices_curves_arr1(ind2) = res_slice1

                                        slices_curves_arr1.RemoveAt(ind1)
                                    Else
                                        slices_curves_arr1(ind2) = res_slice1

                                        slices_curves_arr1.RemoveAt(ind1)

                                    End If

                                End If
                                to_stop1 = 1
                                found_merge1 = 1
                                ind2 = slices_curves_arr1.Count
                                ind1 = slices_curves_arr1.Count + 1
                            End If
                        End If

                    End If
                    ind2 += 1

                    If ind2 >= slices_curves_arr1.Count Then
                        to_stop1 = 1
                    End If
                End While
                'For ind2 = 0 To slices_curves_arr1.Count - 1

                'Next

            Next
        End While

    End Function


    Public Function crop_by_pxls_arr1(pxls_arr1 As ArrayList, path_of_result1 As String, sobel_ind1 As Integer)

        Dim res_folder1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1.Substring(0, CGlobals1.form_obj1.file_name1.IndexOf("\")) + "\crop_res1\"
        CGlobals1.create_folder1(res_folder1)
        Dim org_crop_bmp1 As Bitmap = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")
        Dim org_crop_bmp2 As Bitmap = New Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")
        Dim mask_bmp1 As Bitmap = CGlobals1.create_fill_bitmap(org_crop_bmp1.Width, org_crop_bmp1.Height, Color.FromArgb(255, 255, 255))

        CGlobals1.form_obj1.markingfldimg_obj1.set_double_pixel_arr_on_bmp2(pxls_arr1, mask_bmp1, Color.FromArgb(250, 50, 10))
        path_of_result1 = res_folder1
        mask_bmp1.Save(path_of_result1 + "crop1_" + sobel_ind1.ToString() + ".bmp")

        Dim bmp_crop2 As Bitmap = CGlobals1.form_obj1.markingfldimg_obj1.paint_recursive3(mask_bmp1, 10, 10, Color.FromArgb(250, 50, 10), Color.FromArgb(0, 0, 0))
        bmp_crop2.Save(path_of_result1 + "crop2_" + sobel_ind1.ToString() + ".bmp")
        Dim x1 As Integer
        Dim y1 As Integer

        For x1 = 0 To org_crop_bmp1.Width - 1
            For y1 = 0 To org_crop_bmp1.Height - 1
                If bmp_crop2.GetPixel(x1, y1).R = 0 And bmp_crop2.GetPixel(x1, y1).G = 0 And bmp_crop2.GetPixel(x1, y1).B = 0 Then
                    org_crop_bmp1.SetPixel(x1, y1, Color.FromArgb(0, 0, 0, 0))
                    org_crop_bmp2.SetPixel(x1, y1, Color.FromArgb(255, 50, 50))


                End If
            Next

        Next

        org_crop_bmp1 = CGlobals1.form_obj1.markingfldimg_obj1.remove_around_object1(org_crop_bmp1, Color.FromArgb(0, 0, 0, 0))
        org_crop_bmp1 = CGlobals1.form_obj1.markingfldimg_obj1.remove_around_object1(org_crop_bmp1, Color.FromArgb(0, 0, 0, 0))
        org_crop_bmp2 = CGlobals1.form_obj1.markingfldimg_obj1.remove_around_object1(org_crop_bmp2, Color.FromArgb(255, 50, 50))
        org_crop_bmp2 = CGlobals1.form_obj1.markingfldimg_obj1.remove_around_object1(org_crop_bmp2, Color.FromArgb(255, 50, 50))

        org_crop_bmp1.Save(path_of_result1 + "crop3_" + sobel_ind1.ToString() + ".bmp")
        org_crop_bmp2.Save(path_of_result1 + "crop4_" + sobel_ind1.ToString() + ".bmp")
    End Function


    Public Function slices_curves_to_pxls_arr1(slices_curves_arr1 As ArrayList)
        Dim pxls_arr1 As ArrayList = New ArrayList()

        Dim i1 As Integer
        For i1 = 0 To slices_curves_arr1.Count - 1
            Dim curve_pixels_arr1 As ArrayList = slices_curves_arr1(i1)("cords_arr1")

            Dim i2 As Integer

            For i2 = 0 To curve_pixels_arr1.Count - 1
                pxls_arr1.Add(curve_pixels_arr1(i2))
            Next
        Next


        Return pxls_arr1
    End Function


    Public Function lock_pixel_on_bmp1(ByRef bmp1 As Bitmap, arr1 As ArrayList, ByRef lock_pixel_dict2 As Dictionary(Of String, Integer), color1 As Color)
        Dim i1 As Integer

        For i1 = 0 To arr1.Count - 1
            Dim cords_arr1 As ArrayList = arr1(i1)("cords_arr1")
            Dim i2 As Integer

            If cords_arr1.Count > 30 Then
                For i2 = 5 To cords_arr1.Count - 5
                    Dim cord_xy1() As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, i2)
                    lock_pixel_dict2(cords_arr1(i2)) = 1
                    'bmp1.SetPixel(cord_xy1(0), cord_xy1(1), Color.FromArgb(255, 255, 255))
                Next

            End If
            Dim d1 As Integer = 3
        Next

        For i1 = 0 To lock_pixel_dict2.Keys.Count - 1

            Dim cord_xy_str1() As String = lock_pixel_dict2.Keys(i1).Split(",")
            bmp1.SetPixel(Integer.Parse(cord_xy_str1(0)), Integer.Parse(cord_xy_str1(1)), color1)
        Next

        Return bmp1
    End Function

    Public Function curves_arrays_to_dict1(curves_arr1 As ArrayList)

        Dim pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim i1 As Integer

        For i1 = 0 To curves_arr1.Count - 1
            Dim cords_arr1 As ArrayList = curves_arr1(i1)("cords_arr1")
            Dim i2 As Integer

            If cords_arr1.Count > 30 Then
                For i2 = 5 To cords_arr1.Count - 5
                    Dim cord_xy1() As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, i2)
                    pixels_dict1(cords_arr1(i2)) = 1
                    'bmp1.SetPixel(cord_xy1(0), cord_xy1(1), Color.FromArgb(255, 255, 255))
                Next

            End If
            Dim d1 As Integer = 3
        Next


        Return pixels_dict1
    End Function

    Public Function compare_dict_of_pixels1(dict_pixels1 As Dictionary(Of String, Integer), dict_pixels2 As Dictionary(Of String, Integer))
        Dim i1 As Integer

        Dim dict_pixels1_not_exist1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        For i1 = 0 To dict_pixels1.Keys.Count - 1
            Dim cord_xy_str1() As String = dict_pixels1.Keys(i1).Split(",")
            Dim x1 As Integer = Integer.Parse(cord_xy_str1(0))
            Dim y1 As Integer = Integer.Parse(cord_xy_str1(1))

            Dim x_cord1 As Integer
            Dim y_cord1 As Integer

            Dim exist1 As String = ""

            For x_cord1 = -2 To 2
                For y_cord1 = -2 To 2
                    Dim xy_cord_str1 As String = (x1 + x_cord1).ToString() + "," + (y1 + y_cord1).ToString()

                    If dict_pixels2.ContainsKey(xy_cord_str1) = True Then
                        exist1 = "yes"
                    End If
                Next

            Next

            If exist1 = "" And dict_pixels2.Count > 0 Then
                dict_pixels1_not_exist1(dict_pixels1.Keys(i1)) = 1
            End If


        Next

        Return dict_pixels1_not_exist1
    End Function
    Public Function loop_on_sobel_vals4(line_to_search_start_sobel_pixels1 As ArrayList)

        Dim lock_pixels1 As String = "yes"

        Dim last_pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        CGlobals1.delete_files1(CGlobals1.global_path1 + "\sobel_pics1", "*.bmp")

        CGlobals1.dir_x1_to_sobel = 1

        CGlobals1.dir_m1_to_sobel = 0

        'CGlobals1.current_start_x1 = 1340
        'CGlobals1.current_start_y1 = 3

        CGlobals1.current_start_x1 = 500 '200
        CGlobals1.current_start_y1 = 3


        'CGlobals1.current_start_x1 = 370 '200
        'CGlobals1.current_start_y1 = 273


        CGlobals1.current_start_x1 = 1400 '200
        CGlobals1.current_start_y1 = 1000


        CGlobals1.dir_x1_to_sobel = 0
        CGlobals1.dir_m1_to_sobel = 1


        Dim lock_pixel_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        Dim bmp_max_diff1 As Bitmap = CGlobals1.form_obj1.markingfldimg_obj1.get_max_diff_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp1)

        Dim to_stop_round_with_sobal1 As Integer = 0
        'הקו שמקיף את הסובל וגדל לפי החלקים שמחברים אליו בכל אינטרציה
        Dim current_pixel_line_arr1 As ArrayList = New ArrayList()
        'מפתח שאומר אם הנקודה על הקו ומה האינדקס שלה
        Dim dict_current_pixel_line_arr1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        'For x1 = 0 To bmp_current_sobel.Width - 1
        'For y1 = 0 To bmp_current_sobel.Height - 1
        'bmp_current_sobel.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))
        'Next

        'Next




        'Dim bmp_max_diff1 As Bitmap = get_max_diff_bmp1(bmp1)



        'Dim bmp3 As Bitmap = markingfldimg_obj1.compute_max_diff_from_neighboors1(bmp2)

        'Dim clear_bmp1 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim first_pixels_arr1 As ArrayList
        Dim image_ind1 As Integer = 0

        Dim dict_max_dist_sobel As Dictionary(Of Double, Object) = New Dictionary(Of Double, Object)

        Dim dict_lock_pixels1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim dict_sobel_arrs1 As Dictionary(Of Integer, Object) = New Dictionary(Of Integer, Object)
        Dim dict_contains_slices2 As Dictionary(Of Integer, Object) = New Dictionary(Of Integer, Object)

        Dim arr_of_slice_min_len1 As ArrayList = New ArrayList()

        Dim last_merged2_arr_of_slice_min_len1 As ArrayList = New ArrayList()
        'Dim dcit_pixel_arr_around_sobel_by_sobel_ind1 As Dictionary(Of Integer, ArrayList) = New Dictionary(Of Integer, ArrayList)
        While to_stop_round_with_sobal1 = 0




            CGlobals1.max_last_index_all_exist_in_prev_pixels1 = -1


            'CGlobals1.step_num1 += 1
            'cur_sobel_ind_val1 = 0
            Dim to_stop1 As Integer = 0
            CGlobals1.max_pixels_arr_length1 = -99
            CGlobals1.max_count_pixels1 = -99
            Dim dict_result_by_sobel_val1 As Dictionary(Of Integer, Object) = New Dictionary(Of Integer, Object)

            If CGlobals1.step_num1 = 9 Then
                Dim d1 As Integer = 1
            End If
            Dim step_num2 As Integer = 0
            Dim last_srat_cord_line_line1 As Integer = -1

            Dim dict_res_sobel_pxls2 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
            Dim dict_slice_curves1 As Dictionary(Of Integer, Object) = New Dictionary(Of Integer, Object)
            Dim count_slice_curves1 As Integer = 0

            Dim total_added_connected1 As ArrayList = New ArrayList()

            CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 = 1
            While to_stop1 = 0
                last_srat_cord_line_line1 = -1
                CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 += 1
                Try
                    CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel = New Bitmap(CGlobals1.path_of_sobel_cache1 + "\" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".jpg")
                Catch ex As Exception
                    Dim err1 As Integer = 1
                End Try

                'add_dec_sobel_ind("add1", 1)

                Dim to_stop_search_start_point1 As Integer = 0
                Dim dict_res1 As Dictionary(Of String, Object)


                If CGlobals1.global_suffix_file_name1 = "_right_glass1" And CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 = 3 Then
                    Dim d1 As Integer = 1
                End If
                Dim found_around_sobel As String = "yes"


                'find_start_sobel1(cur_sobel_ind_val1, line_to_search_start_sobel_pixels1, Me.bmp_current_sobel)
                Dim cord1 As Integer()
                Try
                    cord1 = CGlobals1.form_obj1.markingfldimg_obj1.find_start_point_by_line1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, line_to_search_start_sobel_pixels1, last_srat_cord_line_line1)
                    CGlobals1.form_obj1.markingfldimg_obj1.x_start2 = cord1(0)
                    CGlobals1.form_obj1.markingfldimg_obj1.y_start2 = cord1(1)
                Catch ex As Exception
                    found_around_sobel = "no"
                    to_stop_search_start_point1 = 1
                End Try


                'arr_of_slice_min_len1

                If lock_pixels1 = "yes" Then


                    Dim copy_sobel_bmp1 As Bitmap = CGlobals1.copy_bitmap1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel)
                    copy_sobel_bmp1 = lock_pixel_on_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, arr_of_slice_min_len1, lock_pixel_dict1, Color.FromArgb(250, 100, 55))
                    copy_sobel_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_lock2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                    CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel = lock_pixel_on_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, arr_of_slice_min_len1, lock_pixel_dict1, Color.FromArgb(255, 255, 255))
                    CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_lock_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                    'CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel
                End If
                Dim d3 As Integer = 5
                dict_res1 = CGlobals1.form_obj1.markingfldimg_obj1.find_max_sobel_length3(CGlobals1.form_obj1.markingfldimg_obj1.x_start2, CGlobals1.form_obj1.markingfldimg_obj1.y_start2)



                If found_around_sobel = "yes" Then
                    Dim padding_search1 As Integer = 10
                    Dim padding_no_search1 As Integer = 3
                    dict_result_by_sobel_val1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) = dict_res1

                    Dim sobel_pixels_arr1 As ArrayList = CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList)
                    Dim sobel_pixels_arr2 As ArrayList = sobel_pixels_arr1.Clone()
                    Dim dict_sobel_pixels1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(sobel_pixels_arr1)
                    Dim dict_sobel_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                    dict_sobel_res1("arr1") = sobel_pixels_arr1
                    dict_sobel_res1("dict1") = dict_sobel_pixels1
                    dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) = dict_sobel_res1
                    'set_pixels_arr_and_save1(CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList), CGlobals1.copy_bitmap1(bmp_current_sobel), CGlobals1.global_path1 + "\sobel_pics1\step_res_" + CGlobals1.step_num1.ToString() + "_" + cur_sobel_ind_val1.ToString() + ".jpg")

                    If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 > 15 Then





                        Dim dict_res_connectivity1 As Dictionary(Of String, Integer) = check_connectivity_between_pixels1(dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 - 1), dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1))
                        If dict_res_connectivity1.Count > 0 And False Then
                            Dim start_ind1 As Integer = Integer.Parse(dict_res_connectivity1.Keys(0).Split(",")(0).ToString())
                            Dim end_ind1 As Integer = Integer.Parse(dict_res_connectivity1.Keys(0).Split(",")(1).ToString())

                            Dim ind2 As Integer

                            For ind2 = start_ind1 To end_ind1
                                dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)("arr1").RemoveAt(start_ind1)
                            Next


                            dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)("cords_arr1") = dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)("arr1")
                            dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)("dict_sqrs_of_cords1") = get_sqrs_of_cords1(dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)("arr1"))

                            dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)("cords_dict1") = CGlobals1.add_to_dict1(dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)("arr1"))

                            'save_slices_curves_in_bmp1(dict_sobel_arrs1(cur_sobel_ind_val1)("arr1"), CGlobals1.global_path1 + "sobel_pics1\no_hole1_" + cur_sobel_ind_val1.ToString() + ".bmp")
                            Dim bmp5 As Bitmap = CGlobals1.create_fill_bitmap(2700, 1800, Color.FromArgb(255, 255, 255))

                            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(dict_sobel_arrs1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)("cords_arr1"), bmp5, Color.FromArgb(1, 1, 1))

                            bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\no_hole1_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")

                        End If
                        Dim slice_curves_arr1 As ArrayList

                        Try
                            slice_curves_arr1 = check_if_trend_without_noise(sobel_pixels_arr1, CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)
                        Catch ex As Exception
                            Dim err1 As String = "1"
                        End Try

                        Try
                            print_slices_curve1(slice_curves_arr1, CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)

                        Catch ex As Exception

                        End Try
                        dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) = slice_curves_arr1



                        If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 = 18 Then
                            Dim d34 As Integer = 1
                        End If


                        If arr_of_slice_min_len1 IsNot Nothing Then
                            Try
                                check_connectivity_between_slice_curves1(dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 - 1), dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1), arr_of_slice_min_len1)
                                save_slices_curves_in_bmp1(dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1), CGlobals1.global_path1 + "sobel_pics1\no_hole_slice2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")

                            Catch ex As Exception

                            End Try

                        End If

                        count_slice_curves1 = slice_curves_arr1.Count

                        Dim to_merge_slices1 As String = ""




                        If dict_slice_curves1.Count > 1 Then
                            If arr_of_slice_min_len1.Count = 0 Then
                                arr_of_slice_min_len1 = dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 - 1)
                            End If

                            save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\start_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")


                            Dim i3 As Integer
                            Dim ind1 As Integer
                            Dim ind2 As Integer
                            ind1 = 0

                            Dim to_stop_merge1 As Integer = 1

                            While to_stop_merge1 = 0

                                Dim dict_res2 As Dictionary(Of String, Object) = try_to_merge_slices_curves1(arr_of_slice_min_len1, ind1, ind1 + 1)
                                If dict_res2 IsNot Nothing Then
                                    arr_of_slice_min_len1(ind1) = dict_res2
                                    arr_of_slice_min_len1.RemoveAt(ind1 + 1)
                                Else
                                    ind1 += 1
                                End If

                                If ind1 >= arr_of_slice_min_len1.Count - 2 Then
                                    to_stop_merge1 = 1
                                End If

                            End While
                            If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 = 37 Then
                                Dim d1 As Integer = 2
                            End If
                            save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\merged_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")

                            Dim cur_last_pixels_dict1 As Dictionary(Of String, Integer) = curves_arrays_to_dict1(arr_of_slice_min_len1)


                            Dim not_exist_pixels As Dictionary(Of String, Integer) = compare_dict_of_pixels1(last_pixels_dict1, cur_last_pixels_dict1)

                            If not_exist_pixels.Count > 0 Then
                                Dim err1 As Integer = 1


                                Dim pxls_arr1 As ArrayList = CGlobals1.dict_keys_to_arr1(not_exist_pixels)
                                Dim bmp_pxl_no_exist1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
                                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp1(pxls_arr1, bmp_pxl_no_exist1)
                                bmp_pxl_no_exist1.Save(CGlobals1.global_path1 + "sobel_pics1\not_exist_pxls0_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")

                            End If
                            last_pixels_dict1 = cur_last_pixels_dict1

                            If lock_pixels1 = "yes" Then


                                Dim copy_sobel_bmp1 As Bitmap = CGlobals1.copy_bitmap1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel)
                                copy_sobel_bmp1 = lock_pixel_on_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, arr_of_slice_min_len1, lock_pixel_dict1, Color.FromArgb(250, 100, 55))
                                copy_sobel_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_lock3_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                                'CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel
                            End If



                            If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 < 25 Then
                                arr_of_slice_min_len1 = replace_slices_curves_with_bigger_and_conatain_slices_curves1(arr_of_slice_min_len1, dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1), CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)

                            End If
                            save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")


                            If lock_pixels1 = "yes" Then


                                Dim copy_sobel_bmp1 As Bitmap = CGlobals1.copy_bitmap1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel)
                                copy_sobel_bmp1 = lock_pixel_on_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, arr_of_slice_min_len1, lock_pixel_dict1, Color.FromArgb(250, 100, 55))
                                copy_sobel_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_lock4_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                                'CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel
                            End If

                            If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 = 22 Then
                                Dim d2 As Integer = 2
                            End If
                            arr_of_slice_min_len1 = add_slices_curves_where_overlaps_slices_curves1(arr_of_slice_min_len1, dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1), "start")


                            cur_last_pixels_dict1 = curves_arrays_to_dict1(arr_of_slice_min_len1)


                            not_exist_pixels = compare_dict_of_pixels1(last_pixels_dict1, cur_last_pixels_dict1)

                            If not_exist_pixels.Count > 0 Then
                                Dim err1 As Integer = 1
                                Dim pxls_arr1 As ArrayList = CGlobals1.dict_keys_to_arr1(not_exist_pixels)
                                Dim bmp_pxl_no_exist1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
                                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp1(pxls_arr1, bmp_pxl_no_exist1)
                                bmp_pxl_no_exist1.Save(CGlobals1.global_path1 + "sobel_pics1\not_exist_pxls1_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                            End If
                            last_pixels_dict1 = cur_last_pixels_dict1



                            If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 = 22 Then
                                save_slices_curves_in_bmps2(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\logs1\")

                            End If

                            save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added1_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")

                            If lock_pixels1 = "yes" Then


                                Dim copy_sobel_bmp1 As Bitmap = CGlobals1.copy_bitmap1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel)
                                copy_sobel_bmp1 = lock_pixel_on_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, arr_of_slice_min_len1, lock_pixel_dict1, Color.FromArgb(250, 100, 55))
                                copy_sobel_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_lock5_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                                'CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel
                            End If


                            'arr_of_slice_min_len1 = add_slices_curves_where_overlaps_slices_curves1(arr_of_slice_min_len1, dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1), "end")


                            cur_last_pixels_dict1 = curves_arrays_to_dict1(arr_of_slice_min_len1)


                            not_exist_pixels = compare_dict_of_pixels1(last_pixels_dict1, cur_last_pixels_dict1)

                            If not_exist_pixels.Count > 0 Then
                                Dim err1 As Integer = 1
                                Dim pxls_arr1 As ArrayList = CGlobals1.dict_keys_to_arr1(not_exist_pixels)
                                Dim bmp_pxl_no_exist1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
                                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp1(pxls_arr1, bmp_pxl_no_exist1)
                                bmp_pxl_no_exist1.Save(CGlobals1.global_path1 + "sobel_pics1\not_exist_pxls1_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                            End If
                            last_pixels_dict1 = cur_last_pixels_dict1

                            save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                            If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 >= 35 Then
                                Dim slice_ind1 As Integer

                                For slice_ind1 = 0 To arr_of_slice_min_len1.Count - 2
                                    Dim arr_slice1 As ArrayList = arr_of_slice_min_len1(slice_ind1)("cords_arr1")
                                    Dim arr_slice2 As ArrayList = arr_of_slice_min_len1(slice_ind1 + 1)("cords_arr1")
                                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr_slice1, arr_slice1.Count - 1)
                                    Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(arr_slice2, 0)
                                    Dim dist1 As Double = CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy1(cord_xy1, cord_xy2)
                                    If dist1 >= 1 And dist1 < 10 Then
                                        Dim arr2 As ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(cord_xy1, cord_xy2)
                                        Dim ind4 As Integer

                                        For ind4 = 0 To arr2.Count - 1
                                            arr_slice1.Add(arr2(ind4))
                                        Next
                                        Dim d1234 As Integer = 1
                                    End If


                                Next

                            End If
                            save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added3_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")


                            'crop_by_pxls_arr1
                            If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 >= 20 Then
                                Dim d123 As Integer = 1
                            End If

                            arr_of_slice_min_len1 = add_slices_curves_where_no_slices_curves1(arr_of_slice_min_len1, dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1))

                            cur_last_pixels_dict1 = curves_arrays_to_dict1(arr_of_slice_min_len1)


                            not_exist_pixels = compare_dict_of_pixels1(last_pixels_dict1, cur_last_pixels_dict1)

                            If not_exist_pixels.Count > 0 Then
                                Dim err1 As Integer = 1
                                Dim pxls_arr1 As ArrayList = CGlobals1.dict_keys_to_arr1(not_exist_pixels)
                                Dim bmp_pxl_no_exist1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
                                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp1(pxls_arr1, bmp_pxl_no_exist1)
                                bmp_pxl_no_exist1.Save(CGlobals1.global_path1 + "sobel_pics1\not_exist_pxls2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                            End If
                            last_pixels_dict1 = cur_last_pixels_dict1

                            'arr_of_slice_min_len1 = add_slices_curves_where_no_slices_curves1(arr_of_slice_min_len1, dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1))
                            save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added_where_no_slice2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                            'save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added_missing_" + cur_sobel_ind_val1.ToString() + ".bmp")
                            If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 >= 34 Then
                                Dim d123 As Integer = 1
                            End If


                            If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 = 24 Then
                                Dim d1 As Integer = 4
                            End If

                            'arr_of_slice_min_len1 = check_if_can_merge_slices_curves2(arr_of_slice_min_len1)
                            arr_of_slice_min_len1 = check_if_can_merge_slices_curves3(arr_of_slice_min_len1)

                            'check_if_can_merge_slices_curves3()
                            save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\merged2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")



                            cur_last_pixels_dict1 = curves_arrays_to_dict1(arr_of_slice_min_len1)


                            not_exist_pixels = compare_dict_of_pixels1(last_pixels_dict1, cur_last_pixels_dict1)

                            If not_exist_pixels.Count > 0 Then
                                Dim err1 As Integer = 1
                                Dim pxls_arr1 As ArrayList = CGlobals1.dict_keys_to_arr1(not_exist_pixels)
                                Dim bmp_pxl_no_exist1 As Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, Color.FromArgb(255, 255, 255))
                                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp1(pxls_arr1, bmp_pxl_no_exist1)
                                bmp_pxl_no_exist1.Save(CGlobals1.global_path1 + "sobel_pics1\not_exist_pxls3_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                            End If
                            last_pixels_dict1 = cur_last_pixels_dict1



                            If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 Mod 10 = 0 Then
                                crop_by_pxls_arr1(sobel_pixels_arr2, CGlobals1.global_path1 + "sobel_pics1\", CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)
                                'crop_by_pxls_arr1(slices_curves_to_pxls_arr1(slice_curves_arr1), CGlobals1.global_path1 + "sobel_pics1\crop1_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                                CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1.Substring(0, CGlobals1.form_obj1.file_name1.IndexOf("\")) + "\crop_res1\conture_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".txt", dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"))



                                '*********
                            End If

                            CGlobals1.form_obj1.lbl_progress1.Text = "cur_sobel=" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString()
                            Application.DoEvents()
                            If CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 > Integer.Parse(CGlobals1.form_obj1.txtbox_sobel_factor1.Text.ToString()) Then
                                MessageBox.Show("finish!")
                                Return 1
                            End If
                            If False Then


                                Dim arr_of_slice_min_len2 As ArrayList = arr_of_slice_min_len1.Clone()

                                check_if_can_merge_slices_curves2(arr_of_slice_min_len2)


                                save_slices_curves_in_bmp1(arr_of_slice_min_len2, CGlobals1.global_path1 + "sobel_pics1\merged2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")



                                If slices_curves_to_pxls_arr1(arr_of_slice_min_len2).Count >= slices_curves_to_pxls_arr1(last_merged2_arr_of_slice_min_len1).Count Then
                                    last_merged2_arr_of_slice_min_len1 = arr_of_slice_min_len2
                                End If
                                arr_of_slice_min_len1 = last_merged2_arr_of_slice_min_len1

                                save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\merged3_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")

                                Dim pxls_arr1 As ArrayList = slices_curves_to_pxls_arr1(arr_of_slice_min_len1)
                                If sobel_pixels_arr1.Count * 0.75 < pxls_arr1.Count Then
                                    crop_by_pxls_arr1(sobel_pixels_arr1, CGlobals1.global_path1 + "sobel_pics1\", CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)

                                End If


                            End If
                            'If cur_sobel_ind_val1 >= 35 Then

                            'End If
                            If False Then


                                Dim arr1 As ArrayList = compare_slice_curves_arr4(arr_of_slice_min_len1, dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1), CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)
                                'Dim arr2 As ArrayList = add_slice_curves_that_part_is_not_in_curves(dict_slice_curves1(cur_sobel_ind_val1 - 1), arr1, cur_sobel_ind_val1)
                                'arr_of_slice_min_len1 = add_slices_of_curve_when_no_curves(arr_of_slice_min_len1, dict_slice_curves1(cur_sobel_ind_val1), cur_sobel_ind_val1)
                                Dim added_connect_slices1 As ArrayList = connect_slices_curves_by_new_slices_curves1(dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 - 1), dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1), CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)
                                For i3 = 0 To added_connect_slices1.Count - 1
                                    total_added_connected1.Add(added_connect_slices1(i3))
                                Next

                                For i3 = 0 To total_added_connected1.Count - 1
                                    arr_of_slice_min_len1.Add(total_added_connected1(i3))
                                Next
                                arr_of_slice_min_len1 = compare_slice_curves_arr4(arr_of_slice_min_len1, dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1), CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)
                                merge_connect_slices_of_curves1(arr_of_slice_min_len1)
                                'arr_of_slice_min_len1 = add_slice_curves_that_part_is_not_in_curves(dict_slice_curves1(cur_sobel_ind_val1 - 1), arr_of_slice_min_len1, cur_sobel_ind_val1)


                                arr_of_slice_min_len1 = New ArrayList()

                            End If

                            'For i3 = 0 To arr1.Count - 1
                            'arr_of_slice_min_len1.Add(arr1(i3))
                            'Next


                            'For i3 = 0 To arr2.Count - 1
                            'arr_of_slice_min_len1.Add(arr2(i3))
                            'Next

                            'merge_slices_arr1(arr_of_slice_min_len1)
                            'compare_slice_curves_arr3(dict_slice_curves1(cur_sobel_ind_val1 - 1), dict_slice_curves1(cur_sobel_ind_val1))

                            'compare_slice_curves_arr2(dict_slice_curves1(cur_sobel_ind_val1 - 1), dict_slice_curves1(cur_sobel_ind_val1))
                            'dict_contains_slices2(cur_sobel_ind_val1) = compare_slice_curves_arr1(dict_slice_curves1(cur_sobel_ind_val1 - 1), dict_slice_curves1(cur_sobel_ind_val1))








                        End If

                    End If
                    Dim compute1 As String = "no"
                    If compute1 = "yes" Then


                        Dim pixel_ind1 As Integer

                        For pixel_ind1 = 0 To sobel_pixels_arr1.Count - 1

                            Dim dict_colors1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

                            If pixel_ind1 = 127 Then
                                Dim d1 As Integer = 1
                            End If
                            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sobel_pixels_arr1, pixel_ind1)
                            Dim color1 As Color = bmp_max_diff1.GetPixel(cord_xy1(0), cord_xy1(1))


                            Dim exist_neighboors_with_more_diff1 As String = "no"
                            Dim not_same_color_neighboors1 As String = "no"
                            Dim x1 As Integer
                            Dim y1 As Integer
                            Dim count_exist_neighboors_with_more_diff1 As Integer = 0
                            Dim count_not_same_color_neighboors1 As Integer = 0
                            Dim count_search1 As Integer = 0

                            For x1 = -padding_search1 To padding_search1
                                For y1 = -padding_search1 To padding_search1
                                    Dim cur_x1 As Integer = cord_xy1(0) + x1
                                    Dim cur_y1 As Integer = cord_xy1(1) + y1
                                    Dim no_search1 As String = "no"
                                    If x1 > -padding_no_search1 And x1 < padding_no_search1 And y1 > -padding_no_search1 And y1 < padding_no_search1 Then
                                        no_search1 = "yes"
                                    End If
                                    If no_search1 = "no" And cur_x1 > 0 And cur_y1 > 0 And cur_x1 < (bmp_max_diff1.Width - 1) And cur_y1 < (bmp_max_diff1.Height - 1) Then
                                        Try
                                            count_search1 += 1
                                            Dim color2 As Color = bmp_max_diff1.GetPixel(cord_xy1(0) + x1, cord_xy1(1) + y1)
                                            dict_colors1(x1.ToString() + "," + y1.ToString()) = color2.R
                                            If color2.R > color1.R Then
                                                exist_neighboors_with_more_diff1 = "yes"
                                                count_exist_neighboors_with_more_diff1 += 1
                                            End If

                                            If color2.R <> color1.R Then
                                                not_same_color_neighboors1 = "yes"
                                                count_not_same_color_neighboors1 += 1
                                            End If

                                        Catch ex As Exception
                                            Dim err1 As String = "yes"
                                        End Try
                                    End If

                                Next

                            Next







                            Dim color_mono1 As Color = CGlobals1.form_obj1.markingfldimg_obj1.bmp1.GetPixel(cord_xy1(0), cord_xy1(1))
                            Dim exist_neighboors_with_less_color1 As String = "no"

                            If exist_neighboors_with_more_diff1 = "no" Then
                                For x1 = -padding_search1 To padding_search1
                                    For y1 = -padding_search1 To padding_search1

                                        Dim no_search1 As String = "no"
                                        If x1 > -padding_no_search1 And x1 < padding_no_search1 And y1 > -padding_no_search1 And y1 < padding_no_search1 Then
                                            no_search1 = "yes"
                                        End If

                                        If no_search1 = "no" And (cord_xy1(0) + x1) > 0 And (cord_xy1(1) + y1) > 0 And (cord_xy1(0) + x1) < bmp_max_diff1.Width - 1 And (cord_xy1(1) + y1) < bmp_max_diff1.Height - 1 Then
                                            Dim color_mono2 As Color = CGlobals1.form_obj1.markingfldimg_obj1.bmp1.GetPixel(cord_xy1(0) + x1, cord_xy1(1) + y1)
                                            If color_mono2.R < color_mono1.R Then
                                                exist_neighboors_with_less_color1 = "yes"
                                            End If
                                        End If

                                    Next

                                Next
                            End If


                            Dim x2 As Integer
                            Dim y2 As Integer
                            Dim dict_max_diff1 As Dictionary(Of String, Double) = New Dictionary(Of String, Double)
                            Dim max_diff_cord1 As String = ""
                            Dim max_diff_val1 As Double = 0
                            Dim max_diff_x1 As Integer = -1
                            Dim max_diff_y1 As Integer = -1
                            For x2 = -18 To 18
                                For y2 = -18 To 18
                                    Dim cur_max_diff_val1 As Double = count_neighboors_with_less_diff1(bmp_max_diff1, New Integer() {cord_xy1(0) + x2, cord_xy1(1) + y2})
                                    dict_max_diff1(x2.ToString() + "," + y2.ToString()) = cur_max_diff_val1

                                    If max_diff_val1 <= cur_max_diff_val1 Then
                                        max_diff_val1 = cur_max_diff_val1
                                        max_diff_cord1 = x2.ToString() + "," + y2.ToString()

                                        max_diff_x1 = cord_xy1(0) + x2
                                        max_diff_y1 = cord_xy1(1) + y2
                                        If max_diff_cord1 = "0,0" Then
                                            Dim d2 As Integer = 1
                                        End If

                                    End If
                                Next
                            Next



                            Dim x3 As Integer
                            Dim y3 As Integer

                            For x3 = -2 To 2
                                For y3 = -2 To 2
                                    If dict_sobel_pixels1.ContainsKey((max_diff_x1 + x3).ToString() + "," + (max_diff_y1 + y3).ToString()) = True Then
                                        Dim d1 As Integer = 1
                                        dict_res_sobel_pxls2((max_diff_x1 + x3).ToString() + "," + (max_diff_y1 + y3).ToString()) = 1
                                    End If

                                Next

                            Next
                            If exist_neighboors_with_more_diff1 = "no" Then
                                Dim d1 As Integer = 1
                            End If

                            If exist_neighboors_with_less_color1 = "no" Then
                                Dim d1 As Integer = 1
                            End If

                            If not_same_color_neighboors1 = "no" Then
                                Dim d1 As Integer = 1
                            End If

                            If count_exist_neighboors_with_more_diff1 < (count_search1 * 0.1) Then
                                Dim d1 As Integer = 1
                            End If
                            If exist_neighboors_with_more_diff1 = "no" And exist_neighboors_with_less_color1 = "no" And not_same_color_neighboors1 = "yes" Then
                                dict_result_by_sobel_val1(cord_xy1(0).ToString() + "," + cord_xy1(1).ToString()) = 1
                            End If
                        Next
                    End If

                    'clear_bmp1 = set_pixels_arr_and_save1(CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList), clear_bmp1, CGlobals1.global_path1 + "\sobel_pics1\step_res1_" + CGlobals1.step_num1.ToString() + "_" + cur_sobel_ind_val1.ToString() + ".jpg")


                    CGlobals1.current_max_arr_sobel = dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1")
                    'Dim res_str1 As String = find_max_sobel_length1()
                    'If res_str1 = "stop_sobel1" Or res_str1 = "arrive_to_start_point" Then
                    'to_stop1 = 1
                    'End If
                End If

            End While





            'compute_current_start_cord_and_vec1()
            CGlobals1.step_num1 += 1
        End While


    End Function

End Class
