class CEdgeDetection1:
    def __init__(self):
        self.d1=1
        
        
    def lock_pixel_on_bmp1(self,bmp1:Bitmap, arr1:ArrayList, lock_pixel_dict2:Dictionary, color1):
        from CGlobals1 import CGlobals1
        
		
        for i1 in range(0 , arr1.count()):
            cords_arr1:ArrayList = arr1[i1]["cords_arr1"]

            if cords_arr1.count() > 30:
                for i2 in range(5 , cords_arr1.count() - 5+1):
                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, i2)
                    lock_pixel_dict2[cords_arr1[i2]] = 1

        for i1 in range (0 , lock_pixel_dict2.count()):

            cord_xy_str1 = lock_pixel_dict2.dict.keys[i1].Split(",")
            bmp1.SetPixel(int(cord_xy_str1(0)), int(cord_xy_str1(1)), color1)

        return bmp1