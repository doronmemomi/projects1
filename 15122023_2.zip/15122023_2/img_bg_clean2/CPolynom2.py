fi = od = yrt = end = lambda object: None;
from ArrayList import ArrayList
import math

class CPolynom2:
    def __init__(self):
            self.coef_arr1=ArrayList()
            self.coef_coef_derivative_arr1=ArrayList()
            self.polynom_name1=""

    def add_coef(self,val):
        self.coef_arr1.Add(val)

        
    def get_polynom_vals_str1(self):
        poly_str1=""
        
        for i1 in range(self.coef_arr1.count()):
        
            if i1>0:
                poly_str1 += ","
            else:
                e1=1
            
            poly_str1+= str(self.coef_arr1[i1])
            od
        return poly_str1
    
    
    def create_derivative1(self):
        
       
     
        self.coef_derivative_arr1 = ArrayList()
        
        for i1 in range(1,self.coef_arr1.count()):
                self.coef_derivative_arr1.Add(self.coef_arr1[i1] * i1)
    
        
        
    def get_derivative1(self,x_val1):
        derivative_val1=0
        
        for i1 in range(self.coef_derivative_arr1.count()):
            derivative_val1+=self.coef_derivative_arr1[i1] *pow(x_val1, i1)
            
    
        return derivative_val1
    
     
    
    
    
    def find_x_by_derivative_val(self,derivative_val1):
        x_val1=0
        to_stop1=0
        add_x_val1=1
        factor_add_x_val1=1
        
        while to_stop1==0:
            if self.get_derivative1(x_val1) < derivative_val1:
                x_val1 += factor_add_x_val1
            else:
                x_val1 -= factor_add_x_val1
                factor_add_x_val1 /= 2
            
            if factor_add_x_val1 < pow(10, -12):
                to_stop1 = 1
        od   
            
            
        return x_val1


    def get_y_val1(self,x_val1):
        y_val1=0
        
        for i1 in range(self.coef_arr1.count()):
            y_val1 += self.coef_arr1[i1] * pow(x_val1, i1)
            

        return y_val1
    


    def is_all_coef_zero_as_least1(self):
        
        for i1 in range(self.coef_arr1.count()):
            if self.coef_arr1[i1]<0:
                    return 0
 