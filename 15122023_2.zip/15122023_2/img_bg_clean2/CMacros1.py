from ArrayList import ArrayList
from test1 import test1
from CPolynom2 import CPolynom2
from Dictionary import Dictionary
from bitmap import Bitmap



class CMacros1:
    
    def __init__(self):
        self.x1=1
        
        
    def find_rect_of_pixels_arr(self,pixels_arr1:ArrayList,with_arr_of_inds:str=""):
        from CGlobals1 import CGlobals1 as CGlobals1
        
		
        min_x1=9999
        mix_x1=9999
        min_y1=9999
        mix_y1=9999
        
        min_x_ind1=9999
        max_x_ind1=9999
        min_y_ind1=9999
        max_y_ind1=9999
    
        for i1 in range(pixels_arr1.count()):
            
            cord_xy1=CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
            if i1==0:
                min_x1 = cord_xy1[0]
                max_x1 = cord_xy1[0]
                min_y1 = cord_xy1[1]
                max_y1 = cord_xy1[1]
                
                min_x_ind1 = i1
                max_x_ind1 = i1
                min_y_ind1 = i1
                max_y_ind1 = i1
            else:
                if min_x1 > cord_xy1[0]:
                    min_x1 = cord_xy1[0]
                    min_x_ind1 = i1
                
                if max_x1 < cord_xy1[0]:
                    max_x1 = cord_xy1[0]
                    max_x_ind1 = i1
                
                
                if min_y1 > cord_xy1[1]:
                    min_y1 = cord_xy1[1]
                    min_y_ind1 = i1
                
                
                if max_y1 < cord_xy1[1]:
                    max_y1 = cord_xy1[1]
                    max_y_ind1 = i1
               
               
            inds_of_min_x1  =  ArrayList()
            inds_of_max_x1  =  ArrayList()

            inds_of_min_y1  =  ArrayList()
            inds_of_max_y1  =  ArrayList()



        if with_arr_of_inds == "yes":
            for i1 in range(pixels_arr1.count()):
                cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
                if cord_xy1[0] == min_x1:
                    inds_of_min_x1.Add(i1)

                if cord_xy1[0] == max_x1:
                    inds_of_max_x1.Add(i1)

                if cord_xy1[1] == min_y1:
                    inds_of_min_y1.Add(i1)

                if cord_xy1[1] == max_y1:
                    inds_of_max_y1.Add(i1)






        dict_rect1:Dictionary = Dictionary()
        dict_rect1["min_x1"] = min_x1
        dict_rect1["max_x1"] = max_x1
        dict_rect1["min_y1"] = min_y1
        dict_rect1["max_y1"] = max_y1

        dict_rect1["inds_of_min_x1"] = inds_of_min_x1
        dict_rect1["inds_of_max_x1"] = inds_of_max_x1
        dict_rect1["inds_of_min_y1"] = inds_of_min_y1
        dict_rect1["inds_of_max_y1"] = inds_of_max_y1



        dict_rect1["min_x_ind1"] = min_x_ind1
        dict_rect1["max_x_ind1"] = max_x_ind1
        dict_rect1["min_y_ind1"] = min_y_ind1
        dict_rect1["max_y_ind1"] = max_y_ind1

        return dict_rect1

