class ArrayList:
    def __init__(self):
        
        self.arr=[]
        return
       
    def count(self):
        return len(self.arr)
    
    
    def get_count(self):
        return len(self.arr)
    
    count=property(get_count,None) 
    
    def Add(self,obj1):
        self.arr.append(obj1)
        return 1
    def __setitem__(self, key,value):
        self.arr[key]=value
        
    def print(self):
        print(self.arr)
        return 1
   
    def __getitem__(self, ind):
        return self.arr[ind]
    
    
    def RemoveAt(self, ind):
        del self.arr[ind]
    
    
    def Reverse(self):
        self.arr.reverse()

    def Insert(self,ind1,obj1):
        self.arr.insert(ind1,obj1)
        
        
    def clone(self):
        new_arr1=ArrayList()
        new_arr1.arr=self.arr.copy()
        return new_arr1
        
        
    def clear(self):
        new_arr1=ArrayList()
        
