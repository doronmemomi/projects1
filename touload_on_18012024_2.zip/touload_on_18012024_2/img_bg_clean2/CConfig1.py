class CConfig1:

    delta_add_last_ind1 = 25
    min_dist_last_derivative1 = 0.1
    min_dist_down_last_derivative1 = 0.08
    min_dist_up_last_derivative1 = 0.08
    min_diff_last_derivative1 = 0.1
    max_add_curve_height1 = 1.1
    
    def __init__(self):
        self.d1=1
        
    