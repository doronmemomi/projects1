import sys
from ArrayList import ArrayList


a=ArrayList()
a2=ArrayList()

a.Add(8)
a.Add(9)
a.Add(10)
a.RemoveAt(1)
a.print()

a2.Add(8)
a2.Add(9)
a2.Add(110)
a2.print()
print(a[1])

print(sys.version) 