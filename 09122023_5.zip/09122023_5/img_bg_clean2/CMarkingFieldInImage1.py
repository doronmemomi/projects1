class CMarkingFieldInImage1:
    
    def __init__(self):
        
        