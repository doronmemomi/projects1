from Dictionary import Dictionary
from CPolynom2 import CPolynom2
from CGlobals1 import CGlobals1
import json
import sys
import os

class CPolynom_curve1:
    def __init__(self):
        
        self.init_poynom_obj1=CPolynom2()
        
    def analize_polynom2(self):
        dict_polynoms1=Dictionary()
        self.init_poynom_obj1.coef_arr1.Add(0)
        self.init_poynom_obj1.coef_arr1.Add(0.9)
        
        self.init_poynom_obj1.coef_arr1.Add(0.00001)
        self.init_poynom_obj1.coef_arr1.Add(0.00001)
        self.init_poynom_obj1.create_derivative1()
        
        self.pre_proccessing_curve2()
        
        
    def pre_proccessing_curve2(self):
        
        if os.path.isfile(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_json_of_curves_slices1.txt") == True:
             str_json3 = CGlobals1.read_all_file_text(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_json_of_curves_slices1.txt")
             json_obj1=json.loads(str_json3)
             
             for key in json_obj1.keys():
                 
                dict_json3=Dictionary()
        
        