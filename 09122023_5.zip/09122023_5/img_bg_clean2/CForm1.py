class CForm1:
    
    def __init__(self):
        self.file_name1="980376340_2\\195768205504__A"
    