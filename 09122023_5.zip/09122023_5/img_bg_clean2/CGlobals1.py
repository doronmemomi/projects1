from bitmap import Bitmap
from CForm1 import CForm1

class CGlobals1:
    
    global_path1="E:\\memomi_folder1\\glass_pics_8\\"
    form_obj1=CForm1()
    
    def __init__(self):
        print("init1")
        self.x1=82
        return
       
       
    def func1(self):
        print("func11",self.x1)
        return 1
   
   
    def copy_bitmap(bitmp1:Bitmap):
        return bitmp1.clone()
    


    def read_all_file_text(path):
        file = open(path,mode='r')
        text1 = file.read()
        file.close()
        
        return text1
        