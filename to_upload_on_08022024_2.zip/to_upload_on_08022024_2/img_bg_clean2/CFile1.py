import os


class CFile1:
    
    def is_file_exist(path_of_file:str):
        if os.path.isfile(path_of_file):
            return True
        
        return False
            
            
    def is_directory_exist(path_of_directory:str):
        if os.path.isdir(path_of_directory):
            return True
        
        return False
    
    def create_directory(path_of_directory:str):
        try:
            os.mkdir(path_of_directory)
        except:
            return False
        
        return True


    def read_all_file_text(path):
        file = open(path,mode='r')
        text1 = file.read()
        file.close()
        
        return text1
    
    
    def write_all_text_to_file(text,path):
        file = open(path,mode='w')
        file.write(text)
        file.close()
        
        
    
        
    