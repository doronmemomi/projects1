from ArrayList import ArrayList
from test1 import test1
from CPolynom2 import CPolynom2
from Dictionary import Dictionary
from bitmap import Bitmap
from CMarkingFieldInImageUtils1 import CMarkingFieldInImageUtils1
from CConfig1 import CConfig1


class CMacros1:
    
    def __init__(self):
        self.x1=1
        



    def combine_new_curve_in_frame_pixels_arr1(self,new_curve1:ArrayList, frame_pixel_arr1:ArrayList):
        from CGlobals1 import CGlobals1
        i1:int
        dict_new_curve1:Dictionary = CGlobals1.add_to_dict1(new_curve1)
        min_dist_arr1:ArrayList = ArrayList()

        first_cord_ind1:int = -1
        first_min_dist1:float = 99
        lock_first_min_dist1:bool = False


        second_cord_ind1:int = -1
        second_min_dist1:float = 99
        lock_second_min_dist1:int = 0

        last_min_dist_x1:int = -1
        last_min_dist_y1:int = -1


        for i1 in range(0 , frame_pixel_arr1.count):
            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixel_arr1, i1)
            x1:int
            y1:int
            min_dist_x1:int = -1
            min_dist_y1:int = -1
            min_dist1:float = 99
            delta_xy1:int = CConfig1.delta_xy_combine_new_curve_in_frame_pixels_arr1
            for x1 in range(cord_xy1[0] - delta_xy1 , cord_xy1[0] + delta_xy1+1):
                for y1 in range( cord_xy1[1] - delta_xy1 , cord_xy1[1] + delta_xy1+1):
                    if dict_new_curve1.ContainsKey(str(x1) + "," + str(y1)):
                        dist1:float = self.markingfldimg_obj1.get_dist_between_2_cords_xy1((x1, y1), cord_xy1)
                        if dist1 < min_dist1:
                            min_dist1 = dist1
                            min_dist_x1 = x1
                            min_dist_y1 = y1

            if first_min_dist1 < min_dist1 and not lock_first_min_dist1:
                lock_first_min_dist1 = True


            if first_min_dist1 > min_dist1 and not lock_first_min_dist1:
                first_min_dist1 = min_dist1
                first_cord_ind1 = i1
                last_min_dist_x1 = min_dist_x1
                last_min_dist_y1 = min_dist_y1



            if min_dist1 < 6:
                min_dist_arr1.Add(str(i1) + "," + str(min_dist1) + "#" + min_dist_x1.ToString() + "," + str(min_dist_y1) + "#" + frame_pixel_arr1[i1])

        dict_res1:Dictionary = Dictionary()
        dict_res1["first_cord_ind1"] = first_cord_ind1
        dict_res1["last_min_dist_x1"] = last_min_dist_x1
        dict_res1["last_min_dist_y1"] = last_min_dist_y1

        return dict_res1




    def find_handles_of_glasses1(self):
        from CGlobals1 import CGlobals1
        dict_res1:Dictionary #todo= self.markingfldimg_obj1.find_curves_of_handles1(-1)

        start_ind1:int = dict_res1["second_pxl_cord_ind1"]

        end_ind1:int = dict_res1["start_point1"]

        pixel_line_arr1:ArrayList = dict_res1["pxl_line_arr1"]
        pixel_arr1:ArrayList = dict_res1["pixels_arr1"]

        dict_res2:Dictionary = self.markingfldimg_obj1.find_curves_of_handles1(1)

        start_ind2:int = dict_res2["second_pxl_cord_ind1"]

        end_ind2:int = dict_res2["start_point1"]

        pixel_line_arr2:ArrayList = dict_res2["pxl_line_arr1"]
        pixel_arr2:ArrayList = dict_res2["pixels_arr1"]

        left_pixel_arr1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixel_arr2, min(end_ind1, end_ind2), max(end_ind1, end_ind2))

        handle_pixel_arr1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixel_arr2, start_ind2, start_ind1)

        bmp1:Bitmap = Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")
        bmp2:Bitmap = Bitmap(bmp1.width, bmp1.height, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(left_pixel_arr1, bmp2,(255, 200, 70,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(handle_pixel_arr1, bmp2, (255, 200, 70,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_line_arr1, bmp2, (255, 200, 70,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_line_arr2, bmp2, (255, 200, 70,0))
        bmp2 = CGlobals1.form_obj1.markingfldimg_obj1.paint_recursive3(bmp2, 20, 20, (255, 200, 70,0), (55, 100, 70,0))

        x1:int
        y1:int
        for x1 in range(0 , bmp1.width ):
            for y1 in range(0 , bmp1.height ):
                if not CGlobals1.form_obj1.markingfldimg_obj1.compare_colors1(bmp2.GetPixel( x1, y1), (255, 255, 255,0)):
                    bmp1.SetPixel(x1, y1, (0, 0, 0, 0))

        bmp1 = CGlobals1.form_obj1.markingfldimg_obj1.remove_around_object1(bmp1, (0, 0, 0, 0))
        bmp1 = CGlobals1.form_obj1.markingfldimg_obj1.remove_around_object1(bmp1, (0, 0, 0, 0))
        bmp1.SaveAs(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_handle1.bmp")
        return bmp1



        
    def find_rect_of_pixels_arr(self,pixels_arr1:ArrayList,with_arr_of_inds:str=""):
        from CGlobals1 import CGlobals1 as CGlobals1
        
        min_x1=9999
        mix_x1=9999
        min_y1=9999
        mix_y1=9999
        
        min_x_ind1=9999
        max_x_ind1=9999
        min_y_ind1=9999
        max_y_ind1=9999
    
        for i1 in range(0,pixels_arr1.count):
            
            cord_xy1=CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
            if i1==0:
                min_x1 = cord_xy1[0]
                max_x1 = cord_xy1[0]
                min_y1 = cord_xy1[1]
                max_y1 = cord_xy1[1]
                
                min_x_ind1 = i1
                max_x_ind1 = i1
                min_y_ind1 = i1
                max_y_ind1 = i1
            else:
                if min_x1 > cord_xy1[0]:
                    min_x1 = cord_xy1[0]
                    min_x_ind1 = i1
                
                if max_x1 < cord_xy1[0]:
                    max_x1 = cord_xy1[0]
                    max_x_ind1 = i1
                
                
                if min_y1 > cord_xy1[1]:
                    min_y1 = cord_xy1[1]
                    min_y_ind1 = i1
                
                
                if max_y1 < cord_xy1[1]:
                    max_y1 = cord_xy1[1]
                    max_y_ind1 = i1
               
               
            inds_of_min_x1  =  ArrayList()
            inds_of_max_x1  =  ArrayList()

            inds_of_min_y1  =  ArrayList()
            inds_of_max_y1  =  ArrayList()



        if with_arr_of_inds:
            for i1 in range(pixels_arr1.count):
                cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
                if cord_xy1[0] == min_x1:
                    inds_of_min_x1.Add(i1)

                if cord_xy1[0] == max_x1:
                    inds_of_max_x1.Add(i1)

                if cord_xy1[1] == min_y1:
                    inds_of_min_y1.Add(i1)

                if cord_xy1[1] == max_y1:
                    inds_of_max_y1.Add(i1)






        dict_rect1:Dictionary = Dictionary()
        dict_rect1["min_x1"] = min_x1
        dict_rect1["max_x1"] = max_x1
        dict_rect1["min_y1"] = min_y1
        dict_rect1["max_y1"] = max_y1

        dict_rect1["inds_of_min_x1"] = inds_of_min_x1
        dict_rect1["inds_of_max_x1"] = inds_of_max_x1
        dict_rect1["inds_of_min_y1"] = inds_of_min_y1
        dict_rect1["inds_of_max_y1"] = inds_of_max_y1



        dict_rect1["min_x_ind1"] = min_x_ind1
        dict_rect1["max_x_ind1"] = max_x_ind1
        dict_rect1["min_y_ind1"] = min_y_ind1
        dict_rect1["max_y_ind1"] = max_y_ind1

        return dict_rect1









    def move_pixel_line_above_until_not_overlap_curve1(self,curve_pxls1:ArrayList, pxls_line1:ArrayList):
        from CGlobals1 import CGlobals1
        
        debug_mode1:bool=True
        CGlobals1.global_vars_dict1["loop_overlap1"] += 1
        curve_pxls_dict1:Dictionary = CGlobals1.add_to_dict1(curve_pxls1)

        not_to_stop_move_line1:bool=True
        line_touch_curve_above_arr1:ArrayList = ArrayList()
        dict_res1:Dictionary = Dictionary()
        while to_stop_move_line1:
            
            is_overlap1:bool = CGlobals1.is_pixels_arr_overlap_pixels_dict1(pxls_line1, curve_pxls_dict1)
            dict_xy1:Dictionary = CGlobals1.arr_xy_to_dict2(curve_pxls1)
            for i1 in range( 0 , pxls_line1.count ):
                cord_xy1a = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, i1)
                if dict_xy1.ContainsKey(cord_xy1a[0]):
                    if cord_xy1a[1] >= dict_xy1(cord_xy1a[0]):
                        is_overlap1 = True

            if is_overlap1:
                pxls_line1 = CGlobals1.add_val_to_pxls_arr1(pxls_line1, 0, -1)
            else:
                first_touch_ind1:int = -1
                last_touch_ind1:int = -1
                first_curve_ind1:int = -1
                last_curve_ind1:int = -1
                for i1 in range(0 , pxls_line1.count ):
                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, i1)
                    if curve_pxls_dict1.ContainsKey(str(cord_xy1[0]) + "," + str(cord_xy1[1] + 1)):
                        if first_touch_ind1 == -1:
                            first_touch_ind1 = i1
                            first_curve_ind1 = curve_pxls_dict1(str(cord_xy1[0]) + "," + str(cord_xy1(1) + 1))

                        last_touch_ind1 = i1
                        line_touch_curve_above_arr1.Add(i1)
                        last_curve_ind1 = curve_pxls_dict1(str(cord_xy1[0]) + "," + str((cord_xy1[1] + 1)))

                dict_res1["first_touch_ind1"] = first_touch_ind1
                dict_res1["last_touch_ind1"] = last_touch_ind1
                dict_res1["first_curve_ind1"] = first_curve_ind1
                dict_res1["last_curve_ind1"] = last_curve_ind1
                dict_res1["line_touch_curve_above_arr1"] = line_touch_curve_above_arr1
                dict_res1["pxls_line1"] = pxls_line1
                if debug_mode1:
                    bmp1:Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, (255, 255, 255,0))
                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pxls1, bmp1, (255, 100, 100,0))
                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pxls_line1, bmp1, (55, 200, 100,0))
                    bmp1.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\overlap1_" + str(CGlobals1.global_vars_dict1["loop_overlap1"]) + ".bmp")

                to_stop_move_line1 = 1



        return dict_res1














    def search_for_start_pixels_between_frame_and_handles_above2(self,curve_pxls1:ArrayList):

        from CGlobals1 import CGlobals1
        debug_mode1:bool = True
        start_ind1:int
        curve_pxls_dict1:Dictionary = CGlobals1.add_to_dict1(curve_pxls1)

        not_to_stop1:bool=True
        dict_rect1:Dictionary = find_rect_of_pixels_arr(curve_pxls1)


        center_x1:int = int((dict_rect1["min_x1"] + dict_rect1["max_x1"]) / 2)
        start_x1:int = int(center_x1 + (dict_rect1["max_x1"] - center_x1) * 0.1)
        y1:int = 0
        while not curve_pxls_dict1.ContainsKey(str(start_x1) + "," + str(y1)):
            y1 += 1
        

        start_ind1 = curve_pxls_dict1(str(start_x1) + "," + str(y1))


        bmp1:Bitmap = Bitmap(dict_rect1["max_x1"] + 5, dict_rect1["max_y1"] + 5, (255, 255, 255,0))
        bmp2:Bitmap = Bitmap(dict_rect1["max_x1"] + 5, dict_rect1["max_y1"] + 5, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pxls1, bmp1, (255, 50, 100,0))
        ind3:int = 0

        ind3 += 1
        
        dict_res1:Dictionary = self.markingfldimg_obj1.find_max_line_len_on_curve1(curve_pxls1, start_ind1, start_ind1 + 1, 1)
        end_ind1 = dict_res1["end_ind1"]

        cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls1, start_ind1)
        cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls1, end_ind1)

        m1:float = (cord_xy2[1] - cord_xy1[1]) / (cord_xy2[0] - cord_xy1[0])

        add_x1:int = dict_rect1["max_x1"] - cord_xy2[0]
        cord_xy3=ArrayList()
        cord_xy3.Add(cord_xy2[0] + add_x1)
        cord_xy3.Add(cord_xy2[1] + add_x1 * m1)
        pxls_line1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points2(cord_xy2, cord_xy3)




        m1_arr1:ArrayList = ArrayList()
        CGlobals1.global_vars_dict1["loop_overlap1"] = 0

        last_last_x1:int = -1

        add_m1:float = 0.01
        max_len1:float = -1
        max_len_m1:float = -1

        max_x1:float = -1
        delta_max_x_arr1:Dictionary = Dictionary()
        max_delta_max_x1:float = -1
        max_delta_max_x1_m1:float = -1
        res_arr1:ArrayList = ArrayList()
        max_delta_max_x1_is_first_to_last1:str = ""
        max_len1_arr1:ArrayList = ArrayList()
        ok_m1:float = -1
        max_m1_to_search1:float = 0.1
        while not_to_stop1:
            m1 += add_m1
            cord_xy3[0] = cord_xy2[0] + add_x1
            cord_xy3[1] = cord_xy2[1] + add_x1 * m1
            pxls_line1 = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points2(cord_xy2, cord_xy3)
            dict_res2:Dictionary = self.move_pixel_line_above_until_not_overlap_curve1(curve_pxls1, pxls_line1)

            line_touch_curve_above_arr1:ArrayList = dict_res2["line_touch_curve_above_arr1"]
            pxls_line1 = dict_res2["pxls_line1"]

            last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, line_touch_curve_above_arr1[line_touch_curve_above_arr1.count - 1])
            last_cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, dict_res2["last_touch_ind1"])
            first_cord_xy2  = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, dict_res2["first_touch_ind1"])
            len1:float = abs(last_cord_xy2[0] - first_cord_xy2[0])
            if first_cord_xy2[0] > max_x1 and max_x1 != -1:
                cur_len1:float = abs(max_x1 - first_cord_xy2[0])
                if max_len1 == -1:
                    max_len1 = cur_len1
                    max_len_m1 = m1
                else:
                    if max_len1 < cur_len1:
                        max_len1 = cur_len1

                max_len1_arr1.Add(str(cur_len1) + "," + str(first_cord_xy2[0]) + "," + str(max_x1))

            max_len1_arr1.Add(len1)
            if max_x1 < last_cord_xy2[0]:
                if max_x1 != -1:
                    delta_max_x_arr1[m1] = last_cord_xy2[0] - max_x1
                    if max_delta_max_x1 < (last_cord_xy2[0] - max_x1):
                        max_delta_max_x1 = (last_cord_xy2[0] - max_x1)
                        max_delta_max_x1_m1 = m1
                        dict_res2["max_delta_max_x1_m1"] = max_delta_max_x1_m1

                max_x1 = last_cord_xy2[0]

            dict_res2["m1"] = m1
            res_arr1.Add(dict_res2)

            last_last_x1 = last_cord_xy2[0]
            if m1 >= max_m1_to_search1:

                max_delta_max_x1_m1_ind1:int = -1
                for i2 in range(0 , res_arr1.count - 1):
                    dict_res3:Dictionary = res_arr1[i2]
                    if dict_res3.ContainsKey("max_delta_max_x1_m1"):
                        max_delta_max_x1_m1_ind1 = i2

                last_touch_ind1_last1:int = res_arr1[max_delta_max_x1_m1_ind1]["last_touch_ind1"]
                first_touch_ind1_last1:int = res_arr1[max_delta_max_x1_m1_ind1]["first_touch_ind1"]

                last_touch_ind1_before1:int= res_arr1[max_delta_max_x1_m1_ind1 - 1]["last_touch_ind1"]
                first_touch_ind1_after1:int = res_arr1[max_delta_max_x1_m1_ind1 + 1]["first_touch_ind1"]

                if first_touch_ind1_last1 <= last_touch_ind1_before1 and last_touch_ind1_last1 >= first_touch_ind1_after1:
                    not_to_stop1 = False
                    ok_m1 = m1
                    pxls_line1_res:ArrayList = res_arr1[max_delta_max_x1_m1_ind1]["pxls_line1"]
                    bmp1a:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pxls_line1_res, bmp1a, (55, 200, 100,0))


                    first_curve_ind1:int = res_arr1[max_delta_max_x1_m1_ind1]["first_curve_ind1"]
                    last_curve_ind1:int = res_arr1[max_delta_max_x1_m1_ind1]["last_curve_ind1"]

                    sub_curve1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls1, first_curve_ind1, last_curve_ind1)
                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(sub_curve1, bmp1a, (255, 100, 100,0))
                    bmp1a.SaveAs(CGlobals1.global_path1 + "sobel_pics1\overlap1_1res.bmp")

                    
                    max_dist1:float = -1
                    max_dist1_ind1:int = -1
                    for i3 in range( 0 , sub_curve1.count):
                        dict_res3:Dictionary = self.markingfldimg_obj1.check_min_dist_to_curve1(pxls_line1_res, CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, i3), 150)


                        if max_dist1 <= dict_res3["min_dist1"] and dict_res3["min_dist_ind1"] != -1:
                            max_dist1 = dict_res3["min_dist1"]
                            max_dist1_ind1 = i3


                    CGlobals1.draw_sqr_around_pixels2(bmp1a, CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, max_dist1_ind1)(0), CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, max_dist1_ind1)[1], 3, (255, 50, 120,0))
                    bmp1a.SaveAsave(CGlobals1.global_path1 + "sobel_pics1\overlap1_1res2.bmp")

                    dict_return_res1:Dictionary = Dictionary()
                    dict_return_res1["cord_xy_res1"] = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, max_dist1_ind1)
                    dict_return_res1["ind_in_pixels1"] = curve_pxls_dict1[sub_curve1[max_dist1_ind1]]

                    return dict_return_res1



                m1 = max_delta_max_x1_m1 - add_m1 * 2
                max_m1_to_search1 = res_arr1[max_delta_max_x1_m1_ind1 + 1]["m1"] + add_m1
                max_delta_max_x1_m1 = -1
                max_delta_max_x1 = -1
                max_x1 = -1
                add_m1 /= 2
                res_arr1=ArrayList()


        while not_to_stop1:

            m1_arr1.Add(m1)
            add_x1 = dict_rect1["max_x1"] - cord_xy2[0]

            cord_xy3[0] = cord_xy2[0] + add_x1
            cord_xy3[1] = cord_xy2[1] + add_x1 * m1
            pxls_line1 = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points2(cord_xy3, cord_xy2)
            pxl_ind1:int = 0
            last_ind_sub_curve2:int = -1
            while not curve_pxls_dict1.ContainsKey(pxls_line1[pxl_ind1]):
                pxl_ind1 += 1

            last_ind_sub_curve2 = curve_pxls_dict1[pxls_line1[pxl_ind1]]
            x1:int = int(str(pxls_line1[pxl_ind1 - 1]).Split(",")[0])
            max_x_ind1:int = dict_rect1["max_x_ind1"]
            sub_curve1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls1, start_ind1, max_x_ind1)

            pxl_ind2:int = pxls_line1.count - 1


            dict_res2:Dictionary = self.markingfldimg_obj1.check_min_dist_to_curve1(sub_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, pxl_ind2), 5)
            while dict_res2["min_dist1"] <= 2:
                dict_res2 = self.markingfldimg_obj1.check_min_dist_to_curve1(sub_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, pxl_ind2), 5)
                pxl_ind2 -= 1


            cord_xy4 = CGlobals1.get_cord_xy_in_pixels_arr1(pxls_line1, pxl_ind2)

            
            if not (cord_xy1[0] <= x1 and x1 <= cord_xy4[0]):
                sub_curve2:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls1, end_ind1, last_ind_sub_curve2)

                if debug_mode1:

                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(sub_curve2, bmp2, (255, 50, 100,0))
                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pxls_line1, bmp2, (55, 150, 100,0))

                    bmp2.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\check_" + str(ind3) + ".bmp")

                max_dist1:float = -1
                max_dist_ind1:float = -1
                for i2 in range( 0 , sub_curve2.count):
                    dict_res2 = self.markingfldimg_obj1.check_min_dist_to_curve1(pxls_line1, CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve2, i2), 145)
                    if max_dist1 <= dict_res2["min_dist1"] and dict_res2["min_dist_ind1"] != -1:
                        max_dist1 = dict_res2["min_dist1"]
                        max_dist_ind1 = i2

                cord_xy_res1 = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve2, max_dist_ind1)
                dict_res_cord1:Dictionary = Dictionary()
                dict_res_cord1["cord_xy_res1"] = cord_xy_res1
                dict_res_cord1["max_dist_ind1"] = max_dist_ind1
                dict_res_cord1["ind_in_pixels1"] = curve_pxls_dict1(str(cord_xy_res1[0]) + "," + str(cord_xy_res1[1]))
                return dict_res_cord1
                not_to_stop1 = False

            if not not_to_stop1:
                CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy_res1[0], cord_xy_res1[1], 4, (100, 30, 200,0))

            if debug_mode1:

                CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pxls_line1, bmp1, (20, 250, 100,0))
                bmp1.SaveAse(CGlobals1.global_path1 + "sobel_pics1\\" + str(ind3) + ".bmp")

            if (start_ind1 + 2) >= end_ind1:
                not_to_stop1 = False

            start_ind1 += 1







