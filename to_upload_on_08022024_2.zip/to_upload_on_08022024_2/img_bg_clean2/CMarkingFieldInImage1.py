
from ArrayList import ArrayList
from vec_3d1 import vec_3d1
from point_3d1 import point_3d1
from bitmap import Bitmap
from Dictionary import Dictionary

from StringBuilder import StringBuilder
from CFile1 import CFile1
from CMarkingFieldInImageUtils1 import CMarkingFieldInImageUtils1
import math,os
import pickle
from CConfig1 import CConfig1
class CMarkingFieldInImage1:
    
    
    dir_arr1 = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]]
    dir_arr1_rev  = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]]
    dir_arr2  = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]]

    
    def __init__(self):
        
        self.d1=1
        self.bmp1=Bitmap()
        self.bmp_current_sobel= Bitmap()
        
        self.color_of_sobel=(255,255,255,0)
        self.color_of_region=(255, 120, 100,0)
        self.color_of_bg=(0, 0, 0,0)
        self.x_start2=0
        self.y_start2=0



    def set_double_pixel_arr_on_bmp2(self,pixels_arr1:ArrayList,bmp1:Bitmap, color_to_set1):
        

        for i1 in range( 0 , pixels_arr1.count):
            try:
                x1:int = float(str(pixels_arr1[i1]).split(",")[0])
                y1:int = float(str(pixels_arr1[i1]).split(",")[1])
                if x1 >= 0 and x1 < bmp1.width and y1 >= 0 and y1 < bmp1.height:
                    bmp1.SetPixel(x1, y1, color_to_set1)


            except:
                err1:int=1






    def set_3d_arr_pixels_on_bmp1_prespective(self,pixels_3d_cords_arr:ArrayList, bmp1:Bitmap, color1):

        vec_3d_obj1:vec_3d1 = vec_3d1()
        vec_3d_obj1.p1.z1 = -5000
        vec_3d_obj1.p1.x1 = bmp1.width / 2
        vec_3d_obj1.p1.y1 = bmp1.height / 2




        for i1 in range(0 , pixels_3d_cords_arr.count):
            point_3d_obj1:point_3d1 = pixels_3d_cords_arr[i1]
            try:
                vec_3d_obj1.p2.x1 = point_3d_obj1.x1
                vec_3d_obj1.p2.y1 = point_3d_obj1.y1
                vec_3d_obj1.p2.z1 = point_3d_obj1.z1

                x_dir1:float = vec_3d_obj1.p2.x1 - vec_3d_obj1.p1.x1
                y_dir1:float = vec_3d_obj1.p2.y1 - vec_3d_obj1.p1.y1
                z_dir1:float = vec_3d_obj1.p2.z1 - vec_3d_obj1.p1.z1
                z_plane1:float = -2000

                a1:float = (z_plane1 - vec_3d_obj1.p2.z1) / z_dir1
                x_val1:float = vec_3d_obj1.p2.x1 + a1 * x_dir1
                y_val1:float = vec_3d_obj1.p2.y1 + a1 * y_dir1

                bmp1.SetPixel(x_val1, y_val1, color1)

            except:
                err1:int=1




    def rotate_3d_points_arr2(self,pixels_3d_cords_arr:ArrayList, arbitrary_3d_axis:vec_3d1, rot_angle1:float):
        


        for i1 in range(0 , pixels_3d_cords_arr.count ):
            point_3d_obj1:point_3d1 = pixels_3d_cords_arr[i1]
            CMarkingFieldInImageUtils1.rotate_around_arbitrary_axis(arbitrary_3d_axis, point_3d_obj1, rot_angle1)
            





    def find_curves_of_handles1(self,dir1:int):
        from CGlobals1 import CGlobals1
        CGlobals1.global_suffix_file_name1 = ""
        sobel_ind1:int=-1

        path_sign_sobel_ind1:str = CGlobals1.global_path1 + self.form_obj1.file_name1 + "_sign_sobel_ind1.txt"
        sobel_ind1 = int(CFile1.read_all_file_text(path_sign_sobel_ind1))

        path_of_bmp1:str = CGlobals1.global_path1 + self.form_obj1.file_name1 + "_sobel_cache1\\" + str(sobel_ind1) + ".bmp"
        bmp1:Bitmap = Bitmap(path_of_bmp1)

        pixels_arr1:ArrayList = self.load_2d_pixels_arr1(CGlobals1.global_path1 + self.form_obj1.file_name1 + "_2d_pixels_sobel_" + str(sobel_ind1) + ".txt")
        dict_pixels1:Dictionary = CGlobals1.add_to_dict1(pixels_arr1)

        last_secod_cords1:ArrayList = ArrayList()
        last_secod_cords2:ArrayList = ArrayList()

        dict_second_cord1:Dictionary = Dictionary()
        i1:int

        dict_pixel_arr1:Dictionary = Dictionary()
        dict_pixel_arr1 = CGlobals1.add_to_dict1(pixels_arr1)

        ver_pixels_arr1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points(bmp1.width / 2 + CConfigs1.find_curves_of_handles1_add_width, 0, bmp1.width / 2 + CConfig1.find_curves_of_handles1_add_width, bmp1.hHeight - 1)


        not_to_stop1:bool=True

        dict_center_curve_pixels1:Dictionary = Dictionary()


        start_secord_pxl_cord_ind1:int=-1

        first_pxl_cord1:str=""
        second_pxl_cord1:str=""
        first_pxl_cord_ind1:int=0
        second_pxl_cord_ind1:int=0
        
        
        for i1 in range(ver_pixels_arr1.count - 1 , 1,  -1):
            if dict_pixel_arr1.ContainsKey(ver_pixels_arr1[i1]):
                
                if first_pxl_cord1 == "":
                    first_pxl_cord1 = ver_pixels_arr1[i1]
                    first_pxl_cord_ind1 = dict_pixel_arr1[ver_pixels_arr1[i1]]
                else:
                    if second_pxl_cord1 == "":
                        second_pxl_cord1 = ver_pixels_arr1[i1]
                        second_pxl_cord_ind1 = dict_pixel_arr1[ver_pixels_arr1[i1]]


        start_secord_pxl_cord_ind1 = second_pxl_cord_ind1
        last_x1a:int=-1
        last_y1a:int=-1
        cord_dir1:int = 1
        x1a:int = int((int(first_pxl_cord1.split(",")[0]) + int(second_pxl_cord1.split(",")[0])) / 2)
        y1a:int = int((int(first_pxl_cord1.split(",")[1]) + int(second_pxl_cord1.split(",")[1])) / 2)

        CGlobals1.draw_sqr_around_pixels2(bmp1, x1a, y1a, 8, (200, 150, 100,0))
        cord_dir1 = dir1
        if cord_dir1 == -1:
            x1a = int((int(second_pxl_cord1.split(",")[0]) + int(first_pxl_cord1.split(",")[0])) / 2)
            y1a = int((int(second_pxl_cord1.split(",")[1]) + int(first_pxl_cord1.split(",")[1])) / 2)
            temp1:int = first_pxl_cord_ind1
            first_pxl_cord_ind1 = second_pxl_cord_ind1
            second_pxl_cord_ind1 = temp1

        first_pxl_cord_ind1_arr:ArrayList = ArrayList()

        b1:int = 0
        count_sign_pxls1:int=0
        count_last_cord_equals1:int=0
        max_cord_ind1:int=-1
        count_not_over_max_cord1:int=0
        while not_to_stop1:

            min_first_pxl_cord_ind1:int=-1
            min_second_pxl_cord_ind1:int=-1

            x1b:int
            y1b:int

            min_x1b:int=-1
            min_y1b:int=-1

            min_dist1:float = 999

            min_dist1_ind1:int=-1
            for i1 in range( second_pxl_cord_ind1 - 20 , second_pxl_cord_ind1 + 20+1):
                cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, first_pxl_cord_ind1)
                cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
                dist1:float = math.pow(math.pow(cord_xy1[0] - cord_xy2[0], 2) + math.pow(cord_xy1[1] - cord_xy2[1], 2), 0.5)
                if min_dist1 > dist1:
                    min_dist1 = dist1
                    min_dist1_ind1 = i1

            second_pxl_cord_ind1 = min_dist1_ind1

            if cord_dir1 == 1:
                if max_cord_ind1 == -1:
                    max_cord_ind1 = second_pxl_cord_ind1
                else:
                    if max_cord_ind1 > second_pxl_cord_ind1:
                        max_cord_ind1 = second_pxl_cord_ind1
                        count_not_over_max_cord1 = 0

                    else:
                        count_not_over_max_cord1 += 1
            else:
                if max_cord_ind1 == -1:
                    max_cord_ind1 = second_pxl_cord_ind1
                else:
                    if max_cord_ind1 < second_pxl_cord_ind1:
                        max_cord_ind1 = second_pxl_cord_ind1
                        count_not_over_max_cord1 = 0
                    else:
                        count_not_over_max_cord1 += 1

            if count_not_over_max_cord1 > CConfig1.max_count_not_over_max_cord1:
                not_to_stop1 =False

            delta_search_second_cord1:int = 40
            if first_pxl_cord_ind1 >= second_pxl_cord_ind1 - delta_search_second_cord1 and first_pxl_cord_ind1 <= second_pxl_cord_ind1 + delta_search_second_cord1:
                not_to_stop1 = False


            cord_xy1b = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, first_pxl_cord_ind1)
            cord_xy2b  = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, min_dist1_ind1)

            x_center1:int = int((cord_xy1b[0] + cord_xy2b[0]) / 2)
            y_center1:int = int((cord_xy1b(1) + cord_xy2b(1)) / 2)


            first_pxl_cord_ind1 += cord_dir1
            CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy1b[0], cord_xy1b[1], 3, (200, 50, 100,0))
            CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy2b[0], cord_xy2b[1], 3, (1, 50, 100,0))


            last_secod_cords2.Add(str(cord_xy1b[0]) + "," + str(cord_xy1b[1]))

            if cord_dir1 == 1:

                last_secod_cords1.Add(str(cord_xy2b[0]) + "," + str(cord_xy2b[1]))
            else:
                last_secod_cords1.Add(str(cord_xy1b[0]) + "," + str(cord_xy1b[1]))


            if count_sign_pxls1 >= 50:

                all_last_cords_equal1:bool=True
                last_secod_cords1_ind1:int
                for last_secod_cords1_ind1 in range(CConfig1.max_last_cords1 , 1,-1):
                    if not dict_second_cord1.ContainsKey(last_secod_cords1[last_secod_cords1_ind1]):
                        all_last_cords_equal1 = False

                if all_last_cords_equal1:
                    count_last_cord_equals1 += 1



            if cord_dir1 == 1:
                dict_second_cord1[str(cord_xy2b[0]) + "," + str(cord_xy2b[1])] = 1
            else:

                dict_second_cord1[str(cord_xy1b[0]) + "," + str(cord_xy1b[1])] = 1


            while last_secod_cords1.count > CConfig1.max_last_cords1 + 1:
                last_secod_cords1.RemoveAt(0)


            bmp1.SetPixel(x_center1, y_center1, (255, 30, 30,0))
            count_sign_pxls1 += 1
            if count_sign_pxls1 > CConfig1.max_count_sign_pxls2:
                not_to_stop1 = False

        sec_cord_xy1a = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, second_pxl_cord_ind1)

        CGlobals1.draw_sqr_around_pixels2(bmp1, sec_cord_xy1a[0], sec_cord_xy1a[1], 4, (200, 80, 90,0))
        dict_res1:Dictionary = Dictionary()

        dict_res1["second_pxl_cord_ind1"] = second_pxl_cord_ind1
        if start_secord_pxl_cord_ind1 < second_pxl_cord_ind1:
            sec_cord_xy1b = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, second_pxl_cord_ind1 - 50)

            CGlobals1.draw_sqr_around_pixels2(bmp1, sec_cord_xy1b(0), sec_cord_xy1b(1), 4, (20, 200, 90,0))
            m1 = (sec_cord_xy1a[1] - sec_cord_xy1b[1]) / (sec_cord_xy1a[0] - sec_cord_xy1b[0])
            add_x1:int = 2000
            new_y1:int = sec_cord_xy1a[1] - abs(m1) * add_x1
            new_x1:int = sec_cord_xy1a[0] - add_x1


            pxl_line_arr1:ArrayList =CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points(sec_cord_xy1a[0], sec_cord_xy1a[1], new_x1, new_y1)
            i4:int
            pixel_cut_ind1:int = -1
            for i4 in range(pxl_line_arr1.count - 1 , 0+1, -1):
                if dict_pixels1.ContainsKey(pxl_line_arr1[i4]):
                    if pixel_cut_ind1 == -1:
                        pixel_cut_ind1 = i4


            dict_res1["start_point1"] = dict_pixels1[pxl_line_arr1[pixel_cut_ind1]]
            while pxl_line_arr1.count > pixel_cut_ind1:
                pxl_line_arr1.RemoveAt(pxl_line_arr1.count - 1)

            dict_res1["pxl_line_arr1"] = pxl_line_arr1
            for i4 in range(0 , pxl_line_arr1.count ):
                cord_xy5 = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, i4)
                CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy5[0], cord_xy5[1], 3, (230, 50, 100,0))


            CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pxl_line_arr1, bmp1, (200, 70, 80,0))


        else:
            sec_cord_xy1b = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, second_pxl_cord_ind1 + 50)

            CGlobals1.draw_sqr_around_pixels2(bmp1, sec_cord_xy1b[0], sec_cord_xy1b[1], 4, (20, 200, 90,0))
            m1:float= (sec_cord_xy1a[1] - sec_cord_xy1b[1]) / (sec_cord_xy1a[0] - sec_cord_xy1b[0])
            add_x1:int = 2000
            new_y1:int =int( sec_cord_xy1a[1] - abs(m1) * add_x1)
            new_x1:int =int( sec_cord_xy1a[0] - add_x1)


            pxl_line_arr1:ArrayList =CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points(sec_cord_xy1a[0], sec_cord_xy1a[1], new_x1, new_y1)
            i4:int
            pixel_cut_ind1:int-1
            for i4 in range(pxl_line_arr1.count - 1 ,1, -1):
                if dict_pixels1.ContainsKey(pxl_line_arr1[i4]):
                    if pixel_cut_ind1 == -1:
                        pixel_cut_ind1 = i4

            dict_res1["start_point1"] = dict_pixels1[pxl_line_arr1[pixel_cut_ind1]]

            while pxl_line_arr1.count > pixel_cut_ind1:
                pxl_line_arr1.RemoveAt(pxl_line_arr1.count - 1)

            dict_res1["pxl_line_arr1"] = pxl_line_arr1
            for i4 in range(0 , pxl_line_arr1.count ):
                cord_xy5 = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, i4)
                CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy5[0], cord_xy5[1], 3,(230, 50, 100,0))


            CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pxl_line_arr1, bmp1, (200, 70, 80,0))

        dict_res1["pixels_arr1"] = pixels_arr1

        return dict_res1














    def paint_recursive3(self,in_bmp1:Bitmap, start_x1:int, start_y1:int, color_of_region, color_to_set):
        from CGlobals1 import CGlobals1
        copy_bmp1:Bitmap = in_bmp1.clone()
        not_to_stop1:bool=True

        xa:int
        ya:int
        stack_arr1:ArrayList =  ArrayList()
        count_set_pixels1:int=0
        loop_c1:int=0
        last_str_cord1:str=""
        while not_to_stop1:
            if stack_arr1.count > 0:
                cord_xy1b = stack_arr1[stack_arr1.Count - 1]
                start_x1 = cord_xy1b[0]
                start_y1 = cord_xy1b[1]

            was_pixels_around1:bool=False
            if not self.compare_colors1(copy_bmp1.GetPixel( start_x1, start_y1), color_of_region) and not self.compare_colors1(copy_bmp1.GetPixel( start_x1, start_y1), color_to_set):
                stack_arr1.Add((start_x1, start_y1))
                copy_bmp1.SetPixel(start_x1, start_y1, color_to_set)
                count_set_pixels1 += 1
                was_set_last_str_cord:bool=False
                
                for i1 in range(0 , 3+1):
                    dir_x1:int = CGlobals1.dir_arr3[i1][ 0]
                    dir_y1:int = CGlobals1.dir_arr3[i1][ 1]
                    new_x1:int = start_x1 + CGlobals1.dir_arr3[i1][ 0]
                    new_y1:int = start_y1 + CGlobals1.dir_arr3[i1][ 1]
                    if new_x1 >= 0 and new_y1 >= 0 and new_x1 <= copy_bmp1.width - 1 and new_y1 <= copy_bmp1.height - 1:
                        if not self.compare_colors1(copy_bmp1.GetPixel( new_x1, new_y1), color_of_region) and not self.compare_colors1(copy_bmp1.GetPixel( new_x1, new_y1), color_to_set):

                            if not was_set_last_str_cord :
                                last_str_cord1 = str(new_x1) + "," + str(new_y1)
                                was_set_last_str_cord =True

                            stack_arr1.Add((new_x1, new_y1))

                            was_pixels_around1 = True
                            count_set_pixels1 += 1

            if not was_pixels_around1:
                if stack_arr1.Count > 0:
                    stack_arr1.RemoveAt(stack_arr1.count - 1)

                last_str_cord1 = ""
            if stack_arr1.count <= 0:
                not_to_stop1 = False



        return copy_bmp1












    def find_curve_nearset_to_cord_xy1(self,curves_arr1:ArrayList, cord_xy1):
        from CGlobals1 import CGlobals1
        
        min_dist_curve1:float = 9999
        min_dist_curve_ind1:float = -1
        for curve_ind1 in range(0 , curves_arr1.count):
            
            min_dist1:float = 9999
            curve1:ArrayList = curves_arr1(curve_ind1)
            for pixel_ind1 in range(0 , curve1.count ):
                dist1:float = CMarkingFieldInImageUtils1.get_dist_between_2_cords_xy1(CGlobals1.get_cord_xy_in_pixels_arr1(curve1, pixel_ind1), cord_xy1)
                if min_dist1 > dist1:
                    min_dist1 = dist1

            if min_dist_curve1 > min_dist1:
                min_dist_curve1 = min_dist1
                min_dist_curve_ind1 = curve_ind1

        return min_dist_curve_ind1





    def find_max_tangent_len_on_curve1(self,curve_pixels1:ArrayList):
        from CGlobals1 import CGlobals1
        
        if curve_pixels1.count <= 2:
            return curve_pixels1

        start_ind1:int = 0
        end_ind1:int = curve_pixels1.count - 1
        cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels1, start_ind1)
        angle1:float = 90
        line_len1:int = 1500
        not_to_stop1:bool=True

        debug_mode1:bool=False

        ind1:int = 0
        while not_to_stop1:

            sin1:float = math.sin(angle1 * math.pi / 180)
            cos1:float= math.cos(angle1 * math.pi / 180)
            cord_xy2:ArrayList=ArrayList()
            
            cord_xy2.Add(cord_xy1[0] + line_len1 * sin1)
            cord_xy2.Add( cord_xy1[1] + line_len1 * cos1)

            pxl_line_arr1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points2(cord_xy1, cord_xy2)
            if debug_mode1:
                bmp3= Bitmap(2500, 1300, (255, 255, 255,0))
                CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pxl_line_arr1, bmp3, (200, 50, 100,0))
                CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pixels1, bmp3, (20, 250, 100,0))
                bmp3.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\s_angle_" + str(ind1) + ".bmp")

            ind1 += 1
            pxl_line_dict1:Dictionary = CGlobals1.add_to_dict1(pxl_line_arr1)

            new_sub_curve1:ArrayList = CGlobals1.add_val_to_pxls_arr1(curve_pixels1, 0, 0)


            not_on_line1:bool=True
            i2:int=0
            last_ok_i2:int=-1
            max_ovarlap_pixels1:int=-1

            new_pxl_line_arr1:ArrayList = pxl_line_arr1.Clone()
            max_overlap_curve1:ArrayList=None
            max_overlap_new_pxl_line1ArrayList=None

            while not_on_line1 and i2 < 15:
                if not_on_line1:
                    not_on_line1 = False
                    add_x1:int = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, i2 + 1)[0] - CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, 0)[0]
                    add_y1:int = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, i2 + 1)[1] - CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, 0)[1]
                    new_sub_curve1 = CGlobals1.add_val_to_pxls_arr1(curve_pixels1, add_x1, add_y1)



                    new_pxl_line_dict1:Dictionary = CGlobals1.add_to_dict1(new_pxl_line_arr1)


                    start_ind_on_line1:int = new_pxl_line_dict1[new_sub_curve1[0]]

                    overlap_ind1:int=0
                    not_to_stop4:bool=True
                    while not_to_stop4:
                        if new_sub_curve1[overlap_ind1] == new_pxl_line_arr1[start_ind_on_line1 + overlap_ind1]:
                            overlap_ind1 += 1
                        else:
                            not_to_stop4 = False

                        if overlap_ind1 > new_sub_curve1.count - 1:
                            not_to_stop4 = False  


                    if max_ovarlap_pixels1 < overlap_ind1:
                        max_ovarlap_pixels1 = overlap_ind1
                        last_ok_i2 = i2

                    not_to_stop3:bool=True
                    i1 = start_ind1
                    last_index_on_line1:int=-1


                i2 += 1

            if max_ovarlap_pixels1 >= 5 or max_ovarlap_pixels1 >= curve_pixels1.count - 1:

                bmp2:Bitmap = Bitmap(2500, 1300, (255, 255, 255,0))

                if debug_mode1:
                    bmp2a:Bitmap = Bitmap(2500, 1300, (255, 255, 255,0))

                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pxl_line_arr1, bmp2a, (200, 50, 100,0))
                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(new_sub_curve1, bmp2a, (20, 250, 100,0))

                    bmp2a.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\b_angle_" + str(ind1) + ".bmp")


                vec_3d_obj1:vec_3d1 = vec_3d1()
                vec_3d_obj1.p1 = point_3d1(cord_xy1[0], cord_xy1[1], 0)
                vec_3d_obj1.p2 = point_3d1(cord_xy1[0], cord_xy1[1], 10)

                pxl_line_arr1_r1:ArrayList=CMarkingFieldInImageUtils1.rotate_2d_pixels_arr(pxl_line_arr1, vec_3d_obj1, angle1)
                new_sub_curve1_r1:ArrayList=CMarkingFieldInImageUtils1.rotate_2d_pixels_arr(new_sub_curve1, vec_3d_obj1, angle1)
                if debug_mode1:


                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pxl_line_arr1_r1, bmp2, (200, 50, 100,0))
                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(new_sub_curve1_r1, bmp2, (20, 250, 100,0))

                    bmp2.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\n_angle_" + str(ind1) + ".bmp")
                    ind1 += 1

                cord_xy5 = CGlobals1.get_cord_xy_in_pixels_arr1(new_sub_curve1_r1, 0)
                ok_start_ind_curve1:bool=False

                for i2 in range(0 , new_sub_curve1_r1.count):
                    cord_xy4 = CGlobals1.get_cord_xy_in_pixels_arr1(new_sub_curve1_r1, i2)
                    if cord_xy4[0] > cord_xy5[0]:
                        ok_start_ind_curve1 = False
                    
                if not ok_start_ind_curve1:
                    not_to_stop1 = True
                    curve_pixels1.RemoveAt(0)

                    start_ind1 = 0
                    end_ind1 = curve_pixels1.Count - 1
                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels1, start_ind1)
                    angle1 = 90
                else:
                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pixels1, bmp2, (200, 50, 100,0))
                    bmp2.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\angle_" + str(ind1) + ".bmp")


                    not_to_stop1 = False

            else:
                angle1 -= 0.5
                if angle1 == 0:
                    angle1 = 90
                    curve_pixels1.RemoveAt(0)

                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels1, start_ind1)

        return curve_pixels1
        


    def only_complete_missing_pixels_in_curve1(self,curve1:ArrayList):
        from CGlobals1 import CGlobals1
        
        if curve1.count <= 2:
            return curve1

        new_curve1:ArrayList = ArrayList()

        last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        new_curve1.Add(str(last_cord_xy1[0]) + "," + str(last_cord_xy1[1]))
        for i1 in range(1 , curve1.count ):
            new_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)

            coennct_to_new_cord1:bool=False   
            for x1 in range(last_cord_xy1[0] - 1 , last_cord_xy1(0) + 1+1):
                for y1 in range( last_cord_xy1[1] - 1 , last_cord_xy1(1) + 1+1):
                    if x1 == new_cord_xy1[0] and y1 == new_cord_xy1[1]:
                        coennct_to_new_cord1 =True

            if not coennct_to_new_cord1:
                pxl_line1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points2(last_cord_xy1, new_cord_xy1)
                
                for i2 in range( 1 , pxl_line1.Count - 2+1):
                    new_curve1.Add(pxl_line1[i2])

                new_curve1.Add(str(new_cord_xy1[0]) + "," + str(new_cord_xy1[1]))
                last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)

        return new_curve1




    def filter_curve_by_top_line1(self,curve_pixels_arr1:ArrayList, top_line1:ArrayList):
        from CGlobals1 import CGlobals1
        top_line_dict1:Dictionary = CGlobals1.arr_xy_to_dict2(top_line1)

        new_curve_pixels_arr1:ArrayList = ArrayList()
        start_cord_top_line1 = CGlobals1.get_cord_xy_in_pixels_arr1(top_line1, 0)
        
        for i1 in range( 0 , curve_pixels_arr1.count ):
            cord_xy1  = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)
            if start_cord_top_line1[0] <= cord_xy1[0]:

                if top_line_dict1[cord_xy1[0]] <= cord_xy1[1]:
                    new_curve_pixels_arr1.Add(curve_pixels_arr1[i1])

        return new_curve_pixels_arr1



    def get_curve_from_pixels_arr_by_region(self,pixels_arr1:ArrayList, x1:int, y1:int, w1:int, h1:int):
        from CGlobals1 import CGlobals1
        max_len_to_search1:int = 53000
        i1:int = 0
        not_to_stop1:bool=True
        curves_arrs1:ArrayList = ArrayList()
        current_curve1:ArrayList = ArrayList()
        cord_xy_status1:str = ""

        if pixels_arr1.Count <= 0:
            return curves_arrs1

        while not_to_stop1:

            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
            if cord_xy1[0] >= x1 and cord_xy1[1] >= y1 and cord_xy1[0] <= (x1 + w1 - 1) and cord_xy1[1] <= (y1 + h1 - 1):
                if cord_xy_status1 == "":
                    cord_xy_status1 = "start"
                
                if cord_xy_status1 == "start":
                    current_curve1.Add(pixels_arr1[i1])
            else:
                if cord_xy_status1 == "start":
                    cord_xy_status1 = ""
                    curves_arrs1.Add(current_curve1)
                    current_curve1 = ArrayList()

            i1 += 1
            if i1 >= pixels_arr1.count or i1 >= max_len_to_search1:

                if cord_xy_status1 == "start":
                    cord_xy_status1 = ""
                    curves_arrs1.Add(current_curve1)
                    current_curve1 = ArrayList()


                not_to_stop1 = False


        return curves_arrs1







    def filter_curve_by_curvature3(self,curve_pixels_arr1:ArrayList, line_cord_xy1, top_line1:ArrayList, false_positive_cords_arr1:ArrayList, dict_pixels1:Dictionary):
        from CGlobals1 import CGlobals1
        CGlobals1.global_vars_dict1["cuvature3_loop1"] += 1



        for i1 in range(0 , false_positive_cords_arr1.count ):
            curve_pixels_arr1.Remove(false_positive_cords_arr1[i1])

        top_line1_start_ok_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(top_line1, 0)


        dict_curve1:Dictionary = CGlobals1.add_to_dict1(curve_pixels_arr1)

        x1:int = top_line1_start_ok_cord1[0]
        y1:int = top_line1_start_ok_cord1[1]

        while not dict_curve1.ContainsKey(str(x1) + "," + str(y1)):
            y1 += 1

        ind2:int=0
        rect_dict2:Dictionary = self.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pixels_arr1)
        while CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, ind2)[0] <= rect_dict2["max_x1"] - 1:
            ind2 += 1

        ind1:int = dict_curve1[str(x1) + "," + str(y1)]
        curve_pixels_arr1 = CGlobals1.get_arr_from_ind_to_ind1(curve_pixels_arr1, ind1, ind2)

        top_line_dict1:Dictionary = Dictionary()

        curve_pixels_arr1 = self.filter_curve_by_top_line1(curve_pixels_arr1, top_line1)



        bmp1a:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp1a, (100, 100, 220,0))
        bmp1a.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\curve_pixels_arr1_top_line_" + str(CGlobals1.global_vars_dict1["cuvature3_loop1"]) + ".bmp")



        cord_xy1a = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, 0)
        vec_3d_obj1:vec_3d1 = vec_3d1()
        vec_3d_obj1.p1 =  point_3d1()
        vec_3d_obj1.p1.x1 = cord_xy1a[0]
        vec_3d_obj1.p1.y1 = cord_xy1a[1]


        vec_3d_obj1.p2 = point_3d1()
        vec_3d_obj1.p2.x1 = cord_xy1a[0]
        vec_3d_obj1.p2.y1 = cord_xy1a[1]
        vec_3d_obj1.p2.z1 = -10

        false_positive_cords_from_sub_curves1:ArrayList =  ArrayList()

        last_x1:int = line_cord_xy1[0]
        last_y1:int = line_cord_xy1[1]
        new_curve_pixels_arr1:ArrayList = ArrayList()
        last_ok_x1:int = -1
        last_not_ok_x1:int = -1
        sub_curves_arr1:ArrayList = ArrayList()
        cur_sub_curve_arr1:ArrayList = ArrayList()
        for i1 in range( 0 , curve_pixels_arr1.count ):
            cord_xy1  = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)

            if cord_xy1[0] >= last_x1:
                last_x1 = cord_xy1[0]
                if cord_xy1[1] >= last_y1:
                    last_y1 = cord_xy1[1]
                    if cord_xy1[0] - 1 > last_ok_x1:

                        cur_sub_curve_arr1 = self.only_complete_missing_pixels_in_curve1(cur_sub_curve_arr1)
                        org_cub_curve1 = cur_sub_curve_arr1.clone()

                        len1 = cur_sub_curve_arr1.count
                        bmp1b:Bitmap = Bitmap(3500, 2300, (255, 255, 255,0))
                        self.set_pixels_arr_and_save2(cur_sub_curve_arr1, bmp1b, Color.FromArgb(0, 0, 0,0), CGlobals1.global_path1 + "sobel_pics1\\sub_curve_img1_before_" + str(CGlobals1.global_vars_dict1["cuvature3_loop1"]) + "_" + str(sub_curves_arr1.count) + ".bmp")

                        cur_sub_curve_arr1 = self.find_max_tangent_len_on_curve1(cur_sub_curve_arr1)
                        dict_org_sub_curve1:Dictionary = CGlobals1.add_to_dict1(cur_sub_curve_arr1)
                        
                        for i4 in range( 0 , org_cub_curve1.count):
                            if not dict_org_sub_curve1.ContainsKey(org_cub_curve1[i4]):
                                false_positive_cords_from_sub_curves1.Add(org_cub_curve1[i4])

                        bmp1c:Bitmap = Bitmap(3500, 2300, (255, 255, 255,0))
                        self.set_pixels_arr_and_save2(cur_sub_curve_arr1, bmp1c, (0, 0, 0,0), CGlobals1.global_path1 + "sobel_pics1\\sub_curve_img1_after_" + str(CGlobals1.global_vars_dict1["cuvature3_loop1"]) + "_" + str(sub_curves_arr1.count) + ".bmp")
                        len2:int = cur_sub_curve_arr1.count

                        sub_curves_arr1.Add(cur_sub_curve_arr1)
                        self.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\\sub_curve_" + str(sub_curves_arr1.count) + ".txt", cur_sub_curve_arr1)
                        cur_sub_curve_arr1 = ArrayList()

                    last_ok_x1 = cord_xy1[0]
                    new_curve_pixels_arr1.Add(curve_pixels_arr1[i1])
                    cur_sub_curve_arr1.Add(curve_pixels_arr1[i1])

                else:

                    last_not_ok_x1 = cord_xy1[0]

        cur_sub_curve_arr1 = self.find_max_tangent_len_on_curve1(cur_sub_curve_arr1)
        sub_curves_arr1.Add(cur_sub_curve_arr1)


        dict_res2:Dictionary = CMarkingFieldInImageUtils1.filter_sub_curves_arr1(sub_curves_arr1)
        new_curve_pixels_arr1 = dict_res2["new_curve1"]
        new_curve_pixels_arr1_dict1:Dictionary = CGlobals1.add_to_dict1(new_curve_pixels_arr1)
        if not new_curve_pixels_arr1_dict1.ContainsKey(str(line_cord_xy1[0]) + "," + str(line_cord_xy1[1])):
            new_curve_pixels_arr1.Insert(0, str(line_cord_xy1[0]) + "," + str(line_cord_xy1[1]))


        bmp_curves1:Bitmap = Bitmap(CGlobals1.global_vars_dict1["crop_bmp2_path1"])
        r1:int = 100
        g1:int = 100
        b1:int = 50
        for i1 in range(0 , sub_curves_arr1.count):
            self.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\\sub_curve_" + str(i1) + ".txt", sub_curves_arr1[i1])
            bmp_curve1:Bitmap = Bitmap(3500, 2500, (255, 255, 255,0))
            CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(sub_curves_arr1[i1], bmp_curves1, (r1, g1, b1,0))
            r1 += 10
            g1 -= 10
            b1 += 20
            if r1>255 or g1>255 or b1>255:
                r1 = 100
                g1 = 100
                b1 = 50
                    


            self.set_pixels_arr_and_save2(sub_curves_arr1[i1], bmp_curve1, (0, 0, 0,0), CGlobals1.global_path1 + "sobel_pics1\sub_curve_img1_" + str(CGlobals1.global_vars_dict1["cuvature3_loop1"]) + "_" + str(i1) + ".bmp")

        bmp_curves1.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\sub_curves_" + str(CGlobals1.global_vars_dict1["cuvature3_loop1"]) + ".bmp")


        bmp1:Bitmap = Bitmap(4000, 2500, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(new_curve_pixels_arr1, bmp1, (200, 40, 100,0))
        bmp1.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\uncomplete_pixels_curve_1.bmp")

        dict_res1:Dictionary = CMarkingFieldInImageUtils1.complete_uncomplete_pixels_curve_with_lines(self,new_curve_pixels_arr1)
        dict_res1["false_positive_cords_from_sub_curves1"] = false_positive_cords_from_sub_curves1
        return dict_res1
    






    def set_pixel_arr_on_bmp2_with_zoom1(self,pixels_arr1:ArrayList,  bmp1:Bitmap, color_to_set1, zoom1:int):
        
        last_x1:int = -1
        last_y1:int = -1
        for i1 in range(0 , pixels_arr1.count):
            try:
                x1:int = int(str(pixels_arr1[i1]).Split(",")[0]) * zoom1
                y1:int = int(str(pixels_arr1[i1]).Split(",")[1]) * zoom1

                if x1 >= 0 and x1 < bmp1.width and y1 >= 0 and y1 < bmp1.height:
                    bmp1.SetPixel(x1, y1, color_to_set1)


                if last_x1 != -1 and last_y1 != -1:

                    pixels_line1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points(last_x1, last_y1, x1, y1)
                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pixels_line1, bmp1, color_to_set1)
                last_x1 = x1
                last_y1 = y1
            except:
                try:
                    x1:int = float(str(pixels_arr1[i1]).Split(",")[0]) * zoom1
                    y1:int = float(str(pixels_arr1[i1]).Split(",")[1]) * zoom1
                    if x1 >= 0 and x1 < bmp1.width and y1 >= 0 and y1 < bmp1.height:
                        bmp1.SetPixel(x1, y1, color_to_set1)

                    if last_x1 != -1 and last_y1 != -1:

                        pixels_line1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points(last_x1, last_y1, x1, y1)
                        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pixels_line1, bmp1, color_to_set1)
                    last_x1 = x1
                    last_y1 = y1

                except:
                    d1=1















    def set_pixels_arr_and_save1(self,pixels_arr1:ArrayList, bmp1:Bitmap, path1:str):
        copy_bmp1:Bitmap = bmp1.clone()
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pixels_arr1, copy_bmp1, (255, 30, 200,0))
        copy_bmp1.Save(path1)


        return copy_bmp1




    def get_angle_change_of_pixels_arr1(self,pixels_arr1:ArrayList, delta_between_pixels1:int):
        from CGlobals1 import CGlobals1
        
        angles_arr1:ArrayList = ArrayList()
        last_angle1:float = 0
        for i1 in range(0 , pixels_arr1.count,  delta_between_pixels1):
            first_ind1:int = i1
            last_ind1:int = i1 + delta_between_pixels1
            p1_xy = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, first_ind1)
            p2_xy = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, min(last_ind1, pixels_arr1.count))

            vec_3d_obj1 = vec_3d1()
            vec_3d_obj1.p1.x1 = p1_xy[0]
            vec_3d_obj1.p1.y1 = p1_xy[1]
            vec_3d_obj1.p2.x1 = p2_xy[0]
            vec_3d_obj1.p2.y1 = p2_xy[1]

            vec_3d_obj2 = vec_3d1()
            vec_3d_obj2.p1.x1 = 0
            vec_3d_obj2.p1.y1 = 0
            vec_3d_obj2.p2.x1 = 100
            vec_3d_obj2.p2.y1 = 0

            angle1:float = self.get_angle_between_2_3d_vectors(vec_3d_obj1, vec_3d_obj2)
            if vec_3d_obj1.p2.y1 < vec_3d_obj2.p2.y1:
                angle1 = -abs(angle1)

            if i1 > 0:
                angles_arr1.Add(last_angle1 - angle1)

            last_angle1 = angle1

        return angles_arr1







    def count_pixel_around(self,bmp1:Bitmap, x1:int, y1:int, color_pixels_around1):
        from CGlobals1 import CGlobals1
        
        count_pixels_around1:int = 0
        for i1 in range( 0 , int(len(CGlobals1.dir_arr2) / 2) - 1+1):
            color1=bmp1.GetPixel( x1 + CGlobals1.dir_arr2[i1][0], y1 + CGlobals1.dir_arr2[i1][1])
            if CGlobals1.compare_colors1(color1, color_pixels_around1):
                count_pixels_around1 += 1

        if count_pixels_around1==1:
            count_pixels_around1 = 0
            for i1 in range(0 , int(len(CGlobals1.dir_arr2) / 2) - 1+1):
                if CGlobals1.compare_colors1(bmp1.GetPixel( x1 + CGlobals1.dir_arr2[i1][0], y1 + CGlobals1.dir_arr2[i1][1]), color_pixels_around1):
                    count_pixels_around1 += 1

        return count_pixels_around1


    def get_dir_arr1(self,ind1:int, ind2:int):
        from CGlobals1 import CGlobals1
        try:
            dir_arr1_val:int = CGlobals1.dir_arr1[ind1, ind2]
            return dir_arr1_val
        except:
            return -1






    def next_pixels_loop3(self,bmp1:Bitmap, start_x1:int, start_y1:int, in_dir_arr1, dict_prms1:Dictionary):
        from CGlobals1 import CGlobals1
        if dict_prms1==None:
            dict_prms1 = Dictionary()

        dict_res1:Dictionary = Dictionary()
        dict_res1["close_loop1"] = False

        over_all_pixels_arr1:ArrayList = ArrayList()
        max_pixels_arr1:ArrayList = ArrayList()
        success_status = ""
        copy_bmp1:Bitmap = bmp1.clone()
        org_bmp1:Bitmap = bmp1.clone()
        not_to_stop1:bool=True   
        pixels_3d_cords_arr = ArrayList()
        pixels_cords_arr1 = ArrayList()
        wrong_pixels_dict1:Dictionary = Dictionary()

        dict_of_pixels_arr1:Dictionary = Dictionary()
        org_x_start2:int = start_x1
        org_y_start2:int = start_y1

        cord_ind1:int
        last_cord_ind1:int
        count_to_stop2:int=0
        min_pixel_around1:int=0

        color_of_wrong_pixel1 = (20, 40, 200,0)
        color_of_wrong_pixel1 = (0, 0, 0,0)
        last_pixel_was_failed:bool = False
        while not_to_stop1:
            print("pixels_cords_arr1.count="+str(pixels_cords_arr1.count))
            color_set1 = copy_bmp1.GetPixel(self.x_start2, self.y_start2)

            if not last_pixel_was_failed:

                count_pixel_around_val2:int = self.count_pixel_around(org_bmp1, self.x_start2, self.y_start2, self.color_of_sobel)
                if count_pixel_around_val2 >= CConfig1.max_pixels_around_one_pixel:
                    dict_res1["over_all_pixels_arr1"] = over_all_pixels_arr1
                    dict_res1["pixels_cords_arr1"] = pixels_cords_arr1
                    dict_res1["max_pixels_arr1"] = max_pixels_arr1
                    return dict_res1


                copy_bmp1.SetPixel(self.x_start2, self.y_start2, self.color_of_region)

                over_all_pixels_arr1.Add(str(self.x_start2) + "," + str(self.y_start2))

                pixels_cords_arr1.Add(str(self.x_start2) + "," + str(self.y_start2))
                max_pixels_arr1.Add(str(self.x_start2) + "," + str(self.y_start2))

                pixels_3d_cords_arr.Add(point_3d1(self.x_start2, self.y_start2, 0))
                dict_of_pixels_arr1[str(self.x_start2) + "," + str(self.y_start2)] = 1

            last_pixel_was_failed = False

            cord_ind1 = 0

            if pixels_cords_arr1.count > 1:


                cord_str1 = pixels_cords_arr1[pixels_cords_arr1.count - 2].split(",")
                x1:int = int(cord_str1[0])
                y1:int = int(cord_str1[1])
                not_to_stop3:bool=True

                while not_to_stop3:
                    try:

                        new_x1:int = self.x_start2 + in_dir_arr1[cord_ind1][ 0]
                        new_y1:int = self.y_start2 + in_dir_arr1[cord_ind1][ 1]
                        if new_x1 == x1 and new_y1 == y1:
                            not_to_stop3 = False
                        else:
                            cord_ind1 += 1

                    except:
                        return pixels_cords_arr1
                        not_to_stop3 = False


            edge_color1 = copy_bmp1.GetPixel(self.x_start2 + in_dir_arr1[cord_ind1][ 0], self.y_start2 + in_dir_arr1[cord_ind1][ 1])
            bg_color1 = copy_bmp1.GetPixel(self.x_start2 + in_dir_arr1[cord_ind1 + 1][ 0], self.y_start2 + in_dir_arr1[cord_ind1 + 1][ 1])

            color_cur_pixel1 = copy_bmp1.GetPixel(self.x_start2 + in_dir_arr1[cord_ind1][ 0], self.y_start2 + in_dir_arr1[cord_ind1][1])
            color_next_pixel1 = copy_bmp1.GetPixel(self.x_start2 + in_dir_arr1[cord_ind1 + 1][ 0], self.y_start2 + in_dir_arr1[cord_ind1 + 1][ 1])


            count_pixel_around_val1:int = self.count_pixel_around(copy_bmp1, self.x_start2 + in_dir_arr1[cord_ind1][ 0], self.y_start2 + in_dir_arr1[cord_ind1][1], edge_color1)
            last_cord_ind1 = cord_ind1

            not_to_stop2:bool=True
            not_to_stop_search_pixel1:bool=True  
            failed_to_find_next_pixel1:bool=False
            arrive_to_start1:bool=False
            while not_to_stop_search_pixel1:
                if CGlobals1.compare_colors1(color_cur_pixel1, self.color_of_bg) and CGlobals1.compare_colors1(color_next_pixel1, self.color_of_sobel):
                    not_to_stop_search_pixel1 = False

                if CGlobals1.compare_colors1(color_cur_pixel1, color_of_wrong_pixel1) and CGlobals1.compare_colors1(color_next_pixel1, self.color_of_sobel):
                    not_to_stop_search_pixel1 = False


                if not_to_stop_search_pixel1:
                    count_pixel_around_val2  = self.count_pixel_around(org_bmp1, self.x_start2 + in_dir_arr1[cord_ind1 + 1][ 0], self.y_start2 + in_dir_arr1[cord_ind1 + 1][ 1], self.color_of_sobel)
                    if count_pixel_around_val2 >= 8:
                        
                        not_to_stop_search_pixel1 = True


                if not_to_stop_search_pixel1:
                    if cord_ind1 >= 14:
                        failed_to_find_next_pixel1 = True
                        not_to_stop_search_pixel1 = False
                    else:
                        cord_ind1 += 1
                        if org_x_start2 == self.x_start2 + in_dir_arr1[cord_ind1][ 0] and org_y_start2 == self.y_start2 + in_dir_arr1[cord_ind1][ 1] and pixels_cords_arr1.count > 5:
                            arrive_to_start1 = True
                            not_to_stop1 = False  

                        dir1a:int = in_dir_arr1[cord_ind1][ 0]
                        dir1b:int = in_dir_arr1[cord_ind1][ 1]


                        dir2a:int = in_dir_arr1[cord_ind1 + 1][ 0]
                        dir2b:int = in_dir_arr1[cord_ind1 + 1][ 1]

                        color_cur_pixel1 = copy_bmp1.GetPixel(self.x_start2 + in_dir_arr1[cord_ind1][ 0], self.y_start2 + in_dir_arr1[cord_ind1][ 1])
                        color_next_pixel1 = copy_bmp1.GetPixel(self.x_start2 + in_dir_arr1[cord_ind1 + 1][ 0], self.y_start2 + in_dir_arr1[cord_ind1 + 1][ 1])

            if arrive_to_start1:
                dict_res1["over_all_pixels_arr1"] = over_all_pixels_arr1
                dict_res1["pixels_cords_arr1"] = pixels_cords_arr1
                dict_res1["max_pixels_arr1"] = max_pixels_arr1
                dict_res1["close_loop1"] = True
                return dict_res1
            
            
            if not failed_to_find_next_pixel1 and not not_to_stop_search_pixel1:
                self.x_start2 = self.x_start2 + in_dir_arr1[cord_ind1 + 1][ 0]
                self.y_start2 = self.y_start2 + in_dir_arr1[cord_ind1 + 1][ 1]

                count_pixel_around_val2:int = self.count_pixel_around(org_bmp1, self.x_start2, self.y_start2, self.color_of_sobel)
                
            elif failed_to_find_next_pixel1:
                last_pixel_was_failed = True
                copy_bmp1.SetPixel(self.x_start2, self.y_start2, color_of_wrong_pixel1)

                over_all_pixels_arr1.Add(str(self.x_start2) + "," + str(self.y_start2))

                dict_of_pixels_arr1.Remove(pixels_cords_arr1[pixels_cords_arr1.count - 1])

                pixels_cords_arr1.RemoveAt(pixels_cords_arr1.count - 1)
                if max_pixels_arr1.count < pixels_cords_arr1.count:
                    max_pixels_arr1 = pixels_cords_arr1.clone()

                if pixels_cords_arr1.count <= 0:
                    dict_res1["over_all_pixels_arr1"] = over_all_pixels_arr1
                    dict_res1["pixels_cords_arr1"] = pixels_cords_arr1
                    dict_res1["max_pixels_arr1"] = max_pixels_arr1
                    return dict_res1

                cord_str1 = pixels_cords_arr1[pixels_cords_arr1.count - 1].split(",")
                x_start2 = int(cord_str1[0])
                y_start2 = int(cord_str1[1])

            if dict_prms1.ContainsKey("check_if_arrive_to_cord_xy1"):

                x1:int = int(dict_prms1["arrive_to_cord_xy1_x1"])
                y1:int = int(dict_prms1["arrive_to_cord_xy1_y1"])
                cord_str2 = pixels_cords_arr1[pixels_cords_arr1.count - 1].split(",")

            if pixels_cords_arr1.count > 5 and dict_prms1.ContainsKey("check_if_arrive_to_start1"):

                cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_cords_arr1,0)
                x_start_1:int = int(cord_xy1[0])
                y_start_1:int = int(cord_xy1[1])


                cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_cords_arr1,pixels_cords_arr1.count-1)
                x_start_2:int = int(cord_str2[0])
                y_start_2:int = int(cord_str2[1])

                delta_xy1:int=1
                for x1 in range( x_start_2 - delta_xy1 , x_start_2 + delta_xy1+1):
                    for y1 in range( y_start_2 - delta_xy1 , y_start_2 + delta_xy1+1):
                        if x_start_1 == x1 and y_start_1 == y1 :
                            not_to_stop1 = False
                            dict_res1["close_loop1"] = True

        dict_res1["over_all_pixels_arr1"] = over_all_pixels_arr1
        dict_res1["pixels_cords_arr1"] = pixels_cords_arr1
        dict_res1["max_pixels_arr1"] = max_pixels_arr1

        return dict_res1








    def next_pixels_loop5(self,bmp1:Bitmap):
        
        from CGlobals1 import CGlobals1
        success_status = ""
        copy_bmp1:Bitmap = bmp1.clone()
        org_bmp1:Bitmap = bmp1.clone()
        not_to_stop1:bool=True
        pixels_3d_cords_arr:ArrayList = ArrayList()
        pixels_cords_arr1:ArrayList = ArrayList()
        wrong_pixels_dict1:Dictionary = Dictionary()
        org_x_start2:int = x_start2
        org_y_start2:int = y_start2

        cord_ind1:int
        last_cord_ind1:int
        count_to_stop2:int=0
        min_pixel_around1:int=0

        while not_to_stop1:
            color_set1 = copy_bmp1.GetPixel(x_start2, y_start2)


            copy_bmp1.SetPixel(x_start2, y_start2, self.color_of_region)
            pixels_cords_arr1.Add(str(x_start2) + "," + str(y_start2))
            pixels_3d_cords_arr.Add(point_3d1(x_start2, y_start2, 0))

            cord_ind1 = 0

            if pixels_cords_arr1.count > 1:

                for ind2 in range(0 , len(CGlobals1.dir_arr1) / 2 - 1):
                    new_x1:int = x_start2 + self.get_dir_arr1(ind2, 0)
                    new_y1:int = y_start2 + self.get_dir_arr1(ind2, 1)
                    count_pixel_around_val2:int= self.count_pixel_around(copy_bmp1, new_x1, new_y1, self.color_of_sobel)
                    if count_pixel_around_val2 <= min_pixel_around1:
                        copy_bmp1.SetPixel(new_x1, new_y1, self.color_of_bg)

                cord_str1 = str(pixels_cords_arr1[pixels_cords_arr1.Count - 2]).Split(",")
                x1:int = int(cord_str1[0])
                y1:int = int(cord_str1[1])
                not_to_stop3:bool=True

                while not_to_stop3:
                    try:


                        new_x1:int = x_start2 + self.get_dir_arr1(cord_ind1, 0)
                        new_y1:int = y_start2 + self.get_dir_arr1(cord_ind1, 1)
                        if new_x1 == x1 and new_y1 == y1:
                            not_to_stop3 = False
                        else:
                            cord_ind1 += 1

                    except:
                        return pixels_cords_arr1
                        to_stop3 = 1


            edge_color1 = copy_bmp1.GetPixel(x_start2 + self.get_dir_arr1(cord_ind1, 0), y_start2 + self.get_dir_arr1(cord_ind1, 1))
            bg_color1 = copy_bmp1.GetPixel(x_start2 + self.get_dir_arr1(cord_ind1 + 1, 0), y_start2 + self.get_dir_arr1(cord_ind1 + 1, 1))
            count_pixel_around_val1:int = self.count_pixel_around(copy_bmp1, x_start2 + self.get_dir_arr1(cord_ind1, 0), y_start2 + self.get_dir_arr1(cord_ind1, 1), edge_color1)
            last_cord_ind1 = cord_ind1

            not_to_stop2:bool=True
            failed_to_find_next_pixel1:bool=False
            
            while not (CGlobals1.compare_colors1(edge_color1, self.color_of_bg) and CGlobals1.compare_colors1(self.bg_color1, self.color_of_sobel) and count_pixel_around_val1 > 1)  and not_to_stop2:
                last_cord_ind1 = cord_ind1
                try:
                    edge_color1 = copy_bmp1.GetPixel(x_start2 + self.get_dir_arr1(cord_ind1, 0), y_start2 + self.get_dir_arr1(cord_ind1, 1))
                    bg_color1 = copy_bmp1.GetPixel(x_start2 + self.get_dir_arr1(cord_ind1 + 1, 0), y_start2 + self.get_dir_arr1(cord_ind1 + 1, 1))

                    count_pixel_around_val1 = self.count_pixel_around(copy_bmp1, x_start2 + self.get_dir_arr1(cord_ind1, 0), y_start2 + self.get_dir_arr1(cord_ind1, 1), edge_color1)

                    if (x_start2 + self.get_dir_arr1(cord_ind1 + 1, 0)) == org_x_start2 and \
                        (y_start2 + self.get_dir_arr1(cord_ind1 + 1, 1)) == org_y_start2:

                        ind_pixel1:int
                        for ind_pixel1 in range( 0 , pixels_cords_arr1.count):
                            x1:int = int(str(pixels_cords_arr1[ind_pixel1]).Split(",")[0])
                            y1:int = int(str(pixels_cords_arr1[ind_pixel1]).Split(",")[1])
                            copy_bmp1.SetPixel(x1, y1, (10, 255, 10,0))

                        if pixels_cords_arr1.count > 300:
                            success_status = "arrive_to_start_point"


                        return pixels_cords_arr1
                except:
                    failed_to_find_next_pixel1 = True

                    not_to_stop2 = False
                    wrong_pixels_dict1[str(x_start2) + "," + str(y_start2)] = 1
                
                cord_ind1 += 1

            if not_to_stop2:

                bg_color1 = copy_bmp1.GetPixel(x_start2 + CGlobals1.dir_arr1(last_cord_ind1 + 1, 0), y_start2 + CGlobals1.dir_arr1(last_cord_ind1 + 1, 1))


            if not not_to_stop2 or failed_to_find_next_pixel1:
                try:

                    cord_str1 = str(pixels_cords_arr1[pixels_cords_arr1.count - 1]).Split(",")
                    x1:int = int(cord_str1[0])
                    y1:int = int(cord_str1[1])
                    copy_bmp1.SetPixel(x1, y1, self.color_of_bg)
                    pixels_cords_arr1.RemoveAt(pixels_cords_arr1.count - 1)
                    x_start2 = int(pixels_cords_arr1[pixels_cords_arr1.count - 1].Split(",")[0])
                    y_start2 = int(pixels_cords_arr1[pixels_cords_arr1.count - 1].Split(",")[1])

                    count_to_stop2 += 1
                    if count_to_stop2 > 30:
                        return None

                except:
                    return pixels_cords_arr1

            else:
                x_start2 = x_start2 + self.get_dir_arr1(last_cord_ind1 + 1, 0)
                y_start2 = y_start2 + self.get_dir_arr1(last_cord_ind1 + 1, 1)

        return pixels_cords_arr1







    def find_max_sobel_length2(self,start_x1:int, start_y1:int):
        
        from CGlobals1 import CGlobals1
        
        dict_res1:Dictionary=None

        if self.cur_sobel_ind_val1 >= CGlobals1.dict_sobel_pixels.count - 5:
            return dict_res1


        start_store1:bool = False



        x_start2 = start_x1
        y_start2 = start_y1

        dict_result1:Dictionary = Dictionary()
        self.bmp_current_sobel.SaveAsave(CGlobals1.global_path1 + "\\sobel_pics1\\to_find_line1_" + str(CGlobals1.step_num1) + ".bmp")
        dict_res1 = self.next_pixels_loop3(self.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1, None)




        dict_res2:Dictionary = self.next_pixels_loop3(self.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1_rev, None)

        dict_result1["pixels_around_sobel_arr1"] = dict_res1
        dict_result1["pixels_around_sobel_arr1_rev"] = dict_res2

        pixels_around_sobel_arr1:ArrayList = dict_res1["pixels_cords_arr1"]
        angles_arr1:ArrayList = self.get_angle_change_of_pixels_arr1(pixels_around_sobel_arr1, 4)
        dict_result1["angles_arr1"] = angles_arr1
        seq_arr1:ArrayList = CGlobals1.find_max_seq_that_val_between1(angles_arr1, -50, 50,21)
        self.set_pixels_arr_and_save1(pixels_around_sobel_arr1, self.bmp_current_sobel, CGlobals1.global_path1 + "sobel_pics1\\pixels_" + str(CGlobals1.step_num1) + ".bmp")

        max_angle1:float = CGlobals1.get_max_value_in_arraylist1(angles_arr1, True)
        dict_result1["max_angle1"] = max_angle1
        count_angle_in_range1:int = CGlobals1.count_value_in_arraylist1(angles_arr1, -30, 30)
        dict_result1["count_angle_in_range1"] = count_angle_in_range1
        percent_ok_angles1:float = (count_angle_in_range1 / angles_arr1.count)
        dict_result1["percent_ok_angles1"] = percent_ok_angles1


        return dict_result1






    def save_2d_pixels_arr1(slef,path_of_file:str, arr_2d_pixels:ArrayList):
        str_2d_pnts1:StringBuilder = StringBuilder()

        for i1 in range(0 ,arr_2d_pixels.count):

            str_2d_pnts1.Append(str(arr_2d_pixels[i1]) + "#")


        CFile1.write_all_text_to_file( str(str_2d_pnts1),path_of_file)




    def find_curves1(self,rect_start_x1:int, rect_start_y1:int, bmp1:Bitmap):
        
        from CGlobals1 import CGlobals1
        
        width_of_bmp1:int = 700
        curves_pixels_dict1:Dictionary = Dictionary()
        only_curves_pixels_dict1:Dictionary = Dictionary()

        sobel_ind1:int = 45
        path_of_bmp1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\\" + str(sobel_ind1) + ".bmp"

        bmp5:Bitmap = bmp1.crop((rect_start_x1, rect_start_y1, width_of_bmp1, 100))
        bmp6:Bitmap = Bitmap(width_of_bmp1, 120, (255, 0, 0, 0))
        bmp7:Bitmap = bmp6.clone()# todo CGlobals1.copy_bitmap_2_bitmap1(bmp6, bmp5, 5, 5)
        bmp1 = bmp7

        bmp_current_sobel = bmp1

        bmp1.SaveAsave(CGlobals1.global_path1 + "sobel_pics1\\bmp1.bmp")
        copy_bmp1:Bitmap = Bitmap(bmp1.width, bmp1.height)


        start_search_curves_ind1:int = 0
        start_search_curves_arr1:ArrayList = ArrayList()
        all_curves_arr1:ArrayList = ArrayList()
        last_pixel_ind1:int = 0

        x_padding1:int = 5
        y_padding1:int = 5
        count_set_pixels1:int = 0
        for x1 in range(x_padding1 , copy_bmp1.width - 1 - x_padding1+1):
            for y1 in range(y_padding1 , copy_bmp1.height - 1 - y_padding1+1):
                copy_bmp1.SetPixel(x1, y1, (255, 0, 0, 0))


                if CGlobals1.compare_colors1(bmp_current_sobel.GetPixel( x1, y1), self.color_of_sobel) and x1 > 5 and x1 < 500 and y1 > 5 and y1 < 900:
                    dir_ind1:int = 0
                    new_cord_x1:int = x1 + CGlobals1.dir_arr1[dir_ind1, 0]
                    new_cord_y1:int = y1 + CGlobals1.dir_arr1[dir_ind1, 1]
                    count_not_sobel_around1:int=0
                    p_ind1:int

                    for dir_ind1 in range(0 , len(CGlobals1.dir_arr1) / 2 - 1+1):
                        new_cord_x1 = x1 + CGlobals1.dir_arr1[dir_ind1, 0]
                        new_cord_y1 = y1 + CGlobals1.dir_arr1[dir_ind1, 1]
                        if not CGlobals1.compare_colors1(bmp_current_sobel.GetPixel( new_cord_x1, new_cord_y1), self.color_of_sobel):
                            count_not_sobel_around1 += 1

                    no_sbel_in_left_or_right1:bool = False

                    if not CGlobals1.compare_colors1(bmp_current_sobel.GetPixel( x1 + 1, y1), self.color_of_sobel) or \
                        not CGlobals1.compare_colors1(bmp_current_sobel.GetPixel( x1 - 1, y1), self.color_of_sobel):
                        no_sbel_in_left_or_right1 = True

                    if count_not_sobel_around1 >= 3 and no_sbel_in_left_or_right1:
                        start_search_curves_arr1.Add((x1, y1))
                        count_set_pixels1 += 1
                        copy_bmp1.SetPixel(x1, y1, (0, 255, 255, 255))
                        last_pixel_ind1 += 1

        copy_bmp1.SaveAsave(CGlobals1.global_path1 + "sobel_pics1\\curves_1.bmp")

        x_start2 = 4
        y_start2 = 4

        dict_res1:Dictionary
        to_save1:int = False


        CGlobals1.dir_x1_to_sobel = 1
        CGlobals1.dir_m1_to_sobel = 0
        not_to_stop1:bool=True

        x_start2 = start_search_curves_arr1[start_search_curves_ind1][0]
        y_start2 = start_search_curves_arr1[start_search_curves_ind1][1]

        while not_to_stop1:

            while curves_pixels_dict1.ContainsKey(str(x_start2) + "," + str(y_start2)):

                start_search_curves_ind1 += 1

                if start_search_curves_ind1 >= start_search_curves_arr1.count:
                    for i3 in range(0, all_curves_arr1.count):
                        self.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\curves_pxls_" + i3.ToString() + ".txt", all_curves_arr1(i3))
                    return all_curves_arr1

                x_start2 = start_search_curves_arr1[start_search_curves_ind1][0]
                y_start2 = start_search_curves_arr1[start_search_curves_ind1][1]

            last_start_search_curves_ind1:int = start_search_curves_ind1

            if not curves_pixels_dict1.ContainsKey(str(x_start2) + "," + str(y_start2)):

                dict_res1 = self.find_max_sobel_length2(x_start2, y_start2)



                while dict_res1["pixels_around_sobel_arr1"]["max_pixels_arr1"].count <= 0 and dict_res1["pixels_around_sobel_arr1_rev"]["max_pixels_arr1"].count <= 0:
                    start_search_curves_ind1 += 1

                    if start_search_curves_ind1 >= start_search_curves_arr1.count:
                        for i3 in range(0 , all_curves_arr1.count):
                            self.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\\curves_pxls_" + str(i3) + ".txt", all_curves_arr1[i3])
                        return all_curves_arr1

                    x_start2 = start_search_curves_arr1(start_search_curves_ind1)[0]
                    y_start2 = start_search_curves_arr1(start_search_curves_ind1)[1]
                    
                    while curves_pixels_dict1.ContainsKey(str(x_start2) + "," + str(y_start2)):

                        start_search_curves_ind1 += 1
                        if start_search_curves_ind1 >= start_search_curves_arr1.count:
                            for i3 in range( 0 , all_curves_arr1.count):
                                self.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\\curves_pxls_" + str(i3) + ".txt", all_curves_arr1[i3])
                            return all_curves_arr1

                        x_start2 = start_search_curves_arr1(start_search_curves_ind1)[0]
                        y_start2 = start_search_curves_arr1(start_search_curves_ind1)[1]


                    if not curves_pixels_dict1.ContainsKey(str(x_start2) + "," + str(y_start2)):
                        dict_res1 = self.find_max_sobel_length2(x_start2, y_start2)





                    for i1 in range(0 , dict_res1["pixels_around_sobel_arr1"]["over_all_pixels_arr1"].count):
                        curves_pixels_dict1[dict_res1["pixels_around_sobel_arr1"]["over_all_pixels_arr1"][i1]] = 1

                    for i1 in range(0 , dict_res1["pixels_around_sobel_arr1_rev"]["over_all_pixels_arr1"].count):

                        curves_pixels_dict1[dict_res1["pixels_around_sobel_arr1_rev"]["over_all_pixels_arr1"][i1]] = 1






                curves_arr1:ArrayList = self.get_curve_from_pixels_arr_by_region(dict_res1["pixels_around_sobel_arr1"]["max_pixels_arr1"], 0, 0, width_of_bmp1, 1070)
                curves_arr2:ArrayList = self.get_curve_from_pixels_arr_by_region(dict_res1["pixels_around_sobel_arr1_rev"]["max_pixels_arr1"], 0, 0, width_of_bmp1, 1070)


                for i1 in range(0 , curves_arr1.count):

                    for i2 in range( 0 , curves_arr1[i1].count):
                        cord_xy1a:int = int(str(curves_arr1[i1][i2]).Split(",")[0])
                        cord_xy1b:int = int(str(curves_arr1[i1][i2]).Split(",")[1])
                        copy_bmp1.SetPixel(cord_xy1a, cord_xy1b, (255, 160, 50, 90))

                        curves_pixels_dict1[curves_arr1[i1][i2]] = 1



                        only_curves_pixels_dict1[curves_arr1[i1][i2]] = 1


                    all_curves_arr1.Add(curves_arr1(i1).Clone())
                if not dict_res1["pixels_around_sobel_arr1"]["close_loop1"]:
                    curves_arr1 = curves_arr2
                    for i1 in range(0 , curves_arr1.count):

                        count_exist_pixels1:int = 0
                        for i2 in range(0 , curves_arr1[i1].count):

                            cord_xy1a:int = int(curves_arr1[i1][i2].Split(",")[0])
                            cord_xy1b:int = int(curves_arr1[i1][i2].Split(",")[1])

                            copy_bmp1.SetPixel(cord_xy1a, cord_xy1b, (255, 160, 50, 90))

                            if curves_pixels_dict1.ContainsKey(curves_arr1[i1][i2]):
                                count_exist_pixels1 += 1

                            curves_pixels_dict1[curves_arr1[i1][i2]]= 1

                            only_curves_pixels_dict1[curves_arr1[i1][i2]] = 1

                        if not (count_exist_pixels1 >= curves_arr1[i1].count - 1):
                            all_curves_arr1.Add(curves_arr1[i1].Clone())




            if start_search_curves_ind1 >= start_search_curves_arr1.count - 1:
                not_to_stop1 = False
                to_save1 = True

            if to_save1:

                copy_bmp1.SaveAsve(CGlobals1.global_path1 + "sobel_pics1\\curves_" + str(start_search_curves_ind1) + ".bmp")


                for i3 in range(0 , all_curves_arr1.count):
                    self.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\curves_pxls_" + i3.ToString() + ".txt", all_curves_arr1(i3))

                count_over_edge1:int = 0

                for i3 in range(0 , start_search_curves_arr1.count ):
                    x_start3:int = start_search_curves_arr1(i3)[0]
                    y_start3:int = start_search_curves_arr1(i3)[1]
                    if curves_pixels_dict1.ContainsKey(str(x_start3) + "," + str(y_start3)):
                        count_over_edge1 += 1


                return all_curves_arr1

            start_search_curves_ind1 += 1







    def set_pixels_arr_and_save2(self,pixels_arr1:ArrayList, bmp1:Bitmap, color1, path1:str):
        copy_bmp1:Bitmap = bmp1.clone()
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(pixels_arr1, copy_bmp1, color1)
        copy_bmp1.SaveAsave(path1)

        return copy_bmp1



    def find_start_point1(self,x_start1:int, y_start1:int):
        self.x_start2 = x_start1
        self.y_start2 = y_start1

        dir1:int = 1
        try:

            while (self.bmp1.GetPixel(self.x_start2, self.y_start2)[0] != self.color_of_sobel[0] or \
                    self.bmp1.GetPixel(self.x_start2, self.y_start2)[1] != self.color_of_sobel[1] or \
                    self.bmp1.GetPixel(self.x_start2, self.y_start2)[2] != self.color_of_sobel[1]) and y_start2 < self.bmp1.height - 1:
                y_start2 += dir1


        except:
            y_start2 = self.bmp1.height - 10
            dir1 = -1
            while (self.bmp1.GetPixel(self.x_start2, self.y_start2)[0] !=self.color_of_sobel[0] or \
                self.bmp1.GetPixel(self.x_start2, self.y_start2)[1] != self.color_of_sobel[1] or \
                self.bmp1.GetPixel(self.x_start2, self.y_start2)[2] != self.color_of_sobel[2]) and y_start2 >0:
                y_start2 += dir1




        return (self.x_start2, self.y_start2)








        
            
    def update_path1(self):
        from CGlobals1 import CGlobals1
        try:
            config_folder1:str=CFile1.read_all_file_text(".\\config_folder1.txt")
        except:
            config_folder1:str=CFile1.read_all_file_text("..\\config_folder1.txt")
        CGlobals1.global_path1 = CFile1.read_all_file_text(config_folder1+"\\root_path1.txt")
        self.file_name1 = CFile1.read_all_file_text(config_folder1+"\\file_path1.txt")

    
    def init1(self):
        self.d1=1
        


    def update_current_sobel(self,new_sobel_ind_val:int):
        from CGlobals1 import CGlobals1
        
        if (self.cur_sobel_ind_val1 > new_sobel_ind_val):
            for sobel_key_ind in range(new_sobel_ind_val , self.cur_sobel_ind_val1+1):
                if sobel_key_ind < CGlobals1.dict_sobel_pixels.count:

                    sobel_key_val:int = CGlobals1.dict_sobel_pixels.keys[sobel_key_ind]
                    pixel_arr1:ArrayList = CGlobals1.dict_sobel_pixels[sobel_key_val]

                    for i1 in range(0 , pixel_arr1.count):
                        x1:int = int(str(pixel_arr1[i1].split(",")[0]))
                        y1:int = int(str(pixel_arr1[i1].split(",")[1]))
                        self.bmp_current_sobel.SetPixel(x1, y1, (255, 255, 255,0))


        else:
            for sobel_key_ind in range(self.cur_sobel_ind_val1 , new_sobel_ind_val+1):
                if sobel_key_ind < CGlobals1.dict_sobel_pixels.count:

                    sobel_key_val:int = CGlobals1.dict_sobel_pixels.keys[sobel_key_ind]
                    pixel_arr1:ArrayList = CGlobals1.dict_sobel_pixels[sobel_key_val]

                    for i1 in range( 0 , pixel_arr1.count):
                        x1:int = int(str(pixel_arr1[i1].split(",")[0]))
                        y1:int = int(str(pixel_arr1[i1].split(",")[1]))
                        self.bmp_current_sobel.SetPixel(x1, y1, (0, 0, 0,0))


        self.cur_sobel_ind_val1 = new_sobel_ind_val

        print("cur_sobel_ind_val1="+str(self.cur_sobel_ind_val1))






    def add_dec_sobel_ind(self,dir1:str, sobel_factor1:int):

        if dir1 == "add1":
            new_cur_sobel_ind_val1:int = self.cur_sobel_ind_val1 + sobel_factor1
            self.update_current_sobel(new_cur_sobel_ind_val1)


        if dir1 == "dec1":
            new_cur_sobel_ind_val1:int = self.cur_sobel_ind_val1 - sobel_factor1
            self.update_current_sobel(new_cur_sobel_ind_val1)
        

    def create_cache_of_sobel_files(self,path_of_cache1:str):
        from CGlobals1 import CGlobals1
        
        for x1 in range(0 , self.bmp_current_sobel.width ):
            for y1 in range( 0 , self.bmp_current_sobel.height):
                self.bmp_current_sobel.SetPixel(x1, y1, (255, 255, 255,0))

        i1:int

        for i1 in range(0 , CGlobals1.dict_sobel_pixels.count - 5+1):
            self.add_dec_sobel_ind("add1", 1)
            #print("step2:(create sobel imgs)" + str((i1 / CGlobals1.dict_sobel_pixels.count * 100) + "        ") + "%")

            self.bmp_current_sobel.SaveAs(path_of_cache1 + "\\" + str(self.cur_sobel_ind_val1) + ".bmp")







    def crop_img_by_color(self,bmp1:Bitmap, color1):
        
        
        
        
        
        x1:int
        y1:int

        top1:int
        not_to_stop1:bool = True
        top1 = 0

        while not_to_stop1:

            for x1 in range (0 , bmp1.width):
                if bmp1.GetPixel(x1, top1)[0] != color1[0] or bmp1.GetPixel(x1, top1)[1] != color1[1] or bmp1.GetPixel(x1, top1)[2] != color1[2]:
                    not_to_stop1 = False


               
            if not_to_stop1:
                top1 += 1

        top1 -= 10

        bottom1:int
        
        not_to_stop1 = True
        bottom1 = bmp1.height - 1
        while not_to_stop1:

            for x1 in range (0 , bmp1.width ):
                if bmp1.GetPixel(x1, bottom1)[0] != color1[0] or \
                   bmp1.GetPixel(x1, bottom1)[1] != color1[1] or \
                   bmp1.GetPixel(x1, bottom1)[2] != color1[2]:
                   not_to_stop1 = False


            
            if not_to_stop1:
                bottom1 -= 1

        bottom1 += 10




        to_stop1 = 0
        left1:int = 0

        while not_to_stop1:

            for y1 in range (0 , bmp1.height):
                if bmp1.GetPixel(left1, y1)[0] != color1[0] or \
                   bmp1.GetPixel(left1, y1)[1] != color1[1] or \
                   bmp1.GetPixel(left1, y1)[2] != color1[2]:
                    not_to_stop1 = False


            if not_to_stop1:
                left1 += 1

        left1 -= 10
        if left1 < 0:
            left1 = 0

        not_to_stop1 = True
        
        right1:int = bmp1.width - 1

        while not_to_stop1:

            for y1 in range( 0, bmp1.height ):
                if bmp1.GetPixel(right1, y1)[0] != color1[0] or \
                   bmp1.GetPixel(right1, y1)[1] != color1[1] or \
                   bmp1.GetPixel(right1, y1)[2] != color1[2]:
                    not_to_stop1 = False


            if not_to_stop1:
                right1 -= 1

        right1 += 10
        if right1 > bmp1.width - 1:
            right1 = bmp1.Width - 1


        width2:int=right1 - left1 + 1
        height2:int=bottom1 - top1 + 1
        bmp2:Bitmap = bmp1.clone()
        bmp2.crop((left1,top1,right1,bottom1))
        
        

        return bmp2
    






    def find_start_point_by_line1(self,bmp1:Bitmap, line_of_pxls_arr1:ArrayList, start_ind1:int = -1):
        from CGlobals1 import CGlobals1
        
        copy_bmp1:Bitmap = bmp1.clone()

        i1:int=0

        if start_ind1 != -1:
            i1 = start_ind1

        xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)

        while xy_cord1[0] >= copy_bmp1.width - 3 or xy_cord1[1] >= copy_bmp1.height - 3 or xy_cord1[0] <= 3 or xy_cord1[1] <= 3:

            i1 += 1
            xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)



        while CGlobals1.compare_colors1(copy_bmp1.GetPixel(xy_cord1[0], xy_cord1[1]), self.color_of_sobel) == 1 and xy_cord1[1] < copy_bmp1.height - 1 and xy_cord1[0] < copy_bmp1.width - 1:
            i1 += 1
            xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)

        


        while (copy_bmp1.GetPixel(xy_cord1[0], xy_cord1[1])[0] != self.color_of_sobel[0] or  copy_bmp1.GetPixel(xy_cord1[0], xy_cord1[1])[1] != self.color_of_sobel[1] or copy_bmp1.GetPixel(xy_cord1[0], xy_cord1[1])[2] != self.color_of_sobel[2]) and xy_cord1[1] < copy_bmp1.height - 1 and xy_cord1[0] < copy_bmp1.width - 1:
            i1 += 1
            xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)



        return (xy_cord1[0], xy_cord1[1], i1)


    def find_max_sobel_length3(self,start_x1:int, start_y1:int):
        from CGlobals1 import CGlobals1
        dict_res1:Dictionary=None

        if self.cur_sobel_ind_val1 >= CGlobals1.dict_sobel_pixels.count - 5:
            return dict_res1




        x_start2 = start_x1
        y_start2 = start_y1

        dict_result1:Dictionary = Dictionary()
        if CGlobals1.debug_mode_sobel:
            self.bmp_current_sobel.SaveAs(CGlobals1.global_path1 + "\\sobel_pics1\\to_find_line1_" + str(CGlobals1.step_num1) + ".bmp")

        dict_res1 = self.next_pixels_loop3(self.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1, None)




        dict_res2:Dictionary = self.next_pixels_loop3(self.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1_rev, None)


        bmp1a:Bitmap=Bitmap(3000,2000,(0,0,0,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(dict_res2, bmp1a, (200, 40, 150,0))


        bmp1a.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\bmp1a.bmp")

        dict_result1["pixels_around_sobel_arr1"] = dict_res1
        dict_result1["pixels_around_sobel_arr1_rev"] = dict_res2



        return dict_result1






    def remove_around_object1(self,bmp1:Bitmap, bg_color1):
        
        from CGlobals1 import CGlobals1
        
        bmp2:Bitmap = bmp1.clone()


        for x1 in range(1 , bmp1.width() - 1):
            for y1 in range( 1 , bmp1.height() - 1):
                if CGlobals1.compare_colors1(bmp1.GetPixel(x1, y1), bg_color1) == 0:
                    set_bg1:int=0

                    
                    for cord_ind1 in range( 0 , 9+1):
                        if CGlobals1.compare_colors1(bmp1.GetPixel(x1 + CGlobals1.dir_arr1[cord_ind1, 0], y1 + CGlobals1.dir_arr1[cord_ind1, 1]), bg_color1) == 1:
                            set_bg1 = 1


                    if set_bg1 == 1:
                        bmp2.SetPixel(x1, y1, bg_color1)

        return bmp2




    def get_line_x_by_y1(self,m_line1:float, b_line1:float, y_line1:float):

        x1:float = (y_line1 - b_line1) / m_line1

        return x1

        
        
   
        
    
        
    
        
    
    
    def load_2d_pixels_arr1(self,path_of_file):
        str_pnts_arr1:str=CFile1.read_all_file_text(path_of_file)
        str_pnds_cord_2d=str_pnts_arr1.split("#")
        
        arr_2d_points=ArrayList()
        
        for i1 in range(len(str_pnds_cord_2d)):
            if len(str(str_pnds_cord_2d[i1])) > 2:
                x1=int(str(str_pnds_cord_2d[i1]).split(",")[0])
                y1=int(str(str_pnds_cord_2d[i1]).split(",")[1])
                arr_2d_points.Add(str(x1) + "," + str(y1))
        
        
        
        return arr_2d_points
    
    
    
    
    


    
    
    




    


    def get_mono_color1(self,bmp1:Bitmap, x1:int, y1:int):
        from CGlobals1 import CGlobals1

        key1:str = str(x1) + "," + str(y1)
        if CGlobals1.dict_mono_colors1.ContainsKey(key1):
            return CGlobals1.dict_mono_colors1[key1]
        
        
        color1 = bmp1.GetPixel(x1, y1)
        mono_color1:int = int(0.3 * color1[0] + 0.59 * color1[1] + 0.11 * color1[2])
        if mono_color1!= 255:
            d1=1
        CGlobals1.dict_mono_colors1[key1] = mono_color1
        return mono_color1

    
    
    
    
    def get_sobel_value1(self,bmp1:Bitmap, x1:int, y1:int):

        mat1  = [[0, 0, 0, 0, 0], [-1, -2, -4, -2, -1], [0, 0, 0, 0, 0], [1, 2, 4, 2, 1], [0, 0, 0, 0, 0]]
        total_sobel_val1:float = 0
        sobel_x1:int
        sobel_y1:int
        sobel_x1 = 0
        for x2 in range (x1 - 2,x1 + 2+1):
            sobel_y1 = 0

            for y2 in range (y1 - 2, y1 + 2+1):
                sobel_val1:float = mat1[sobel_x1][sobel_y1]

                mono_color1:float=self.get_mono_color1(bmp1, x2, y2)
                total_sobel_val1 += self.get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            
            sobel_x1 += 1

        return total_sobel_val1
    



    def get_sobel_value2(self,bmp1:Bitmap, x1:int, y1:int):
        mat1 = [[0, -1, 0, 1, 0], [0, -2, 0, 2, 0], [0, -4, 0, 4, 0], [0, -2, 0, 2, 0], [0, -1, 0, 1, 0]]
        total_sobel_val1:float = 0
        sobel_x1:int
        sobel_y1:int
        sobel_x1 = 0
        for x2 in range( x1 - 2, x1 + 2+1):
            sobel_y1 = 0

            for y2 in range (y1 - 2,y1 + 2+1):
                sobel_val1:float = mat1[sobel_x1][ sobel_y1]

                mono_color1:float=self.get_mono_color1(bmp1, x2, y2)
                total_sobel_val1 += self.get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            
            sobel_x1 += 1
        
        return total_sobel_val1



    def get_sobel_value3(self,bmp1:Bitmap, x1:int, y1:int):
        mat2 = [[0, -1, 0, 0, 0], [2, 0, -2, 0, 0], [0, 4, 0, -4, 0], [0, 0, 2, 0, -2], [0, 0, 0, 1, 0]]

        total_sobel_val1:float = 0
        sobel_x1:int
        sobel_y1:int
        sobel_x1 = 0
        for x2 in range (x1 - 2, x1 + 2+1):
            sobel_y1 = 0

            for y2 in range(y1 - 2, y1 + 2+1):
                sobel_val1:float = mat2[sobel_x1][ sobel_y1]

                total_sobel_val1 += self.get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            sobel_x1 += 1

        return total_sobel_val1



    def get_sobel_value4(self,bmp1:Bitmap, x1:int, y1:int):



        mat2 = [[0, 0, 0, -1, 0], [0, 0, -2, 0, 2], [0, -4, 0, 4, 0], [-2, 0, 2, 0, 0], [0, 1, 0, 0, 0]]


        total_sobel_val1:float = 0
        sobel_x1:int
        sobel_y1:int
        sobel_x1 = 0
        for x2 in range(x1 - 2 , x1 + 2+1):
            sobel_y1 = 0

            for y2 in range(y1 - 2 ,y1 + 2+1):
                sobel_val1:float = mat2[sobel_x1][ sobel_y1]

                mono_color1:float=self.get_mono_color1(bmp1, x2, y2)
                total_sobel_val1 += self.get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            
            sobel_x1 += 1

        return total_sobel_val1


    


    def do_sobel_oparator1(self,bmp1:Bitmap):

        from CGlobals1 import CGlobals1
        
        dict_sobel_val1:Dictionary=Dictionary()
        dict_sobel_val2:Dictionary=Dictionary()
        dict_sobel_val_pixels1:Dictionary=Dictionary()
        
        bmp2:Bitmap =Bitmap(bmp1.width, bmp1.height)
        sobal_size1:int = 7
        ind1:int = 0
        max_sobel:float = 0
        sobel_vals_str1=StringBuilder()

        not_relevant1:int = 1

        for x1 in range(0 + sobal_size1,bmp1.width - sobal_size1):
            
            print("x1="+str(x1)+"/"+str(bmp1.width - sobal_size1))

            for y1 in range (0 + sobal_size1, bmp1.height - sobal_size1):


                sobel_val1a:float = -1
                sobel_val1b:float = -1
                sobel_val1:float = -1
                max_sobel_ind1 = 0
                sobel_val1_1:float = self.get_sobel_value1(bmp1, x1, y1)
                sobel_val1_2:float = self.get_sobel_value2(bmp1, x1, y1)
                sobel_val1_3:float = self.get_sobel_value3(bmp1, x1, y1)
                sobel_val1_4:float = self.get_sobel_value4(bmp1, x1, y1)

                if sobel_val1_1 < 0:
                    sobel_val1_1 = -sobel_val1_1

                if sobel_val1_2 < 0:
                    sobel_val1_2 = -sobel_val1_2

                if sobel_val1_3 < 0:
                    sobel_val1_3 = -sobel_val1_3
                
                
                if sobel_val1_1 < 0:
                    sobel_val1_4 = -sobel_val1_4


                max_sobel_val_1:float = sobel_val1_1
                max_sobel_ind1 = 1
                if sobel_val1_2 > max_sobel_val_1:
                    max_sobel_val_1 = sobel_val1_2
                    max_sobel_ind1 = 2


                if sobel_val1_3 > max_sobel_val_1:
                    max_sobel_val_1 = sobel_val1_3
                    max_sobel_ind1 = 3

                if sobel_val1_4 > max_sobel_val_1:
                    max_sobel_val_1 = sobel_val1_4
                    max_sobel_ind1 = 4

                sobel_val1 = max_sobel_val_1

                if max_sobel < sobel_val1:
                    max_sobel = sobel_val1

                if not_relevant1 == 1:
                    dict_sobel_val_pixels1[str(x1) + "," + str(y1)] = sobel_val1
                    dict_sobel_val1[ind1] = abs(sobel_val1)
                    dict_sobel_val2[abs(sobel_val1)] = 1



                pixels_arr1:ArrayList
                if CGlobals1.dict_sobel_pixels.ContainsKey(abs(sobel_val1)) == False:
                    CGlobals1.dict_sobel_pixels[abs(sobel_val1)] = ArrayList()
                pixels_arr1 = CGlobals1.dict_sobel_pixels[abs(sobel_val1)]
                pixels_arr1.Add(str(x1) + "," + str(y1))

                ind1 += 1

                sobel_vals_str1.Append(str(x1) + "," + str(y1) + "," + str(abs(sobel_val1)) + "#")




        path1:str = CGlobals1.global_path1 +CGlobals1.form_obj1.file_name1 + "_sobel_vals1.txt"
        
        CFile1.write_all_text_to_file( str(sobel_vals_str1),path1)
        sorted = dict_sobel_val1.sort_by_value()

        sortedDictionary = sorted

        s2 = 30

        count_sobel_ok_pixels1:int = 0
        for x1 in range(0 + sobal_size1 , bmp1.width - 1 - sobal_size1+1):
            for y1 in range(0 + sobal_size1 , bmp1.height - 1 - sobal_size1+1):
                sobel_val1:float = dict_sobel_val_pixels1[str(x1) + "," + str(y1)]
                if sobel_val1 > s2:
                    bmp2.SetPixel(x1, y1, (255, 255, 255))
                    count_sobel_ok_pixels1 += 1
                else:
                    bmp2.SetPixel(x1, y1, (0, 0, 0))

        percent_ok1:float = count_sobel_ok_pixels1 / (bmp1.width * bmp1.height)




        return bmp2




    def get_angle_between_2_3d_vectors(self,in_vec1:vec_3d1, in_vec2:vec_3d1):
        
        vec1:vec_3d1 = vec_3d1()
        vec2:vec_3d1 = vec_3d1()
        vec1.p2.x1 = in_vec1.p2.x1 - in_vec1.p1.x1
        vec1.p2.y1 = in_vec1.p2.y1 - in_vec1.p1.y1
        vec1.p2.z1 = in_vec1.p2.z1 - in_vec1.p1.z1


        vec2.p2.x1 = in_vec2.p2.x1 - in_vec2.p1.x1
        vec2.p2.y1 = in_vec2.p2.y1 - in_vec2.p1.y1
        vec2.p2.z1 = in_vec2.p2.z1 - in_vec2.p1.z1


        if vec1.p2.x1 == vec2.p2.x1 and vec1.p2.y1 == vec2.p2.y1 and vec1.p2.z1 == vec2.p2.z1:
            return 0

        dot_mul1:float = vec1.p2.x1 * vec2.p2.x1 + vec1.p2.y1 * vec2.p2.y1 + vec1.p2.z1 * vec2.p2.z1
        vec1_len1:float = pow(vec1.p2.x1 * vec1.p2.x1 + vec1.p2.y1 * vec1.p2.y1 + vec1.p2.z1 * vec1.p2.z1, 0.5)
        vec2_len1:float = pow(vec2.p2.x1 * vec2.p2.x1 + vec2.p2.y1 * vec2.p2.y1 + vec2.p2.z1 * vec2.p2.z1, 0.5)
        inv_cos1:float = 1
        try:
            inv_cos1 =math.acos(dot_mul1 / (vec1_len1 * vec2_len1))

        except:
            return None

        return inv_cos1 / (math.p1 / 180)





    def read_sobel_values1(self,path1:str):
        
        from CGlobals1 import CGlobals1
        
        if CFile1.is_file_exist(CGlobals1.global_path1+CGlobals1.form_obj1.file_name1[0: CGlobals1.form_obj1.file_name1.rindex("\\")]+"\\sobal_vals_cache1.bin"):
            
            CGlobals1.dict_sobel_pixels = pickle.load(open(CGlobals1.global_path1+CGlobals1.form_obj1.file_name1[0: CGlobals1.form_obj1.file_name1.rindex("\\")]+"\\sobal_vals_cache1.bin", "rb"))
        else:
        
        
        
            sobel_vals_str:str = CFile1.read_all_file_text(path1)
            sobel_pixels_vals= sobel_vals_str.split("#")

            for i1 in range (0, len(sobel_pixels_vals)):
                if i1 % 100000 == 0:
                    print("i1="+str(i1)+"/"+str(len(sobel_pixels_vals)))
                vals_str1 = sobel_pixels_vals[i1].split(",")
                if len(vals_str1) >= 3:
                    sobel_val1:int = int(vals_str1[2])
                    x1:int = int(vals_str1[0])
                    y1:int = int(vals_str1[1])
                    
                    if not CGlobals1.dict_sobel_pixels.ContainsKey(abs(sobel_val1)):
                        CGlobals1.dict_sobel_pixels[abs(sobel_val1)] = ArrayList()

                    pixels_arr1 = CGlobals1.dict_sobel_pixels[abs(sobel_val1)]
                    pixels_arr1.Add(str(x1) + "," + str(y1))



            pickle.dump(CGlobals1.dict_sobel_pixels, open(CGlobals1.global_path1+CGlobals1.form_obj1.file_name1[0: CGlobals1.form_obj1.file_name1.rindex("\\")]+"\\sobal_vals_cache1.bin", "wb"))

        
        

        sortedDictionary = CGlobals1.dict_sobel_pixels.sort_by_key()
        CGlobals1.dict_sobel_pixels = sortedDictionary
        key1:str = sortedDictionary.keys[sortedDictionary.count - 1]


        self.cur_sobel_ind_val1 = sortedDictionary.count
        self.cur_sobel_ind_val1 = 0
        CGlobals1.current_sobel_threshold = int(key1)
        CGlobals1.last_sobel_threshold = int(key1)
        #self.bmp_current_sobel = Bitmap(self.bmp1.width, self.bmp1.height)

        self.bmp_current_sobel=Bitmap(self.bmp1.width, self.bmp1.height,(255, 255, 255))

        #for x1 in range(0, self.bmp_current_sobel.width ):
            #for y1 in range(0, self.bmp_current_sobel.height ):
                #self.bmp_current_sobel.SetPixel(x1, y1, (255, 255, 255))


    def get_max_diff_bmp1(self,bmp1:Bitmap):
        from CGlobals1 import CGlobals1
        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_max_diff1.bmp"
        if os.path.isfile(path1) == True:

            bmp5:Bitmap = Bitmap(path1)

            return bmp5
        


        bmp2:Bitmap = CMarkingFieldInImageUtils1.rgb_to_monochrome1(bmp1)
        bmp3:Bitmap = self.compute_max_diff_from_neighboors1(bmp2)
        bmp3.SaveAs(path1)

        return bmp3
    



    def compute_max_diff_from_neighboors1(self,bmp1:Bitmap):
        
        bmp2:Bitmap = Bitmap(bmp1.width,bmp1.height,(255,255,255,0))
        for x1 in range(1 ,bmp1.width-2+1):
            for y1 in range(1 ,bmp1.height - 2+1):
                color1 = bmp1.GetPixel(x1, y1)
                color_val1 = int(0.3 * color1[0] + 0.59 * color1[1] + 0.11 * color1[2])

                max_diff1:float = 0
                for x2 in range(-1 ,1+1):
                    for y2 in range(-1, 1+1):
                        if x2 != 0 or y2 != 0:
                            color2= bmp1.GetPixel(x1 + x2, y1 + y2)
                            color_val2:float = int(0.3 * color2[0] + 0.59 * color2[1] + 0.11 * color2[2])
                            if abs(color_val1 - color_val2) > max_diff1:
                                max_diff1 = abs(color_val1 - color_val2)

                color3:int = max_diff1

                bmp2.SetPixel(x1, y1, (color3, color3, color3,0))

        return bmp2
