from CMarkingFieldInImage1 import CMarkingFieldInImage1
from CMacros1 import CMacros1
from bitmap import Bitmap
from ArrayList import ArrayList
from CEdgeDetection1 import CEdgeDetection1
from CFile1 import CFile1
from Dictionary import Dictionary

class CForm1:
    
    def __init__(self):
        self.file_name1="980376340_2\\195768205504__A"
        self.markingfldimg_obj1=CMarkingFieldInImage1()
        self.macros_obj1=CMacros1()
        self.compute_sobel=False        
        self.compute_sobel_imgs1=True
        
    def prepare_sobel_images(self):
        from CGlobals1 import CGlobals1
        
        sobel_pics1_path:str = CGlobals1.global_path1 + "sobel_pics1\\"
        if not CFile1.is_directory_exist(sobel_pics1_path):
                CFile1.create_directory(sobel_pics1_path)
       
       
       
        sobel_bmp1:Bitmap=None
        
        
        path_of_cache1:str = CGlobals1.global_path1 + self.file_name1 + "_sobel_cache1"
        CGlobals1.path_of_sobel_cache1 = path_of_cache1
        
        

        if self.compute_sobel:

            

            bmp1:Bitmap = Bitmap(CGlobals1.global_path1 + self.file_name1 + ".jpg")
            crop_bmp1:Bitmap = self.markingfldimg_obj1.crop_img_by_color(bmp1, (255, 255, 255,0))
            crop_bmp1.SaveAs(CGlobals1.global_path1 + self.file_name1 + "_crop1.bmp")

            bmp2:Bitmap = self.markingfldimg_obj1.rgb_to_monochrome1(bmp1)
            bmp2.SaveAs(CGlobals1.global_path1 + self.file_name1 + "_mono1.bmp")

            crop_bmp1=Bitmap(CGlobals1.global_path1 + self.file_name1 + "_crop1.bmp")
            sobel_bmp1 = self.markingfldimg_obj1.do_sobel_oparator1(crop_bmp1)
            sobel_bmp1.SaveAs(CGlobals1.global_path1 + self.file_name1 + "_s1.bmp")

           
        
        
        self.markingfldimg_obj1.bmp1 = Bitmap(CGlobals1.global_path1 + self.file_name1 + "_crop1.bmp")
        copy_bmp1:Bitmap = self.markingfldimg_obj1.bmp1.clone()

        copy_bmp1.SaveAs(CGlobals1.global_path1 + self.file_name1 + "_test1.bmp")
        self.markingfldimg_obj1.read_sobel_values1(CGlobals1.global_path1 + self.file_name1 + "_sobel_vals1.txt")
        
        
        sobel_bmp1 = Bitmap(CGlobals1.global_path1 + self.file_name1 + "_s1.bmp")

        CGlobals1.current_bmp1 = sobel_bmp1
        
        
        





        x_start2:int = 50
        y_start2:int = 0

        self.markingfldimg_obj1.bmp1 = sobel_bmp1.clone()
        cord1 = self.markingfldimg_obj1.find_start_point1(x_start2, y_start2)
        x_start2 = cord1[0]
        y_start2 = cord1[1]
        if self.compute_sobel_imgs1:
            path_of_cache1:str = CGlobals1.global_path1 + self.file_name1 + "_sobel_cache1"
            CGlobals1.path_of_sobel_cache1 = path_of_cache1
            if not CFile1.is_directory_exist(path_of_cache1):
                CFile1.create_directory(path_of_cache1)

            self.markingfldimg_obj1.create_cache_of_sobel_files(path_of_cache1)
            CGlobals1.dict_mono_colors1=Dictionary()

        return








        
        
        
        
        
        
        
    def find_edge_curve1(self):
        from CGlobals1 import CGlobals1
        cut_frame_only1:str = ""
        CGlobals1.clear_all_caches1()

        CGlobals1.global_suffix_file_name1 = "_frame1"

        path_of_cache1:str= CGlobals1.global_path1 + self.file_name1 + "_sobel_cache1"
        CGlobals1.path_of_sobel_cache1 = path_of_cache1

        sobel_ind1:int = -1

        path_sign_sobel_ind1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"
        



        self.markingfldimg_obj1.bmp1 = Bitmap(CGlobals1.global_path1 + self.file_name1 + "_crop1.jpg")
        copy_bmp1:Bitmap =self.markingfldimg_obj1.bmp1.clone()
        copy_bmp1.SaveAs(CGlobals1.global_path1 + self.file_name1 + "_test1.bmp")
        self.markingfldimg_obj1.read_sobel_values1(CGlobals1.global_path1 + self.file_name1 + "_sobel_vals1.txt")

        CGlobals1.current_bmp1 = Bitmap(CGlobals1.global_path1 + self.file_name1 + "_s1.jpg")


        line_to_search_start_sobel_pixels1:ArrayList = self.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points(500, 0, 500, 2000)
        self.markingfldimg_obj1.cur_sobel_ind_val1 = 0

        edge_detection_obj1:CEdgeDetection1 = CEdgeDetection1()

        edge_detection_obj1.loop_on_sobel_vals4(line_to_search_start_sobel_pixels1)
