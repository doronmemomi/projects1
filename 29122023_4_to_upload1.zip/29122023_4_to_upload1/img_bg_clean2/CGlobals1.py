from bitmap import Bitmap
from CForm1 import CForm1
from CMarkingFieldInImage1 import CMarkingFieldInImage1

from ArrayList import ArrayList
from Dictionary import Dictionary
import os, fnmatch
class CGlobals1:
    
    global_path1="E:\\memomi_folder1\\glass_pics_8\\"
    form_obj1=CForm1()
    dict_mono_colors1:Dictionary=Dictionary()
    dict_sobel_pixels:Dictionary=Dictionary()
    global_vars_dict1:Dictionary=Dictionary()

    save_slices_curves_for_debug=True
    debug_mode_sobel=True
    
    angle_treshold1:float = 45
    def __init__(self):

        self.x1=82
        
        return
       
    def clear_all_caches1():
        CGlobals1.dict_sobel_pixels=Dictionary()
        CGlobals1.global_vars_dict1=Dictionary()
        CGlobals1.last_dict_sobel_line_pixels1=Dictionary()
    
    def func1(self):
        print("func11",self.x1)
        return 1

    def compare_colors1(color1, color2):
        if color1[0] == color2[0] and color1[1] == color2[1] and color1[2] == color2[2]:
            return 1

        return 0

    def draw_sqr_around_pixels2(bmp1:Bitmap, x1:int, y1:int, sqr_radius1:int, color1):

        for x1a in range( x1 - sqr_radius1 , x1 + sqr_radius1+1):
            for y1a in range(y1 - sqr_radius1 , y1 + sqr_radius1+1):
                try:
                    bmp1.SetPixel(x1a, y1a, color1)

                except:
                    err1=1


        return bmp1
    
    
   
   
    def copy_bitmap(bitmp1:Bitmap):
        return bitmp1.clone()
    
    def get_cord_xy_in_pixels_arr1(pixels_arr1:ArrayList,cord_ind1:int):
        x1=int(str(pixels_arr1[cord_ind1]).split(",")[0])
        y1=int(str(pixels_arr1[cord_ind1]).split(",")[1])
        if len(str(pixels_arr1[cord_ind1]).split(","))==3:
            z1=int(str(pixels_arr1[cord_ind1]).split(",")[2])
            return (x1, y1, z1)
        
        
        return (x1,y1)




    def get_arr_from_ind_to_ind1(arr1:ArrayList,start_ind1:int,end_ind1:int):
        new_arr1=ArrayList()
        
        if start_ind1<=end_ind1:
            i1=start_ind1
            while i1<=min(end_ind1, arr1.count - 1):
                new_arr1.Add(arr1[i1])
                i1+=1
        
        if end_ind1 < start_ind1:
            i1=start_ind1
            while i1<=(arr1.count - 1):
                new_arr1.Add(arr1[i1])
                i1+=1

            i1=0
            while i1<=min(end_ind1, arr1.count - 1): #end_ind1
                new_arr1.Add(arr1(i1))
                i1+=1

        
        
        return new_arr1
            
            


    def get_double_cord_xy_in_pixels_arr2(pixels_arr1:ArrayList, cord_ind1:int):
        x1 = float(pixels_arr1[cord_ind1].split(",")[0])
        y1 = float(pixels_arr1[cord_ind1].split(",")[1])
        if len(pixels_arr1[cord_ind1].split(",")) == 3:
            z1 = float(pixels_arr1[cord_ind1].split(",")[2])
            return (x1, y1, z1)
        
        return (x1, y1)
    
    
    
    
    def delete_files1(path1:str, pattern1:str):
        
        if os.path.isfile(path1)==False:
            return -1
        files1:list=os.listdir(path1)
        
        for i1 in range(0,len(files1)):
            if os.path.isfile(path1+files1[i1]) and fnmatch.fnmatch(files1[i1], pattern1):
                os.remove(path1+files1[i1])
        
        
        
    def add_to_dict1(arr1:ArrayList):
        dict1:Dictionary = Dictionary()

        for i1 in range(0, arr1.count()):
            dict1[arr1[i1]] = i1

        return dict1

    
    
    
    def dict_type_Int32_Double_to_str(dict1:Dictionary):
        

        str1:str = ""

        for i1 in range( 0 , dict1.count):
            if str1 != "" :
                str1 += "#"

            str1 += str(dict1.keys[i1]) + "," + str(dict1[dict1.keys[i1]])

        return str1
