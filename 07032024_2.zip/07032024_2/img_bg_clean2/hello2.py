import sys
import os

sys.path.append(os.path.abspath("/python_env1/prjs1/img_bg_clean2"))
from ArrayList import ArrayList
from test1 import test1
from CPolynom2 import CPolynom2
from Dictionary import Dictionary
from bitmap import Bitmap
from CPolynom_curve1 import CPolynom_curve1
from CEdgeDetection1 import CEdgeDetection1
from CJson1 import CJson1
import json
from PIL import Image  
import PIL  
import time


import numpy as np
from CGlobals1 import CGlobals1
from setuptools import setup
from Cython.Build import cythonize
if False:
    setup(
        ext_modules = cythonize("./foo.pyx")
    )

def to_json(obj1):
    type_str1:str=str(type(obj1))
    
    if "Dictionary.Dictionary" in type_str1:
        dict_obj1:Dictionary=obj1
        for key_ind1 in range(0,dict_obj1.count):
            key_str:str=dict_obj1.keys[key_ind1]
            to_json(dict_obj1[key_str])
            
    if "ArrayList.ArrayList" in type_str1:
        arr_obj1:ArrayList=obj1
        for ind1 in range(0,arr_obj1.count):
            to_json(arr_obj1[ind1])
        
            
    i1:int=1

if False:            
    i6=1
    i5_count=0
    t0= time.time()
    for i5 in range(0,10000000):
        d1=1
        if i5 % 1000==0:
            i5_count+=1
            
        
    t1= time.time()-t0

dict1:Dictionary=Dictionary()
dict1["1"]=1
dict1["2"]=1.2
dict1["3"]=ArrayList()
dict1["3"].Add(3)
dict1["3"].Add("3")
dict1["3"].Add(Dictionary())
dict1["3"][2][2]="3"
dict1["3"][2][21]="3"

json_str:str=CJson1.to_json1(dict1)
print(json_str)
CJson1.json_to_obj1(json_str)
json_obj1=json.loads(json_str)


CGlobals1.form_obj1.markingfldimg_obj1.init1()
CGlobals1.form_obj1.markingfldimg_obj1.update_path1()
CGlobals1.form_obj1.init1()
CGlobals1.form_obj1.polynom_curve_obj1.analize_polynom2()




CGlobals1.form_obj1.prepare_sobel_images()

CGlobals1.form_obj1.find_edge_curve1()
exit(0)


polynom_curve_obj1=CPolynom_curve1()
polynom_curve_obj1.analize_polynom2()
edge_detection_obj1=CEdgeDetection1()



CGlobals1.delete_files1("E:\\memomi_folder1\\glass_pics_8\\980376340_2\\crop_res1\\","*.txt")

CGlobals1.form_obj1.find_edge_curve1()
x4=9
dict1 =Dictionary()

dict1["x4"]=98
globals()['x4'] = 42
bitmap1=Bitmap("..\\imgs1\\i11.bmp")
bitmap2:Bitmap=CMarkingFieldInImageUtils1.rgb_to_monochrome1(bitmap1)
bitmap2.SaveAs("..\\imgs1\\i11b.bmp")
bitmap3:Bitmap=CGlobals1.form_obj1.markingfldimg_obj1.do_sobel_oparator1(bitmap2)

bitmap3.SaveAs("..\\imgs1\\sobel11b.bmp")
bmp1=Bitmap(4000, 3000,(255,255,255,0))

polynom_curve_obj1=CPolynom_curve1()
polynom_curve_obj1.analize_polynom2()


bitmap1.SetPixel(0,0,(100,50,50,0))
bitmap1.SetPixel(1,1,(100,50,50,0))
bitmap1.SetPixel(29,2,(100,50,50,0))
bitmap1.SetPixel(29,29,(100,50,50,0))


bitmap1.SaveAs("..\imgs1\i11b.bmp")

p1:CPolynom2=CPolynom2()
p1.add_coef(0.7)
p1.add_coef(2.7)
print(p1.get_polynom_vals_str1())
p1.create_derivative1()
print(p1.find_x_by_derivative_val(0.03))
      
x5=8





d1=Dictionary()
d1["3242"]=2342;
d1["13242"]=234122;
d1.print()
d2=d1.sort_by_key()
d2.print()
d3=d1.sort_by_value()
d3["353453453453"]=23423423
d3.print()

p1.create_derivative1()
t1=test1()

a=ArrayList()
a2=ArrayList()

a.Add(8)
a.Add(9)
a[1]="656556gchgf"
a.Add(10)
#a.RemoveAt(1)
a.print()

a2.Add(8)
a2.Add(9)
a2.Add(110)
a2.print()

b=23
print(a[1])

print(sys.version) 