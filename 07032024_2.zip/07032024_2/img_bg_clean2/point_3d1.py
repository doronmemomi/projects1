import math

class point_3d1:

    
    
    
        
        
        
    def __init__(self, *inp):
        
        if len(inp) == 3:
            self.x1 = inp[0]
            self.y1 = inp[1]
            self.z1 = inp[2]
        elif len(inp) == 0:
            self.x1 = 0
            self.y1 = 0
            self.z1 = 0
        
        
    def clone1(self):
        new_point_3d:point_3d1 =point_3d1(self.x1, self.y1, self.z1)

        return new_point_3d



    def rotate_x1(self,rot_deg1):
        rot_deg2  = rot_deg1 * math.pi / 180.0
        new_y1 = float(self.y1) * math.cos(rot_deg2) - float(self.z1) * math.sin(rot_deg2)
        new_z1 = float(self.y1) * math.sin(rot_deg2) + float(self.z1) * math.cos(rot_deg2)
        self.y1 = new_y1
        self.z1 = new_z1



    def rotate_y1(self,rot_deg1):
        rot_deg2 = rot_deg1 * math.pi / 180.0
        new_z1 = float(self.z1) * math.cos(rot_deg2) - float(self.x1) * math.sin(rot_deg2)
        new_x1 = float(self.z1) * math.sin(rot_deg2) + float(self.x1) * math.cos(rot_deg2)
        self.z1 = new_z1
        self.x1 = new_x1



    def rotate_z1(self,rot_deg1):
        rot_deg2 = rot_deg1 * math.pi / 180.0
        new_x1 = float(self.x1) * math.cos(rot_deg2) - float(self.y1) * math.sin(rot_deg2)
        new_y1 = float(self.x1) * math.sin(rot_deg2) + float(self.y1) * math.cos(rot_deg2)
        self.x1 = new_x1
        self.y1 = new_y1


    