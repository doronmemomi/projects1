from bitmap import Bitmap
from CForm1 import CForm1
from CMarkingFieldInImage1 import CMarkingFieldInImage1
from point_3d1 import point_3d1
from ArrayList import ArrayList
from Dictionary import Dictionary
from CFile1 import CFile1
import os, fnmatch
class CGlobals1:
    
    global_path1=""
    form_obj1=CForm1()
    dict_mono_colors1:Dictionary=Dictionary()
    dict_sobel_pixels:Dictionary=Dictionary()
    global_vars_dict1:Dictionary=Dictionary()
    some_max_diff_val1:Dictionary=Dictionary()
    save_slices_curves_for_debug=True
    debug_mode_sobel=True
    
    angle_treshold1:float = 45
    
    step_num1:int=0
    
    
    
    dir_arr1  = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]]
    dir_arr1_rev  = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]]
    dir_arr2  = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]]

    dir_arr4 = [[-2, -2], [-1, -2], [0, -2], [1, -2], [2, -2], [2, -1], [2, 0], [2, 1], [2, 2], [1, 2], [0, 2], [-1, 2], [-2, 2], [-2, 1], [-2, 0], [-2, -1]]
    dir_arr3  = [[0, -1], [1, 0], [0, 1], [-1, 0]]


    def __init__(self):

        self.x1=82
        
        return
       

    def convert_2darr_to_3d_arr(arr_2d:ArrayList):
        

        new_3d_arr1:ArrayList = ArrayList()

        for i1 in range( 0 , arr_2d.count ):
            point_3d_obj1:point_3d1 = point_3d1()
            point_3d_obj1.x1 = float(arr_2d[i1].split(",")[0])
            point_3d_obj1.y1 = float(arr_2d[i1].split(",")[1])
            point_3d_obj1.z1 = 0
            new_3d_arr1.Add(point_3d_obj1)

        return new_3d_arr1

    def get_cord_xy_in_pixels_arr_by_3_cord1(pixels_arr1:ArrayList, cord_ind1:int):


        for i1 in range(0 , pixels_arr1.count):
            x1:int = float(pixels_arr1[i1].split(",")[0])
            y1:int = float(pixels_arr1[i1].split(",")[1])

            z1:int = float(pixels_arr1[i1].split(",")[2])
            if z1 == int(float(str(cord_ind1))):
                return (x1, y1, z1)




    def conv_2d_arr_to_2d_cords_dict1(arr1:ArrayList):
        i1:int
        dict_cords1:Dictionary = Dictionary()
        for i1 in range(0, arr1.count ):
            dict_cords1[i1] = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, i1)

        return dict_cords1



    def get_arr_from_ind_to_ind_by_3_ind1(arr1:ArrayList, start_ind_3ind1:int, end_ind_3ind1:int):
        new_arr1:ArrayList = ArrayList()


        i1:int

        for i1 in range(0 , arr1.count):
            cord_xy3 = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, i1)
            if cord_xy3[2] >= start_ind_3ind1 and cord_xy3[2] <= end_ind_3ind1 or cord_xy3[2] <= start_ind_3ind1 and cord_xy3[2] >= end_ind_3ind1:
                new_arr1.Add(arr1[i1])


        return new_arr1




    def arr_xy_to_dict2(arr1:ArrayList):
        dict1:Dictionary = Dictionary()
        i1:int

        for i1 in range(0 , arr1.count):
            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, i1)
            dict1[cord_xy1[0]] = cord_xy1[1]

        return dict1


    def dict_keys_to_arr1(dict_keys1:Dictionary):

        i1:int
        new_arr1:ArrayList = ArrayList()

        for i1 in range(0 , dict_keys1.keys):
            new_arr1.Add(dict_keys1.keys[i1])

        return new_arr1





    def count_value_in_arraylist1(self,arr1:ArrayList, min_value1:float, max_value1:float):
    
        count_value1:int=0
        if arr1.Count <= 0:
            return 0


        for i1 in range(0 , arr1.count ):
            if arr1[i1] >= min_value1 and arr1[i1] <= max_value1:
                count_value1 += 1

        return count_value1


    def add_val_to_pxls_arr1(self,pxls_arr1:ArrayList, add_x1:int, add_y1:int):
        
        new_pxls_arr1:ArrayList = ArrayList()

        for i1 in range(0 , pxls_arr1.count ):
            cord_xy1 = self.get_cord_xy_in_pixels_arr1(pxls_arr1, i1)
            cord_xy1[0] += add_x1
            cord_xy1[1] += add_y1
            new_pxls_arr1.Add(str(cord_xy1[0]) + "," + str(cord_xy1[1]))

        return new_pxls_arr1

       
       
    def get_max_value_in_arraylist1(self,arr1:ArrayList, abs_value1:bool = False):
        
        if arr1.count <= 0:
            return None

        max_value1:float = arr1[0]
        if abs_value1:
            max_value1 = abs(arr1[0])

        for i1 in range(1 , arr1.count ):
            if abs_value1:
                if max_value1 < abs(arr1[i1]):
                    max_value1 = abs(arr1[i1])

            else:
                if max_value1 > arr1[i1]:
                    max_value1 = arr1[i1]

        return max_value1


       
       

    def find_max_seq_that_val_between1(arr1:ArrayList, min_value1:float, max_value1:float,min_arr_len1:int):

        ind1 = 0
        not_to_stop1:bool=True
        seq_arr1:ArrayList = ArrayList()
        if arr1.count <= min_arr_len1:
            return seq_arr1

        while not_to_stop1:

            while arr1[ind1] < min_value1 or arr1[ind1] > max_value1 and ind1 < arr1.count - 2:

                ind1 += 1

                if ind1 >= arr1.count - 1:
                    not_to_stop1 = False
                    return seq_arr1


            ind2:int = ind1
            while arr1[ind2] >= min_value1 and arr1[ind2] <= max_value1 and ind2 < arr1.count - 2:
                ind2 += 1
                if ind1 >= arr1.count - 1:
                    not_to_stop1 = False
                    return seq_arr1

            seq_arr1.Add(str(ind1) + "," + str(ind2))
            ind1 = ind2

            if ind1 >= arr1.count - 2:
                not_to_stop1 = False
                
        return seq_arr1



       
       
    def clear_all_caches1():
        CGlobals1.dict_sobel_pixels=Dictionary()
        CGlobals1.global_vars_dict1=Dictionary()
        CGlobals1.last_dict_sobel_line_pixels1=Dictionary()
    
    def func1(self):
        print("func11",self.x1)
        return 1

    def compare_colors1(color1, color2):
        if color1[0] == color2[0] and color1[1] == color2[1] and color1[2] == color2[2]:
            return 1

        return 0

    def draw_sqr_around_pixels2(bmp1:Bitmap, x1:int, y1:int, sqr_radius1:int, color1):

        for x1a in range( int(x1) - sqr_radius1 , int(x1) + sqr_radius1+1):
            for y1a in range(int(y1) - sqr_radius1 , int(y1) + sqr_radius1+1):
                try:
                    bmp1.SetPixel(x1a, y1a, color1)

                except:
                    err1=1


        return bmp1
    
    
   
   
    def copy_bitmap(bitmp1:Bitmap):
        return bitmp1.clone()
    
    def get_cord_xy_in_pixels_arr1(pixels_arr1:ArrayList,cord_ind1:int):
        x1=int(float(str(pixels_arr1[int(cord_ind1)]).split(",")[0]))
        y1=int(float(str(pixels_arr1[int(cord_ind1)]).split(",")[1]))
        if len(str(pixels_arr1[int(cord_ind1)]).split(","))==3:
            z1=int(float(str(pixels_arr1[int(cord_ind1)]).split(",")[2]))
            return (x1, y1, z1)
        
        
        return (x1,y1)




    def get_arr_from_ind_to_ind1(arr1:ArrayList,start_ind1:int,end_ind1:int):
        new_arr1=ArrayList()
        
        if start_ind1<=end_ind1:
            i1=start_ind1
            while i1<=min(end_ind1, arr1.count - 1):
                new_arr1.Add(arr1[i1])
                i1+=1
        
        if end_ind1 < start_ind1:
            i1=start_ind1
            while i1<=(arr1.count - 1):
                new_arr1.Add(arr1[i1])
                i1+=1

            i1=0
            while i1<=min(end_ind1, arr1.count - 1): #end_ind1
                new_arr1.Add(arr1(i1))
                i1+=1

        
        
        return new_arr1
            
            


    def get_double_cord_xy_in_pixels_arr2(pixels_arr1:ArrayList, cord_ind1:int):
        x1 = float(pixels_arr1[cord_ind1].split(",")[0])
        y1 = float(pixels_arr1[cord_ind1].split(",")[1])
        if len(pixels_arr1[cord_ind1].split(",")) == 3:
            z1 = float(pixels_arr1[cord_ind1].split(",")[2])
            return (x1, y1, z1)
        
        return (x1, y1)
    
    
    
    
    def delete_files1(path1:str, pattern1:str):
        
        if os.path.isfile(path1)==False:
            return -1
        files1:list=os.listdir(path1)
        
        for i1 in range(0,len(files1)):
            if os.path.isfile(path1+files1[i1]) and fnmatch.fnmatch(files1[i1], pattern1):
                os.remove(path1+files1[i1])
        


    def read_int_if_exist(key_path1:str,  key_val1:int):
        if CFile1.is_file_exist(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt"):
            key_val1 = int(CFile1.read_all_file_text(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_" + key_path1 + ".txt"))
            return key_val1

        
        
    def add_to_dict1(arr1:ArrayList):
        dict1:Dictionary = Dictionary()

        for i1 in range(0, arr1.count):
            dict1[arr1[i1]] = i1

        return dict1

    
    
    
    def dict_type_Int32_Double_to_str(dict1:Dictionary):
        

        str1:str = ""

        for i1 in range( 0 , dict1.count):
            if str1 != "" :
                str1 += "#"

            str1 += str(dict1.keys[i1]) + "," + str(dict1[dict1.keys[i1]])

        return str1




    def is_pixels_arr_overlap_pixels_dict1(self,pixels_arr1:ArrayList, pixels_dict:Dictionary):
        for i1 in range(0 , pixels_arr1.count ):
            if pixels_dict.ContainsKey(pixels_arr1[i1]):
                return True

        return False
