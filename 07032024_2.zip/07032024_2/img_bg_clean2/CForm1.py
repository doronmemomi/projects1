from CMarkingFieldInImage1 import CMarkingFieldInImage1
from CMacros1 import CMacros1
from bitmap import Bitmap
from ArrayList import ArrayList
from CEdgeDetection1 import CEdgeDetection1
from CFile1 import CFile1
from Dictionary import Dictionary
from CMarkingFieldInImageUtils1 import CMarkingFieldInImageUtils1
from vec_3d1 import vec_3d1

class CForm1:
    
    def __init__(self):
        self.file_name1="980376340_2\\195768205504__A"
        self.markingfldimg_obj1=CMarkingFieldInImage1()
        self.macros_obj1=CMacros1()
        self.compute_sobel=True        
        self.compute_sobel_imgs1=True
        
    def init1(self):
        from CPolynom_curve1 import CPolynom_curve1
        self.polynom_curve_obj1=CPolynom_curve1()








    def show_3d_prespective1(self):
        from CGlobals1 import CGlobals1
        angle_file_name1:str = "980115617\\980115617_angle"
        front_file_name1:str = "980115617\\980115617_front"
        sobel_ind1:int = 3 
        pixels_arr1:ArrayList = self.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + front_file_name1 + "_2d_pixels_sobel_" + str(sobel_ind1) + ".txt")
        pxl_arr1a:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixels_arr1, 1200, 1700)
        pxl_arr1b:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixels_arr1, 2800, 3600)
        pixels_arr1 = self.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + angle_file_name1 + "_2d_pixels_sobel_" + str(sobel_ind1) + ".txt")
        pxl_arr2a:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixels_arr1, 600, 1800)
        pixels_3d_arr2a = CGlobals1.convert_2darr_to_3d_arr(pxl_arr2a)

        pixels_3d_arr1a = CGlobals1.convert_2darr_to_3d_arr(pxl_arr1a)
        pixels_3d_arr1b = CGlobals1.convert_2darr_to_3d_arr(pxl_arr1b)

        rot_vec_3d_obj1:vec_3d1 = vec_3d1()
        rot_vec_3d_obj1.p1.x1 = 600
        rot_vec_3d_obj1.p1.y1 = 0
        rot_vec_3d_obj1.p1.z1 = 0

        rot_vec_3d_obj1.p2.x1 = 600
        rot_vec_3d_obj1.p2.y1 = 1500
        rot_vec_3d_obj1.p2.z1 = 0

        self.markingfldimg_obj1.rotate_3d_points_arr2(pixels_3d_arr1a, rot_vec_3d_obj1, CGlobals1.global_vars_dict1("x_deg_rot1"))
        self.markingfldimg_obj1.rotate_3d_points_arr2(pixels_3d_arr1b, rot_vec_3d_obj1, CGlobals1.global_vars_dict1("x_deg_rot1"))


        rot_vec_3d_obj2:vec_3d1 = vec_3d1()
        rot_vec_3d_obj2.p1.x1 = 600
        rot_vec_3d_obj2.p1.y1 = 600
        rot_vec_3d_obj2.p1.z1 = 0

        rot_vec_3d_obj2.p2.x1 = 600
        rot_vec_3d_obj1.p2.y1 = 600
        rot_vec_3d_obj2.p2.z1 = 40


        bmp1:Bitmap = CGlobals1.create_fill_bitmap(3000, 3000, (255, 0, 0, 0))

        self.markingfldimg_obj1.set_3d_arr_pixels_on_bmp1_prespective(pixels_3d_arr2a, bmp1, (255, 255, 200, 100))
        self.markingfldimg_obj1.set_3d_arr_pixels_on_bmp1_prespective(pixels_3d_arr1a, bmp1, (255, 255, 50, 255))
        self.markingfldimg_obj1.set_3d_arr_pixels_on_bmp1_prespective(pixels_3d_arr1b, bmp1, (255, 255, 255, 255))










    def remove_handle_above_the_frame1(self):
        from CGlobals1 import CGlobals1
        #todo load the current soberl image
        CGlobals1.form_obj1.compute_sobel=False
        CGlobals1.global_suffix_file_name1 = "_frame1"

        path_of_cache1:str = CGlobals1.global_path1 + self.file_name1 + "_sobel_cache1"
        CGlobals1.path_of_sobel_cache1 = self.path_of_cache1

        sobel_ind1:int = -1

        path_sign_sobel_ind1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"


        sobel_ind1 = int(CFile1.read_all_file_text(path_sign_sobel_ind1))

        path_of_bmp1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\\" + str(sobel_ind1) + ".bmp"
        bmp1:Bitmap = Bitmap(path_of_bmp1)
        bmp1b:Bitmap = Bitmap(path_of_bmp1)
        pixels_arr1:ArrayList =CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + str(sobel_ind1) + CGlobals1.global_suffix_file_name1 + ".txt")

        curve_pixels2:ArrayList =CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_filtered_curde3.txt")

        rev_pixels_arr1:ArrayList = pixels_arr1.clone()
        rev_pixels_arr1.Reverse()

        dict_res1a:Dictionary #todo= self.macros_obj1.combine_new_curve_in_frame_pixels_arr1(curve_pixels2, pixels_arr1)

        first_cord1a:str = pixels_arr1[dict_res1a["first_cord_ind1"]]
        first_cord1_on_new_curve:str = str(dict_res1a["last_min_dist_x1"]) + "," + str(dict_res1a["last_min_dist_y1"])

        dict_res1b:Dictionary #todo= self.macros_obj1.combine_new_curve_in_frame_pixels_arr1(curve_pixels2, rev_pixels_arr1)

        second_cord1a:str = pixels_arr1[rev_pixels_arr1.count - dict_res1b["first_cord_ind1"]]
        second_cord1_on_new_curve:str = str(dict_res1b["last_min_dist_x1"]) + "," + str(dict_res1b["last_min_dist_y1"])


        new_frame_curve1:ArrayList = ArrayList()
        for i1 in range( 0 , dict_res1a["first_cord_ind1"]+1):
            new_frame_curve1.Add(pixels_arr1[i1])

        first_ind_curve1:int=0
        while curve_pixels2[first_ind_curve1] != first_cord1_on_new_curve:
            first_ind_curve1 += 1

        last_ind_curve1:int = first_ind_curve1
        while curve_pixels2[last_ind_curve1] != second_cord1_on_new_curve:
            last_ind_curve1 += 1

        for i1 in range(first_ind_curve1 , last_ind_curve1+1):
            new_frame_curve1.Add(curve_pixels2[i1])


        for i1 in range(rev_pixels_arr1.count - dict_res1b["first_cord_ind1"] , pixels_arr1.count ):
            new_frame_curve1.Add(pixels_arr1[i1])



        self.markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame4.txt", new_frame_curve1)
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(new_frame_curve1, bmp1, (200, 60, 90,0))

        bmp2:Bitmap = Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")
        bmp3:Bitmap = Bitmap(bmp2.width, bmp2.height, (255, 255, 255,0))
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(new_frame_curve1, bmp3,(200, 60, 90,0))


        bmp3 = self.markingfldimg_obj1.paint_recursive3(bmp3, 20, 20, (200, 60, 90,0), (55, 100, 70,0))
        org_bmp1:Bitmap = Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg")

        org_bmp1 = self.markingfldimg_obj1.set_pixels_by_mask1(bmp3, (255, 255, 255,0), org_bmp1)
        org_bmp1 = self.markingfldimg_obj1.remove_around_object1(org_bmp1, (0, 0, 0, 0))





    def cut_handles_from_frame1(self):
        from CGlobals1 import CGlobals1
        
        self.prepare_sobel_images()
        
        CGlobals1.global_suffix_file_name1 = "_frame1"

        path_of_cache1:str = CGlobals1.global_path1 + self.file_name1 + "_sobel_cache1"
        CGlobals1.path_of_sobel_cache1 = path_of_cache1

        sobel_ind1:int = -1

        path_sign_sobel_ind1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"


        sobel_ind1 = int(CFile1.read_all_file_text(path_sign_sobel_ind1))

        path_of_bmp1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\\" + str(sobel_ind1) + ".bmp"
        bmp1:Bitmap = Bitmap(path_of_bmp1)
        bmp1b:Bitmap = Bitmap(path_of_bmp1)
        pixels_arr1:ArrayList = self.markingfldimg_obj1.load_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + str(sobel_ind1) + CGlobals1.global_suffix_file_name1 + ".txt")

        self.markingfldimg_obj1.set_pixels_arr_and_save2(pixels_arr1, bmp1b, (200, 30, 100,0), CGlobals1.global_path1 + "sobel_pics1\\p1_" + str(sobel_ind1) + ".bmp")
        dict_rect1:Dictionary = self.macros_obj1.find_rect_of_pixels_arr(pixels_arr1)
        min_x1:int = dict_rect1["min_x1"]
        max_x1:int = dict_rect1["max_x1"]
        max_y1:int = dict_rect1["max_y1"]

        dict_pixels1:Dictionary = CGlobals1.add_to_dict1(pixels_arr1)

        center_x1:int = int((min_x1 + max_x1) / 2)
        y1:int = 0
        while not dict_pixels1.ContainsKey(str(center_x1) + "," + str(y1)):
            y1 += 1

        center_top_pixel_ind1:int = dict_pixels1(str(center_x1) + "," + str(y1))

        dict_res_cord1:Dictionary = self.macros_obj1.search_for_start_pixels_between_frame_and_handles_above2(pixels_arr1)

        cord_start_pixels1 = dict_res_cord1["cord_xy_res1"]

        cord_start_pixels_prev_10_pxls1 = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, dict_res_cord1["ind_in_pixels1"] - 10)


        crop_bmp2:Bitmap = Bitmap(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.bmp")
        CGlobals1.global_vars_dict1["crop_bmp2_path1"] = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.bmp"
        bmp3:Bitmap = Bitmap(crop_bmp2.width, crop_bmp2.height, (255, 255, 255,0))

        CMarkingFieldInImageUtils1(pixels_arr1, bmp3, (200, 60, 90,0))

        CGlobals1.draw_sqr_around_pixels2(bmp3, cord_start_pixels1[0], cord_start_pixels1[1], 4, (2, 250, 100,0))

        CGlobals1.draw_sqr_around_pixels2(bmp3, cord_start_pixels_prev_10_pxls1[0], cord_start_pixels_prev_10_pxls1[1], 4, Color.FromArgb(200, 50, 30,0))

        m1:float = (cord_start_pixels1[1] - cord_start_pixels_prev_10_pxls1[1]) / (cord_start_pixels1[0] - cord_start_pixels_prev_10_pxls1[0])
        new_cord_xy1:ArrayList = ArrayList()
        new_cord_xy1.Add(cord_start_pixels1[0] + 50)
        new_cord_xy1.Add( cord_start_pixels1[1] + 50 * m1)

        new_cord_xy2:ArrayList = ArrayList()
        new_cord_xy2.Add(cord_start_pixels1[0] + 2500)
        new_cord_xy2.Add(cord_start_pixels1[1] + 2500 * m1)


        CGlobals1.draw_sqr_around_pixels2(bmp3, new_cord_xy1[0], new_cord_xy1[1], 4, (200, 50, 30,0))

        pixel_line_find_curve1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points2(cord_start_pixels1, new_cord_xy1)
        pixel_line_top1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points2(cord_start_pixels1, new_cord_xy2)

        dec_delta_y1:int = 4
        dec_delta_x1:int = -10
        sobel_ind1b:int
        curves_arr1:ArrayList=None
        last_curve1:ArrayList=None
        dict_all_sobel_curves_res1:Dictionary = Dictionary()
        max_x1_of_curve1:int=-1
        last_ok_curve_by_sobel1:int = -1
        start_sobel_ind1:int = 5
        end_sobel_ind1:int = 300
        last_ok_curve_by_sobel1=CGlobals1.read_int_if_exist("last_ok_curve_by_sobel1", last_ok_curve_by_sobel1)
        if last_ok_curve_by_sobel1 != -1:
            start_sobel_ind1 = last_ok_curve_by_sobel1
            end_sobel_ind1 = last_ok_curve_by_sobel1 + 10


        for sobel_ind1b in range(start_sobel_ind1, end_sobel_ind1+1,  5):
            
            
            path_of_bmp1b:str = ""
            path_of_bmp1b = path_of_cache1 + "\\" + str(sobel_ind1b) + ".bmp"
            bmp_sobel1:Bitmap = Bitmap(path_of_bmp1b)
            curves_arr1 = self.markingfldimg_obj1.find_curves1(cord_start_pixels1[0] + dec_delta_x1, cord_start_pixels1[1] - dec_delta_y1, bmp_sobel1)

            x_offset1:int = cord_start_pixels1[0] + dec_delta_x1 - 5
            y_offset1:int = cord_start_pixels1[1] - dec_delta_y1 - 5
            cord_xy3:ArrayList=ArrayList()
            cord_xy3.Add(cord_start_pixels1[0] - x_offset1)
            cord_xy3.Add(cord_start_pixels1[1] - y_offset1)

            
            curves_arr3:ArrayList = ArrayList()
            for curve_ind2 in range(0 ,curves_arr1.count):
                dict_rect_res1:Dictionary = self.macros_obj1.find_rect_of_pixels_arr(curves_arr1[curve_ind2])
                curves_arr2:ArrayList = self.markingfldimg_obj1.get_curve_from_pixels_arr_by_region(curves_arr1[curve_ind2], 10, 0, dict_rect_res1["max_x1"] - 1, 1070)

                

                for curve_ind3 in range(0 , curves_arr2.count ):
                    curves_arr3.Add(curves_arr2[curve_ind3])


            curve_ind1b:int = self.markingfldimg_obj1.find_curve_nearset_to_cord_xy1(curves_arr3, cord_xy3)

            curve_pxls_arr2:ArrayList = CGlobals1.add_val_to_pxls_arr1(curves_arr3[curve_ind1b], x_offset1, y_offset1)
            bmp_sobel2:Bitmap = Bitmap(path_of_bmp1b)
            self.markingfldimg_obj1.set_pixels_arr_and_save2(curve_pxls_arr2, bmp_sobel2, (255, 20, 20,0), CGlobals1.global_path1 + "sobel_pics1\\bmp_sobel2_" + str(sobel_ind1b) + ".bmp")

            curve_dict1:Dictionary = CGlobals1.add_to_dict1(curve_pxls_arr2)

            curve_contain_start_pixel1:bool = False
            for x3 in range ( cord_start_pixels1[0] - 1 , cord_start_pixels1[0] + 1+1):
                for y3 in range (cord_start_pixels1[1] - 1 , cord_start_pixels1[1] + 1+1):
                    if curve_dict1.ContainsKey(str(x3) + "," + str(y3)):
                        curve_contain_start_pixel1 = True
                    


            if curve_dict1.ContainsKey(str(cord_start_pixels1[0]) + "," + str(cord_start_pixels1[1])) or curve_contain_start_pixel1:

                dict_rect_curve1:Dictionary = self.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr2)
                if max_x1_of_curve1 == -1:
                    max_x1_of_curve1 = dict_rect_curve1["max_x1"] - 10

                if max_x1_of_curve1 <= dict_rect_curve1["max_x1"]:
                    max_x1_of_curve1 = dict_rect_curve1["max_x1"] - 10
                    last_ok_curve_by_sobel1 = sobel_ind1b

            pixel_arr2:ArrayList = CGlobals1.dict_keys_to_arr1(dict_pixels1)

            CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pxls_arr2, bmp_sobel1, (100, 50, 200,0))
            bmp_sobel1.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\bmp_sobel1_" + str(sobel_ind1b) + ".bmp")
            filtered_curve1:ArrayList = ArrayList()
            
            count_min_dist_to_line1:int = 0
            first_ind_curve_min_dist_line1:int = -1
            last_ind_curve_min_dist_line1:int = -1
            ind_ok_curve_arr1:ArrayList = ArrayList()
            dict_inds1:Dictionary = Dictionary()

            for i5  in range(0,pixel_line_find_curve1.count):

                dict_res1:Dictionary = self.markingfldimg_obj1.check_min_dist_to_curve1(curve_pxls_arr2, CGlobals1.get_cord_xy_in_pixels_arr1(pixel_line_find_curve1, i5), 20)

                min_dist2:int = dict_res1["min_dist1"]


                if min_dist2 < 3:
                    count_min_dist_to_line1 += 1
                    if first_ind_curve_min_dist_line1 == -1:
                        first_ind_curve_min_dist_line1 = dict_res1["min_dist_ind1"]

                    last_ind_curve_min_dist_line1 = dict_res1["min_dist_ind1"]
                    if not dict_inds1.ContainsKey(dict_res1["min_dist_ind1"]):

                        ind_ok_curve_arr1.Add(dict_res1["min_dist_ind1"])
                        dict_inds1[dict_res1["min_dist_ind1"]] = 1

            dict_curve_res1:Dictionary = Dictionary()
            dict_curve_res1["curve_pxls_arr2"] = curve_pxls_arr2
            dict_curve_res1["count_min_dist_to_line1"] = count_min_dist_to_line1
            dict_curve_res1["first_ind_curve_min_dist_line1"] = first_ind_curve_min_dist_line1
            dict_curve_res1["last_ind_curve_min_dist_line1"] = last_ind_curve_min_dist_line1
            dict_curve_res1["ind_ok_curve_arr1"] = ind_ok_curve_arr1

            dict_all_sobel_curves_res1[sobel_ind1b] = dict_curve_res1
            for i5 in range(0 , curve_pxls_arr2.count):

                dict_res1:Dictionary = self.markingfldimg_obj1.check_min_dist_to_curve1(pixels_arr1, CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr2, i5), 20)
                min_dist1:int = dict_res1["min_dist1"]

            bmp4:Bitmap = Bitmap(8000, 1500, (255, 255, 255,0))

            self.markingfldimg_obj1.set_pixel_arr_on_bmp2_with_zoom1(curve_pxls_arr2, bmp4, (100, 50, 200,0), 4)

            last_curve1 = curve_pxls_arr2

        max_count_min_dist_to_line1:int = -1
        for key_ind1 in range(0 , dict_all_sobel_curves_res1.count):
            count_min_dist_to_line1:int = dict_all_sobel_curves_res1[dict_all_sobel_curves_res1.keys[key_ind1]]["count_min_dist_to_line1"]
            if max_count_min_dist_to_line1 < count_min_dist_to_line1:
                max_count_min_dist_to_line1 = count_min_dist_to_line1

        max_width_rect1:int = -1
        max_width_rect_ind1:int = -1
        max_len_curve_pxls_arr2:int = -1
        max_len_curve_pxls_arr2_ind1:int = -1
        for key_ind1 in range(0, dict_all_sobel_curves_res1.count):
            count_min_dist_to_line1:int = dict_all_sobel_curves_res1[dict_all_sobel_curves_res1.keys[key_ind1]]["count_min_dist_to_line1"]
            if max_count_min_dist_to_line1 / 3 <= count_min_dist_to_line1:
                curve_pxls_arr2:ArrayList = dict_all_sobel_curves_res1[dict_all_sobel_curves_res1.keys[key_ind1]]["curve_pxls_arr2"]
                dict_rect1a:Dictionary = self.macros_obj1.find_rect_of_pixels_arr(curve_pxls_arr2)

                w1:int = abs(dict_rect1a["min_x1"] - dict_rect1a["max_x1"])
                if max_width_rect1 <= w1:
                    max_width_rect1 = w1
                    max_width_rect_ind1 = key_ind1



                if curve_pxls_arr2.count > max_len_curve_pxls_arr2:
                    max_len_curve_pxls_arr2 = curve_pxls_arr2.count
                    max_len_curve_pxls_arr2_ind1 = key_ind1

        max_width_rect_ind1=CGlobals1.read_int_if_exist("max_width_rect_ind1", max_width_rect_ind1)
        max_len_curve_pxls_arr2_ind1 = 10
        CGlobals1.write_int1("max_width_rect_ind1", max_width_rect_ind1)
        CGlobals1.write_int1("last_ok_curve_by_sobel1", last_ok_curve_by_sobel1)

        ok_start_curve_inds1:ArrayList=None
        org_curve1:ArrayList=None


        ok_start_curve_inds1 = dict_all_sobel_curves_res1[last_ok_curve_by_sobel1]["ind_ok_curve_arr1"]
        org_curve1 = dict_all_sobel_curves_res1[last_ok_curve_by_sobel1]["curve_pxls_arr2"]

        path_of_last_ok_curve_by_sobel1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\\" + str(last_ok_curve_by_sobel1) + ".bmp"
        bmp_last_ok_curve_by_sobel1:Bitmap = Bitmap(path_of_last_ok_curve_by_sobel1)


        new_ok_start_curve1:ArrayList = ArrayList()
        for i1 in range(0 , ok_start_curve_inds1.count):
            new_ok_start_curve1.Add(org_curve1[ok_start_curve_inds1[i1]])



        first_ind1:int = 0
        last_ind1:int = 0
        while org_curve1[first_ind1] != new_ok_start_curve1[0]:
            first_ind1 += 1
            last_ind1 += 1

        for i1 in range(0 , dict_all_sobel_curves_res1.count):
            if dict_all_sobel_curves_res1.keys[i1] == last_ok_curve_by_sobel1:
                max_width_rect_ind1 = i1


        path_of_cache2:str = CGlobals1.global_path1 + self.file_name1 + "_sobel_cache1\\" + str(dict_all_sobel_curves_res1.keys[max_width_rect_ind1]) + ".bmp"
        bmp3 = Bitmap(path_of_cache2)
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(org_curve1, bmp3, (100, 100, 220,0))
        bmp3.SaveAs(CGlobals1.global_path1 + "sobel_pics1\\org_curve1.bmp")

        start_pixel_str1:str = str(cord_start_pixels1[0]) + "," + str(cord_start_pixels1[1])
        org_crve_clone1b:ArrayList = org_curve1.Clone()
        org_curve1.Insert(0, start_pixel_str1)
        org_crve_clone1:ArrayList = org_curve1.Clone()
        false_positive_cords_arr1:ArrayList = ArrayList()
        filtered_curde_res3:Dictionary = Dictionary()
        override_curve_by_New_complete_curve1:bool = False
        CGlobals1.global_vars_dict1["cuvature3_loop1"] = 0

        filtered_curde_res3 = self.markingfldimg_obj1.filter_curve_by_curvature3(org_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, first_ind1), pixel_line_top1, false_positive_cords_arr1, dict_pixels1)
        while filtered_curde_res3.ContainsKey("false_positive_cords_arr1"):
            new_false_positive_cords_arr1:ArrayList = filtered_curde_res3["false_positive_cords_arr1"]


            for i3 in range( 0 , new_false_positive_cords_arr1.count ):
                false_positive_cords_arr1.Add(new_false_positive_cords_arr1[i3])

            new_false_positive_cords_arr1 = filtered_curde_res3["false_positive_cords_from_sub_curves1"]
            for i3 in range(0 , new_false_positive_cords_arr1.count ):
                false_positive_cords_arr1.Add(new_false_positive_cords_arr1[i3])

            if override_curve_by_New_complete_curve1:
                org_curve1 = filtered_curde_res3["new_complete_curve1"]

            filtered_curde_res3 = self.markingfldimg_obj1.filter_curve_by_curvature3(org_curve1, CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, first_ind1), pixel_line_top1, false_positive_cords_arr1, dict_pixels1)

        filtered_curde3:ArrayList = filtered_curde_res3["new_complete_curve1"]

        bmp_curves1:Bitmap = Bitmap(str(CGlobals1.global_vars_dict1["crop_bmp2_path1"]))
        self.markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_between_frame_and_handle1.txt", filtered_curde3)


        self.markingfldimg_obj1.set_pixels_arr_and_save2(filtered_curde3, bmp_curves1, (255, 20, 100,0), CGlobals1.global_path1 + "sobel_pics1\\sub_curves_f1.bmp")
        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(filtered_curde3, bmp_last_ok_curve_by_sobel1, (55, 250, 100,0))

        self.markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\\sub_curves_f1.txt", filtered_curde3)
        dict_false_positive_cords:Dictionary = Dictionary()

        false_positive_cords1:ArrayList = ArrayList()
        for c_ind1 in range(0 , filtered_curde3.count - 2+1):
            dict_res1:Dictionary = CMarkingFieldInImage1Utils1.find_the_tangent_to_curve_from_cord_ind(CGlobals1.form_obj1.markingfldimg_obj1, filtered_curde3, c_ind1)
            curve_arr1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(dict_res1["rot_curve_pixels"], dict_res1["cord_ind1"], dict_res1["last_cord_ind1"])
            good_curve1:bool = True
            
            cord_xy3a = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, 0)
            for i2 in range(0 , curve_arr1.count):
                cord_xy3b = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i2)
                if cord_xy3b[0] < cord_xy3a[0] - 1:
                    good_curve1 = False
                    if not dict_false_positive_cords.ContainsKey(filtered_curde3[dict_res1["cord_ind1"] + i2]):
                        false_positive_cords_arr1.Add(filtered_curde3[dict_res1["cord_ind1"] + i2])
                        dict_false_positive_cords[filtered_curde3[dict_res1["cord_ind1"] + i2]] = 1


            if not good_curve1:


                false_positive_cords1.Add(c_ind1)




        self.markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_filtered_curde3.txt", filtered_curde3)

        #return
        
        curve_inds_cut_with_line1:ArrayList = ArrayList()
        min_dist_by_curve1:Dictionary = Dictionary()
        min_dist_ind_by_curve1:Dictionary = Dictionary()

        for curve_ind1 in range(0 , curves_arr1.count):
            curve_pxls1:ArrayList = curves_arr1[curve_ind1]
            
            curve_pxls2:ArrayList = CGlobals1.add_val_to_pxls_arr1(curve_pxls1, cord_start_pixels1[0] - (5 - dec_delta_x1), cord_start_pixels1[1] - (5 + dec_delta_y1))
            dict_curve_pxls1:Dictionary = CGlobals1.add_to_dict1(curve_pxls2)

            line_pxl_ind1:int
            cut_with_line1:bool = False
            for line_pxl_ind1 in range(0 , pixel_line_find_curve1.count):
                if dict_curve_pxls1.ContainsKey(pixel_line_find_curve1[line_pxl_ind1]):
                    
                    cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(pixel_line_find_curve1, line_pxl_ind1)
                    
                    dist1:float = pow(pow(cord_xy2[0] - cord_start_pixels1[0], 2) + pow(cord_xy2[1] - cord_start_pixels1[1], 2), 0.5)
                    if dist1 > 5:

                        if not min_dist_by_curve1.ContainsKey(curve_ind1):
                            min_dist_by_curve1[curve_ind1] = dist1
                            min_dist_ind_by_curve1[curve_ind1] = dict_curve_pxls1[pixel_line_find_curve1[line_pxl_ind1]]
                        else:
                            if min_dist_by_curve1[curve_ind1] > dist1:
                                min_dist_by_curve1[curve_ind1] = dist1
                                min_dist_ind_by_curve1[curve_ind1] = dict_curve_pxls1[pixel_line_find_curve1[line_pxl_ind1]]


                    cut_with_line1 = True
            if cut_with_line1:
                curve_inds_cut_with_line1.Add(curve_ind1)

        #Return
        bmp3 = crop_bmp2

        CGlobals1.draw_sqr_around_pixels2(bmp3, new_cord_xy1[0], new_cord_xy1[1], 4, (200, 50, 30,0))
        CGlobals1.draw_sqr_around_pixels2(bmp3, cord_start_pixels1[0], cord_start_pixels1[1], 4, (200, 50, 100,0))


        curve_pxls3:ArrayList = CGlobals1.add_val_to_pxls_arr1(curves_arr1[min_dist_ind_by_curve1.keys[0]], cord_start_pixels1[0] - 5 + dec_delta_x1, cord_start_pixels1[1] - 5 - dec_delta_y1)


        cord_min_dist1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls3, min_dist_ind_by_curve1(min_dist_ind_by_curve1.keys[0]) + 0)
        CGlobals1.draw_sqr_around_pixels2(bmp3, cord_min_dist1[0], cord_min_dist1[1], 5, (0, 200, 0,0))

        sub_curve1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls3, min_dist_ind_by_curve1(min_dist_ind_by_curve1.keys[0]) - 10, min_dist_ind_by_curve1[min_dist_ind_by_curve1.keys[0]] + 50)

        CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(sub_curve1, bmp3, (100, 50, 200,0))
        cord_xy4 = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, 3)
        CGlobals1.draw_sqr_around_pixels2(bmp3, cord_xy4[0], cord_xy4[1], 8, (0, 20, 220,0))























        
    def prepare_sobel_images(self):
        from CGlobals1 import CGlobals1
        
        sobel_pics1_path:str = CGlobals1.global_path1 + "sobel_pics1\\"
        if not CFile1.is_directory_exist(sobel_pics1_path):
                CFile1.create_directory(sobel_pics1_path)
       
       
       
        sobel_bmp1:Bitmap=None
        
        
        path_of_cache1:str = CGlobals1.global_path1 + self.file_name1 + "_sobel_cache1"
        CGlobals1.path_of_sobel_cache1 = path_of_cache1
        
        

        if self.compute_sobel:

            

            bmp1:Bitmap = Bitmap(CGlobals1.global_path1 + self.file_name1 + ".jpg")
            crop_bmp1:Bitmap =None
            if not CFile1.is_file_exist(CGlobals1.global_path1 + self.file_name1 + "_crop1.bmp"):
                crop_bmp1 = self.markingfldimg_obj1.crop_img_by_color(bmp1, (255, 255, 255,0))
                crop_bmp1.SaveAs(CGlobals1.global_path1 + self.file_name1 + "_crop1.bmp")

            if not CFile1.is_file_exist(CGlobals1.global_path1 + self.file_name1 + "_mono1.bmp"):
                bmp2:Bitmap = CMarkingFieldInImageUtils1.rgb_to_monochrome1(bmp1)
                bmp2.SaveAs(CGlobals1.global_path1 + self.file_name1 + "_mono1.bmp")

            crop_bmp1=Bitmap(CGlobals1.global_path1 + self.file_name1 + "_crop1.bmp")
            sobel_bmp1 = self.markingfldimg_obj1.do_sobel_oparator1(crop_bmp1)
            sobel_bmp1.SaveAs(CGlobals1.global_path1 + self.file_name1 + "_s1.bmp")

           
        
        
        self.markingfldimg_obj1.bmp1 = Bitmap(CGlobals1.global_path1 + self.file_name1 + "_crop1.bmp")
        copy_bmp1:Bitmap = self.markingfldimg_obj1.bmp1.clone()

        copy_bmp1.SaveAs(CGlobals1.global_path1 + self.file_name1 + "_test1.bmp")
        self.markingfldimg_obj1.read_sobel_values1(CGlobals1.global_path1 + self.file_name1 + "_sobel_vals1.txt")
        
        
        sobel_bmp1 = Bitmap(CGlobals1.global_path1 + self.file_name1 + "_s1.bmp")

        CGlobals1.current_bmp1 = sobel_bmp1
        
        
        





        x_start2:int = int(sobel_bmp1.width/2) #center of image top of the image
        y_start2:int = 0#top of the image

        self.markingfldimg_obj1.bmp1 = sobel_bmp1.clone()
        cord1 = self.markingfldimg_obj1.find_start_point1(x_start2, y_start2)
        x_start2 = cord1[0]
        y_start2 = cord1[1]
        if self.compute_sobel_imgs1:
            path_of_cache1:str = CGlobals1.global_path1 + self.file_name1 + "_sobel_cache1"
            CGlobals1.path_of_sobel_cache1 = path_of_cache1
            if not CFile1.is_directory_exist(path_of_cache1):
                CFile1.create_directory(path_of_cache1)

            self.markingfldimg_obj1.create_cache_of_sobel_files(path_of_cache1)
            CGlobals1.dict_mono_colors1=Dictionary()

        return






















        
        
        
        
        
        
        
    def find_edge_curve1(self):
        from CGlobals1 import CGlobals1
        cut_frame_only1:str = ""
        CGlobals1.clear_all_caches1()

        CGlobals1.global_suffix_file_name1 = "_frame1"

        path_of_cache1:str= CGlobals1.global_path1 + self.file_name1 + "_sobel_cache1"
        CGlobals1.path_of_sobel_cache1 = path_of_cache1

        sobel_ind1:int = -1

        path_sign_sobel_ind1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"
        



        self.markingfldimg_obj1.bmp1 = Bitmap(CGlobals1.global_path1 + self.file_name1 + "_crop1.bmp")
        copy_bmp1:Bitmap =self.markingfldimg_obj1.bmp1.clone()
        copy_bmp1.SaveAs(CGlobals1.global_path1 + self.file_name1 + "_test1.bmp")
        self.markingfldimg_obj1.read_sobel_values1(CGlobals1.global_path1 + self.file_name1 + "_sobel_vals1.txt")

        CGlobals1.current_bmp1 = Bitmap(CGlobals1.global_path1 + self.file_name1 + "_s1.bmp")


        line_to_search_start_sobel_pixels1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points(500, 0, 500, 2000)
        self.markingfldimg_obj1.cur_sobel_ind_val1 = 0

        edge_detection_obj1:CEdgeDetection1 = CEdgeDetection1()

        edge_detection_obj1.loop_on_sobel_vals4(line_to_search_start_sobel_pixels1)
