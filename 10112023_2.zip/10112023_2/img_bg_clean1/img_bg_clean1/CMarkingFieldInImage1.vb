﻿Imports System.Globalization
Imports System.Runtime.Intrinsics.X86

Public Class CMarkingFieldInImage1

    Public form_obj1 As Form1

    Public x_start2 As Integer
    Public y_start2 As Integer
    Public color_of_region As Color = Color.FromArgb(255, 120, 100)
    Public color_of_sobel As Color = Color.FromArgb(255, 255, 255)
    Public color_of_bg As Color = Color.FromArgb(0, 0, 0)

    Public bmp1 As Bitmap
    Public bmp_current_sobel As Bitmap

    Public success_status As String = ""

    Public cur_sobel_ind_val1 As Integer = -1
    Public last_sobel_ind_val1 As Integer = -1

    Public pixels_3d_cords_arr As ArrayList = New ArrayList()

    Public pixels_cords_arr1 As ArrayList = New ArrayList()
    Public max_pixels_cords_arr1 As ArrayList = New ArrayList()

    Public Function rotate_around_arbitrary_axis(in_vec_3d_1 As vec_3d1, in_rotate_p1 As point_3d1, rot_deg_around_axis1 As Double)
        Dim delta_x1 As Double = in_vec_3d_1.p1.x1
        Dim delta_y1 As Double = in_vec_3d_1.p1.y1
        Dim delta_z1 As Double = in_vec_3d_1.p1.z1

        Dim vec_3d_1 As vec_3d1 = in_vec_3d_1.clone1()
        Dim rotate_p1 As point_3d1 = in_rotate_p1.clone1()

        vec_3d_1.p1.x1 -= delta_x1
        vec_3d_1.p1.y1 -= delta_y1
        vec_3d_1.p1.z1 -= delta_z1


        vec_3d_1.p2.x1 -= delta_x1
        vec_3d_1.p2.y1 -= delta_y1
        vec_3d_1.p2.z1 -= delta_z1

        rotate_p1.x1 -= delta_x1
        rotate_p1.y1 -= delta_y1
        rotate_p1.z1 -= delta_z1


        Dim rot_deg1 As Double = Math.Atan(vec_3d_1.p2.y1 / vec_3d_1.p2.z1) / (Math.PI / 180.0)
        If (vec_3d_1.p2.z1 = 0) Then
            rot_deg1 = 90
        End If

        vec_3d_1.p1.rotate_x1(rot_deg1)
        vec_3d_1.p2.rotate_x1(rot_deg1)
        rotate_p1.rotate_x1(rot_deg1)





        Dim rot_deg2 As Double = -Math.Atan(vec_3d_1.p2.x1 / vec_3d_1.p2.z1) / (Math.PI / 180.0)
        If (vec_3d_1.p2.z1 = 0) Then
            rot_deg2 = 90
        End If


        vec_3d_1.p1.rotate_y1(rot_deg2)
        vec_3d_1.p2.rotate_y1(rot_deg2)
        rotate_p1.rotate_y1(rot_deg2)


        vec_3d_1.p1.rotate_z1(rot_deg_around_axis1)
        vec_3d_1.p2.rotate_z1(rot_deg_around_axis1)
        rotate_p1.rotate_z1(rot_deg_around_axis1)


        vec_3d_1.p1.rotate_y1(-rot_deg2)
        vec_3d_1.p2.rotate_y1(-rot_deg2)
        rotate_p1.rotate_y1(-rot_deg2)

        vec_3d_1.p1.rotate_x1(-rot_deg1)
        vec_3d_1.p2.rotate_x1(-rot_deg1)
        rotate_p1.rotate_x1(-rot_deg1)



        vec_3d_1.p1.x1 += delta_x1
        vec_3d_1.p1.y1 += delta_y1
        vec_3d_1.p1.z1 += delta_z1


        vec_3d_1.p2.x1 += delta_x1
        vec_3d_1.p2.y1 += delta_y1
        vec_3d_1.p2.z1 += delta_z1

        rotate_p1.x1 += delta_x1
        rotate_p1.y1 += delta_y1
        rotate_p1.z1 += delta_z1

        in_rotate_p1.x1 = rotate_p1.x1
        in_rotate_p1.y1 = rotate_p1.y1
        in_rotate_p1.z1 = rotate_p1.z1


    End Function
    Public Function rotate_2d_pixels_arr(pixels_arr1 As ArrayList, arbitrary_3d_axis As vec_3d1, rot_angle1 As Double)
        Dim i1 As Integer

        Dim new_2d_pixels_arr1 As ArrayList = New ArrayList()

        For i1 = 0 To pixels_arr1.Count - 1
            Dim point_3d_obj1 As point_3d1 = New point_3d1(Double.Parse(pixels_arr1(i1).ToString().Split(",")(0)), Double.Parse(pixels_arr1(i1).ToString().Split(",")(1)), 0)

            If pixels_arr1(i1).ToString().Split(",").Count = 3 Then
                point_3d_obj1 = New point_3d1(Double.Parse(pixels_arr1(i1).ToString().Split(",")(0)), Double.Parse(pixels_arr1(i1).ToString().Split(",")(1)), Double.Parse(pixels_arr1(i1).ToString().Split(",")(2)))

            End If
            rotate_around_arbitrary_axis(arbitrary_3d_axis, point_3d_obj1, rot_angle1)
            If pixels_arr1(i1).ToString().Split(",").Count = 3 Then
                new_2d_pixels_arr1.Add(point_3d_obj1.x1.ToString() + "," + point_3d_obj1.y1.ToString() + "," + point_3d_obj1.z1.ToString())
            Else
                new_2d_pixels_arr1.Add(point_3d_obj1.x1.ToString() + "," + point_3d_obj1.y1.ToString())

            End If
            Dim d1 As Integer = 1
        Next

        Return new_2d_pixels_arr1
    End Function

    Public Function rotate_3d_points_arr(arbitrary_3d_axis As vec_3d1, rot_angle1 As Double)
        Dim i1 As Integer


        For i1 = 0 To pixels_3d_cords_arr.Count - 1
            Dim point_3d_obj1 As point_3d1 = pixels_3d_cords_arr(i1)
            rotate_around_arbitrary_axis(arbitrary_3d_axis, point_3d_obj1, rot_angle1)
            Dim d1 As Integer = 1
        Next
    End Function

    Public Function rotate_3d_points_arr2(pixels_3d_cords_arr As ArrayList, arbitrary_3d_axis As vec_3d1, rot_angle1 As Double)
        Dim i1 As Integer


        For i1 = 0 To pixels_3d_cords_arr.Count - 1
            Dim point_3d_obj1 As point_3d1 = pixels_3d_cords_arr(i1)
            rotate_around_arbitrary_axis(arbitrary_3d_axis, point_3d_obj1, rot_angle1)
            Dim d1 As Integer = 1
        Next
    End Function

    Public Function move_3d_points_arr2(pixels_3d_cords_arr As ArrayList, x_move1 As Double, y_move1 As Double, z_move1 As Double)
        Dim i1 As Integer


        For i1 = 0 To pixels_3d_cords_arr.Count - 1
            Dim point_3d_obj1 As point_3d1 = pixels_3d_cords_arr(i1)
            point_3d_obj1.x1 += x_move1
            point_3d_obj1.y1 += y_move1
            point_3d_obj1.z1 += z_move1
            Dim d1 As Integer = 1
        Next
    End Function
    Public Function find_start_point1(x_start1 As Integer, y_start1 As Integer)
        x_start2 = x_start1
        y_start2 = y_start1

        Dim dir1 As Integer = 1
        Try

            While (bmp1.GetPixel(x_start2, y_start2).R <> color_of_sobel.R Or
                    bmp1.GetPixel(x_start2, y_start2).G <> color_of_sobel.G Or
                    bmp1.GetPixel(x_start2, y_start2).B <> color_of_sobel.B) And y_start2 < bmp1.Height - 1
                'y_start2 += 1
                y_start2 += dir1

            End While
        Catch ex As Exception
            y_start2 = bmp1.Height - 10
            dir1 = -1
            While (bmp1.GetPixel(x_start2, y_start2).R <> color_of_sobel.R Or
                bmp1.GetPixel(x_start2, y_start2).G <> color_of_sobel.G Or
                bmp1.GetPixel(x_start2, y_start2).B <> color_of_sobel.B) And y_start2 < bmp1.Height - 1
                'y_start2 += 1
                y_start2 += dir1

            End While

        End Try


        Return New Integer() {x_start2, y_start2}
    End Function

    Public Function get_dir_arr1(ind1 As Integer, ind2 As Integer)
        Try
            Dim dir_arr1_val As Integer = CGlobals1.dir_arr1(ind1, ind2)
            Return dir_arr1_val
        Catch ex As Exception

        End Try
        Throw New Exception()
        Return -1
    End Function

    Public Function next_pixels_loop1()
        success_status = ""
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp_current_sobel)
        Dim to_Stop1 As Integer = 0
        pixels_3d_cords_arr = New ArrayList()
        pixels_cords_arr1 = New ArrayList()
        Dim wrong_pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim org_x_start2 As Integer = x_start2
        Dim org_y_start2 As Integer = y_start2

        Dim cord_ind1 As Integer
        Dim last_cord_ind1 As Integer
        Dim count_to_stop2 As Integer = 0
        Dim min_pixel_around1 As Integer = 0
        If CGlobals1.current_max_sobel_ind1 = 13 Then
            Dim d1 As Integer = 1
        End If
        While to_Stop1 = 0
            Dim color_set1 As Color = copy_bmp1.GetPixel(x_start2, y_start2)
            If CGlobals1.compare_colors1(color_set1, color_of_sobel) = 0 Then
                Dim e1 As Integer = 1
            End If



            copy_bmp1.SetPixel(x_start2, y_start2, color_of_region)
            pixels_cords_arr1.Add(x_start2.ToString() + "," + y_start2.ToString())
            pixels_3d_cords_arr.Add(New point_3d1(x_start2, y_start2, 0))
            'If org_bmp1 IsNot Nothing Then

            'org_bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(255, 0, 0, 0))
            'End If
            'color_a is not the edge color
            'color_b is the edge color

            'search for cord_ind that is the previues pixel_point:
            cord_ind1 = 0

            If pixels_cords_arr1.Count > 1 Then

                Dim ind2 As Integer

                For ind2 = 0 To CGlobals1.dir_arr1.Length / 2 - 1
                    Dim new_x1 As Integer = x_start2 + get_dir_arr1(ind2, 0)
                    Dim new_y1 As Integer = y_start2 + get_dir_arr1(ind2, 1)
                    Dim count_pixel_around_val2 As Integer = count_pixel_around(copy_bmp1, new_x1, new_y1, color_of_sobel)
                    If count_pixel_around_val2 <= min_pixel_around1 Then
                        copy_bmp1.SetPixel(new_x1, new_y1, color_of_bg)
                    End If
                Next

                'ברגע שיש כבר נקודה אחת שסימנו - אז תמיד מתחילים לחפש מהנקודה הקודמת עם כיוון השעון
                Dim cord_str1 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 2).ToString().Split(",")
                Dim x1 As Integer = Integer.Parse(cord_str1(0))
                Dim y1 As Integer = Integer.Parse(cord_str1(1))
                Dim to_stop3 As Integer = 0
                'לולאה עד שמגיעים לנקודה הקודמת שממנה נחפש עם כיון השעון
                While to_stop3 = 0
                    Try


                        Dim new_x1 As Integer = x_start2 + get_dir_arr1(cord_ind1, 0)
                        Dim new_y1 As Integer = y_start2 + get_dir_arr1(cord_ind1, 1)
                        If new_x1 = x1 And new_y1 = y1 Then
                            to_stop3 = 1
                        Else
                            cord_ind1 += 1

                        End If
                    Catch ex As Exception
                        to_stop3 = 1
                    End Try
                End While

            End If
            '--


            Dim edge_color1 As Color = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1))
            Dim bg_color1 As Color = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1 + 1, 0), y_start2 + get_dir_arr1(cord_ind1 + 1, 1))
            Dim count_pixel_around_val1 As Integer = count_pixel_around(copy_bmp1, x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1), edge_color1)
            last_cord_ind1 = cord_ind1

            Dim to_stop2 As Integer = 0
            Dim failed_to_find_next_pixel1 As Integer = 0
            'מחפשים את הנקודה של סובל כאשר נקודה לפניה היא של הרקע
            While (CGlobals1.compare_colors1(edge_color1, color_of_bg) = 1 And CGlobals1.compare_colors1(bg_color1, color_of_sobel) = 1 And count_pixel_around_val1 > 1) = False And to_stop2 = 0
                last_cord_ind1 = cord_ind1

                Try
                    edge_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1))
                    bg_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1 + 1, 0), y_start2 + get_dir_arr1(cord_ind1 + 1, 1))

                    count_pixel_around_val1 = count_pixel_around(copy_bmp1, x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1), edge_color1)

                    If (x_start2 + get_dir_arr1(cord_ind1 + 1, 0)) = org_x_start2 And
                        (y_start2 + get_dir_arr1(cord_ind1 + 1, 1)) = org_y_start2 Then

                        Dim ind_pixel1 As Integer
                        For ind_pixel1 = 0 To pixels_cords_arr1.Count - 1
                            Dim x1 As Integer = Integer.Parse(pixels_cords_arr1(ind_pixel1).ToString().Split(",")(0))
                            Dim y1 As Integer = Integer.Parse(pixels_cords_arr1(ind_pixel1).ToString().Split(",")(1))
                            'copy_bmp1.SetPixel(x1, y1, color_of_region)
                            copy_bmp1.SetPixel(x1, y1, Color.FromArgb(10, 255, 10))
                        Next
                        If pixels_cords_arr1.Count > 300 Then
                            success_status = "arrive_to_start_point"

                        End If

                        Return copy_bmp1
                    End If
                Catch ex As Exception
                    failed_to_find_next_pixel1 = 1

                    to_stop2 = 1
                    wrong_pixels_dict1(x_start2.ToString() + "," + y_start2.ToString()) = 1
                    If wrong_pixels_dict1.Count > 50 Then
                        'Return bmp1
                    End If
                    'Return bmp1
                End Try
                cord_ind1 += 1

            End While
            If to_stop2 = 0 Then

                bg_color1 = copy_bmp1.GetPixel(x_start2 + CGlobals1.dir_arr1(last_cord_ind1 + 1, 0), y_start2 + CGlobals1.dir_arr1(last_cord_ind1 + 1, 1))
                If CGlobals1.compare_colors1(bg_color1, color_of_sobel) = 0 Then
                    Dim err1 As Integer = 1
                End If

            End If

            If to_stop2 = 1 And False Then
                Dim c1 As Integer = 50
                'bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(10, 255, 10))

                cord_ind1 = 0
                edge_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + CGlobals1.dir_arr1(cord_ind1, 1))
                bg_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1 + 1, 0), y_start2 + CGlobals1.dir_arr1(cord_ind1 + 1, 1))
                last_cord_ind1 = cord_ind1

                Dim loop_ind1 As Integer = 0
                to_stop2 = 0
                While (CGlobals1.compare_colors1(edge_color1, color_of_bg) = 1 And CGlobals1.compare_colors1(bg_color1, color_of_sobel) = 1) = False And to_stop2 = 0
                    last_cord_ind1 = cord_ind1

                    Try
                        edge_color1 = copy_bmp1.GetPixel(x_start2 + CGlobals1.dir_arr1(cord_ind1, 0), y_start2 + CGlobals1.dir_arr1(cord_ind1, 1))
                        bg_color1 = copy_bmp1.GetPixel(x_start2 + CGlobals1.dir_arr1((cord_ind1 + 1), 0), y_start2 + CGlobals1.dir_arr1(cord_ind1 + 1, 1))
                        If loop_ind1 < 9 Then
                            'bmp1.SetPixel(x_start2 + dir_arr1(cord_ind1, 0), y_start2 + dir_arr1(cord_ind1, 1), Color.FromArgb(c1, 70, 255))

                        End If
                        loop_ind1 += 1
                        c1 += 30
                    Catch ex As Exception
                        Return copy_bmp1
                    End Try
                    cord_ind1 += 1
                End While

            End If
            If to_stop2 = 1 Or failed_to_find_next_pixel1 = 1 Then
                'x_start2 = x_start2 + dir_arr1(last_cord_ind1 + 1, 0)
                'y_start2 = y_start2 + dir_arr1(last_cord_ind1 + 1, 1)
                Dim cord_str1 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")
                Dim x1 As Integer = Integer.Parse(cord_str1(0))
                Dim y1 As Integer = Integer.Parse(cord_str1(1))
                copy_bmp1.SetPixel(x1, y1, color_of_bg)
                pixels_cords_arr1.RemoveAt(pixels_cords_arr1.Count - 1)
                x_start2 = Integer.Parse(pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")(0))
                y_start2 = Integer.Parse(pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")(1))
                'pixels_cords_arr1.RemoveAt(pixels_cords_arr1.Count - 1)
                count_to_stop2 += 1
                If count_to_stop2 > 30 Then
                    Return Nothing
                End If
            Else
                Try
                    x_start2 = x_start2 + get_dir_arr1(last_cord_ind1 + 1, 0)
                    y_start2 = y_start2 + get_dir_arr1(last_cord_ind1 + 1, 1)

                Catch ex As Exception
                    Dim e1 As Integer = 1
                End Try
            End If


            'last_cord_ind1 = cord_ind1

        End While

    End Function




    Public Function next_pixels_loop3(bmp1 As Bitmap)

        success_status = ""
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        Dim org_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        Dim to_Stop1 As Integer = 0
        pixels_3d_cords_arr = New ArrayList()
        pixels_cords_arr1 = New ArrayList()
        Dim wrong_pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim org_x_start2 As Integer = x_start2
        Dim org_y_start2 As Integer = y_start2

        Dim cord_ind1 As Integer
        Dim last_cord_ind1 As Integer
        Dim count_to_stop2 As Integer = 0
        Dim min_pixel_around1 As Integer = 0
        If CGlobals1.current_max_sobel_ind1 = 13 Then
            Dim d1 As Integer = 1
        End If
        While to_Stop1 = 0
            Dim color_set1 As Color = copy_bmp1.GetPixel(x_start2, y_start2)
            If CGlobals1.compare_colors1(color_set1, color_of_sobel) = 0 Then
                Dim e1 As Integer = 1
            End If



            copy_bmp1.SetPixel(x_start2, y_start2, color_of_region)
            pixels_cords_arr1.Add(x_start2.ToString() + "," + y_start2.ToString())
            pixels_3d_cords_arr.Add(New point_3d1(x_start2, y_start2, 0))
            'If org_bmp1 IsNot Nothing Then

            'org_bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(255, 0, 0, 0))
            'End If
            'color_a is not the edge color
            'color_b is the edge color

            'search for cord_ind that is the previues pixel_point:
            cord_ind1 = 0

            If pixels_cords_arr1.Count > 1 Then

                Dim ind2 As Integer

                For ind2 = 0 To CGlobals1.dir_arr1.Length / 2 - 1
                    Dim new_x1 As Integer = x_start2 + get_dir_arr1(ind2, 0)
                    Dim new_y1 As Integer = y_start2 + get_dir_arr1(ind2, 1)
                    Dim count_pixel_around_val2 As Integer = count_pixel_around(copy_bmp1, new_x1, new_y1, color_of_sobel)
                    If count_pixel_around_val2 <= min_pixel_around1 Then
                        copy_bmp1.SetPixel(new_x1, new_y1, color_of_bg)
                    End If
                Next

                'ברגע שיש כבר נקודה אחת שסימנו - אז תמיד מתחילים לחפש מהנקודה הקודמת עם כיוון השעון
                Dim cord_str1 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 2).ToString().Split(",")
                Dim x1 As Integer = Integer.Parse(cord_str1(0))
                Dim y1 As Integer = Integer.Parse(cord_str1(1))
                Dim to_stop3 As Integer = 0
                'לולאה עד שמגיעים לנקודה הקודמת שממנה נחפש עם כיון השעון
                While to_stop3 = 0
                    Try


                        Dim new_x1 As Integer = x_start2 + get_dir_arr1(cord_ind1, 0)
                        Dim new_y1 As Integer = y_start2 + get_dir_arr1(cord_ind1, 1)
                        If new_x1 = x1 And new_y1 = y1 Then
                            to_stop3 = 1
                        Else
                            cord_ind1 += 1

                        End If
                    Catch ex As Exception
                        Return pixels_cords_arr1
                        to_stop3 = 1
                    End Try
                End While

            End If
            '--


            Dim edge_color1 As Color = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1))
            Dim bg_color1 As Color = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1 + 1, 0), y_start2 + get_dir_arr1(cord_ind1 + 1, 1))
            Dim count_pixel_around_val1 As Integer = count_pixel_around(copy_bmp1, x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1), edge_color1)
            last_cord_ind1 = cord_ind1

            Dim to_stop2 As Integer = 0
            Dim failed_to_find_next_pixel1 As Integer = 0
            'מחפשים את הנקודה של סובל כאשר נקודה לפניה היא של הרקע
            While (CGlobals1.compare_colors1(edge_color1, color_of_bg) = 1 And CGlobals1.compare_colors1(bg_color1, color_of_sobel) = 1 And count_pixel_around_val1 > 1) = False And to_stop2 = 0
                last_cord_ind1 = cord_ind1

                Try
                    edge_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1))
                    bg_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1 + 1, 0), y_start2 + get_dir_arr1(cord_ind1 + 1, 1))

                    count_pixel_around_val1 = count_pixel_around(copy_bmp1, x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1), edge_color1)

                    If (x_start2 + get_dir_arr1(cord_ind1 + 1, 0)) = org_x_start2 And
                        (y_start2 + get_dir_arr1(cord_ind1 + 1, 1)) = org_y_start2 Then

                        Dim ind_pixel1 As Integer
                        For ind_pixel1 = 0 To pixels_cords_arr1.Count - 1
                            Dim x1 As Integer = Integer.Parse(pixels_cords_arr1(ind_pixel1).ToString().Split(",")(0))
                            Dim y1 As Integer = Integer.Parse(pixels_cords_arr1(ind_pixel1).ToString().Split(",")(1))
                            'copy_bmp1.SetPixel(x1, y1, color_of_region)
                            copy_bmp1.SetPixel(x1, y1, Color.FromArgb(10, 255, 10))
                        Next
                        If pixels_cords_arr1.Count > 300 Then
                            success_status = "arrive_to_start_point"

                        End If

                        Return pixels_cords_arr1
                    End If
                Catch ex As Exception
                    failed_to_find_next_pixel1 = 1

                    to_stop2 = 1
                    wrong_pixels_dict1(x_start2.ToString() + "," + y_start2.ToString()) = 1
                    If wrong_pixels_dict1.Count > 50 Then
                        'Return bmp1
                    End If
                    'Return bmp1
                End Try
                cord_ind1 += 1

            End While
            If to_stop2 = 0 Then

                bg_color1 = copy_bmp1.GetPixel(x_start2 + CGlobals1.dir_arr1(last_cord_ind1 + 1, 0), y_start2 + CGlobals1.dir_arr1(last_cord_ind1 + 1, 1))
                If CGlobals1.compare_colors1(bg_color1, color_of_sobel) = 0 Then
                    Dim err1 As Integer = 1
                End If

            End If

            If to_stop2 = 1 And False Then
                Dim c1 As Integer = 50
                'bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(10, 255, 10))

                cord_ind1 = 0
                edge_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + CGlobals1.dir_arr1(cord_ind1, 1))
                bg_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1 + 1, 0), y_start2 + CGlobals1.dir_arr1(cord_ind1 + 1, 1))
                last_cord_ind1 = cord_ind1

                Dim loop_ind1 As Integer = 0
                to_stop2 = 0
                While (CGlobals1.compare_colors1(edge_color1, color_of_bg) = 1 And CGlobals1.compare_colors1(bg_color1, color_of_sobel) = 1) = False And to_stop2 = 0
                    last_cord_ind1 = cord_ind1

                    Try
                        edge_color1 = copy_bmp1.GetPixel(x_start2 + CGlobals1.dir_arr1(cord_ind1, 0), y_start2 + CGlobals1.dir_arr1(cord_ind1, 1))
                        bg_color1 = copy_bmp1.GetPixel(x_start2 + CGlobals1.dir_arr1((cord_ind1 + 1), 0), y_start2 + CGlobals1.dir_arr1(cord_ind1 + 1, 1))
                        If loop_ind1 < 9 Then
                            'bmp1.SetPixel(x_start2 + dir_arr1(cord_ind1, 0), y_start2 + dir_arr1(cord_ind1, 1), Color.FromArgb(c1, 70, 255))

                        End If
                        loop_ind1 += 1
                        c1 += 30
                    Catch ex As Exception
                        Return pixels_cords_arr1
                    End Try
                    cord_ind1 += 1
                End While

            End If
            If to_stop2 = 1 Or failed_to_find_next_pixel1 = 1 Then
                Try

                    'x_start2 = x_start2 + dir_arr1(last_cord_ind1 + 1, 0)
                    'y_start2 = y_start2 + dir_arr1(last_cord_ind1 + 1, 1)
                    Dim cord_str1 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")
                    Dim x1 As Integer = Integer.Parse(cord_str1(0))
                    Dim y1 As Integer = Integer.Parse(cord_str1(1))
                    copy_bmp1.SetPixel(x1, y1, color_of_bg)
                    pixels_cords_arr1.RemoveAt(pixels_cords_arr1.Count - 1)
                    x_start2 = Integer.Parse(pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")(0))
                    y_start2 = Integer.Parse(pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")(1))
                    'pixels_cords_arr1.RemoveAt(pixels_cords_arr1.Count - 1)
                    count_to_stop2 += 1
                    If count_to_stop2 > 30 Then
                        Return Nothing
                    End If
                Catch ex As Exception
                    Return pixels_cords_arr1
                End Try

            Else
                Try
                    x_start2 = x_start2 + get_dir_arr1(last_cord_ind1 + 1, 0)
                    y_start2 = y_start2 + get_dir_arr1(last_cord_ind1 + 1, 1)

                Catch ex As Exception
                    Dim e1 As Integer = 1
                End Try
            End If


            'last_cord_ind1 = cord_ind1

        End While
        Return pixels_cords_arr1
    End Function


    Public Function next_pixels_loop3(bmp1 As Bitmap, start_x1 As Integer, start_y1 As Integer, in_dir_arr1 As Integer(,), dict_prms1 As Dictionary(Of String, Object))
        If dict_prms1 Is Nothing Then
            dict_prms1 = New Dictionary(Of String, Object)
        End If
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res1("close_loop1") = "no"

        Dim over_all_pixels_arr1 As ArrayList = New ArrayList()
        Dim max_pixels_arr1 As ArrayList = New ArrayList()
        success_status = ""
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        Dim org_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        Dim to_stop1 As Integer = 0
        pixels_3d_cords_arr = New ArrayList()
        pixels_cords_arr1 = New ArrayList()
        Dim wrong_pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        Dim dict_of_pixels_arr1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim org_x_start2 As Integer = start_x1
        Dim org_y_start2 As Integer = start_y1

        Dim cord_ind1 As Integer
        Dim last_cord_ind1 As Integer
        Dim count_to_stop2 As Integer = 0
        Dim min_pixel_around1 As Integer = 0
        If CGlobals1.current_max_sobel_ind1 = 13 Then
            Dim d1 As Integer = 1
        End If

        Dim color_of_wrong_pixel1 As Color = Color.FromArgb(20, 40, 200)
        color_of_wrong_pixel1 = Color.FromArgb(0, 0, 0)
        Dim last_pixel_was_failed As String = ""
        While to_stop1 = 0
            Dim color_set1 As Color = copy_bmp1.GetPixel(x_start2, y_start2)
            If CGlobals1.compare_colors1(color_set1, color_of_sobel) = 0 Then
                Dim e1 As Integer = 1
            End If

            If last_pixel_was_failed = "" Then


                'בדיקה אם הפיקסל מוקף בלבן - סובל

                Dim count_pixel_around_val2 As Integer = count_pixel_around(org_bmp1, x_start2, y_start2, color_of_sobel)
                If count_pixel_around_val2 >= 8 Then
                    Dim err1 As Integer = 1
                    dict_res1("over_all_pixels_arr1") = over_all_pixels_arr1
                    dict_res1("pixels_cords_arr1") = pixels_cords_arr1
                    dict_res1("max_pixels_arr1") = max_pixels_arr1
                    Return dict_res1
                End If


                'צובעים את הפיקסל הנוכחי
                copy_bmp1.SetPixel(x_start2, y_start2, color_of_region)
                If x_start2 = 269 And y_start2 = 516 Then
                    Dim d1 As Integer = 1
                End If
                over_all_pixels_arr1.Add(x_start2.ToString() + "," + y_start2.ToString())
                'מוספים את הפיקסל הנוכחי למערך
                pixels_cords_arr1.Add(x_start2.ToString() + "," + y_start2.ToString())
                max_pixels_arr1.Add(x_start2.ToString() + "," + y_start2.ToString())
                If max_pixels_arr1.Count < pixels_cords_arr1.Count Then
                    'max_pixels_arr1 = pixels_cords_arr1.Clone()
                Else

                End If
                pixels_3d_cords_arr.Add(New point_3d1(x_start2, y_start2, 0))
                dict_of_pixels_arr1(x_start2.ToString() + "," + y_start2.ToString()) = 1

            End If
            last_pixel_was_failed = ""
            'If org_bmp1 IsNot Nothing Then

            'org_bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(255, 0, 0, 0))
            'End If
            'color_a is not the edge color
            'color_b is the edge color

            'search for cord_ind that is the previues pixel_point:
            cord_ind1 = 0
            'אם יש לפחות 2 פיקסלים - כלומר היה פיקסל לפני הנוכחי - אז מחשבים את נקודת ההתחלה בשביל לחפש את הפיקסל הבא
            If pixels_cords_arr1.Count > 1 Then

                If False Then

                    Dim ind2 As Integer

                    For ind2 = 0 To in_dir_arr1.Length / 2 - 1
                        Dim new_x1 As Integer = x_start2 + in_dir_arr1(ind2, 0) ' get_dir_arr1(ind2, 0)
                        Dim new_y1 As Integer = y_start2 + in_dir_arr1(ind2, 1) 'get_dir_arr1(ind2, 1)
                        Dim count_pixel_around_val2 As Integer = count_pixel_around(copy_bmp1, new_x1, new_y1, color_of_sobel)
                        If count_pixel_around_val2 <= min_pixel_around1 Then
                            copy_bmp1.SetPixel(new_x1, new_y1, color_of_bg)
                        End If
                    Next

                End If


                'ברגע שיש כבר נקודה אחת שסימנו - אז תמיד מתחילים לחפש מהנקודה הקודמת עם כיוון השעון
                Dim cord_str1 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 2).ToString().Split(",")
                Dim x1 As Integer = Integer.Parse(cord_str1(0))
                Dim y1 As Integer = Integer.Parse(cord_str1(1))
                Dim to_stop3 As Integer = 0
                'לולאה עד שמגיעים לנקודה הקודמת שממנה נחפש עם כיון השעון
                While to_stop3 = 0
                    Try


                        Dim new_x1 As Integer = x_start2 + in_dir_arr1(cord_ind1, 0) 'get_dir_arr1(cord_ind1, 0)
                        Dim new_y1 As Integer = y_start2 + in_dir_arr1(cord_ind1, 1) 'get_dir_arr1(cord_ind1, 1)
                        If new_x1 = x1 And new_y1 = y1 Then
                            to_stop3 = 1
                        Else
                            cord_ind1 += 1

                        End If
                    Catch ex As Exception
                        Return pixels_cords_arr1
                        to_stop3 = 1
                    End Try
                End While

            End If
            '--


            Dim edge_color1 As Color = copy_bmp1.GetPixel(x_start2 + in_dir_arr1(cord_ind1, 0), y_start2 + in_dir_arr1(cord_ind1, 1))
            Dim bg_color1 As Color = copy_bmp1.GetPixel(x_start2 + in_dir_arr1(cord_ind1 + 1, 0), y_start2 + in_dir_arr1(cord_ind1 + 1, 1))

            Dim color_cur_pixel1 As Color = copy_bmp1.GetPixel(x_start2 + in_dir_arr1(cord_ind1, 0), y_start2 + in_dir_arr1(cord_ind1, 1))
            Dim color_next_pixel1 As Color = copy_bmp1.GetPixel(x_start2 + in_dir_arr1(cord_ind1 + 1, 0), y_start2 + in_dir_arr1(cord_ind1 + 1, 1))


            Dim count_pixel_around_val1 As Integer = count_pixel_around(copy_bmp1, x_start2 + in_dir_arr1(cord_ind1, 0), y_start2 + in_dir_arr1(cord_ind1, 1), edge_color1)
            last_cord_ind1 = cord_ind1

            Dim to_stop2 As Integer = 0
            Dim to_stop_search_pixel1 As Integer = 0
            Dim failed_to_find_next_pixel1 As Integer = 0
            Dim arrive_to_start1 As Integer = 0
            While to_stop_search_pixel1 = 0
                If CGlobals1.compare_colors1(color_cur_pixel1, color_of_bg) = 1 And CGlobals1.compare_colors1(color_next_pixel1, color_of_sobel) = 1 Then
                    to_stop_search_pixel1 = 1
                End If
                If CGlobals1.compare_colors1(color_cur_pixel1, color_of_wrong_pixel1) = 1 And CGlobals1.compare_colors1(color_next_pixel1, color_of_sobel) = 1 Then
                    to_stop_search_pixel1 = 1
                End If

                If to_stop_search_pixel1 = 1 Then
                    Dim count_pixel_around_val2 As Integer = count_pixel_around(org_bmp1, x_start2 + in_dir_arr1(cord_ind1 + 1, 0), y_start2 + in_dir_arr1(cord_ind1 + 1, 1), color_of_sobel)
                    If count_pixel_around_val2 >= 8 Then
                        Dim err1 As Integer = 1
                        to_stop_search_pixel1 = 0
                    End If

                End If

                If to_stop_search_pixel1 = 0 Then
                    If cord_ind1 >= 14 Then
                        failed_to_find_next_pixel1 = 1
                        to_stop_search_pixel1 = 1
                    Else
                        cord_ind1 += 1
                        If org_x_start2 = x_start2 + in_dir_arr1(cord_ind1, 0) And org_y_start2 = y_start2 + in_dir_arr1(cord_ind1, 1) And pixels_cords_arr1.Count > 5 Then
                            arrive_to_start1 = 1
                            to_stop1 = 1
                        End If
                        Dim dir1a As Integer = in_dir_arr1(cord_ind1, 0) ' get_dir_arr1(cord_ind1, 0)
                        Dim dir1b As Integer = in_dir_arr1(cord_ind1, 1) ' get_dir_arr1(cord_ind1, 1)


                        Dim dir2a As Integer = in_dir_arr1(cord_ind1 + 1, 0) ' get_dir_arr1(cord_ind1 + 1, 0)
                        Dim dir2b As Integer = in_dir_arr1(cord_ind1 + 1, 1) ' get_dir_arr1(cord_ind1 + 1, 1)

                        color_cur_pixel1 = copy_bmp1.GetPixel(x_start2 + in_dir_arr1(cord_ind1, 0), y_start2 + in_dir_arr1(cord_ind1, 1))
                        color_next_pixel1 = copy_bmp1.GetPixel(x_start2 + in_dir_arr1(cord_ind1 + 1, 0), y_start2 + in_dir_arr1(cord_ind1 + 1, 1))

                    End If


                End If
            End While

            If arrive_to_start1 = 1 Then
                dict_res1("over_all_pixels_arr1") = over_all_pixels_arr1
                dict_res1("pixels_cords_arr1") = pixels_cords_arr1
                dict_res1("max_pixels_arr1") = max_pixels_arr1
                dict_res1("close_loop1") = "yes"
                Return dict_res1
            End If
            If failed_to_find_next_pixel1 = 0 And to_stop_search_pixel1 = 1 Then
                x_start2 = x_start2 + in_dir_arr1(cord_ind1 + 1, 0) ' get_dir_arr1(cord_ind1 + 1, 0)
                y_start2 = y_start2 + in_dir_arr1(cord_ind1 + 1, 1) ' get_dir_arr1(cord_ind1 + 1, 1)

                Dim count_pixel_around_val2 As Integer = count_pixel_around(org_bmp1, x_start2, y_start2, color_of_sobel)
                If count_pixel_around_val2 >= 8 Then
                    Dim err1 As Integer = 1
                End If

            ElseIf failed_to_find_next_pixel1 = 1 Then
                last_pixel_was_failed = "yes"
                copy_bmp1.SetPixel(x_start2, y_start2, color_of_wrong_pixel1)
                If x_start2 = 269 And y_start2 = 516 Then
                    Dim d1 As Integer = 1
                End If

                over_all_pixels_arr1.Add(x_start2.ToString() + "," + y_start2.ToString())

                dict_of_pixels_arr1.Remove(pixels_cords_arr1(pixels_cords_arr1.Count - 1))

                pixels_cords_arr1.RemoveAt(pixels_cords_arr1.Count - 1)
                If max_pixels_arr1.Count < pixels_cords_arr1.Count Then
                    max_pixels_arr1 = pixels_cords_arr1.Clone()
                End If


                If pixels_cords_arr1.Count <= 0 Then
                    dict_res1("over_all_pixels_arr1") = over_all_pixels_arr1
                    dict_res1("pixels_cords_arr1") = pixels_cords_arr1
                    dict_res1("max_pixels_arr1") = max_pixels_arr1
                    Return dict_res1
                End If
                Dim cord_str1 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")
                x_start2 = Integer.Parse(cord_str1(0))
                y_start2 = Integer.Parse(cord_str1(1))
            End If

            If dict_prms1.ContainsKey("check_if_arrive_to_cord_xy1") = True Then

                Dim x1 As Integer = Integer.Parse(dict_prms1.ContainsKey("arrive_to_cord_xy1_x1"))
                Dim y1 As Integer = Integer.Parse(dict_prms1.ContainsKey("arrive_to_cord_xy1_y1"))
                Dim cord_str2 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")
                Dim x_start_2 As Integer = Integer.Parse(cord_str2(0))
                Dim y_start_2 As Integer = Integer.Parse(cord_str2(1))

            End If
            If pixels_cords_arr1.Count > 5 And dict_prms1.ContainsKey("check_if_arrive_to_start1") Then

                Dim x1 As Integer
                Dim y1 As Integer

                Dim cord_str1 As String() = pixels_cords_arr1(0).ToString().Split(",")
                Dim x_start_1 As Integer = Integer.Parse(cord_str1(0))
                Dim y_start_1 As Integer = Integer.Parse(cord_str1(1))


                Dim cord_str2 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")
                Dim x_start_2 As Integer = Integer.Parse(cord_str2(0))
                Dim y_start_2 As Integer = Integer.Parse(cord_str2(1))

                Dim delta_xy1 As Integer = 1
                For x1 = x_start_2 - delta_xy1 To x_start_2 + delta_xy1
                    For y1 = y_start_2 - delta_xy1 To y_start_2 + delta_xy1
                        If x_start_1 = x1 And y_start_1 = y1 Then
                            to_stop1 = 1
                            dict_res1("close_loop1") = "yes"
                        End If
                    Next

                Next
            End If
            If pixels_cords_arr1.Count > 1000 Then
                'to_stop1 = 1
            End If

        End While
        dict_res1("over_all_pixels_arr1") = over_all_pixels_arr1
        dict_res1("pixels_cords_arr1") = pixels_cords_arr1
        dict_res1("max_pixels_arr1") = max_pixels_arr1

        Return dict_res1
    End Function



    Public Function next_pixels_loop2(bmp1 As Bitmap)

        success_status = ""
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        Dim to_Stop1 As Integer = 0
        pixels_3d_cords_arr = New ArrayList()
        pixels_cords_arr1 = New ArrayList()
        Dim wrong_pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim org_x_start2 As Integer = x_start2
        Dim org_y_start2 As Integer = y_start2

        Dim cord_ind1 As Integer
        Dim last_cord_ind1 As Integer
        Dim count_to_stop2 As Integer = 0
        Dim min_pixel_around1 As Integer = 0
        If CGlobals1.current_max_sobel_ind1 = 13 Then
            Dim d1 As Integer = 1
        End If
        While to_Stop1 = 0
            Dim color_set1 As Color = copy_bmp1.GetPixel(x_start2, y_start2)
            If CGlobals1.compare_colors1(color_set1, color_of_sobel) = 0 Then
                Dim e1 As Integer = 1
            End If



            copy_bmp1.SetPixel(x_start2, y_start2, color_of_region)
            pixels_cords_arr1.Add(x_start2.ToString() + "," + y_start2.ToString())
            pixels_3d_cords_arr.Add(New point_3d1(x_start2, y_start2, 0))
            'If org_bmp1 IsNot Nothing Then

            'org_bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(255, 0, 0, 0))
            'End If
            'color_a is not the edge color
            'color_b is the edge color

            'search for cord_ind that is the previues pixel_point:
            cord_ind1 = 0

            If pixels_cords_arr1.Count > 1 Then

                Dim ind2 As Integer

                For ind2 = 0 To CGlobals1.dir_arr1.Length / 2 - 1
                    Dim new_x1 As Integer = x_start2 + get_dir_arr1(ind2, 0)
                    Dim new_y1 As Integer = y_start2 + get_dir_arr1(ind2, 1)
                    Dim count_pixel_around_val2 As Integer = count_pixel_around(copy_bmp1, new_x1, new_y1, color_of_sobel)
                    If count_pixel_around_val2 <= min_pixel_around1 Then
                        copy_bmp1.SetPixel(new_x1, new_y1, color_of_bg)
                    End If
                Next

                'ברגע שיש כבר נקודה אחת שסימנו - אז תמיד מתחילים לחפש מהנקודה הקודמת עם כיוון השעון
                Dim cord_str1 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 2).ToString().Split(",")
                Dim x1 As Integer = Integer.Parse(cord_str1(0))
                Dim y1 As Integer = Integer.Parse(cord_str1(1))
                Dim to_stop3 As Integer = 0
                'לולאה עד שמגיעים לנקודה הקודמת שממנה נחפש עם כיון השעון
                While to_stop3 = 0
                    Try


                        Dim new_x1 As Integer = x_start2 + get_dir_arr1(cord_ind1, 0)
                        Dim new_y1 As Integer = y_start2 + get_dir_arr1(cord_ind1, 1)
                        If new_x1 = x1 And new_y1 = y1 Then
                            to_stop3 = 1
                        Else
                            cord_ind1 += 1

                        End If
                    Catch ex As Exception
                        Return pixels_cords_arr1
                        to_stop3 = 1
                    End Try
                End While

            End If
            '--


            Dim edge_color1 As Color = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1))
            Dim bg_color1 As Color = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1 + 1, 0), y_start2 + get_dir_arr1(cord_ind1 + 1, 1))
            Dim count_pixel_around_val1 As Integer = count_pixel_around(copy_bmp1, x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1), edge_color1)
            last_cord_ind1 = cord_ind1

            Dim to_stop2 As Integer = 0
            Dim failed_to_find_next_pixel1 As Integer = 0
            'מחפשים את הנקודה של סובל כאשר נקודה לפניה היא של הרקע
            While (CGlobals1.compare_colors1(edge_color1, color_of_bg) = 1 And CGlobals1.compare_colors1(bg_color1, color_of_sobel) = 1 And count_pixel_around_val1 > 1) = False And to_stop2 = 0
                last_cord_ind1 = cord_ind1

                Try
                    edge_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1))
                    bg_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1 + 1, 0), y_start2 + get_dir_arr1(cord_ind1 + 1, 1))

                    count_pixel_around_val1 = count_pixel_around(copy_bmp1, x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + get_dir_arr1(cord_ind1, 1), edge_color1)

                    If (x_start2 + get_dir_arr1(cord_ind1 + 1, 0)) = org_x_start2 And
                        (y_start2 + get_dir_arr1(cord_ind1 + 1, 1)) = org_y_start2 Then

                        Dim ind_pixel1 As Integer
                        For ind_pixel1 = 0 To pixels_cords_arr1.Count - 1
                            Dim x1 As Integer = Integer.Parse(pixels_cords_arr1(ind_pixel1).ToString().Split(",")(0))
                            Dim y1 As Integer = Integer.Parse(pixels_cords_arr1(ind_pixel1).ToString().Split(",")(1))
                            'copy_bmp1.SetPixel(x1, y1, color_of_region)
                            copy_bmp1.SetPixel(x1, y1, Color.FromArgb(10, 255, 10))
                        Next
                        If pixels_cords_arr1.Count > 300 Then
                            success_status = "arrive_to_start_point"

                        End If

                        Return pixels_cords_arr1
                    End If
                Catch ex As Exception
                    failed_to_find_next_pixel1 = 1

                    to_stop2 = 1
                    wrong_pixels_dict1(x_start2.ToString() + "," + y_start2.ToString()) = 1
                    If wrong_pixels_dict1.Count > 50 Then
                        'Return bmp1
                    End If
                    'Return bmp1
                End Try
                cord_ind1 += 1

            End While
            If to_stop2 = 0 Then

                bg_color1 = copy_bmp1.GetPixel(x_start2 + CGlobals1.dir_arr1(last_cord_ind1 + 1, 0), y_start2 + CGlobals1.dir_arr1(last_cord_ind1 + 1, 1))
                If CGlobals1.compare_colors1(bg_color1, color_of_sobel) = 0 Then
                    Dim err1 As Integer = 1
                End If

            End If

            If to_stop2 = 1 And False Then
                Dim c1 As Integer = 50
                'bmp1.SetPixel(x_start2, y_start2, Color.FromArgb(10, 255, 10))

                cord_ind1 = 0
                edge_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1, 0), y_start2 + CGlobals1.dir_arr1(cord_ind1, 1))
                bg_color1 = copy_bmp1.GetPixel(x_start2 + get_dir_arr1(cord_ind1 + 1, 0), y_start2 + CGlobals1.dir_arr1(cord_ind1 + 1, 1))
                last_cord_ind1 = cord_ind1

                Dim loop_ind1 As Integer = 0
                to_stop2 = 0
                While (CGlobals1.compare_colors1(edge_color1, color_of_bg) = 1 And CGlobals1.compare_colors1(bg_color1, color_of_sobel) = 1) = False And to_stop2 = 0
                    last_cord_ind1 = cord_ind1

                    Try
                        edge_color1 = copy_bmp1.GetPixel(x_start2 + CGlobals1.dir_arr1(cord_ind1, 0), y_start2 + CGlobals1.dir_arr1(cord_ind1, 1))
                        bg_color1 = copy_bmp1.GetPixel(x_start2 + CGlobals1.dir_arr1((cord_ind1 + 1), 0), y_start2 + CGlobals1.dir_arr1(cord_ind1 + 1, 1))
                        If loop_ind1 < 9 Then
                            'bmp1.SetPixel(x_start2 + dir_arr1(cord_ind1, 0), y_start2 + dir_arr1(cord_ind1, 1), Color.FromArgb(c1, 70, 255))

                        End If
                        loop_ind1 += 1
                        c1 += 30
                    Catch ex As Exception
                        Return pixels_cords_arr1
                    End Try
                    cord_ind1 += 1
                End While

            End If
            If to_stop2 = 1 Or failed_to_find_next_pixel1 = 1 Then
                Try

                    'x_start2 = x_start2 + dir_arr1(last_cord_ind1 + 1, 0)
                    'y_start2 = y_start2 + dir_arr1(last_cord_ind1 + 1, 1)
                    Dim cord_str1 As String() = pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")
                    Dim x1 As Integer = Integer.Parse(cord_str1(0))
                    Dim y1 As Integer = Integer.Parse(cord_str1(1))
                    copy_bmp1.SetPixel(x1, y1, color_of_bg)
                    pixels_cords_arr1.RemoveAt(pixels_cords_arr1.Count - 1)
                    x_start2 = Integer.Parse(pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")(0))
                    y_start2 = Integer.Parse(pixels_cords_arr1(pixels_cords_arr1.Count - 1).ToString().Split(",")(1))
                    'pixels_cords_arr1.RemoveAt(pixels_cords_arr1.Count - 1)
                    count_to_stop2 += 1
                    If count_to_stop2 > 30 Then
                        Return Nothing
                    End If
                Catch ex As Exception
                    Return pixels_cords_arr1
                End Try

            Else
                Try
                    x_start2 = x_start2 + get_dir_arr1(last_cord_ind1 + 1, 0)
                    y_start2 = y_start2 + get_dir_arr1(last_cord_ind1 + 1, 1)

                Catch ex As Exception
                    Dim e1 As Integer = 1
                End Try
            End If


            'last_cord_ind1 = cord_ind1

        End While
        Return pixels_cords_arr1
    End Function


    Public Function remove_around_object1(bmp1 As Bitmap, bg_color1 As Color)
        Dim bmp2 As Bitmap = CGlobals1.copy_bitmap1(bmp1)

        Dim x1 As Integer
        Dim y1 As Integer

        For x1 = 1 To bmp1.Width - 2
            For y1 = 1 To bmp1.Height - 2
                If CGlobals1.compare_colors1(bmp1.GetPixel(x1, y1), bg_color1) = 0 Then
                    Dim set_bg1 As Integer = 0

                    Dim cord_ind1 As Integer
                    For cord_ind1 = 0 To 9
                        If CGlobals1.compare_colors1(bmp1.GetPixel(x1 + CGlobals1.dir_arr1(cord_ind1, 0), y1 + CGlobals1.dir_arr1(cord_ind1, 1)), bg_color1) = 1 Then
                            set_bg1 = 1

                        End If
                    Next

                    If set_bg1 = 1 Then
                        bmp2.SetPixel(x1, y1, bg_color1)
                    End If
                End If

            Next
        Next

        Return bmp2
    End Function


    Public Function read_sobel_values1(path1 As String)
        Dim sobel_vals_str As String = System.IO.File.ReadAllText(path1)
        Dim sobel_pixels_vals As String() = sobel_vals_str.Split("#")
        Dim i1 As Integer

        For i1 = 0 To sobel_pixels_vals.Length - 1
            Dim vals_str1 As String() = sobel_pixels_vals(i1).Split(",")
            If vals_str1.Length >= 3 Then
                Dim sobel_val1 As Integer = Integer.Parse(vals_str1(2))
                Dim x1 As Integer = Integer.Parse(vals_str1(0))
                Dim y1 As Integer = Integer.Parse(vals_str1(1))
                Dim pixels_arr1 As ArrayList
                If CGlobals1.dict_sobel_pixels.ContainsKey(Math.Abs(sobel_val1)) Then
                    Dim d4 As Integer = 1
                Else
                    CGlobals1.dict_sobel_pixels(Math.Abs(sobel_val1)) = New ArrayList()
                End If

                pixels_arr1 = CGlobals1.dict_sobel_pixels(Math.Abs(sobel_val1))
                pixels_arr1.Add(x1.ToString() + "," + y1.ToString())

            End If
        Next



        Dim sorted = From pair In CGlobals1.dict_sobel_pixels
                     Order By pair.Key
        Dim sortedDictionary = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
        CGlobals1.dict_sobel_pixels = sortedDictionary
        Dim key1 As String = sortedDictionary.Keys(sortedDictionary.Keys.Count - 1)
        'Dim s2 As Double = sortedDictionary(sortedDictionary.Keys(CType(sortedDictionary.Keys.Count * 0.99, Integer)))
        's2 = 30

        cur_sobel_ind_val1 = sortedDictionary.Keys.Count
        cur_sobel_ind_val1 = 0
        'CGlobals1.current_sobel_threshold = s2
        CGlobals1.current_sobel_threshold = Integer.Parse(key1)
        CGlobals1.last_sobel_threshold = Integer.Parse(key1)
        bmp_current_sobel = New Bitmap(bmp1.Width, bmp1.Height)

        'Dim x1 As Integer
        'Dim y1 As Integer

        For x1 = 0 To bmp_current_sobel.Width - 1
            For y1 = 0 To bmp_current_sobel.Height - 1
                bmp_current_sobel.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))
            Next

        Next

    End Function

    Public Function update_current_sobel(new_sobel_ind_val As Integer)
        If (cur_sobel_ind_val1 > new_sobel_ind_val) Then
            For sobel_key_ind = new_sobel_ind_val To cur_sobel_ind_val1
                If sobel_key_ind < CGlobals1.dict_sobel_pixels.Keys.Count Then

                    Dim sobel_key_val As Integer = CGlobals1.dict_sobel_pixels.Keys(sobel_key_ind)
                    Dim pixel_arr1 As ArrayList = CGlobals1.dict_sobel_pixels(sobel_key_val)
                    Dim i1 As Integer

                    For i1 = 0 To pixel_arr1.Count - 1
                        Dim x1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(0).ToString())
                        Dim y1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(1).ToString())
                        bmp_current_sobel.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))

                    Next
                End If

            Next

        Else
            For sobel_key_ind = cur_sobel_ind_val1 To new_sobel_ind_val
                If sobel_key_ind < CGlobals1.dict_sobel_pixels.Keys.Count Then

                    Dim sobel_key_val As Integer = CGlobals1.dict_sobel_pixels.Keys(sobel_key_ind)
                    Dim pixel_arr1 As ArrayList = CGlobals1.dict_sobel_pixels(sobel_key_val)
                    Dim i1 As Integer

                    For i1 = 0 To pixel_arr1.Count - 1
                        Dim x1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(0).ToString())
                        Dim y1 As Integer = Integer.Parse(pixel_arr1(i1).split(",")(1).ToString())
                        bmp_current_sobel.SetPixel(x1, y1, Color.FromArgb(0, 0, 0))

                    Next
                End If

            Next
        End If

        cur_sobel_ind_val1 = new_sobel_ind_val

    End Function

    Public Function add_dec_sobel_ind(dir1 As String, sobel_factor1 As Integer)

        If dir1 = "add1" Then
            Dim new_cur_sobel_ind_val1 As Integer = cur_sobel_ind_val1 + sobel_factor1
            update_current_sobel(new_cur_sobel_ind_val1)
        End If

        If dir1 = "dec1" Then
            Dim new_cur_sobel_ind_val1 As Integer = cur_sobel_ind_val1 - sobel_factor1
            update_current_sobel(new_cur_sobel_ind_val1)
        End If

    End Function

    Public Function save_3d_points_arr(path_of_file As String, arr_3d_points As ArrayList)
        Dim str_3d_pnts1 As System.Text.StringBuilder = New System.Text.StringBuilder()
        Dim i1 As Integer

        For i1 = 0 To arr_3d_points.Count - 1

            str_3d_pnts1.Append(CType(arr_3d_points(i1), point_3d1).x1.ToString() + ",")
            str_3d_pnts1.Append(CType(arr_3d_points(i1), point_3d1).y1.ToString() + ",")
            str_3d_pnts1.Append(CType(arr_3d_points(i1), point_3d1).z1.ToString() + "#")

        Next

        System.IO.File.WriteAllText(path_of_file, str_3d_pnts1.ToString())

    End Function


    Public Function save_2d_pixels_arr1(path_of_file As String, arr_2d_pixels As ArrayList)
        Dim str_2d_pnts1 As System.Text.StringBuilder = New System.Text.StringBuilder()
        Dim i1 As Integer

        For i1 = 0 To arr_2d_pixels.Count - 1

            str_2d_pnts1.Append(arr_2d_pixels(i1).ToString() + "#")

        Next

        System.IO.File.WriteAllText(path_of_file, str_2d_pnts1.ToString())

    End Function

    Public Function load_2d_pixels_arr1(path_of_file As String)
        Dim i1 As Integer
        Dim str_pnts_arr1 As String = System.IO.File.ReadAllText(path_of_file)
        Dim str_pnds_cord_2d As String() = str_pnts_arr1.Split("#")
        Dim arr_2d_points As ArrayList = New ArrayList()

        For i1 = 0 To str_pnds_cord_2d.Count - 1
            If str_pnds_cord_2d(i1).Length > 2 Then


                Dim x1 As Integer = Integer.Parse(str_pnds_cord_2d(i1).Split(",")(0))
                Dim y1 As Integer = Integer.Parse(str_pnds_cord_2d(i1).Split(",")(1))


                arr_2d_points.Add(x1.ToString() + "," + y1.ToString())
            End If
        Next

        Return arr_2d_points

    End Function

    Public Function load_double_2d_pixels_arr1(path_of_file As String)
        Dim i1 As Integer
        Dim str_pnts_arr1 As String = System.IO.File.ReadAllText(path_of_file)
        Dim str_pnds_cord_2d As String() = str_pnts_arr1.Split("#")
        Dim arr_2d_points As ArrayList = New ArrayList()

        For i1 = 0 To str_pnds_cord_2d.Count - 1
            If str_pnds_cord_2d(i1).Length > 2 Then


                Dim x1 As Double = Double.Parse(str_pnds_cord_2d(i1).Split(",")(0))
                Dim y1 As Double = Double.Parse(str_pnds_cord_2d(i1).Split(",")(1))


                arr_2d_points.Add(x1.ToString() + "," + y1.ToString())
            End If
        Next

        Return arr_2d_points

    End Function


    Public Function save_3d_points_arr_2(path_of_file As String, arr_3d_points As ArrayList)
        Dim str_3d_pnts1 As System.Text.StringBuilder = New System.Text.StringBuilder()
        Dim i1 As Integer

        For i1 = 0 To arr_3d_points.Count - 1

            str_3d_pnts1.Append(CType(arr_3d_points(i1), point_3d1).x1.ToString() + ",")
            str_3d_pnts1.Append(CType(arr_3d_points(i1), point_3d1).y1.ToString() + ",")
            str_3d_pnts1.Append(CType(arr_3d_points(i1), point_3d1).z1.ToString() + "#")

        Next

        System.IO.File.WriteAllText(path_of_file, str_3d_pnts1.ToString())

    End Function


    Public Function load_3d_points_arr(path_of_file As String)

        Dim i1 As Integer
        Dim str_pnts_arr1 As String = System.IO.File.ReadAllText(path_of_file)
        Dim str_pnds_cord_3d As String() = str_pnts_arr1.Split("#")
        Dim arr_3d_points As ArrayList = New ArrayList()

        For i1 = 0 To str_pnds_cord_3d.Count - 1
            If str_pnds_cord_3d(i1).Length > 2 Then


                Dim x1 As Integer = Integer.Parse(str_pnds_cord_3d(i1).Split(",")(0))
                Dim y1 As Integer = Integer.Parse(str_pnds_cord_3d(i1).Split(",")(1))
                Dim z1 As Integer = Integer.Parse(str_pnds_cord_3d(i1).Split(",")(2))
                Dim pnt_3d_obj1 As point_3d1 = New point_3d1(x1, y1, z1)

                arr_3d_points.Add(pnt_3d_obj1)
            End If
        Next

        Return arr_3d_points

    End Function

    Public Function set_color_with_sqr_size_from_arr1(bmp1 As Bitmap, pixels_arr1 As ArrayList)
        Dim i1 As Integer
        For i1 = 0 To pixels_arr1.Count - 1
            Dim str_cord1 As String() = pixels_arr1(i1)
            ' Dim 
        Next
    End Function
    Public Function set_pixel_arr_on_bmp1(pixels_arr1 As ArrayList, ByRef bmp1 As Bitmap)
        Dim i1 As Integer

        For i1 = 0 To pixels_arr1.Count - 1
            Dim x1 As Integer = Integer.Parse(Math.Floor(Double.Parse(pixels_arr1(i1).ToString().Split(",")(0))))
            Dim y1 As Integer = Integer.Parse(Math.Floor(Double.Parse(pixels_arr1(i1).ToString().Split(",")(1))))
            If x1 >= 0 And x1 <= bmp1.Width - 1 And y1 >= 0 And y1 <= bmp1.Height - 1 Then
                bmp1.SetPixel(Integer.Parse(Math.Floor(Double.Parse(pixels_arr1(i1).ToString().Split(",")(0)))), Integer.Parse(Math.Floor(Double.Parse(pixels_arr1(i1).ToString().Split(",")(1)))), Color.FromArgb(255, 30, 30))

            End If
            'bmp1.SetPixel(Integer.Parse(pixels_arr1(i1).ToString().Split(",")(0)), Integer.Parse(pixels_arr1(i1).ToString().Split(",")(1)), Color.FromArgb(255, 30, 30))
        Next
    End Function

    Public Function pixels_arr_val_to_integer1(pixels_arr1 As ArrayList)
        Dim i1 As Integer
        Dim new_pixels_arr1 As ArrayList = New ArrayList()
        For i1 = 0 To pixels_arr1.Count - 1
            Dim x1 As Integer = Integer.Parse(Math.Floor(Double.Parse(pixels_arr1(i1).ToString().Split(",")(0)))).ToString()
            Dim y1 As Integer = Integer.Parse(Math.Floor(Double.Parse(pixels_arr1(i1).ToString().Split(",")(1)))).ToString()

            'bmp1.SetPixel(Integer.Parse(Math.Floor(Double.Parse(pixels_arr1(i1).ToString().Split(",")(0)))), Integer.Parse(Math.Floor(Double.Parse(pixels_arr1(i1).ToString().Split(",")(1)))), Color.FromArgb(255, 30, 30))
            new_pixels_arr1.Add(x1.ToString() + "," + y1.ToString())
            'bmp1.SetPixel(Integer.Parse(pixels_arr1(i1).ToString().Split(",")(0)), Integer.Parse(pixels_arr1(i1).ToString().Split(",")(1)), Color.FromArgb(255, 30, 30))
        Next
        Return new_pixels_arr1
    End Function

    Public Function set_pixel_arr_on_bmp2(pixels_arr1 As ArrayList, ByRef bmp1 As Bitmap, color_to_set1 As Color)
        Dim i1 As Integer

        For i1 = 0 To pixels_arr1.Count - 1
            Try
                'Dim x1 As Integer = Integer.Parse(pixels_arr1(i1).ToString().Split(",")(0))
                'Dim y1 As Integer = Integer.Parse(pixels_arr1(i1).ToString().Split(",")(1))


                Dim x1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(0))
                Dim y1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(1))
                If x1 >= 0 And x1 < bmp1.Width And y1 >= 0 And y1 < bmp1.Height Then
                    bmp1.SetPixel(x1, y1, color_to_set1)

                End If

            Catch ex As Exception
                Try
                    Dim x1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(0))
                    Dim y1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(1))
                    If x1 >= 0 And x1 < bmp1.Width And y1 >= 0 And y1 < bmp1.Height Then
                        bmp1.SetPixel(x1, y1, color_to_set1)

                    End If

                Catch ex2 As Exception

                End Try
            End Try



        Next
    End Function


    Public Function set_double_pixel_arr_on_bmp2(pixels_arr1 As ArrayList, ByRef bmp1 As Bitmap, color_to_set1 As Color)
        Dim i1 As Integer

        For i1 = 0 To pixels_arr1.Count - 1
            Try
                Dim x1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(0))
                Dim y1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(1))
                If x1 >= 0 And x1 < bmp1.Width And y1 >= 0 And y1 < bmp1.Height Then
                    bmp1.SetPixel(x1, y1, color_to_set1)

                End If

            Catch ex2 As Exception
            End Try




        Next
    End Function


    Public Function set_pixel_arr_on_bmp2_with_zoom1(pixels_arr1 As ArrayList, ByRef bmp1 As Bitmap, color_to_set1 As Color, zoom1 As Integer)
        Dim i1 As Integer
        Dim last_x1 As Integer = -1
        Dim last_y1 As Integer = -1
        For i1 = 0 To pixels_arr1.Count - 1
            Try
                Dim x1 As Integer = Integer.Parse(pixels_arr1(i1).ToString().Split(",")(0)) * zoom1
                Dim y1 As Integer = Integer.Parse(pixels_arr1(i1).ToString().Split(",")(1)) * zoom1

                If x1 >= 0 And x1 < bmp1.Width And y1 >= 0 And y1 < bmp1.Height Then
                    bmp1.SetPixel(x1, y1, color_to_set1)

                End If

                If last_x1 <> -1 And last_y1 <> -1 Then

                    Dim pixels_line1 As ArrayList = create_pixel_arr_line_from_2_2d_points(last_x1, last_y1, x1, y1)
                    set_pixel_arr_on_bmp2(pixels_line1, bmp1, color_to_set1)
                Else

                End If
                last_x1 = x1
                last_y1 = y1
            Catch ex As Exception
                Try
                    Dim x1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(0)) * zoom1
                    Dim y1 As Integer = Double.Parse(pixels_arr1(i1).ToString().Split(",")(1)) * zoom1
                    If x1 >= 0 And x1 < bmp1.Width And y1 >= 0 And y1 < bmp1.Height Then
                        bmp1.SetPixel(x1, y1, color_to_set1)

                    End If



                    If last_x1 <> -1 And last_y1 <> -1 Then

                        Dim pixels_line1 As ArrayList = create_pixel_arr_line_from_2_2d_points(last_x1, last_y1, x1, y1)
                        set_pixel_arr_on_bmp2(pixels_line1, bmp1, color_to_set1)
                    Else

                    End If
                    last_x1 = x1
                    last_y1 = y1

                Catch ex2 As Exception

                End Try
            End Try



        Next
    End Function


    Public Function set_pixel_arr_on_bmp_with_width2(pixels_arr1 As ArrayList, ByRef bmp1 As Bitmap, width1 As Integer, color_to_set1 As Color)
        Dim i1 As Integer

        For i1 = 0 To pixels_arr1.Count - 1
            Try
                bmp1 = CGlobals1.draw_sqr_around_pixels(bmp1, Integer.Parse(pixels_arr1(i1).ToString().Split(",")(0)), Integer.Parse(pixels_arr1(i1).ToString().Split(",")(1)), width1 / 2, color_to_set1)
                'bmp1.SetPixel(Integer.Parse(pixels_arr1(i1).ToString().Split(",")(0)), Integer.Parse(pixels_arr1(i1).ToString().Split(",")(1)), color_to_set1)

            Catch ex As Exception

            End Try
        Next
    End Function

    Public Function check_if_sobel_found()
        'x_start2 = 60
        'y_start2 = 2
        '1446,706

        'x_start2 = 40
        'y_start2 = 820
        'bmp1 = CGlobals1.copy_bitmap1(bmp_current_sobel)

        'Return bmp1
        'Dim cord1 As Integer() = find_start_point1(CGlobals1.current_start_x1, CGlobals1.current_start_y1)
        'CGlobals1.current_start_x1 = cord1(0)
        'CGlobals1.current_start_y1 = cord1(1)


        If cur_sobel_ind_val1 >= 4 Then
            Dim d1 As Integer = 1
        End If

        bmp1 = CGlobals1.copy_bitmap1(bmp_current_sobel)
        Dim cord1 As Integer() = find_start_point2()
        x_start2 = cord1(0)
        y_start2 = cord1(1)










        bmp_current_sobel.Save(CGlobals1.global_path1 + "sobel_pics1\" + cur_sobel_ind_val1.ToString() + "_b.bmp")
        Try
            Dim bmp1 As Bitmap = next_pixels_loop1()
            Dim bmp2 As Bitmap = CGlobals1.copy_bitmap1(bmp_current_sobel)
            set_pixel_arr_on_bmp1(pixels_cords_arr1, bmp2)
            bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\" + cur_sobel_ind_val1.ToString() + "_sb1.bmp")

            Return bmp1

        Catch ex As Exception
            Dim e1 As Integer = 1
        End Try
        If success_status = "arrive_to_start_point" Then
            MessageBox.Show("arrive sobel value")

        End If

    End Function

    Public Function set_3d_arr_pixels_on_bmp1(pixels_3d_cords_arr As ArrayList, ByRef bmp1 As Bitmap, color1 As Color)
        Dim i1 As Integer

        For i1 = 0 To pixels_3d_cords_arr.Count - 1
            Dim point_3d_obj1 As point_3d1 = pixels_3d_cords_arr(i1)
            Try
                bmp1.SetPixel(point_3d_obj1.x1, point_3d_obj1.y1, color1)

            Catch ex As Exception

            End Try
        Next

    End Function


    Public Function set_3d_arr_pixels_on_bmp1_prespective(pixels_3d_cords_arr As ArrayList, ByRef bmp1 As Bitmap, color1 As Color)

        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
        vec_3d_obj1.p1.z1 = -5000
        vec_3d_obj1.p1.x1 = bmp1.Width / 2
        vec_3d_obj1.p1.y1 = bmp1.Height / 2


        Dim i1 As Integer

        For i1 = 0 To pixels_3d_cords_arr.Count - 1
            Dim point_3d_obj1 As point_3d1 = pixels_3d_cords_arr(i1)
            Try
                vec_3d_obj1.p2.x1 = point_3d_obj1.x1
                vec_3d_obj1.p2.y1 = point_3d_obj1.y1
                vec_3d_obj1.p2.z1 = point_3d_obj1.z1

                Dim x_dir1 As Double = vec_3d_obj1.p2.x1 - vec_3d_obj1.p1.x1
                Dim y_dir1 As Double = vec_3d_obj1.p2.y1 - vec_3d_obj1.p1.y1
                Dim z_dir1 As Double = vec_3d_obj1.p2.z1 - vec_3d_obj1.p1.z1
                Dim z_plane1 As Double = -2000
                'vec_3d_obj1.p2.z1+z_dir1 * a1 = -50
                'z_dir1 * a1=-50-vec_3d_obj1.p2.z1
                'a1=(-50-vec_3d_obj1.p2.z1)/z_dir1
                'z_dir1=(-50-vec_3d_obj1.p2.z1))/a1
                Dim a1 As Double
                a1 = (z_plane1 - vec_3d_obj1.p2.z1) / z_dir1
                Dim x_val1 As Double = vec_3d_obj1.p2.x1 + a1 * x_dir1
                Dim y_val1 As Double = vec_3d_obj1.p2.y1 + a1 * y_dir1
                'Dim xy_vals1 As Double() = vec_3d_obj1.compute_xy_by_z1(-2000)
                bmp1.SetPixel(x_val1, y_val1, color1)

            Catch ex As Exception

            End Try
        Next

    End Function


    Public Function count_pixel_around(bmp1 As Bitmap, x1 As Integer, y1 As Integer, color_pixels_around1 As Color)
        Dim i1 As Integer
        Dim count_pixels_around1 As Integer = 0
        For i1 = 0 To CGlobals1.dir_arr2.Length / 2 - 1
            Dim color1 As Color = get_pixel_at1(bmp1, x1 + CGlobals1.dir_arr2(i1, 0), y1 + CGlobals1.dir_arr2(i1, 1))
            If compare_colors1(color1, color_pixels_around1) = 1 Then
                count_pixels_around1 += 1
            End If
        Next
        If count_pixels_around1 = 1 Then
            count_pixels_around1 = 0
            For i1 = 0 To CGlobals1.dir_arr2.Length / 2 - 1
                If compare_colors1(get_pixel_at1(bmp1, x1 + CGlobals1.dir_arr2(i1, 0), y1 + CGlobals1.dir_arr2(i1, 1)), color_pixels_around1) = 1 Then
                    count_pixels_around1 += 1
                End If
            Next
        End If
        Return count_pixels_around1
    End Function
    Public Function get_pixel_at1(bmp1 As Bitmap, x1 As Integer, y1 As Integer)
        If x1 >= 0 And y1 >= 0 And x1 <= bmp1.Width - 1 And y1 <= bmp1.Height - 1 Then
            Return bmp1.GetPixel(x1, y1)
        Else
            Return Nothing
        End If
    End Function

    Public Function compare_colors1(color1 As Color, color2 As Color)
        If color1.R = color2.R And color1.G = color2.G And color1.B = color2.B Then
            Return 1
        End If

        Return 0
    End Function

    Public Function check_minimum_angle1(start_ind As Integer, current_ind As Integer, pixels_arr As ArrayList)

    End Function

    'פונקציה שמחפשת קווים לפי עובי מקסימלי
    Public Function find_line_in_pixels_arr(pixels_arr As ArrayList, start_ind1 As Integer, line_len1 As Integer, max_line_width1 As Integer)
        If (start_ind1 + line_len1) >= pixels_arr.Count - 1 Then
            Return 0
        End If

        Dim i1 As Integer
        'Dim line_len1 As Integer = 2390
        Dim x1 As Integer = Integer.Parse(pixels_arr(start_ind1).ToString().Split(",")(0))
        Dim y1 As Integer = Integer.Parse(pixels_arr(start_ind1).ToString().Split(",")(1))
        Dim x2 As Integer = Integer.Parse(pixels_arr(start_ind1 + line_len1).ToString().Split(",")(0))
        Dim y2 As Integer = Integer.Parse(pixels_arr(start_ind1 + line_len1).ToString().Split(",")(1))

        Dim angle1 As Double = Math.Atan((y2 - y1) / (x2 - x1)) * 180 / Math.PI



        Dim pnt_3d_obj1a As point_3d1 = New point_3d1()

        pnt_3d_obj1a.x1 = x2 - x1
        pnt_3d_obj1a.y1 = y2 - y1
        pnt_3d_obj1a.z1 = 0

        pnt_3d_obj1a.rotate_z1(-angle1)
        Dim min_y1 As Double = 99
        Dim max_y1 As Double = 99
        Dim width_ok1 As Integer = 1
        For i1 = start_ind1 To start_ind1 + line_len1
            Dim x3 As Integer = Integer.Parse(pixels_arr(i1).ToString().Split(",")(0))
            Dim y3 As Integer = Integer.Parse(pixels_arr(i1).ToString().Split(",")(1))

            Dim pnt_3d_obj1 As point_3d1 = New point_3d1()

            pnt_3d_obj1.x1 = x3 - x1
            pnt_3d_obj1.y1 = y3 - y1
            pnt_3d_obj1.z1 = 0
            Dim cord_xy3 As String = pnt_3d_obj1.x1.ToString() + "," + pnt_3d_obj1.y1.ToString()

            pnt_3d_obj1.rotate_z1(-angle1)
            Dim new_cord_xy3 As String = pnt_3d_obj1.x1.ToString() + "," + pnt_3d_obj1.y1.ToString()
            If i1 = start_ind1 Then
                min_y1 = pnt_3d_obj1.y1
                max_y1 = pnt_3d_obj1.y1
            Else
                If min_y1 > pnt_3d_obj1.y1 Then
                    min_y1 = pnt_3d_obj1.y1
                End If
                If max_y1 < pnt_3d_obj1.y1 Then
                    max_y1 = pnt_3d_obj1.y1
                End If
            End If

            If Math.Abs(max_y1 - min_y1) > max_line_width1 Then
                width_ok1 = 0
            End If
            Dim d1 As Integer = 1

        Next

        Return width_ok1
    End Function


    Public Function find_start_point2()

        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\" + cur_sobel_ind_val1.ToString() + "_b3.bmp")

        Dim current_start_x1 As Double = CGlobals1.current_start_x1
        Dim current_start_y1 As Double = CGlobals1.current_start_y1

        current_start_x1 += CGlobals1.dir_x1_to_sobel
        current_start_y1 += CGlobals1.dir_m1_to_sobel

        current_start_x1 += CGlobals1.dir_x1_to_sobel
        current_start_y1 += CGlobals1.dir_m1_to_sobel

        Dim x_start2 As Integer = current_start_x1
        Dim y_start2 As Integer = current_start_y1


        While (bmp1.GetPixel(x_start2, y_start2).R <> color_of_sobel.R Or
                   bmp1.GetPixel(x_start2, y_start2).G <> color_of_sobel.G Or
                   bmp1.GetPixel(x_start2, y_start2).B <> color_of_sobel.B) And y_start2 < bmp1.Height - 1 And x_start2 < bmp1.Width - 1
            current_start_x1 += CGlobals1.dir_x1_to_sobel
            current_start_y1 += CGlobals1.dir_m1_to_sobel


            x_start2 = Math.Floor(current_start_x1)
            y_start2 = Math.Floor(current_start_y1)

        End While

        Return New Integer() {x_start2, y_start2}

    End Function

    Public Function find_start_point_by_line1(bmp1 As Bitmap, line_of_pxls_arr1 As ArrayList, Optional start_ind1 As Integer = -1)
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)

        Dim i1 As Integer
        i1 = 0
        If start_ind1 <> -1 Then
            i1 = start_ind1
        End If
        Dim xy_cord1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)

        While xy_cord1(0) >= copy_bmp1.Width - 3 Or xy_cord1(1) >= copy_bmp1.Height - 3 Or xy_cord1(0) <= 3 Or xy_cord1(1) <= 3

            i1 += 1
            xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)
        End While


        While compare_colors1(get_pixel_at1(copy_bmp1, xy_cord1(0), xy_cord1(1)), color_of_sobel) = 1 And xy_cord1(1) < copy_bmp1.Height - 1 And xy_cord1(0) < copy_bmp1.Width - 1
            i1 += 1
            xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)

        End While


        While (get_pixel_at1(copy_bmp1, xy_cord1(0), xy_cord1(1)).R <> color_of_sobel.R Or
                   get_pixel_at1(copy_bmp1, xy_cord1(0), xy_cord1(1)).G <> color_of_sobel.G Or
                   get_pixel_at1(copy_bmp1, xy_cord1(0), xy_cord1(1)).B <> color_of_sobel.B) And xy_cord1(1) < copy_bmp1.Height - 1 And xy_cord1(0) < copy_bmp1.Width - 1
            i1 += 1
            xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)

        End While


        Return {xy_cord1(0), xy_cord1(1), i1}
    End Function

    Public Function find_start_point3(bmp1 As Bitmap)

        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        copy_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\" + cur_sobel_ind_val1.ToString() + "_b3.bmp")

        Dim current_start_x1 As Double = CGlobals1.current_start_x1
        Dim current_start_y1 As Double = CGlobals1.current_start_y1

        While Math.Round(current_start_x1) >= copy_bmp1.Width - 3 Or Math.Round(current_start_y1) >= copy_bmp1.Height - 3 Or Math.Round(current_start_x1) <= 3 Or Math.Round(current_start_y1) <= 3
            current_start_x1 += CGlobals1.dir_x1_to_sobel
            current_start_y1 += CGlobals1.dir_m1_to_sobel

        End While

        'current_start_x1 += CGlobals1.dir_x1_to_sobel
        'current_start_y1 += CGlobals1.dir_m1_to_sobel

        Dim x_start2 As Integer = current_start_x1
        Dim y_start2 As Integer = current_start_y1


        While (copy_bmp1.GetPixel(x_start2, y_start2).R <> color_of_sobel.R Or
                   copy_bmp1.GetPixel(x_start2, y_start2).G <> color_of_sobel.G Or
                   copy_bmp1.GetPixel(x_start2, y_start2).B <> color_of_sobel.B) And y_start2 < copy_bmp1.Height - 1 And x_start2 < copy_bmp1.Width - 1
            current_start_x1 += CGlobals1.dir_x1_to_sobel
            current_start_y1 += CGlobals1.dir_m1_to_sobel


            x_start2 = Math.Floor(current_start_x1)
            y_start2 = Math.Floor(current_start_y1)

        End While

        Return New Integer() {x_start2, y_start2}
    End Function

    Public Function compute_current_start_cord_and_vec1()

        If CGlobals1.step_num1 = 3 Then
            Dim d3 As Integer = 1
        End If
        Dim str_cord1 As String = CGlobals1.current_max_arr_sobel(CGlobals1.current_max_arr_sobel.Count * 0.9 - 1)
        Dim str_cord2 As String = CGlobals1.current_max_arr_sobel(CGlobals1.current_max_arr_sobel.Count * 0.98 - 1)

        Dim pnt_3d_obj1 As point_3d1 = New point_3d1()
        pnt_3d_obj1.x1 = Integer.Parse(str_cord1.Split(",")(0).ToString())
        pnt_3d_obj1.y1 = Integer.Parse(str_cord1.Split(",")(1).ToString())


        Dim pnt_3d_obj2 As point_3d1 = New point_3d1()
        pnt_3d_obj2.x1 = Integer.Parse(str_cord2.Split(",")(0).ToString())
        pnt_3d_obj2.y1 = Integer.Parse(str_cord2.Split(",")(1).ToString())

        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        Dim pxls1 As ArrayList = create_pixel_arr_line_from_2_2d_points(pnt_3d_obj1.x1, pnt_3d_obj1.y1, pnt_3d_obj2.x1, pnt_3d_obj2.y1)
        set_pixel_arr_on_bmp2(pxls1, copy_bmp1, Color.FromArgb(255, 10, 10))
        Dim pnt_3d_obj_1_2a As point_3d1 = New point_3d1()
        'הנקודה במרכז הקו שבין 2 הנקודות שלוקחים מהם רפרנס של הפיקסלים האחרונים שהגענו עד עכשיו
        pnt_3d_obj_1_2a.x1 = (pnt_3d_obj1.x1 + pnt_3d_obj2.x1) / 2
        pnt_3d_obj_1_2a.y1 = (pnt_3d_obj1.y1 + pnt_3d_obj2.y1) / 2

        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
        vec_3d_obj1.p1 = pnt_3d_obj_1_2a.clone1()
        vec_3d_obj1.p2 = pnt_3d_obj_1_2a.clone1()
        vec_3d_obj1.p2.z1 += 10
        'הנקודה לכיוון הנקודה למרכז הקו
        Dim pnt_3d_obj_1_2b As point_3d1 = pnt_3d_obj2.clone1()

        rotate_around_arbitrary_axis(vec_3d_obj1, pnt_3d_obj_1_2b, -90)
        'rotate_around_arbitrary_axis(vec_3d_obj1, pnt_3d_obj_1_2b, 90)

        Dim pxls2 As ArrayList = create_pixel_arr_line_from_2_2d_points(pnt_3d_obj_1_2a.x1, pnt_3d_obj_1_2a.y1, pnt_3d_obj_1_2b.x1, pnt_3d_obj_1_2b.y1)
        set_pixel_arr_on_bmp2(pxls2, copy_bmp1, Color.FromArgb(25, 255, 10))

        copy_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\compute_step_" + CGlobals1.step_num1.ToString() + ".jpg")
        'הכיוון הוא
        'b->a


        Dim m1 As Double = (pnt_3d_obj_1_2a.y1 - pnt_3d_obj_1_2b.y1) / (pnt_3d_obj_1_2a.x1 - pnt_3d_obj_1_2b.x1)


        Dim dir_x1 As Integer = -1
        If pnt_3d_obj_1_2b.x1 < pnt_3d_obj_1_2a.x1 Then
            dir_x1 = 1
            'm1 = -m1
        End If

        If pnt_3d_obj_1_2b.y1 < pnt_3d_obj_1_2a.y1 Then
            m1 = Math.Abs(m1)
        Else
            m1 = -Math.Abs(m1)
            'm1 = -m1
        End If

        If pnt_3d_obj_1_2a.x1 = pnt_3d_obj_1_2b.x1 Then
            If pnt_3d_obj_1_2b.y1 < pnt_3d_obj_1_2a.y1 Then
                m1 = 1
            Else
                m1 = -1
                'm1 = -m1
            End If
            dir_x1 = 0
        End If

        Dim cur_x1 As Double = pnt_3d_obj_1_2a.x1
        Dim cur_y1 As Double = pnt_3d_obj_1_2a.y1

        While cur_x1 > 0 And cur_x1 < bmp1.Width - 1 And cur_y1 > 0 And cur_y1 < bmp1.Height - 1
            cur_x1 += -dir_x1
            cur_y1 += -m1
        End While

        CGlobals1.dir_x1_to_sobel = -1
        If pnt_3d_obj_1_2b.x1 < pnt_3d_obj_1_2a.x1 Then
            CGlobals1.dir_x1_to_sobel = 1
        End If

        If Math.Abs(m1) > 1 Then

        End If
        CGlobals1.dir_m1_to_sobel = m1
        CGlobals1.dir_x1_to_sobel = dir_x1


        If Math.Abs(m1) > 1 Then
            CGlobals1.dir_m1_to_sobel = 1
            If m1 < 0 Then
                CGlobals1.dir_m1_to_sobel = -1
            End If
            CGlobals1.dir_x1_to_sobel /= Math.Abs(m1)
        End If

        CGlobals1.current_start_x1 = cur_x1
        CGlobals1.current_start_y1 = cur_y1
        'While 

        'CGlobals1.dir_x1_to_sobel =

        'pnt_3d_obj_1_2b.rotate_z1(90)





    End Function


    Public Function compute_dir_to_pixels1(pnt_3d_obj1 As point_3d1, pnt_3d_obj2 As point_3d1)
        'Dim str_cord1 As String = CGlobals1.current_max_arr_sobel(CGlobals1.current_max_arr_sobel.Count * 0.9 - 1)
        'Dim str_cord2 As String = CGlobals1.current_max_arr_sobel(CGlobals1.current_max_arr_sobel.Count * 0.98 - 1)

        'Dim pnt_3d_obj1 As point_3d1 = New point_3d1()
        'pnt_3d_obj1.x1 = Integer.Parse(str_cord1.Split(",")(0).ToString())
        'pnt_3d_obj1.y1 = Integer.Parse(str_cord1.Split(",")(1).ToString())


        'Dim pnt_3d_obj2 As point_3d1 = New point_3d1()
        'pnt_3d_obj2.x1 = Integer.Parse(str_cord2.Split(",")(0).ToString())
        'pnt_3d_obj2.y1 = Integer.Parse(str_cord2.Split(",")(1).ToString())

        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        Dim pxls1 As ArrayList = create_pixel_arr_line_from_2_2d_points(pnt_3d_obj1.x1, pnt_3d_obj1.y1, pnt_3d_obj2.x1, pnt_3d_obj2.y1)
        set_pixel_arr_on_bmp2(pxls1, copy_bmp1, Color.FromArgb(255, 10, 10))
        Dim pnt_3d_obj_1_2a As point_3d1 = New point_3d1()
        'הנקודה במרכז הקו שבין 2 הנקודות שלוקחים מהם רפרנס של הפיקסלים האחרונים שהגענו עד עכשיו
        pnt_3d_obj_1_2a.x1 = (pnt_3d_obj1.x1 + pnt_3d_obj2.x1) / 2
        pnt_3d_obj_1_2a.y1 = (pnt_3d_obj1.y1 + pnt_3d_obj2.y1) / 2

        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
        vec_3d_obj1.p1 = pnt_3d_obj_1_2a.clone1()
        vec_3d_obj1.p2 = pnt_3d_obj_1_2a.clone1()
        vec_3d_obj1.p2.z1 += 10
        'הנקודה לכיוון הנקודה למרכז הקו
        Dim pnt_3d_obj_1_2b As point_3d1 = pnt_3d_obj2.clone1()

        rotate_around_arbitrary_axis(vec_3d_obj1, pnt_3d_obj_1_2b, -90)
        'rotate_around_arbitrary_axis(vec_3d_obj1, pnt_3d_obj_1_2b, 90)

        Dim pxls2 As ArrayList = create_pixel_arr_line_from_2_2d_points(pnt_3d_obj_1_2a.x1, pnt_3d_obj_1_2a.y1, pnt_3d_obj_1_2b.x1, pnt_3d_obj_1_2b.y1)
        set_pixel_arr_on_bmp2(pxls2, copy_bmp1, Color.FromArgb(25, 255, 10))

        'copy_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\compute_step" + CGlobals1.step_num1.ToString() + ".jpg")
        'הכיוון הוא
        'b->a


        Dim m1 As Double = (pnt_3d_obj_1_2a.y1 - pnt_3d_obj_1_2b.y1) / (pnt_3d_obj_1_2a.x1 - pnt_3d_obj_1_2b.x1)


        Dim dir_x1 As Integer = -1
        If pnt_3d_obj_1_2b.x1 < pnt_3d_obj_1_2a.x1 Then
            dir_x1 = 1
            'm1 = -m1
        End If

        If pnt_3d_obj_1_2b.y1 < pnt_3d_obj_1_2a.y1 Then
            m1 = Math.Abs(m1)
        Else
            m1 = -Math.Abs(m1)
            'm1 = -m1
        End If

        If pnt_3d_obj_1_2a.x1 = pnt_3d_obj_1_2b.x1 Then
            If pnt_3d_obj_1_2b.y1 < pnt_3d_obj_1_2a.y1 Then
                m1 = 1
            Else
                m1 = -1
                'm1 = -m1
            End If
            dir_x1 = 0
        End If

        Dim cur_x1 As Double = pnt_3d_obj_1_2a.x1
        Dim cur_y1 As Double = pnt_3d_obj_1_2a.y1

        While cur_x1 > 0 And cur_x1 < bmp1.Width - 1 And cur_y1 > 0 And cur_y1 < bmp1.Height - 1
            cur_x1 += -dir_x1
            cur_y1 += -m1
        End While

        'CGlobals1.dir_x1_to_sobel = -1
        If pnt_3d_obj_1_2b.x1 < pnt_3d_obj_1_2a.x1 Then
            'CGlobals1.dir_x1_to_sobel = 1
        End If

        Dim dict_prms1 As Dictionary(Of String, Double) = New Dictionary(Of String, Double)
        dict_prms1("dir_x1") = dir_x1
        dict_prms1("m1") = m1
        Return dict_prms1

        'While 

        'CGlobals1.dir_x1_to_sobel =

        'pnt_3d_obj_1_2b.rotate_z1(90)





    End Function


    Public Function get_max_diff_bmp1(bmp1 As Bitmap)

        Dim path1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_max_diff1.jpg"
        If System.IO.File.Exists(path1) = True Then

            Dim bmp5 As Bitmap = New Bitmap(path1)

            Return bmp5
        End If


        Dim bmp2 As Bitmap = rgb_to_monochrome1(bmp1)
        Dim bmp3 As Bitmap = compute_max_diff_from_neighboors1(bmp2)
        bmp3.Save(path1)

        Return bmp3
    End Function








    Public Function check_if_dist_over_then1(new_cords_arr1 As ArrayList)
        Dim i1 As Integer

        For i1 = 0 To new_cords_arr1.Count - 2
            Dim cord_xya1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_cords_arr1, i1)
            Dim cord_xya2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_cords_arr1, i1 + 1)

            If get_dist_between_2_cords_xy1(cord_xya1, cord_xya2) > 3 Then
                Dim err1 As Integer = 1

                Return -1
            End If
        Next

        Return 1
    End Function
    Public Function check_if_overlap_pixel1(cords_dict1 As Dictionary(Of String, Integer), cords_dict2 As Dictionary(Of String, Integer), pad1 As Integer)

        Dim to_stop3 As Integer = 0
        Dim exist_overlap_slice_curve1 As String = ""
        Dim cord_ind1 As Integer = 0
        Dim min_cord_ind1 As Integer = 0
        Dim min_dist_cord1 As Double = 99

        Dim cord_con_dict1_xy1(2) As Integer
        Dim cord_con_dict2_xy1(2) As Integer

        While to_stop3 = 0



            Dim x1 As Integer
            Dim y1 As Integer

            Dim cord_xy_str1 As String() = cords_dict1.Keys(cord_ind1).Split(",")
            Dim cord_xy1(2) As Integer
            cord_xy1(0) = Integer.Parse(cord_xy_str1(0))
            cord_xy1(1) = Integer.Parse(cord_xy_str1(1))

            Dim cord_xy2(2) As Integer

            For x1 = -pad1 To pad1
                For y1 = -pad1 To pad1
                    cord_xy2(0) = cord_xy1(0) + x1
                    cord_xy2(1) = cord_xy1(1) + y1
                    If cords_dict2.ContainsKey(cord_xy2(0).ToString() + "," + cord_xy2(1).ToString()) = True Then

                        If min_dist_cord1 > (Math.Abs(x1) + Math.Abs(y1)) Or min_dist_cord1 = 99 Then
                            min_dist_cord1 = (Math.Abs(x1) + Math.Abs(y1))

                            min_cord_ind1 = cord_ind1

                            cord_con_dict1_xy1(0) = cord_xy1(0)
                            cord_con_dict1_xy1(1) = cord_xy1(1)

                            cord_con_dict2_xy1(0) = cord_xy2(0)
                            cord_con_dict2_xy1(1) = cord_xy2(1)

                        End If
                        'to_stop3 = 1
                        exist_overlap_slice_curve1 = "yes"

                    End If
                Next

            Next
            cord_ind1 += 1
            If cord_ind1 > cords_dict1.Count - 1 Then
                to_stop3 = 1
            End If
        End While

        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        If exist_overlap_slice_curve1 = "yes" Then
            dict_ret_res1("min_cord_ind1") = min_cord_ind1
            dict_ret_res1("cord_con_dict1_xy1") = cord_con_dict1_xy1
            dict_ret_res1("cord_con_dict2_xy1") = cord_con_dict2_xy1
        Else
            dict_ret_res1("min_cord_ind1") = -1
        End If

        Return dict_ret_res1

    End Function







    Public Function loop_on_sobel_vals3(line_to_search_start_sobel_pixels1 As ArrayList)

        CGlobals1.dir_x1_to_sobel = 1

        CGlobals1.dir_m1_to_sobel = 0

        'CGlobals1.current_start_x1 = 1340
        'CGlobals1.current_start_y1 = 3

        CGlobals1.current_start_x1 = 500 '200
        CGlobals1.current_start_y1 = 3


        'CGlobals1.current_start_x1 = 370 '200
        'CGlobals1.current_start_y1 = 273


        CGlobals1.current_start_x1 = 1400 '200
        CGlobals1.current_start_y1 = 1000


        CGlobals1.dir_x1_to_sobel = 0
        CGlobals1.dir_m1_to_sobel = 1

        'Dim line_to_search_start_sobel_pixels1 As ArrayList = create_pixel_arr_line_from_2_2d_points(500, 0, 500, 1000)
        'Dim line_to_search_start_sobel_pixels1 As ArrayList = create_pixel_arr_line_from_2_2d_points(1400, 1000, 1400, 2000)
        'Dim line_to_search_start_sobel_pixels1 As ArrayList = create_pixel_arr_line_from_2_2d_points(2400, 500, 2400, 2000)
        'Dim line_to_search_start_sobel_pixels1 As ArrayList = create_pixel_arr_line_from_2_2d_points(500, 0, 500, 2000)
        'Dim line_to_search_start_sobel_pixels1 As ArrayList = create_pixel_arr_from_2_2d_points(370, 273, 370, 1000)
        Dim to_stop_round_with_sobal1 As Integer = 0
        'הקו שמקיף את הסובל וגדל לפי החלקים שמחברים אליו בכל אינטרציה
        Dim current_pixel_line_arr1 As ArrayList = New ArrayList()
        'מפתח שאומר אם הנקודה על הקו ומה האינדקס שלה
        Dim dict_current_pixel_line_arr1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        'For x1 = 0 To bmp_current_sobel.Width - 1
        'For y1 = 0 To bmp_current_sobel.Height - 1
        'bmp_current_sobel.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))
        'Next

        'Next

        Dim clear_bmp1 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)
        Dim first_pixels_arr1 As ArrayList
        Dim image_ind1 As Integer = 0

        Dim dict_max_dist_sobel As Dictionary(Of Double, Object) = New Dictionary(Of Double, Object)
        'Dim dcit_pixel_arr_around_sobel_by_sobel_ind1 As Dictionary(Of Integer, ArrayList) = New Dictionary(Of Integer, ArrayList)
        While to_stop_round_with_sobal1 = 0


            If CGlobals1.step_num1 = 2 Then
                Dim d1 As Integer = 1
            End If

            CGlobals1.max_last_index_all_exist_in_prev_pixels1 = -1


            'CGlobals1.step_num1 += 1
            'cur_sobel_ind_val1 = 0
            Dim to_stop1 As Integer = 0
            CGlobals1.max_pixels_arr_length1 = -99
            CGlobals1.max_count_pixels1 = -99
            Dim dict_result_by_sobel_val1 As Dictionary(Of Integer, Object) = New Dictionary(Of Integer, Object)

            If CGlobals1.step_num1 = 9 Then
                Dim d1 As Integer = 1
            End If
            Dim step_num2 As Integer = 0
            Dim last_srat_cord_line_line1 As Integer = -1
            While to_stop1 = 0
                last_srat_cord_line_line1 = -1
                cur_sobel_ind_val1 += 1
                Try
                    bmp_current_sobel = New Bitmap(CGlobals1.path_of_sobel_cache1 + "\" + cur_sobel_ind_val1.ToString() + ".jpg")
                Catch ex As Exception
                    Dim err1 As Integer = 1
                End Try

                'add_dec_sobel_ind("add1", 1)

                Dim to_stop_search_start_point1 As Integer = 0
                Dim dict_res1 As Dictionary(Of String, Object)


                If CGlobals1.global_suffix_file_name1 = "_right_glass1" And cur_sobel_ind_val1 = 3 Then
                    Dim d1 As Integer = 1
                End If
                Dim found_around_sobel As String = "yes"
                'לולאה שמחפשת את הפיקסל הראשון שממנו אפשר לבצע הקפה
                While to_stop_search_start_point1 = 0

                    find_start_sobel1(cur_sobel_ind_val1, line_to_search_start_sobel_pixels1, Me.bmp_current_sobel)
                    Dim cord1 As Integer()
                    Try
                        cord1 = find_start_point_by_line1(Me.bmp_current_sobel, line_to_search_start_sobel_pixels1, last_srat_cord_line_line1)
                        x_start2 = cord1(0)
                        y_start2 = cord1(1)

                    Catch ex As Exception
                        found_around_sobel = "no"
                        to_stop_search_start_point1 = 1
                    End Try


                    dict_res1 = find_max_sobel_length2(x_start2, y_start2)
                    If dict_res1 IsNot Nothing Then
                        If CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList).Count <= CGlobals1.min_pixel_arr_count1 Then
                            found_around_sobel = "no"
                        End If
                        If CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList).Count <= 0 Then
                            last_srat_cord_line_line1 = cord1(2)
                        Else
                            to_stop_search_start_point1 = 1
                        End If

                        If CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList).Count > 0 Then
                            Dim dict_rect_pxls1 As Dictionary(Of String, Object) = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"))
                            If CGlobals1.min_pixel_x1 <> -1 Then
                                If dict_rect_pxls1("min_x1") > CGlobals1.min_pixel_x1 Then
                                    found_around_sobel = "no"
                                End If
                            End If
                            If CGlobals1.max_pixel_x1 <> -1 Then
                                If dict_rect_pxls1("max_x1") < CGlobals1.max_pixel_x1 Then
                                    found_around_sobel = "no"
                                End If
                            End If
                        End If

                    End If

                End While

                If found_around_sobel = "yes" Then

                    dict_result_by_sobel_val1(cur_sobel_ind_val1) = dict_res1



                    If dict_result_by_sobel_val1.ContainsKey(cur_sobel_ind_val1 - 1) = True Then

                        Dim copy_bmp_current_sobel1 As Bitmap = CGlobals1.copy_bitmap1(bmp_current_sobel)
                        Dim prev_dict_res1 As Dictionary(Of String, Object) = dict_result_by_sobel_val1(cur_sobel_ind_val1 - 1)

                        save_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_2d_pixels_sobel_" + (cur_sobel_ind_val1 - 1).ToString() + CGlobals1.global_suffix_file_name1 + ".txt", prev_dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"))
                        Dim prev_pixel_arr1 As ArrayList = prev_dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1")
                        Dim pixel_arr1 As ArrayList = dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1")
                        Dim to_mesaure_smoothness As String = "no"
                        If to_mesaure_smoothness = "yes" Then

                            'Dim dict_res_smothness1 As Dictionary(Of String, Object) = measure_pixels_arr_smoothess(pixel_arr1, 3)
                            Dim dict_res_smothness1 As Dictionary(Of String, Object) = measure_pixels_arr_smoothess(prev_pixel_arr1, 2)
                            Dim dict_left_smoothness1 As Dictionary(Of Integer, Double) = dict_res_smothness1("dict_max_left_len1")
                            Dim dict_right_smoothness1 As Dictionary(Of Integer, Double) = dict_res_smothness1("dict_max_right_len1")
                            Dim dict_smoothness1 As Dictionary(Of Integer, Double) = dict_res_smothness1("dict_max_len1")
                            Dim dict_right_to_left_smothnress1 As Dictionary(Of Integer, Double) = dict_res_smothness1("dict_max_left_and_right_len1")
                            Dim ind3 As Integer = 0
                            'לולאה שרצה על כל הנקודות שיש בהן רעש או פיתול שהוא כמו רעב
                            While dict_right_to_left_smothnress1(dict_right_to_left_smothnress1.Keys(ind3)) < 10 And ind3 < dict_right_to_left_smothnress1.Keys.Count
                                'While True
                                'End While
                                If True Then
                                    'dict_left_smoothness1(dict_smoothness1.Keys(ind3)) < 20 And dict_right_smoothness1(dict_smoothness1.Keys(ind3)) < 20 Then
                                    'End If



                                    Dim ind4 As Integer = dict_smoothness1.Keys(ind3)
                                    Dim cord_xy3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(prev_pixel_arr1, ind4)
                                    Dim x1a As Integer
                                    Dim y1a As Integer

                                    For x1a = cord_xy3(0) - 3 To cord_xy3(0) + 3
                                        For y1a = cord_xy3(1) - 3 To cord_xy3(1) + 3
                                            copy_bmp_current_sobel1.SetPixel(x1a, y1a, Color.FromArgb(100, 30, 150))

                                        Next

                                    Next
                                    If False Then

                                        ind4 = dict_right_smoothness1.Keys(ind3)
                                        cord_xy3 = CGlobals1.get_cord_xy_in_pixels_arr1(prev_pixel_arr1, ind4)


                                        For x1a = cord_xy3(0) - 3 To cord_xy3(0) + 3
                                            For y1a = cord_xy3(1) - 3 To cord_xy3(1) + 3
                                                copy_bmp_current_sobel1.SetPixel(x1a, y1a, Color.FromArgb(100, 30, 150))

                                            Next

                                        Next

                                    End If
                                End If
                                ind3 += 1
                            End While
                        End If

                        For ind3 = 10 To 50

                        Next
                        'עבור כל הפיקסלים מהשלה הנוכחי - מוצאים פיקסלים שהם במרחק מקסימלי של 15 מהפיקסלים מהשלב הקודם
                        'Dim pixels_arr_that_contain1 As Dictionary(Of String, String) = check_if_pixels_arr_contain_other_pixels_arr_by_sqr_distance(pixel_arr1, prev_pixel_arr1, 15)
                        Dim dict_res2 As Dictionary(Of String, Object) = check_if_pixels_arr_contain_other_pixels_arr_by_sqr_distance(pixel_arr1, prev_pixel_arr1, 15)

                        Dim pixels_arr_that_contain1 As Dictionary(Of String, String) = dict_res2("pixels_arr_that_contain1")

                        'Dim copy_bmp1 As Bitmap = set_pixels_arr_and_save2(pixel_arr1, CGlobals1.copy_bitmap1(bmp_current_sobel), Color.FromArgb(200, 30, 30), CGlobals1.global_path1 + "\sobel_pics1\step_pxls_res_" + CGlobals1.step_num1.ToString() + "_" + cur_sobel_ind_val1.ToString() + ".jpg")
                        set_pixels_arr_and_save2(prev_pixel_arr1, copy_bmp_current_sobel1, Color.FromArgb(20, 230, 0), CGlobals1.global_path1 + "\sobel_pics1\step_pxls_res_" + image_ind1.ToString() + "_" + cur_sobel_ind_val1.ToString() + ".jpg")
                        image_ind1 += 1

                        'מחשבים את המרחק המקסימלי בין השלב הנוכחי לשלב הקודם
                        Dim ind2 As Integer
                        Dim max_dist1 As Double = -99
                        For ind2 = 0 To pixels_arr_that_contain1.Count - 1
                            Dim cord_xy_str1 As String = pixels_arr_that_contain1.Keys(ind2)
                            Dim cord_xy_str2 As String = pixels_arr_that_contain1(cord_xy_str1)
                            Dim x1 As Integer = Integer.Parse(cord_xy_str1.Split(",")(0))
                            Dim y1 As Integer = Integer.Parse(cord_xy_str1.Split(",")(1))
                            Dim x2 As Integer = Integer.Parse(cord_xy_str2.Split(",")(0))
                            Dim y2 As Integer = Integer.Parse(cord_xy_str2.Split(",")(1))
                            Dim dist1 As Double = Math.Pow(Math.Pow(x1 - x2, 2) + Math.Pow(y1 - y2, 2), 0.5)
                            If max_dist1 < dist1 Then
                                max_dist1 = dist1
                            End If
                        Next
                        dict_max_dist_sobel(max_dist1) = dict_res1

                        Dim d3 As Integer = 4
                        If max_dist1 <= CGlobals1.max_dist_between_sobel_line1 Or dict_res2("no_all_conatained1") = "yes" Then
                            to_stop_round_with_sobal1 = 1
                            to_stop1 = 1

                            Dim path_sign_sobel_ind1 As String = CGlobals1.global_path1 + form_obj1.file_name1 + "_sign_sobel_ind1" + CGlobals1.global_suffix_file_name1 + ".txt"
                            System.IO.File.WriteAllText(path_sign_sobel_ind1, (cur_sobel_ind_val1 - 1).ToString())

                        End If
                    End If


                    set_pixels_arr_and_save1(CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList), CGlobals1.copy_bitmap1(bmp_current_sobel), CGlobals1.global_path1 + "\sobel_pics1\step_res_" + CGlobals1.step_num1.ToString() + "_" + cur_sobel_ind_val1.ToString() + ".jpg")
                    clear_bmp1 = set_pixels_arr_and_save1(CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList), clear_bmp1, CGlobals1.global_path1 + "\sobel_pics1\step_res1_" + CGlobals1.step_num1.ToString() + "_" + cur_sobel_ind_val1.ToString() + ".jpg")

                    If False And dict_res1("max_angle1") <= 90 And dict_res1("percent_ok_angles1") >= 0.9 And CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList).Count > 30 Then
                        to_stop1 = 1
                        If first_pixels_arr1 IsNot Nothing Then
                            Dim pixels_arr_that_contain1 As Dictionary(Of String, String) = check_if_pixels_arr_contain_other_pixels_arr_by_sqr_distance(CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList), first_pixels_arr1, 3)
                            If pixels_arr_that_contain1.Count > 5 And CGlobals1.step_num1 > 2 Then
                                to_stop_round_with_sobal1 = 1
                            End If
                        End If
                        Dim i1 As Integer
                        For i1 = 0 To CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList).Count - 1
                            current_pixel_line_arr1.Add(CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList)(i1))
                        Next

                        If CGlobals1.step_num1 = 0 Then
                            first_pixels_arr1 = CType(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), ArrayList).Clone()
                        End If

                    End If

                    CGlobals1.current_max_arr_sobel = dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1")
                    'Dim res_str1 As String = find_max_sobel_length1()
                    'If res_str1 = "stop_sobel1" Or res_str1 = "arrive_to_start_point" Then
                    'to_stop1 = 1
                    'End If
                End If

            End While




            If CGlobals1.step_num1 = 3 Then
                Dim d1 As Integer = 3
            End If
            'compute_current_start_cord_and_vec1()
            CGlobals1.step_num1 += 1
        End While


    End Function

    Public Function loop_on_sobel_vals2()

        CGlobals1.dir_x1_to_sobel = 1

        CGlobals1.dir_m1_to_sobel = 0

        'CGlobals1.current_start_x1 = 1340
        'CGlobals1.current_start_y1 = 3

        CGlobals1.current_start_x1 = 1319 '200
        CGlobals1.current_start_y1 = 3

        CGlobals1.dir_x1_to_sobel = 0
        CGlobals1.dir_m1_to_sobel = 1
        Dim to_stop_round_with_sobal1 As Integer = 0
        'הקו שמקיף את הסובל וגדל לפי החלקים שמחברים אליו בכל אינטרציה
        Dim current_pixel_line_arr1 As ArrayList = New ArrayList()
        'מפתח שאומר אם הנקודה על הקו ומה האינדקס שלה
        Dim dict_current_pixel_line_arr1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        While to_stop_round_with_sobal1 = 0

            If CGlobals1.step_num1 = 2 Then
                Dim d1 As Integer = 1
            End If

            CGlobals1.max_last_index_all_exist_in_prev_pixels1 = -1
            For x1 = 0 To bmp_current_sobel.Width - 1
                For y1 = 0 To bmp_current_sobel.Height - 1
                    bmp_current_sobel.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))
                Next

            Next

            CGlobals1.step_num1 += 1
            cur_sobel_ind_val1 = 0
            Dim to_stop1 As Integer = 0
            CGlobals1.max_pixels_arr_length1 = -99
            CGlobals1.max_count_pixels1 = -99
            While to_stop1 = 0
                'Dim res_str2 As String = find_max_sobel_length2()
                Dim res_str1 As String = find_max_sobel_length1()
                If res_str1 = "stop_sobel1" Or res_str1 = "arrive_to_start_point" Then
                    to_stop1 = 1
                End If
                'If res_str1 = "stop_sobel1" Then


                '
                'End If
                If False Then

                    If CGlobals1.max_last_index_all_exist_in_prev_pixels1 < pixels_cords_arr1.Count And pixels_cords_arr1.Count > 0 And CGlobals1.max_last_index_all_exist_in_prev_pixels1 > -1 Then
                        While pixels_cords_arr1.Count > CGlobals1.max_last_index_all_exist_in_prev_pixels1
                            pixels_cords_arr1.RemoveAt(pixels_cords_arr1.Count - 1)
                        End While
                        While CGlobals1.current_max_arr_sobel.Count > CGlobals1.max_last_index_all_exist_in_prev_pixels1
                            CGlobals1.current_max_arr_sobel.RemoveAt(CGlobals1.current_max_arr_sobel.Count - 1)
                        End While
                        CGlobals1.current_max_arr_sobel = pixels_cords_arr1.Clone()
                        res_str1 = "stop_sobel1"
                    End If
                End If

                If res_str1 = "arrive_to_start_point" Then
                    to_stop_round_with_sobal1 = 1
                End If
                If cur_sobel_ind_val1 >= CGlobals1.dict_sobel_pixels.Keys.Count - 3 Or cur_sobel_ind_val1 > 1000 Then
                    to_stop1 = 1
                End If
            End While
            'בודקים אם יש קו שכבר חושב כדי להוסיף לו את המקטע החדש
            If current_pixel_line_arr1.Count > 0 Then


                'מעבירים את התוצאה של הקו למפתח
                Dim dict_pixels_cords1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
                Dim i1 As Integer

                For i1 = 0 To CGlobals1.current_max_arr_sobel.Count - 1
                    dict_pixels_cords1(CGlobals1.current_max_arr_sobel(i1)) = i1
                Next

                '--
                Dim last_index_of_dict_pixels_cords1 As Integer = -1
                last_index_of_dict_pixels_cords1 = current_pixel_line_arr1.Count - 1

                Dim start_index_of_pixels_cords_arr1 As Integer = -1

                'מחפשים את הערך האחרון בקו המצבטר שהוא גם בקו שצריך להוסיף
                Try
                    While dict_pixels_cords1.ContainsKey(current_pixel_line_arr1(last_index_of_dict_pixels_cords1)) = False
                        last_index_of_dict_pixels_cords1 -= 1
                    End While

                Catch ex As Exception

                End Try
                If last_index_of_dict_pixels_cords1 < 0 Then
                    last_index_of_dict_pixels_cords1 = 0
                End If
                'בעיה של נפילה שמפתח לא תמיד קיים
                'start_index_of_pixels_cords_arr1 = dict_pixels_cords1(current_pixel_line_arr1(last_index_of_dict_pixels_cords1))

                '----

                For i1 = current_pixel_line_arr1.Count - 1 To 0

                    dict_pixels_cords1(pixels_cords_arr1(i1)) = i1
                Next

                If dict_current_pixel_line_arr1.Count > 0 Then



                    Dim start_ind1 As Integer = -1
                    Dim end_ind1 As Integer = -1
                    Try

                        i1 = 1
                        While start_ind1 = -1
                            If dict_current_pixel_line_arr1.ContainsKey(CGlobals1.current_max_arr_sobel(i1)) Then
                                start_ind1 = i1
                            End If
                            i1 += 1

                        End While
                    Catch ex As Exception

                    End Try

                    Try

                        i1 = CGlobals1.current_max_arr_sobel.Count - 1
                        While end_ind1 = -1
                            If dict_current_pixel_line_arr1.ContainsKey(CGlobals1.current_max_arr_sobel(i1)) Then
                                end_ind1 = i1
                            End If
                            i1 -= 1

                        End While
                    Catch ex As Exception

                    End Try

                End If

                'For i1 = 1 To CGlobals1.current_max_arr_sobel.Count - 1
                'If dict_current_pixel_line_arr1.ContainsKey(CGlobals1.current_max_arr_sobel(i1)) Then
                'start_ind1 = i1
                'End If
                ''current_pixel_line_arr1.Add(CGlobals1.current_max_arr_sobel(i1))
                'Next

            Else

            End If

            For i1 = 0 To CGlobals1.current_max_arr_sobel.Count - 1
                current_pixel_line_arr1.Add(CGlobals1.current_max_arr_sobel(i1))
            Next

            For i1 = 0 To current_pixel_line_arr1.Count - 1
                dict_current_pixel_line_arr1(current_pixel_line_arr1(i1)) = i1
            Next


            Dim crop_bmp2 As Bitmap = New Bitmap(CGlobals1.global_path1 + form_obj1.file_name1 + "_crop1.jpg")
            set_pixel_arr_on_bmp2(current_pixel_line_arr1, crop_bmp2, color_of_region)
            crop_bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\step_" + CGlobals1.step_num1.ToString() + ".jpg")

            If CGlobals1.step_num1 = 2 Then
                Dim d1 As Integer = 1
            End If

            compute_current_start_cord_and_vec1()


            If CGlobals1.step_num1 = 4 Then
                to_stop_round_with_sobal1 = 1
            End If

        End While
        Dim crop_bmp1 As Bitmap = New Bitmap(CGlobals1.global_path1 + form_obj1.file_name1 + "_crop1.jpg")
        set_pixel_arr_on_bmp2(current_pixel_line_arr1, crop_bmp1, color_of_region)
        crop_bmp1.Save(CGlobals1.global_path1 + form_obj1.file_name1 + "_crop_sobel1.jpg")
    End Function


    Public Function get_sobel_width_for_every_pixels(pixels_arr1 As ArrayList)
        bmp_current_sobel.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_width1.jpg")
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp_current_sobel)
        set_pixel_arr_on_bmp2(pixels_cords_arr1, copy_bmp1, Color.FromArgb(200, 30, 20))
        copy_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\copy_bmp1_sobel_width1.jpg")
        Dim i1 As Integer
        Dim min_sobel_width1 As Integer = 999
        For i1 = 0 To pixels_arr1.Count - 1 Step 20
            Dim start_ind1 As Integer = i1
            Dim end_ind1 As Integer = Math.Min(i1 + 20, pixels_arr1.Count - 1)


            Dim pnt_3d_obj1 As point_3d1 = New point_3d1()
            pnt_3d_obj1.x1 = Integer.Parse(pixels_arr1(start_ind1).ToString().Split(",")(0).ToString())
            pnt_3d_obj1.y1 = Integer.Parse(pixels_arr1(start_ind1).ToString().Split(",")(1).ToString())


            Dim pnt_3d_obj2 As point_3d1 = New point_3d1()
            pnt_3d_obj2.x1 = Integer.Parse(pixels_arr1(Math.Min(end_ind1, pixels_arr1.Count - 1)).ToString().Split(",")(0).ToString())
            pnt_3d_obj2.y1 = Integer.Parse(pixels_arr1(Math.Min(end_ind1, pixels_arr1.Count - 1)).ToString().Split(",")(1).ToString())

            Dim dict_prms1 As Dictionary(Of String, Double) = compute_dir_to_pixels1(pnt_3d_obj1, pnt_3d_obj2)

            Dim i2 As Integer
            end_ind1 = start_ind1 + 1
            For i2 = start_ind1 To end_ind1
                Dim x1 As Integer = Integer.Parse(pixels_arr1(i2).ToString().Split(",")(0).ToString())
                Dim y1 As Integer = Integer.Parse(pixels_arr1(i2).ToString().Split(",")(1).ToString())

                While compare_colors1(get_pixel_at1(bmp_current_sobel, x1, y1), color_of_bg) = 0

                    x1 += -dict_prms1("dir_x1")
                    y1 += -dict_prms1("m1")
                End While
                'copy_bmp1.SetPixel(x1, y1, Color.FromArgb(1, 255, 1))

                While compare_colors1(get_pixel_at1(bmp_current_sobel, x1, y1), color_of_bg) = 1

                    x1 += dict_prms1("dir_x1")
                    y1 += dict_prms1("m1")
                    copy_bmp1.SetPixel(x1, y1, Color.FromArgb(1, 111, 255))
                End While
                'copy_bmp1.SetPixel(x1, y1, Color.FromArgb(1, 1, 255))
                Dim sobel_width1 As Integer = 0
                While compare_colors1(get_pixel_at1(bmp_current_sobel, x1, y1), color_of_bg) = 0

                    x1 += dict_prms1("dir_x1")
                    y1 += dict_prms1("m1")
                    sobel_width1 += 1
                    copy_bmp1.SetPixel(x1, y1, Color.FromArgb(255, 25, 55))
                End While

                If sobel_width1 = 1 Then
                    Dim d2 As Integer = 1
                End If
                'copy_bmp1.SetPixel(x1, y1, Color.FromArgb(255, 25, 55))

                If min_sobel_width1 > sobel_width1 Then
                    min_sobel_width1 = sobel_width1
                End If

            Next
            Dim d1 As Integer = 1
        Next
        copy_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\copy_bmp1_sobel_width2.jpg")

        Return min_sobel_width1
    End Function

    Public Function loop_on_sobel_vals()

        CGlobals1.step_num1 = 0
        Dim to_stop1 As Integer = 0
        While to_stop1 = 0
            Dim res_str1 As String = find_max_sobel_length1()
            If res_str1 = "stop_sobel1" Or res_str1 = "arrive_to_start_point" Then
                to_stop1 = 1
            End If
            If cur_sobel_ind_val1 >= CGlobals1.dict_sobel_pixels.Keys.Count - 3 Or cur_sobel_ind_val1 > 1000 Then
                to_stop1 = 1
            End If
        End While

        pixels_cords_arr1 = max_pixels_cords_arr1.Clone()
        Dim dict_pixels_arr_1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        Dim i1 As Integer

        For i1 = 0 To pixels_cords_arr1.Count - 1
            dict_pixels_arr_1(pixels_cords_arr1(i1)) = 1
        Next
        'Dim str_cord1 As String = CGlobals1.current_max_arr_sobel(CGlobals1.current_max_arr_sobel.Count - 5)




        compute_current_start_cord_and_vec1()



        'Dim cord1 As Integer() = find_start_point1(CGlobals1.current_start_x1, CGlobals1.current_start_y1)
        'CGlobals1.current_start_x1 = cord1(0)
        'CGlobals1.current_start_y1 = cord1(1)

        For x1 = 0 To bmp_current_sobel.Width - 1
            For y1 = 0 To bmp_current_sobel.Height - 1
                bmp_current_sobel.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))
            Next

        Next


        CGlobals1.step_num1 = 1
        cur_sobel_ind_val1 = 0
        to_stop1 = 0
        CGlobals1.max_pixels_arr_length1 = -99
        CGlobals1.max_count_pixels1 = -99
        While to_stop1 = 0
            Dim res_str1 As String = find_max_sobel_length1()
            If res_str1 = "stop_sobel1" Or res_str1 = "arrive_to_start_point" Then
                to_stop1 = 1
            End If

            If cur_sobel_ind_val1 >= CGlobals1.dict_sobel_pixels.Keys.Count - 3 Or cur_sobel_ind_val1 > 1000 Then
                to_stop1 = 1
            End If
        End While
        Dim new_pixel_arr2 As ArrayList = max_pixels_cords_arr1.Clone()

        Dim end_ind_sobel1 As Integer = -1
        For i1 = 1 To new_pixel_arr2.Count - 1
            If dict_pixels_arr_1.ContainsKey(new_pixel_arr2(i1)) Then
                If end_ind_sobel1 = -1 Then
                    end_ind_sobel1 = i1
                End If
                Dim d1 As Integer = 2
            End If

        Next

        For i1 = 1 To end_ind_sobel1 - 1
            pixels_cords_arr1.Add(new_pixel_arr2(i1))

        Next
    End Function




    Public Function find_max_sobel_length3(start_x1 As Integer, start_y1 As Integer)
        Dim dict_res1 As Dictionary(Of String, Object)

        If cur_sobel_ind_val1 >= CGlobals1.dict_sobel_pixels.Keys.Count - 5 Then
            Return dict_res1

        End If

        Dim start_store1 As String = ""


        'Dim cord1 As Integer() = find_start_point3(Me.bmp_current_sobel)
        'x_start2 = cord1(0)
        'y_start2 = cord1(1)

        x_start2 = start_x1
        y_start2 = start_y1

        Dim dict_result1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        'set_pixels_arr_and_save1(pixels_around_sobel_arr1, Me.bmp_current_sobel, CGlobals1.global_path1 + "\sobel_pics1\pixels2.jpg")
        Try
            Me.bmp_current_sobel.Save(CGlobals1.global_path1 + "\sobel_pics1\to_find_line1_" + CGlobals1.step_num1.ToString() + ".jpg")

        Catch ex As Exception

        End Try
        dict_res1 = next_pixels_loop3(Me.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1, Nothing)




        Dim dict_res2 As Dictionary(Of String, Object) = next_pixels_loop3(Me.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1_rev, Nothing)

        dict_result1("pixels_around_sobel_arr1") = dict_res1
        dict_result1("pixels_around_sobel_arr1_rev") = dict_res2



        Return dict_result1

    End Function



    Public Function find_max_sobel_length2(start_x1 As Integer, start_y1 As Integer)
        Dim dict_res1 As Dictionary(Of String, Object)

        If cur_sobel_ind_val1 >= CGlobals1.dict_sobel_pixels.Keys.Count - 5 Then
            Return dict_res1

        End If

        Dim start_store1 As String = ""


        'Dim cord1 As Integer() = find_start_point3(Me.bmp_current_sobel)
        'x_start2 = cord1(0)
        'y_start2 = cord1(1)

        x_start2 = start_x1
        y_start2 = start_y1

        Dim dict_result1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        'set_pixels_arr_and_save1(pixels_around_sobel_arr1, Me.bmp_current_sobel, CGlobals1.global_path1 + "\sobel_pics1\pixels2.jpg")
        Try
            Me.bmp_current_sobel.Save(CGlobals1.global_path1 + "\sobel_pics1\to_find_line1_" + CGlobals1.step_num1.ToString() + ".jpg")

        Catch ex As Exception

        End Try
        dict_res1 = next_pixels_loop3(Me.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1, Nothing)




        Dim dict_res2 As Dictionary(Of String, Object) = next_pixels_loop3(Me.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1_rev, Nothing)

        dict_result1("pixels_around_sobel_arr1") = dict_res1
        dict_result1("pixels_around_sobel_arr1_rev") = dict_res2

        Dim pixels_around_sobel_arr1 As ArrayList = dict_res1("pixels_cords_arr1")
        Dim angles_arr1 As ArrayList = get_angle_change_of_pixels_arr1(pixels_around_sobel_arr1, 4)
        dict_result1("angles_arr1") = angles_arr1
        Dim seq_arr1 As ArrayList = CGlobals1.find_max_seq_that_val_between1(angles_arr1, -50, 50)
        set_pixels_arr_and_save1(pixels_around_sobel_arr1, Me.bmp_current_sobel, CGlobals1.global_path1 + "sobel_pics1\pixels_" + CGlobals1.step_num1.ToString() + ".jpg")

        Dim max_angle1 As Double = CGlobals1.get_max_value_in_arraylist1(angles_arr1, True)
        dict_result1("max_angle1") = max_angle1
        Dim count_angle_in_range1 As Integer = CGlobals1.count_value_in_arraylist1(angles_arr1, -30, 30)
        dict_result1("count_angle_in_range1") = count_angle_in_range1
        Dim percent_ok_angles1 As Double = (count_angle_in_range1 / angles_arr1.Count)
        dict_result1("percent_ok_angles1") = percent_ok_angles1
        If percent_ok_angles1 > 0.95 Then
            Dim d3 As Integer = 1
        End If
        If (seq_arr1.Count / angles_arr1.Count) < 0.05 Then
            Dim d1 As Integer = 1
        End If
        Dim d2 As Integer = 1

        Return dict_result1

    End Function
    Public Function find_max_sobel_length1()
        If cur_sobel_ind_val1 >= CGlobals1.dict_sobel_pixels.Keys.Count - 5 Then
            Return "stop_sobel1"

        End If

        Dim start_store1 As String = ""
        add_dec_sobel_ind("add1", 1)


        Dim bmp1 As Bitmap = check_if_sobel_found()

        Dim new_sobel_line_arr1 As ArrayList = New ArrayList()
        Dim count_pixels1 As Integer = pixels_cords_arr1.Count

        set_pixels_arr_and_save1(pixels_cords_arr1, bmp_current_sobel, CGlobals1.global_path1 + "\sobel_pics1\pxls1_" + CGlobals1.step_num1.ToString() + ".jpg")
        Dim angles_arr1 As ArrayList = get_angle_change_of_pixels_arr1(pixels_cords_arr1, 2)
        Dim seq_arr1 As ArrayList = CGlobals1.find_max_seq_that_val_between1(angles_arr1, -50, 50)
        If seq_arr1.Count / angles_arr1.Count < 0.05 Then
            Dim d1 As Integer = 1
        End If
        Dim min_angle1 As Double = CGlobals1.get_max_value_in_arraylist1(angles_arr1, True)

        Dim i1 As Integer
        Dim count_equal1 As Integer = 0
        Dim first_pixel_ind1 As Integer = -1
        Dim last_pixel_ind1 As Integer = -1



        For i1 = 0 To count_pixels1 - 1

            If CGlobals1.last_dict_sobel_line_pixels1.ContainsKey(pixels_cords_arr1(i1).ToString()) = True Then
                count_equal1 += 1
                new_sobel_line_arr1.Add(pixels_cords_arr1(i1).ToString())
                If first_pixel_ind1 = -1 Then
                    first_pixel_ind1 = i1
                Else
                    If first_pixel_ind1 > i1 Then
                        first_pixel_ind1 = i1
                    End If
                End If

                If last_pixel_ind1 = -1 Then
                    last_pixel_ind1 = i1
                Else
                    If last_pixel_ind1 < i1 Then
                        last_pixel_ind1 = i1
                    End If
                End If
            Else
                'first_pixel_ind1 = i1 + 1
            End If
        Next

        Dim last_index_all_exist_in_prev_pixels1 As Integer = -1
        If CGlobals1.last_dict_sobel_line_pixels1.Count > 0 And first_pixel_ind1 >= 0 Then
            Dim to_stop2 As Integer = 0
            i1 = first_pixel_ind1
            While CGlobals1.last_dict_sobel_line_pixels1.ContainsKey(pixels_cords_arr1(i1).ToString()) = True And to_stop2 = 0
                last_index_all_exist_in_prev_pixels1 = i1
                If CGlobals1.max_last_index_all_exist_in_prev_pixels1 < last_index_all_exist_in_prev_pixels1 Then
                    CGlobals1.max_last_index_all_exist_in_prev_pixels1 = last_index_all_exist_in_prev_pixels1
                End If
                i1 += 1
                If pixels_cords_arr1.Count = i1 + 1 Then
                    to_stop2 = 1
                End If
            End While
        End If

        'For i1 = first_pixel_ind1 To count_pixels1 - 1
        'If CGlobals1.last_dict_sobel_line_pixels1.ContainsKey(pixels_cords_arr1(i1).ToString()) = True Then
        'last_index_all_exist_in_prev_pixels1 = i1
        'Else

        'End If

        'Next


        new_sobel_line_arr1 = pixels_cords_arr1.Clone()
        Dim store_sobel_line1 As Integer = 0
        If CGlobals1.max_count_pixels1 < count_equal1 Then
            CGlobals1.max_count_pixels1 = count_equal1
            If CGlobals1.max_count_pixels1 >= 200 And start_store1 = "" Then
                start_store1 = "yes"
            End If
            If start_store1 = "yes" Then
                Dim min_sobel_width1 As Integer = get_sobel_width_for_every_pixels(pixels_cords_arr1)
                If (min_sobel_width1 >= 2) Then
                    store_sobel_line1 = 1
                Else
                    start_store1 = "no"
                End If
            End If

            CGlobals1.current_max_sobel_ind1 = cur_sobel_ind_val1
        Else
            If CGlobals1.max_count_pixels1 = count_equal1 Then

            End If
        End If


        CGlobals1.last_dict_sobel_line_pixels1.Clear()
        For i1 = 0 To count_pixels1 - 1
            CGlobals1.last_dict_sobel_line_pixels1(pixels_cords_arr1(i1).ToString()) = 1
        Next
        CGlobals1.ind1 += 1

        Dim bmp2 As Bitmap = CGlobals1.copy_bitmap1(bmp_current_sobel)
        If store_sobel_line1 = 1 Then


            If (last_pixel_ind1 - first_pixel_ind1) > 50 Then

                pixels_cords_arr1.Clear()
                For i1 = first_pixel_ind1 To last_pixel_ind1
                    pixels_cords_arr1.Add(new_sobel_line_arr1(i1))
                Next
            End If


            max_pixels_cords_arr1 = pixels_cords_arr1.Clone()
        End If
        set_pixel_arr_on_bmp1(pixels_cords_arr1, bmp2)
        'bmp2.Save("D:\glass_pics1\sobel_pics1\" + CGlobals1.ind1.ToString() + "a.bmp")
        bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\" + cur_sobel_ind_val1.ToString() + "_b2.bmp")

        'bmp_current_sobel.Save("D:\glass_pics1\sobel_pics1\" + CGlobals1.ind1.ToString() + ".bmp")


        If CGlobals1.max_pixels_arr_length1 < count_pixels1 Then
            CGlobals1.max_pixels_arr_length1 = count_pixels1

            CGlobals1.current_max_arr_sobel = pixels_cords_arr1.Clone()

            CGlobals1.max_sobel_length_bmp1 = CGlobals1.copy_bitmap1(bmp_current_sobel)



        End If
        If count_pixels1 > 4000 Then
            Dim ind_len1 As Integer
            ind_len1 = 3400
            Dim to_stop_w1 As Integer = 1
            While to_stop_w1 = 0
                Dim res1 As Integer = find_line_in_pixels_arr(pixels_cords_arr1, 120, ind_len1, 5)
                If res1 = 1 Then
                    to_stop_w1 = 1
                Else
                    ind_len1 -= 1
                End If

            End While
            For ind_len1 = 10 To 1500

            Next

        End If
        'Dim cord_strs1 As String = pixels_cords_arr1(pixels_cords_arr1.Count - 1)

        'set_pixel_arr_on_bmp1(pixels_cords_arr1, bmp1)

        If success_status = "arrive_to_start_point" Then
            'markingfldimg_obj1.find_line_in_pixels_arr(markingfldimg_obj1.pixels_cords_arr1, 0, 10, 4)

            Return success_status
        End If
        Return ""
    End Function

    Public Function get_change_color_on_region_by_dir(bmp1 As Bitmap, start_x1 As Integer, start_y1 As Integer, width1 As Integer, height1 As Integer)

        Dim x1 As Integer
        Dim y1 As Integer
        Dim max_color_change1 As Integer = -1
        Dim last_y1_max_color_change As Integer = -1
        Dim delta_y_from_last_y1 As Integer = 2
        For x1 = start_x1 To start_x1 + width1
            max_color_change1 = -1
            Dim y1_max_color_chage As Integer = -1
            Dim dict_max_change_with_y1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
            For y1 = start_y1 To start_y1 + height1

                If (y1 < last_y1_max_color_change - delta_y_from_last_y1 Or y1 < last_y1_max_color_change + delta_y_from_last_y1) And last_y1_max_color_change <> -1 Then
                Else
                    Dim color_change1 As Integer = Math.Abs(CType(bmp1.GetPixel(x1, y1).R, Integer) - CType(bmp1.GetPixel(x1, y1 - 1).R, Integer)) + Math.Abs(CType(bmp1.GetPixel(x1, y1).R, Integer) - CType(bmp1.GetPixel(x1, y1 + 1).R, Integer))
                    dict_max_change_with_y1(color_change1) = y1
                    If max_color_change1 < color_change1 Then
                        max_color_change1 = color_change1
                        y1_max_color_chage = y1
                    End If

                End If

            Next

            Dim sorted = From pair In dict_max_change_with_y1
                         Order By pair.Key
            Dim sortedDictionary = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)

            dict_max_change_with_y1 = sortedDictionary
            Dim y2 As Integer
            For y2 = dict_max_change_with_y1.Keys.Count - 1 - 1 To dict_max_change_with_y1.Keys.Count - 1
                Dim y2_cord As Integer = dict_max_change_with_y1(dict_max_change_with_y1.Keys(y2))
                bmp1.SetPixel(x1, y2_cord, Color.FromArgb(255, 30, 30))
            Next
            'bmp1.SetPixel(x1, y1_max_color_chage, Color.FromArgb(255, 30, 30))
        Next

    End Function


    Public Function find_simetric_line1(pixel_arr1 As ArrayList)
        Dim start_x1 As Integer = 300
        Dim start_y1 As Integer = 3
        Dim line_height1 As Integer = 50
        Dim start_deg As Double = 45
        Dim point_3d_obj1 As point_3d1 = New point_3d1()
        point_3d_obj1.x1 = start_x1
        point_3d_obj1.y1 = start_y1


        Dim point_3d_obj2 As point_3d1 = New point_3d1()
        point_3d_obj1.x1 = start_x1
        point_3d_obj1.y1 = start_y1 + line_height1

        Dim vec_3d_obj1 = New vec_3d1()
        vec_3d_obj1.p1 = point_3d_obj1
        vec_3d_obj1.p2 = point_3d_obj1.clone1()
        vec_3d_obj1.p2.z1 -= 10
        Dim point_3d_obj2b As point_3d1 = point_3d_obj2.clone1()

        Dim x_pos1 As Integer

        Dim copy_bmp1c = New Bitmap(bmp1.Width, bmp1.Height)
        set_pixel_arr_on_bmp1(pixel_arr1, copy_bmp1c)
        copy_bmp1c.Save(CGlobals1.global_path1 + form_obj1.file_name1 + "_center1c.jpg")


        rotate_around_arbitrary_axis(vec_3d_obj1, point_3d_obj2b, start_deg)
        Dim sum_stia_arr1 As ArrayList = New ArrayList()
        Dim min_stia_val1 As Integer = 999999
        Dim min_stia_rot_angle1 As Double = 9999
        Dim min_stia_x_pos1 As Integer = 9999
        Dim rot_angle1 As Double = -0.1

        'pixel_arr1 = rotate_2d_pixels_arr(pixel_arr1, vec_3d_obj1, 2)
        pixel_arr1 = pixels_arr_val_to_integer1(pixel_arr1)

        Dim copy_bmp1b As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        set_pixel_arr_on_bmp1(pixel_arr1, copy_bmp1b)
        copy_bmp1b.Save(CGlobals1.global_path1 + form_obj1.file_name1 + "_center1b.jpg")

        Dim bmp_width1 As Integer = bmp1.Width
        Dim bmp_height1 As Integer = bmp1.Height
        Dim rot_angle1b As Double
        For rot_angle1 = -3 To 3 Step 0.05

            'For rot_angle1b = 0 To 1
            'rot_angle1 = 0
            For x_pos1 = (bmp_width1 / 2 - 10) To (bmp_width1 / 2 + 10)



                Dim rot_pixels_arr1 As ArrayList = rotate_2d_pixels_arr(pixel_arr1, vec_3d_obj1, rot_angle1)
                'create_pixel_arr_from_2_2d_points(point_3d_obj1.x1, point_3d_obj1.y1, point_3d_obj2b.x1, point_3d_obj2b.y1)
                Dim dict_by_y_pos1 As Dictionary(Of Integer, ArrayList) = create_dict_y_pos_from_pixels_arr(rot_pixels_arr1)
                Dim y_pos1 As Integer
                If x_pos1 = 1388 / 2 + 2 Then
                    Dim d1 As Integer = 1
                End If
                'x_pos1 = 1388 / 2 + 2
                Dim sum_stia_val2 As Integer = 0
                For y_pos1 = 50 To bmp_height1 - 50
                    Dim pixels_arr_y_pos1 As ArrayList
                    If dict_by_y_pos1.ContainsKey(y_pos1) Then
                        pixels_arr_y_pos1 = dict_by_y_pos1(y_pos1)
                        If pixels_arr_y_pos1.Count Mod 2 <> 0 Then
                            Dim d2 As Integer = 1
                        End If
                        Dim dict_x_pos1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
                        Dim dict_x_pos1b As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
                        Dim to_check_stia1 As String = ""
                        For i1 = 0 To pixels_arr_y_pos1.Count - 1
                            Dim x_pos1b As Integer = CType(Math.Floor(Double.Parse(pixels_arr_y_pos1(i1).ToString().Split(",")(0))), Integer)
                            Dim y_pos1b As Integer = CType(Math.Floor(Double.Parse(pixels_arr_y_pos1(i1).ToString().Split(",")(0))), Integer)
                            Dim delta_x1 As Integer = x_pos1b - x_pos1
                            If Math.Abs(delta_x1) < 300 Then
                                dict_x_pos1(delta_x1) = 1
                                dict_x_pos1b(delta_x1) = 1
                                If Math.Abs(delta_x1) < 200 Then
                                    to_check_stia1 = "yes1"
                                End If
                            End If
                        Next
                        If dict_x_pos1.Count > 0 And to_check_stia1 = "yes1" Then
                            Dim d1 As Integer = 1
                            Dim sum_stia_val1 As Integer = sum_stia_delta1(dict_x_pos1, 200)
                            'Dim sum_stia_val1b As Integer = sum_stia_delta1(dict_x_pos1b, 200)

                            sum_stia_val2 += sum_stia_val1
                        End If
                    End If
                Next
                sum_stia_arr1.Add(sum_stia_val2)
                If min_stia_val1 > sum_stia_val2 Then
                    min_stia_val1 = sum_stia_val2
                    min_stia_rot_angle1 = rot_angle1
                    min_stia_x_pos1 = x_pos1
                End If
            Next
        Next

        Dim rot_pixels_arr1b As ArrayList = rotate_2d_pixels_arr(pixel_arr1, vec_3d_obj1, min_stia_rot_angle1)
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        copy_bmp1 = New Bitmap(bmp1.Width, bmp1.Height)
        'set_pixel_arr_on_bmp1(rot_pixels_arr1b, copy_bmp1)

        Dim p_ind1 As Integer

        For p_ind1 = 0 To rot_pixels_arr1b.Count - 1
            Dim x1 As Integer = Integer.Parse(Math.Round(Double.Parse(rot_pixels_arr1b(p_ind1).ToString().Split(",")(0))))
            Dim y1 As Integer = Integer.Parse(Math.Round(Double.Parse(rot_pixels_arr1b(p_ind1).ToString().Split(",")(1))))
            Try

                If x1 > min_stia_x_pos1 Then
                    x1 = min_stia_x_pos1 - Math.Abs(min_stia_x_pos1 - x1)
                    copy_bmp1.SetPixel(x1, y1, Color.FromArgb(200, 20, 200))
                Else
                    copy_bmp1.SetPixel(x1, y1, Color.FromArgb(25, 200, 200))

                End If
            Catch ex As Exception

            End Try

        Next
        copy_bmp1.Save(CGlobals1.global_path1 + form_obj1.file_name1 + "_center1.jpg")

    End Function

    Public Function sum_stia_delta1(dict_delta_x1 As Dictionary(Of Integer, Integer), max_delta_val1 As Integer)
        Dim i1 As Integer
        Dim i2 As Integer
        Dim i3 As Integer
        Dim sum_stia1 As Integer = 0
        Dim max_delta_to_remove1 As Integer
        Dim keys_to_remove_arr1 As ArrayList = New ArrayList()
        For max_delta_to_remove1 = 0 To 10
            Dim min_delta_key1 As String = ""
            Dim min_delta_key2 As String = ""
            Dim keys_str1 As String = ""
            For i1 = 0 To dict_delta_x1.Keys.Count - 1
                'Dim keys_str1 As String = dict_delta_x1.Keys(i1)
                Dim min_delta_val1 As Integer = 99


                For i2 = 0 To dict_delta_x1.Keys.Count - 1
                    If i1 <> i2 Then

                        Dim keys_str2 As String = dict_delta_x1.Keys(i2)
                        keys_str1 = dict_delta_x1.Keys(i1)
                        If max_delta_val1 > Integer.Parse(keys_str1) And max_delta_val1 > Integer.Parse(keys_str2) Then


                            Dim delta_x_val As Integer = Math.Abs(Integer.Parse(keys_str1) + Integer.Parse(keys_str2))
                            If delta_x_val = max_delta_to_remove1 Then
                                min_delta_key1 = keys_str1
                                min_delta_key2 = keys_str2
                                keys_to_remove_arr1.Add(keys_str1 + "," + keys_str2)
                                sum_stia1 += max_delta_to_remove1
                            End If
                        End If
                    End If

                Next
            Next


        Next


        For i3 = 0 To keys_to_remove_arr1.Count - 1
            dict_delta_x1.Remove(keys_to_remove_arr1(i3).ToString().Split(",")(0))
            dict_delta_x1.Remove(keys_to_remove_arr1(i3).ToString().Split(",")(1))

        Next
        'keys_to_remove_arr1.Clear()


        For i1 = 0 To dict_delta_x1.Keys.Count - 1
            If Math.Abs(Integer.Parse(dict_delta_x1.Keys(i1).ToString())) < max_delta_val1 Then
                sum_stia1 += Math.Abs(Integer.Parse(dict_delta_x1.Keys(i1).ToString()))

            End If

        Next

        Return sum_stia1
    End Function


    Public Function create_dict_y_pos_from_pixels_arr(pixels_arr1 As ArrayList)
        Dim dict_y_pos1 As Dictionary(Of Integer, ArrayList) = New Dictionary(Of Integer, ArrayList)

        For i1 = 0 To pixels_arr1.Count - 1
            Dim x_pos1 As Integer = CType(Math.Floor(Double.Parse(pixels_arr1(i1).ToString().Split(",")(0))), Integer)
            Dim y_pos1 As Integer = CType(Math.Floor(Double.Parse(pixels_arr1(i1).ToString().Split(",")(1))), Integer)
            Dim pixels_arr_y_pos1 As ArrayList
            If dict_y_pos1.ContainsKey(y_pos1) Then


            Else
                dict_y_pos1(y_pos1) = New ArrayList()
            End If
            pixels_arr_y_pos1 = dict_y_pos1(y_pos1)
            pixels_arr_y_pos1.Add(pixels_arr1(i1))

        Next
        Return dict_y_pos1
    End Function
    Public Function find_pixels_in_arr_by_y_pos(pixels_arr As ArrayList, y_pos1 As Integer)
        Dim i1 As Integer


    End Function
    Public Function create_pixel_arr_line_from_2_2d_points2(cord_xy1 As Integer(), cord_xy2 As Integer())
        Return create_pixel_arr_line_from_2_2d_points(cord_xy1(0), cord_xy1(1), cord_xy2(0), cord_xy2(1))
    End Function

    Public Function create_pixel_arr_line_from_2_2d_points(start_x1 As Double, start_y1 As Double, end_x1 As Double, end_y1 As Double)
        Dim pixel_arr1 As ArrayList = New ArrayList()

        Dim start_x2 As Double = start_x1
        Dim start_y2 As Double = start_y1
        Dim end_x2 As Double = end_x1
        Dim end_y2 As Double = end_y1

        If start_x1 > end_x1 Then
            start_x2 = end_x1
            start_y2 = end_y1
            end_x2 = start_x1
            end_y2 = start_y1
        End If
        Dim dir_y1 As Double = 1
        If start_y2 > end_y2 Then
            dir_y1 = -1
        End If
        Dim right_x1 As Double = end_x2
        Dim right_y1 As Double = end_y2
        Dim min_y1 As Double = Math.Min(start_y2, end_y2)
        Dim max_y1 As Double = Math.Max(start_y2, end_y2)


        Dim min_x1 As Double = Math.Min(start_x2, end_x2)
        Dim max_x1 As Double = Math.Max(start_x2, end_x2)

        Dim add_one1 As Integer = 1
        If (end_y1 - start_y1) < 0 Then
            add_one1 = -1
        End If
        Dim add_one2 As Integer = 1
        If (end_x1 - start_x1) < 0 Then
            add_one2 = -1
        End If
        Dim add_one3 As Integer = 1
        If (end_x1 - start_x1) < 0 Then
            add_one2 = -1
        End If

        Dim add_one4 As Integer = 1
        If (end_y1 - start_y1) < 0 Then
            add_one4 = -1
        End If
        add_one1 = 0
        add_one2 = 0
        add_one3 = 0
        add_one4 = 0
        Dim m1 As Double = ((end_y1 - start_y1) + add_one1) / ((end_x1 - start_x1) + add_one2)
        Dim m2 As Double = ((end_x1 - start_x1) + add_one3) / ((end_y1 - start_y1) + add_one4)
        Dim add_to_start1 As String = ""

        If start_x2 = end_x1 Then
            If start_x2 <> start_x1 Then

                add_to_start1 = "yes"
            Else

            End If
        End If
        If start_x2 = max_x1 Then
            m2 = -Math.Abs(m2)

        Else
            m2 = Math.Abs(m2)
        End If
        Dim to_stop1 As Integer = 0


        Dim x2_val1a As Integer = CType(Math.Floor(start_x2), Integer)
        Dim y2_val1a As Integer = CType(Math.Floor(start_y2), Integer)
        x2_val1a = CType(Math.Round(start_x2), Integer)
        y2_val1a = CType(Math.Round(start_y2), Integer)
        pixel_arr1.Add(x2_val1a.ToString() + "," + y2_val1a.ToString())

        While to_stop1 = 0
            If Math.Abs(m1) <= 1 Then
                start_x2 += 1
                start_y2 += m1
            Else
                start_x2 += m2
                start_y2 += dir_y1

            End If
            If start_x2 > max_x1 Or start_x2 < min_x1 Or start_y2 > max_y1 Or start_y2 < min_y1 Then

                If add_to_start1 = "yes" Then
                    If pixel_arr1(0) <> (start_x1.ToString() + "," + start_y1.ToString()) Then
                        pixel_arr1.Insert(0, start_x1.ToString() + "," + start_y1.ToString())

                    End If
                Else
                    If pixel_arr1(pixel_arr1.Count - 1) <> (end_x1.ToString() + "," + end_y1.ToString()) Then
                        pixel_arr1.Add(end_x1.ToString() + "," + end_y1.ToString())

                    End If

                End If

                to_stop1 = 1
            Else
                Dim x2_val1 As Integer = CType(Math.Floor(start_x2), Integer)
                Dim y2_val1 As Integer = CType(Math.Floor(start_y2), Integer)
                If add_to_start1 = "yes" Then
                    pixel_arr1.Insert(0, x2_val1.ToString() + "," + y2_val1.ToString())
                Else

                    pixel_arr1.Add(x2_val1.ToString() + "," + y2_val1.ToString())
                End If
            End If

        End While


        Return pixel_arr1
    End Function



    Public Function create_pixel_arr_line_from_2_2d_points_with_len_limit(start_x1 As Double, start_y1 As Double, end_x1 As Double, end_y1 As Double, len_limit1 As Integer)
        Dim pixel_arr1 As ArrayList = New ArrayList()

        Dim start_x2 As Double = start_x1
        Dim start_y2 As Double = start_y1
        Dim end_x2 As Double = end_x1
        Dim end_y2 As Double = end_y1

        If start_x1 > end_x1 Then
            start_x2 = end_x1
            start_y2 = end_y1
            end_x2 = start_x1
            end_y2 = start_y1
        End If
        Dim dir_y1 As Double = 1
        If start_y2 > end_y2 Then
            dir_y1 = -1
        End If
        Dim right_x1 As Double = end_x2
        Dim right_y1 As Double = end_y2
        Dim min_y1 As Double = Math.Min(start_y2, end_y2)
        Dim max_y1 As Double = Math.Max(start_y2, end_y2)


        Dim min_x1 As Double = Math.Min(start_x2, end_x2)
        Dim max_x1 As Double = Math.Max(start_x2, end_x2)

        Dim add_one1 As Integer = 1
        If (end_y1 - start_y1) < 0 Then
            add_one1 = -1
        End If
        Dim add_one2 As Integer = 1
        If (end_x1 - start_x1) < 0 Then
            add_one2 = -1
        End If
        Dim add_one3 As Integer = 1
        If (end_x1 - start_x1) < 0 Then
            add_one2 = -1
        End If

        Dim add_one4 As Integer = 1
        If (end_y1 - start_y1) < 0 Then
            add_one4 = -1
        End If
        add_one1 = 0
        add_one2 = 0
        add_one3 = 0
        add_one4 = 0
        Dim m1 As Double = ((end_y1 - start_y1) + add_one1) / ((end_x1 - start_x1) + add_one2)
        Dim m2 As Double = ((end_x1 - start_x1) + add_one3) / ((end_y1 - start_y1) + add_one4)
        Dim add_to_start1 As String = ""

        If start_x2 = end_x1 Then
            If start_x2 <> start_x1 Then

                add_to_start1 = "yes"
            Else

            End If
        End If
        If start_x2 = max_x1 Then
            m2 = -Math.Abs(m2)

        Else
            m2 = Math.Abs(m2)
        End If
        Dim to_stop1 As Integer = 0


        Dim x2_val1a As Integer = CType(Math.Floor(start_x2), Integer)
        Dim y2_val1a As Integer = CType(Math.Floor(start_y2), Integer)
        x2_val1a = CType(Math.Round(start_x2), Integer)
        y2_val1a = CType(Math.Round(start_y2), Integer)
        pixel_arr1.Add(x2_val1a.ToString() + "," + y2_val1a.ToString())

        While to_stop1 = 0 And pixel_arr1.Count < len_limit1
            If Math.Abs(m1) <= 1 Then
                start_x2 += 1
                start_y2 += m1
            Else
                start_x2 += m2
                start_y2 += dir_y1

            End If
            If start_x2 > max_x1 Or start_x2 < min_x1 Or start_y2 > max_y1 Or start_y2 < min_y1 Then

                If add_to_start1 = "yes" Then
                    If pixel_arr1(0) <> (start_x1.ToString() + "," + start_y1.ToString()) Then
                        pixel_arr1.Insert(0, start_x1.ToString() + "," + start_y1.ToString())

                    End If
                Else
                    If pixel_arr1(pixel_arr1.Count - 1) <> (end_x1.ToString() + "," + end_y1.ToString()) Then
                        pixel_arr1.Add(end_x1.ToString() + "," + end_y1.ToString())

                    End If

                End If

                to_stop1 = 1
            Else
                Dim x2_val1 As Integer = CType(Math.Floor(start_x2), Integer)
                Dim y2_val1 As Integer = CType(Math.Floor(start_y2), Integer)
                If add_to_start1 = "yes" Then
                    pixel_arr1.Insert(0, x2_val1.ToString() + "," + y2_val1.ToString())
                Else

                    pixel_arr1.Add(x2_val1.ToString() + "," + y2_val1.ToString())
                End If
            End If

        End While


        Return pixel_arr1
    End Function




    Public Function create_pixel_arr_line_from_2_2d_points_in_double(start_x1 As Double, start_y1 As Double, end_x1 As Double, end_y1 As Double)
        Dim pixel_arr1 As ArrayList = New ArrayList()

        Dim start_x2 As Double = start_x1
        Dim start_y2 As Double = start_y1
        Dim end_x2 As Double = end_x1
        Dim end_y2 As Double = end_y1

        If start_x1 > end_x1 Then
            start_x2 = end_x1
            start_y2 = end_y1
            end_x2 = start_x1
            end_y2 = start_y1
        End If
        Dim dir_y1 As Double = 1
        If start_y2 > end_y2 Then
            dir_y1 = -1
        End If
        Dim right_x1 As Double = end_x2
        Dim right_y1 As Double = end_y2
        Dim min_y1 As Double = Math.Min(start_y2, end_y2)
        Dim max_y1 As Double = Math.Max(start_y2, end_y2)


        Dim min_x1 As Double = Math.Min(start_x2, end_x2)
        Dim max_x1 As Double = Math.Max(start_x2, end_x2)

        Dim add_one1 As Integer = 1
        If (end_y1 - start_y1) < 0 Then
            add_one1 = -1
        End If
        Dim add_one2 As Integer = 1
        If (end_x1 - start_x1) < 0 Then
            add_one2 = -1
        End If
        Dim add_one3 As Integer = 1
        If (end_x1 - start_x1) < 0 Then
            add_one2 = -1
        End If

        Dim add_one4 As Integer = 1
        If (end_y1 - start_y1) < 0 Then
            add_one4 = -1
        End If
        add_one1 = 0
        add_one2 = 0
        add_one3 = 0
        add_one4 = 0
        Dim m1 As Double = ((end_y1 - start_y1) + add_one1) / ((end_x1 - start_x1) + add_one2)
        Dim m2 As Double = ((end_x1 - start_x1) + add_one3) / ((end_y1 - start_y1) + add_one4)
        Dim add_to_start1 As String = ""

        If start_x2 = end_x1 Then
            If start_x2 <> start_x1 Then

                add_to_start1 = "yes"
            Else

            End If
        End If
        If start_x2 = max_x1 Then
            m2 = -Math.Abs(m2)

        Else
            m2 = Math.Abs(m2)
        End If
        Dim to_stop1 As Integer = 0


        Dim x2_val1a As Double = CType(Math.Floor(start_x2), Double)
        Dim y2_val1a As Double = CType(Math.Floor(start_y2), Double)
        x2_val1a = CType(start_x2, Double)
        y2_val1a = CType(start_y2, Double)
        pixel_arr1.Add(x2_val1a.ToString() + "," + y2_val1a.ToString())

        While to_stop1 = 0
            If Math.Abs(m1) <= 1 Then
                start_x2 += 1
                start_y2 += m1
            Else
                start_x2 += m2
                start_y2 += dir_y1

            End If
            If start_x2 > max_x1 Or start_x2 < min_x1 Or start_y2 > max_y1 Or start_y2 < min_y1 Then

                If add_to_start1 = "yes" Then
                    If pixel_arr1(0) <> (start_x1.ToString() + "," + start_y1.ToString()) Then
                        pixel_arr1.Insert(0, start_x1.ToString() + "," + start_y1.ToString())

                    End If
                Else
                    If pixel_arr1(pixel_arr1.Count - 1) <> (end_x1.ToString() + "," + end_y1.ToString()) Then
                        pixel_arr1.Add(end_x1.ToString() + "," + end_y1.ToString())

                    End If

                End If

                to_stop1 = 1
            Else
                Dim x2_val1 As Double = CType(start_x2, Double)
                Dim y2_val1 As Double = CType(start_y2, Double)
                If add_to_start1 = "yes" Then
                    pixel_arr1.Insert(0, x2_val1.ToString() + "," + y2_val1.ToString())
                Else

                    pixel_arr1.Add(x2_val1.ToString() + "," + y2_val1.ToString())
                End If
            End If

        End While


        Return pixel_arr1
    End Function




    Public Function create_pixel_arr_line_from_2_2d_points_in_double_with_len_limit1(start_x1 As Double, start_y1 As Double, end_x1 As Double, end_y1 As Double, len_limit1 As Integer)
        Dim pixel_arr1 As ArrayList = New ArrayList()

        Dim start_x2 As Double = start_x1
        Dim start_y2 As Double = start_y1
        Dim end_x2 As Double = end_x1
        Dim end_y2 As Double = end_y1

        If start_x1 > end_x1 Then
            start_x2 = end_x1
            start_y2 = end_y1
            end_x2 = start_x1
            end_y2 = start_y1
        End If
        Dim dir_y1 As Double = 1
        If start_y2 > end_y2 Then
            dir_y1 = -1
        End If
        Dim right_x1 As Double = end_x2
        Dim right_y1 As Double = end_y2
        Dim min_y1 As Double = Math.Min(start_y2, end_y2)
        Dim max_y1 As Double = Math.Max(start_y2, end_y2)


        Dim min_x1 As Double = Math.Min(start_x2, end_x2)
        Dim max_x1 As Double = Math.Max(start_x2, end_x2)

        Dim add_one1 As Integer = 1
        If (end_y1 - start_y1) < 0 Then
            add_one1 = -1
        End If
        Dim add_one2 As Integer = 1
        If (end_x1 - start_x1) < 0 Then
            add_one2 = -1
        End If
        Dim add_one3 As Integer = 1
        If (end_x1 - start_x1) < 0 Then
            add_one2 = -1
        End If

        Dim add_one4 As Integer = 1
        If (end_y1 - start_y1) < 0 Then
            add_one4 = -1
        End If
        add_one1 = 0
        add_one2 = 0
        add_one3 = 0
        add_one4 = 0
        Dim m1 As Double = ((end_y1 - start_y1) + add_one1) / ((end_x1 - start_x1) + add_one2)
        Dim m2 As Double = ((end_x1 - start_x1) + add_one3) / ((end_y1 - start_y1) + add_one4)
        Dim add_to_start1 As String = ""

        If start_x2 = end_x1 Then
            If start_x2 <> start_x1 Then

                add_to_start1 = "yes"
            Else

            End If
        End If
        If start_x2 = max_x1 Then
            m2 = -Math.Abs(m2)

        Else
            m2 = Math.Abs(m2)
        End If
        Dim to_stop1 As Integer = 0


        Dim x2_val1a As Double = CType(Math.Floor(start_x2), Double)
        Dim y2_val1a As Double = CType(Math.Floor(start_y2), Double)
        x2_val1a = CType(start_x2, Double)
        y2_val1a = CType(start_y2, Double)
        pixel_arr1.Add(x2_val1a.ToString() + "," + y2_val1a.ToString())

        While to_stop1 = 0 And pixel_arr1.Count < len_limit1
            If Math.Abs(m1) <= 1 Then
                start_x2 += 1
                start_y2 += m1
            Else
                start_x2 += m2
                start_y2 += dir_y1

            End If
            If start_x2 > max_x1 Or start_x2 < min_x1 Or start_y2 > max_y1 Or start_y2 < min_y1 Then

                If add_to_start1 = "yes" Then
                    If pixel_arr1(0) <> (start_x1.ToString() + "," + start_y1.ToString()) Then
                        pixel_arr1.Insert(0, start_x1.ToString() + "," + start_y1.ToString())

                    End If
                Else
                    If pixel_arr1(pixel_arr1.Count - 1) <> (end_x1.ToString() + "," + end_y1.ToString()) Then
                        pixel_arr1.Add(end_x1.ToString() + "," + end_y1.ToString())

                    End If

                End If

                to_stop1 = 1
            Else
                Dim x2_val1 As Double = CType(start_x2, Double)
                Dim y2_val1 As Double = CType(start_y2, Double)
                If add_to_start1 = "yes" Then
                    pixel_arr1.Insert(0, x2_val1.ToString() + "," + y2_val1.ToString())
                Else

                    pixel_arr1.Add(x2_val1.ToString() + "," + y2_val1.ToString())
                End If
            End If

        End While


        Return pixel_arr1
    End Function


    Public Function paint_recursive2(in_bmp1 As Bitmap, start_x1 As Integer, start_y1 As Integer, color_of_region As Color, color_to_set As Color)
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(in_bmp1)
        Dim to_stop1 As Integer = 0

        Dim xa As Integer
        Dim ya As Integer
        For xa = 95 To 1200
            For ya = 30 To 700
                Dim c1 As Color = get_pixel_at1(copy_bmp1, xa, ya)
                If compare_colors1(get_pixel_at1(copy_bmp1, xa, ya), color_of_region) = 1 Then
                    Dim d1 As Integer = 1
                End If
            Next
        Next
        Dim stack_arr1 As ArrayList = New ArrayList()
        Dim add_stack_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        'stack_arr1.AddRange(add_stack_arr1)
        'to_stop1 = 1
        Dim count_set_pixels1 As Integer = 0
        Dim loop_c1 As Integer = 0
        Dim last_str_cord1 As String = ""
        While to_stop1 = 0
            If count_set_pixels1 > 235500 Then
                'to_stop1 = 1
            End If
            If add_stack_dict1.Keys.Count > 0 Then
                If last_str_cord1 <> "" Then
                    start_x1 = Integer.Parse(last_str_cord1.Split(",")(0))
                    start_y1 = Integer.Parse(last_str_cord1.Split(",")(1))
                Else
                    Dim str_cord1 As String = add_stack_dict1.Keys(add_stack_dict1.Keys.Count - 1)
                    start_x1 = Integer.Parse(str_cord1.Split(",")(0))
                    start_y1 = Integer.Parse(str_cord1.Split(",")(1))
                    Dim last_str_cord1b As String = ""
                    While compare_colors1(get_pixel_at1(copy_bmp1, start_x1, start_y1), color_of_region) = 1 Or compare_colors1(get_pixel_at1(copy_bmp1, start_x1, start_y1), color_to_set) = 1
                        add_stack_dict1.Remove(str_cord1)
                        str_cord1 = add_stack_dict1.Keys(add_stack_dict1.Keys.Count - 1)
                        start_x1 = Integer.Parse(str_cord1.Split(",")(0))
                        start_y1 = Integer.Parse(str_cord1.Split(",")(1))
                        last_str_cord1b = str_cord1
                    End While
                End If

            End If
            If compare_colors1(get_pixel_at1(copy_bmp1, start_x1, start_y1), color_of_region) = 1 Then
                Dim d1 As Integer = 1
            End If
            Dim was_pixels_around1 As Integer = 0
            If compare_colors1(get_pixel_at1(copy_bmp1, start_x1, start_y1), color_of_region) = 0 And compare_colors1(get_pixel_at1(copy_bmp1, start_x1, start_y1), color_to_set) = 0 Then
                add_stack_dict1(start_x1.ToString() + "," + start_y1.ToString()) = 1
                copy_bmp1.SetPixel(start_x1, start_y1, color_to_set)
                count_set_pixels1 += 1
                Dim was_set_last_str_cord As String = ""
                Dim i1 As Integer
                For i1 = 0 To 3
                    Dim dir_x1 As Integer = CGlobals1.dir_arr3(i1, 0)
                    Dim dir_y1 As Integer = CGlobals1.dir_arr3(i1, 1)
                    Dim new_x1 As Integer = start_x1 + CGlobals1.dir_arr3(i1, 0)
                    Dim new_y1 As Integer = start_y1 + CGlobals1.dir_arr3(i1, 1)
                    If new_x1 >= 0 And new_y1 >= 0 And new_x1 <= copy_bmp1.Width - 1 And new_y1 <= copy_bmp1.Height - 1 Then
                        If compare_colors1(get_pixel_at1(copy_bmp1, new_x1, new_y1), color_of_region) = 0 And compare_colors1(get_pixel_at1(copy_bmp1, new_x1, new_y1), color_to_set) = 0 Then

                            If was_set_last_str_cord = "" Then
                                last_str_cord1 = new_x1.ToString() + "," + new_y1.ToString()
                                was_set_last_str_cord = "yes"
                            End If
                            add_stack_dict1(new_x1.ToString() + "," + new_y1.ToString()) = 1
                            'bmp1.SetPixel(new_x1, new_y1, color_to_set)
                            was_pixels_around1 = 1
                            count_set_pixels1 += 1
                        Else
                            Dim was_set1 As Integer = 1
                        End If

                    End If
                Next

            End If
            If was_pixels_around1 = 0 Then
                add_stack_dict1.Remove(start_x1.ToString() + "," + start_y1.ToString())
                last_str_cord1 = ""
            End If
            If add_stack_dict1.Keys.Count <= 0 Then 'Or count_set_pixels1 > 100000 Then
                to_stop1 = 1
            End If
        End While


        'current_bmp1 = next_pixel_edge(current_bmp1, Color.FromArgb(255, 255, 255))

        'current_bmp1.Save(CGlobals1.global_path1 + file_name1 + "_red_edge1.jpg")
        'org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0))
        'org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0))


        Return copy_bmp1
    End Function

    Public Function paint_recursive3(in_bmp1 As Bitmap, start_x1 As Integer, start_y1 As Integer, color_of_region As Color, color_to_set As Color)
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(in_bmp1)
        Dim to_stop1 As Integer = 0

        Dim xa As Integer
        Dim ya As Integer
        For xa = 95 To 1200
            For ya = 30 To 700
                Dim c1 As Color = get_pixel_at1(copy_bmp1, xa, ya)
                If compare_colors1(get_pixel_at1(copy_bmp1, xa, ya), color_of_region) = 1 Then
                    Dim d1 As Integer = 1
                End If
            Next
        Next
        Dim stack_arr1 As ArrayList = New ArrayList()
        'Dim add_stack_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        'stack_arr1.AddRange(add_stack_arr1)
        'to_stop1 = 1
        Dim count_set_pixels1 As Integer = 0
        Dim loop_c1 As Integer = 0
        Dim last_str_cord1 As String = ""
        While to_stop1 = 0
            If count_set_pixels1 > 20000 Then
                'to_stop1 = 1
            End If
            If stack_arr1.Count > 0 Then
                If last_str_cord1 <> "" Or True Then
                    Dim cord_xy1b As Integer() = stack_arr1(stack_arr1.Count - 1)
                    start_x1 = cord_xy1b(0)
                    start_y1 = cord_xy1b(1)
                Else
                    Dim cord_xy1 As Integer() = stack_arr1(stack_arr1.Count - 1)

                    Dim last_str_cord1b As String = ""
                    While compare_colors1(get_pixel_at1(copy_bmp1, cord_xy1(0), cord_xy1(1)), color_of_region) = 1 Or compare_colors1(get_pixel_at1(copy_bmp1, cord_xy1(0), cord_xy1(1)), color_to_set) = 1
                        stack_arr1.RemoveAt(stack_arr1.Count - 1)
                        cord_xy1 = stack_arr1(stack_arr1.Count - 1)

                        last_str_cord1b = cord_xy1(0).ToString() + "," + cord_xy1(1).ToString()
                    End While
                End If

            End If
            If compare_colors1(get_pixel_at1(copy_bmp1, start_x1, start_y1), color_of_region) = 1 Then
                Dim d1 As Integer = 1
            End If
            Dim was_pixels_around1 As Integer = 0
            If compare_colors1(get_pixel_at1(copy_bmp1, start_x1, start_y1), color_of_region) = 0 And compare_colors1(get_pixel_at1(copy_bmp1, start_x1, start_y1), color_to_set) = 0 Then
                stack_arr1.Add({start_x1, start_y1}) ' (start_x1.ToString() + "," + start_y1.ToString()) = 1
                copy_bmp1.SetPixel(start_x1, start_y1, color_to_set)
                count_set_pixels1 += 1
                Dim was_set_last_str_cord As String = ""
                Dim i1 As Integer
                For i1 = 0 To 3
                    Dim dir_x1 As Integer = CGlobals1.dir_arr3(i1, 0)
                    Dim dir_y1 As Integer = CGlobals1.dir_arr3(i1, 1)
                    Dim new_x1 As Integer = start_x1 + CGlobals1.dir_arr3(i1, 0)
                    Dim new_y1 As Integer = start_y1 + CGlobals1.dir_arr3(i1, 1)
                    If new_x1 >= 0 And new_y1 >= 0 And new_x1 <= copy_bmp1.Width - 1 And new_y1 <= copy_bmp1.Height - 1 Then
                        If compare_colors1(get_pixel_at1(copy_bmp1, new_x1, new_y1), color_of_region) = 0 And compare_colors1(get_pixel_at1(copy_bmp1, new_x1, new_y1), color_to_set) = 0 Then

                            If was_set_last_str_cord = "" Then
                                last_str_cord1 = new_x1.ToString() + "," + new_y1.ToString()
                                was_set_last_str_cord = "yes"
                            End If
                            'add_stack_dict1(new_x1.ToString() + "," + new_y1.ToString()) = 1
                            stack_arr1.Add({new_x1, new_y1})
                            'bmp1.SetPixel(new_x1, new_y1, color_to_set)
                            was_pixels_around1 = 1
                            count_set_pixels1 += 1
                        Else
                            Dim was_set1 As Integer = 1
                        End If

                    End If
                Next

            End If
            If was_pixels_around1 = 0 Then
                If stack_arr1.Count > 0 Then
                    stack_arr1.RemoveAt(stack_arr1.Count - 1)

                End If
                'add_stack_dict1.Remove(start_x1.ToString() + "," + start_y1.ToString())
                last_str_cord1 = ""
            End If
            If stack_arr1.Count <= 0 Then 'Or count_set_pixels1 > 100000 Then
                to_stop1 = 1
            End If
        End While


        'current_bmp1 = next_pixel_edge(current_bmp1, Color.FromArgb(255, 255, 255))

        'current_bmp1.Save(CGlobals1.global_path1 + file_name1 + "_red_edge1.jpg")
        'org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0))
        'org_bmp1 = markingfldimg_obj1.remove_around_object1(org_bmp1, Color.FromArgb(0, 0, 0))


        Return copy_bmp1
    End Function
    Public Function measure_pixels_arr_smoothess(pixels_arr1 As ArrayList, dist_smooth1 As Double)
        Dim max_len_smooth1 As Integer = -1
        Dim ind1 As Integer
        Dim ind2 As Integer
        ind1 = 0 '5310
        ind2 = ind1 + 1
        Dim to_stop1 As Integer = 0
        Dim dict_max_left_len1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim dict_max_right_len1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim dict_max_left_and_right_len1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim dict_max_len1 As Dictionary(Of Integer, Double) = New Dictionary(Of Integer, Double)
        Dim min_dist_left_right1 As Integer = -1
        Dim max_pixel_ind_smooth_left_ok1 As Integer = 0
        Dim last_50_prev_ok_max_ind1 As Integer = 0
        Dim dict_pixel_ok1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        While to_stop1 = 0

            CGlobals1.update_label_progress("measure smothness:" + ((ind1 / pixels_arr1.Count * 100.0).ToString() + "     ").Substring(0, 5) + "%")
            Dim cord_xy1 As Integer()
            Dim cord_xy2 As Integer()


            Try
                cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, ind1)
                cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, ind2)

            Catch ex As Exception

                Dim sorted = From pair In dict_max_left_len1
                             Order By pair.Value
                Dim sortedDictionary = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
                dict_max_left_len1 = sortedDictionary


                Dim sorted1 = From pair In dict_max_right_len1
                              Order By pair.Value
                Dim sortedDictionary1 = sorted1.ToDictionary(Function(p) p.Key, Function(p) p.Value)
                dict_max_right_len1 = sortedDictionary1


                Dim sorted2 = From pair In dict_max_len1
                              Order By pair.Value
                Dim sortedDictionary2 = sorted2.ToDictionary(Function(p) p.Key, Function(p) p.Value)
                dict_max_len1 = sortedDictionary2

                Dim sorted3 = From pair In dict_max_left_and_right_len1
                              Order By pair.Value
                Dim sortedDictionary3 = sorted3.ToDictionary(Function(p) p.Key, Function(p) p.Value)
                dict_max_left_and_right_len1 = sortedDictionary3


                Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                dict_res1("dict_max_left_len1") = dict_max_left_len1
                dict_res1("dict_max_right_len1") = dict_max_right_len1
                dict_res1("dict_max_len1") = dict_max_len1
                dict_res1("dict_max_left_and_right_len1") = dict_max_left_and_right_len1
                Return dict_res1
            End Try
            Dim pixels_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points(cord_xy1(0), cord_xy1(1), cord_xy2(0), cord_xy2(1))
            Dim i1 As Integer
            Dim max_dist1 As Double = -99
            If ind1 > 5300 Then
                Dim d1 As Integer = 1
            End If
            Dim to_stop2 = 0
            i1 = ind1
            While to_stop2 = 0


                'For i1 = ind1 To ind2
                Dim i2 As Integer
                Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
                Dim min_dist1 As Double = 99
                For i2 = 0 To pixels_line_arr1.Count - 1
                    Dim cord_xy1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_line_arr1, i2)
                    Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1a(0) - cord_xy1b(0), 2) + Math.Pow(cord_xy1a(1) - cord_xy1b(1), 2), 0.5)
                    If min_dist1 > dist1 Then
                        min_dist1 = dist1
                    End If
                Next
                If max_dist1 < min_dist1 Then
                    max_dist1 = min_dist1
                End If

                Dim dist1a As Double = get_distance_between_2_point_in_pixels_arr1(i1, ind1, pixels_arr1)

                If dict_max_left_len1.ContainsKey(i1) Then
                    If dict_max_left_len1(i1) < dist1a Then
                        dict_max_left_len1(i1) = dist1a
                    End If
                Else
                    dict_max_left_len1(i1) = dist1a
                End If


                Dim dist1b As Double = get_distance_between_2_point_in_pixels_arr1(i1, ind2, pixels_arr1)

                If dict_max_right_len1.ContainsKey(i1) Then
                    If dict_max_right_len1(i1) < dist1b Then
                        dict_max_right_len1(i1) = dist1b
                    End If
                Else
                    dict_max_right_len1(i1) = dist1b
                End If



                If dict_max_left_and_right_len1.ContainsKey(i1) Then
                    If dict_max_left_and_right_len1(i1) < Math.Min(dist1a, dist1b) Then
                        dict_max_left_and_right_len1(i1) = Math.Min(dist1a, dist1b)
                    End If
                Else
                    dict_max_left_and_right_len1(i1) = Math.Min(dist1a, dist1b)
                End If






                Dim dist1c As Double = get_distance_between_2_point_in_pixels_arr1(ind1, ind2, pixels_arr1)

                If dict_max_len1.ContainsKey(i1) Then
                    If dict_max_len1(i1) < dist1c Then
                        dict_max_len1(i1) = dist1c
                    End If
                Else
                    dict_max_len1(i1) = dist1c
                End If
                min_dist_left_right1 = Math.Min(dist1a, dist1b)
                If min_dist_left_right1 > 40 Then
                    dict_pixel_ok1(i1) = 1
                    Dim p_ind1 As Integer
                    Dim all_50_prev_ok1 As String = "yes"
                    If last_50_prev_ok_max_ind1 + 1 = i1 Then
                        last_50_prev_ok_max_ind1 = i1
                    Else
                        For p_ind1 = i1 To i1 - 50 Step -1
                            If dict_pixel_ok1.ContainsKey(i1) = False Then
                                all_50_prev_ok1 = "no"
                            End If
                        Next

                    End If

                    If all_50_prev_ok1 = "yes" Then
                        last_50_prev_ok_max_ind1 = i1
                        If max_pixel_ind_smooth_left_ok1 < i1 Then
                            max_pixel_ind_smooth_left_ok1 = i1 - 50
                        End If
                    End If

                End If
                'Next


                i1 += 1
                If i1 = ind2 Or min_dist_left_right1 > 40 Then
                    to_stop2 = 1
                End If
            End While

            If max_dist1 < dist_smooth1 And min_dist_left_right1 < 30 Then
                ind2 += 1
            Else
                If max_len_smooth1 < (ind2 - ind1) Then
                    max_len_smooth1 = (ind2 - ind1)
                End If
                ind1 += 1
                If ind1 < max_pixel_ind_smooth_left_ok1 Then
                    ind1 = max_pixel_ind_smooth_left_ok1

                End If
                ind2 = ind1 + 1
                ' to_stop1 = 1
            End If
        End While

    End Function
    Public Function get_angle_change_of_pixels_arr1(pixels_arr1 As ArrayList, delta_between_pixels1 As Integer)
        Dim i1 As Integer
        Dim angles_arr1 As ArrayList = New ArrayList()
        Dim last_angle1 As Double = 0
        For i1 = 0 To pixels_arr1.Count - 1 Step delta_between_pixels1
            Dim first_ind1 As Integer = i1
            Dim last_ind1 As Integer = i1 + delta_between_pixels1
            Dim p1_xy As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, first_ind1)
            Dim p2_xy As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, Math.Min(last_ind1, pixels_arr1.Count - 1))

            Dim vec_3d_obj1 = New vec_3d1()
            vec_3d_obj1.p1.x1 = p1_xy(0)
            vec_3d_obj1.p1.y1 = p1_xy(1)
            vec_3d_obj1.p2.x1 = p2_xy(0)
            vec_3d_obj1.p2.y1 = p2_xy(1)

            Dim vec_3d_obj2 = New vec_3d1()
            vec_3d_obj2.p1.x1 = 0
            vec_3d_obj2.p1.y1 = 0
            vec_3d_obj2.p2.x1 = 100
            vec_3d_obj2.p2.y1 = 0

            Dim angle1 As Double = get_angle_between_2_3d_vectors(vec_3d_obj1, vec_3d_obj2)
            If vec_3d_obj1.p2.y1 < vec_3d_obj2.p2.y1 Then
                angle1 = -Math.Abs(angle1)
            End If
            If Math.Abs(last_angle1 - angle1) >= 90 Then
                Dim d2 As Integer = 3
            End If
            If i1 > 0 Then
                angles_arr1.Add(last_angle1 - angle1)
                If Math.Abs(last_angle1 - angle1) >= 135 Then
                    Dim d4 As Integer = 1
                End If
            End If
            Dim d1 As Integer = 1
            last_angle1 = angle1
        Next

        Return angles_arr1
    End Function


    Public Function get_angle_of_pixels_arr1(pixels_arr1 As ArrayList, delta_between_pixels1 As Integer)
        Dim i1 As Integer
        Dim angles_arr1 As ArrayList = New ArrayList()
        Dim last_angle1 As Double = 0
        For i1 = 0 To pixels_arr1.Count - 1 Step delta_between_pixels1
            Dim first_ind1 As Integer = i1
            Dim last_ind1 As Integer = i1 + delta_between_pixels1
            Dim p1_xy As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, first_ind1)
            Dim p2_xy As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, Math.Min(last_ind1, pixels_arr1.Count - 1))

            Dim vec_3d_obj1 = New vec_3d1()
            vec_3d_obj1.p1.x1 = p1_xy(0)
            vec_3d_obj1.p1.y1 = p1_xy(1)
            vec_3d_obj1.p2.x1 = p2_xy(0)
            vec_3d_obj1.p2.y1 = p2_xy(1)

            Dim vec_3d_obj2 = New vec_3d1()
            vec_3d_obj2.p1.x1 = 0
            vec_3d_obj2.p1.y1 = 0
            vec_3d_obj2.p2.x1 = 100
            vec_3d_obj2.p2.y1 = 0

            Dim angle1 As Double = get_angle_between_2_3d_vectors(vec_3d_obj1, vec_3d_obj2)
            If vec_3d_obj1.p1.y1 < vec_3d_obj1.p2.y1 Then
                angle1 = -Math.Abs(angle1)
            End If
            If Math.Abs(last_angle1 - angle1) >= 90 Then
                Dim d2 As Integer = 3
            End If
            If i1 > 0 Then

                Dim dict_prm1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                dict_prm1("angle1") = angle1
                dict_prm1("first_ind1") = first_ind1
                dict_prm1("last_ind1") = last_ind1
                angles_arr1.Add(dict_prm1)
                If Math.Abs(last_angle1 - angle1) >= 135 Then
                    Dim d4 As Integer = 1
                End If
            End If
            Dim d1 As Integer = 1
            last_angle1 = angle1
        Next

        Return angles_arr1
    End Function




    Public Function get_angle_between_2_3d_vectors(in_vec1 As vec_3d1, in_vec2 As vec_3d1)
        Dim vec1 As vec_3d1 = New vec_3d1()
        Dim vec2 As vec_3d1 = New vec_3d1()
        vec1.p2.x1 = in_vec1.p2.x1 - in_vec1.p1.x1
        vec1.p2.y1 = in_vec1.p2.y1 - in_vec1.p1.y1
        vec1.p2.z1 = in_vec1.p2.z1 - in_vec1.p1.z1


        vec2.p2.x1 = in_vec2.p2.x1 - in_vec2.p1.x1
        vec2.p2.y1 = in_vec2.p2.y1 - in_vec2.p1.y1
        vec2.p2.z1 = in_vec2.p2.z1 - in_vec2.p1.z1


        If vec1.p2.x1 = vec2.p2.x1 And vec1.p2.y1 = vec2.p2.y1 And vec1.p2.z1 = vec2.p2.z1 Then
            Return 0
        End If
        Dim dot_mul1 As Double = vec1.p2.x1 * vec2.p2.x1 + vec1.p2.y1 * vec2.p2.y1 + vec1.p2.z1 * vec2.p2.z1
        Dim vec1_len1 As Double = Math.Pow(vec1.p2.x1 * vec1.p2.x1 + vec1.p2.y1 * vec1.p2.y1 + vec1.p2.z1 * vec1.p2.z1, 0.5)
        Dim vec2_len1 As Double = Math.Pow(vec2.p2.x1 * vec2.p2.x1 + vec2.p2.y1 * vec2.p2.y1 + vec2.p2.z1 * vec2.p2.z1, 0.5)
        Dim inv_cos1 As Double = 1
        Try
            inv_cos1 = Math.Acos(dot_mul1 / (vec1_len1 * vec2_len1))

        Catch ex As Exception

        End Try

        Return inv_cos1 / (Math.PI / 180)



    End Function

    Public Function set_pixels_arr_and_save1(pixels_arr1 As ArrayList, bmp1 As Bitmap, path1 As String)
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        set_pixel_arr_on_bmp2(pixels_arr1, copy_bmp1, Color.FromArgb(255, 30, 200))
        Try
            copy_bmp1.Save(path1)

        Catch ex As Exception

        End Try

        Return copy_bmp1
    End Function

    Public Function set_pixels_arr_and_save2(pixels_arr1 As ArrayList, bmp1 As Bitmap, color1 As Color, path1 As String)
        Dim copy_bmp1 As Bitmap = CGlobals1.copy_bitmap1(bmp1)
        set_pixel_arr_on_bmp2(pixels_arr1, copy_bmp1, color1)
        copy_bmp1.Save(path1)

        Return copy_bmp1
    End Function

    Public Function create_cache_of_sobel_files(path_of_cache1 As String)
        For x1 = 0 To bmp_current_sobel.Width - 1
            For y1 = 0 To bmp_current_sobel.Height - 1
                bmp_current_sobel.SetPixel(x1, y1, Color.FromArgb(255, 255, 255))
            Next

        Next
        Dim i1 As Integer

        For i1 = 0 To CGlobals1.dict_sobel_pixels.Keys.Count - 5
            add_dec_sobel_ind("add1", 1)
            CGlobals1.update_label_progress("step2:(create sobel imgs)" + ((i1 / CGlobals1.dict_sobel_pixels.Keys.Count * 100).ToString() + "        ").Substring(0, 6) + "%")

            bmp_current_sobel.Save(path_of_cache1 + "\" + cur_sobel_ind_val1.ToString() + ".jpg")

        Next
    End Function


    Public Function check_if_pixels_arr_contain_other_pixels_arr_by_sqr_distance(pixels_arr1 As ArrayList, other_pixels_arr1 As ArrayList, sqr_dist1 As Integer)
        Dim i1 As Integer

        Dim dict_pixels1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(pixels_arr1)
        Dim dict_pixels_contained1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(pixels_arr1)
        'For i1 = 0 To pixels_arr1.Count - 1


        'dict_pixels1(pixels_arr1(i1)) = 1
        'Next

        Dim pixels_arr_that_contain1 As Dictionary(Of String, String) = New Dictionary(Of String, String)
        Dim count_pixels_contain_other As Integer = 0
        For i1 = 0 To other_pixels_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(other_pixels_arr1, i1)
            Dim x1 As Integer
            Dim y1 As Integer
            Dim is_contain1 As String = ""
            Dim min_dist1 As Double = 99
            Dim min_dist_cord1 As String = ""

            For x1 = cord_xy1(0) - sqr_dist1 To cord_xy1(0) + sqr_dist1
                For y1 = cord_xy1(1) - sqr_dist1 To cord_xy1(1) + sqr_dist1
                    If dict_pixels1.ContainsKey(x1.ToString() + "," + y1.ToString()) = True Then
                        dict_pixels_contained1(x1.ToString() + "," + y1.ToString()) = 2
                        is_contain1 = "yes"
                        Dim dist1 As Double = Math.Pow(Math.Pow(x1 - cord_xy1(0), 2) + Math.Pow(y1 - cord_xy1(1), 2), 0.5)
                        If min_dist1 > dist1 Then
                            If min_dist1 > dist1 Then
                                min_dist1 = dist1
                                min_dist_cord1 = x1.ToString() + "," + y1.ToString()
                            End If
                        End If


                    End If

                Next
            Next
            If is_contain1 = "yes" Then
                count_pixels_contain_other += 1
                pixels_arr_that_contain1(other_pixels_arr1(i1)) = min_dist_cord1
            Else
                Dim no_contained1 As String = "no"
            End If

        Next
        Dim count_contained1 As Integer = 0
        For i1 = 0 To dict_pixels_contained1.Keys.Count - 1
            If dict_pixels_contained1(dict_pixels_contained1.Keys(i1)) = 2 Then
                count_contained1 += 1
            End If
        Next
        Dim dict_return_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_return_res1("pixels_arr_that_contain1") = pixels_arr_that_contain1
        dict_return_res1("count_contained1") = count_contained1
        dict_return_res1("dict_pixels_contained1") = dict_pixels_contained1
        dict_return_res1("no_all_conatained1") = "no"
        If count_contained1 < dict_pixels_contained1.Keys.Count Then
            Dim no_all_conatained1 As String = "yes"
            dict_return_res1("no_all_conatained1") = "yes"
        End If
        Return dict_return_res1
        Return pixels_arr_that_contain1
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        Return count_pixels_contain_other
    End Function


    Public Function get_distance_between_2_point_in_pixels_arr1(cord1 As Integer, cord2 As Integer, pixels_arr1 As ArrayList)
        Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, cord1)
        Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, cord2)
        Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1(0) - cord_xy2(0), 2) + Math.Pow(cord_xy1(1) - cord_xy2(1), 2), 0.5)
        Return dist1
    End Function



    Public Function find_max_line_in_pixels_arr(pixels_arr1 As ArrayList)
        Dim p_ind1 As Integer
        Dim p_ind2 As Integer
        Dim dict_dists1 As Dictionary(Of String, Double) = New Dictionary(Of String, Double)
        Dim min_angle1 As Double = 3
        Dim max_angle1 As Double = 15
        Dim min_dist1 As Double = 500
        For p_ind1 = 0 To pixels_arr1.Count - 1
            For p_ind2 = 0 To pixels_arr1.Count - 1
                If p_ind1 <> p_ind2 And Math.Abs(p_ind1 - p_ind2) > 2 Then
                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, p_ind1)
                    Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, p_ind2)

                    Dim angle1 As Double = Math.Atan((cord_xy2(1) - cord_xy1(1)) / (cord_xy2(0) - cord_xy1(0))) * 180 / Math.PI
                    If Math.Abs(angle1) > min_angle1 And Math.Abs(angle1) < max_angle1 Then
                        Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1(0) - cord_xy2(0), 2) + Math.Pow(cord_xy1(1) - cord_xy2(1), 2), 0.5)
                        If dist1 > min_dist1 Then
                            dict_dists1(p_ind1.ToString() + "," + p_ind2.ToString()) = dist1

                        End If

                    End If
                End If

            Next

        Next

        Dim sorted = From pair In dict_dists1
                     Order By pair.Value Descending
        Dim sortedDictionary = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)




        dict_dists1 = sortedDictionary

        Dim dist_ind1 As Integer

        dist_ind1 = 0
        Dim to_save1 As Integer = 0
        While dist_ind1 < dict_dists1.Count
            Dim cord_inds_str1 As String = dict_dists1.Keys(dist_ind1)
            Dim cord_ind1 As Integer = Integer.Parse(cord_inds_str1.Split(",")(0))
            Dim cord_ind2 As Integer = Integer.Parse(cord_inds_str1.Split(",")(1))
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, cord_ind1)
            Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, cord_ind2)
            Dim angle1 As Double = Math.Atan((cord_xy2(1) - cord_xy1(1)) / (cord_xy2(0) - cord_xy1(0))) * 180 / Math.PI
            If Math.Abs(angle1) > min_angle1 And Math.Abs(angle1) < max_angle1 Then

                Dim pixel_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points(cord_xy1(0), cord_xy1(1), cord_xy2(0), cord_xy2(1))
                Dim i1 As Integer
                Dim good_line1 As String = "yes"
                i1 = 0
                While good_line1 = "yes" And i1 <= pixel_line_arr1.Count - 1
                    Dim cord_xy_in_line As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixel_line_arr1, i1)
                    '**Dim color1 As Color = get_pixel_at1(bmp_without_bg1, cord_xy_in_line(0), cord_xy_in_line(1))
                    '**If compare_colors1(color1, color_of_sign_bg1) = 1 Then
                    '**good_line1 = "no"
                    '**End If
                    i1 += 1
                End While
                If to_save1 = 1 Then
                    '**Dim path2 As String = CGlobals1.global_path1 + file_name1 + "_signbg_line_ind1" + dist_ind1.ToString() + ".bmp"
                    '**set_pixels_arr_and_save2(pixel_line_arr1, CGlobals1.copy_bitmap1(bmp_without_bg1), Color.FromArgb(200, 50, 30), path2)
                End If
                If good_line1 = "yes" Then
                    Dim d1 As Integer = 1
                End If
            End If

            dist_ind1 += 1

        End While

        For p_ind1 = 0 To pixels_arr1.Count - 1
            For p_ind2 = 0 To pixels_arr1.Count - 1
                If p_ind1 <> p_ind2 And Math.Abs(p_ind1 - p_ind2) > 400 Then
                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, p_ind1)
                    Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, p_ind2)
                    Dim pixel_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points(cord_xy1(0), cord_xy1(1), cord_xy2(0), cord_xy2(1))

                    Dim i1 As Integer
                    Dim good_line1 As String = "yes1"
                    i1 = 0
                    While good_line1 = "yes" And i1 <= pixel_line_arr1.Count - 1
                        'Dim cord_xy_in_line As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixel_line_arr1, i1)
                        'Dim color1 As Color = get_pixel_at1(bmp_without_bg1, cord_xy_in_line(0), cord_xy_in_line(1))
                        'If compare_colors1(color1, color_of_sign_bg1) = 1 Then
                        'good_line1 = "no"
                        'End If
                        i1 += 1
                    End While

                End If
            Next

        Next

    End Function

    Public Function find_max_distance_pixels(pixels_arr1 As ArrayList)
        Dim i1 As Integer
        Dim i2 As Integer

        Dim max_distance1 As Double = -99

        Dim dict_dist1 As Dictionary(Of String, Double) = New Dictionary(Of String, Double)
        Dim dict_dist2 As Dictionary(Of Double, ArrayList) = New Dictionary(Of Double, ArrayList)
        For i1 = 0 To pixels_arr1.Count - 1
            For i2 = 0 To pixels_arr1.Count - 1
                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
                Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i2)

                Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1(0) - cord_xy2(0), 2) + Math.Pow(cord_xy1(1) - cord_xy2(1), 2), 0.5)
                If max_distance1 < dist1 Then
                    max_distance1 = dist1
                End If

                If dict_dist2.ContainsKey(dist1) = False Then
                    dict_dist2(dist1) = New ArrayList()
                End If
                Dim arr1 As ArrayList = dict_dist2(dist1)
                arr1.Add(i1.ToString() + "," + i2.ToString())
                dict_dist1(i1.ToString() + "," + i2.ToString()) = dist1
            Next

        Next

        Return dict_dist2(max_distance1)
        Dim arr_key_to_remove1 As ArrayList = New ArrayList()

        For i1 = 0 To dict_dist1.Keys.Count - 1
            If dict_dist1(dict_dist1.Keys(i1)) <= max_distance1 Then
                arr_key_to_remove1.Add(dict_dist1.Keys(i1))
            End If
        Next


    End Function

    Public Function filter_bmp_by_count_pxls_neigboors(bmp1 As Bitmap, min_count_neighboors As Integer, color_of_pixels1 As Color)
        Dim x1 As Integer
        Dim y1 As Integer
        Dim copy_bmp1 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)

        For x1 = 0 To bmp1.Width - 1


            For y1 = 0 To bmp1.Height - 1
                copy_bmp1.SetPixel(x1, y1, Color.FromArgb(0, 0, 0))
            Next
        Next
        For x1 = 1 To bmp1.Width - 2
            For y1 = 1 To bmp1.Height - 2
                Dim arr_neighbors As ArrayList = New ArrayList()
                If compare_colors1(get_pixel_at1(bmp1, x1, y1), color_of_pixels1) = 1 Then

                    Dim count_pixels_neigboors1 As Integer = 0

                    Dim i3 As Integer
                    For i3 = 0 To 7

                        Dim dir_x1 As Integer = CGlobals1.dir_arr2(i3, 0)
                        Dim dir_y1 As Integer = CGlobals1.dir_arr2(i3, 1)
                        Dim new_x1 As Integer = x1 + CGlobals1.dir_arr2(i3, 0)
                        Dim new_y1 As Integer = y1 + CGlobals1.dir_arr2(i3, 1)
                        If compare_colors1(get_pixel_at1(bmp1, new_x1, new_y1), color_of_pixels1) = 1 Then
                            count_pixels_neigboors1 += 1
                            arr_neighbors.Add(New Integer() {new_x1, new_y1})
                        End If


                    Next


                    For i3 = 0 To CGlobals1.dir_arr4.Length / 2 - 1

                        Dim dir_x1 As Integer = CGlobals1.dir_arr4(i3, 0)
                        Dim dir_y1 As Integer = CGlobals1.dir_arr4(i3, 1)
                        Dim new_x1 As Integer = x1 + CGlobals1.dir_arr4(i3, 0)
                        Dim new_y1 As Integer = y1 + CGlobals1.dir_arr4(i3, 1)
                        If compare_colors1(get_pixel_at1(bmp1, new_x1, new_y1), color_of_pixels1) = 1 Then
                            count_pixels_neigboors1 += 1
                            arr_neighbors.Add(New Integer() {new_x1, new_y1})

                        End If


                    Next
                    If count_pixels_neigboors1 >= min_count_neighboors Then
                        copy_bmp1.SetPixel(x1, y1, color_of_pixels1)

                        For i3 = 0 To arr_neighbors.Count - 1


                            copy_bmp1.SetPixel(arr_neighbors(i3)(0), arr_neighbors(i3)(1), color_of_pixels1)



                        Next


                    Else
                        Dim d1 As Integer = 1
                        ' copy_bmp1.SetPixel(x1, y1, Color.FromArgb(200, 70, 80))
                    End If

                End If

            Next
        Next

        Return copy_bmp1
    End Function

    Public Function get_curve_from_pixels_arr_by_region(pixels_arr1 As ArrayList, x1 As Integer, y1 As Integer, w1 As Integer, h1 As Integer)
        Dim i1 As Integer
        Dim max_len_to_search1 As Integer = 53000
        i1 = 0
        Dim to_stop1 As Integer = 0
        Dim curves_arrs1 As ArrayList = New ArrayList()
        Dim current_curve1 As ArrayList = New ArrayList()
        Dim cord_xy_status1 As String = ""

        If pixels_arr1.Count <= 0 Then
            Return curves_arrs1
        End If
        While to_stop1 = 0

            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
            If cord_xy1(0) >= x1 And cord_xy1(1) >= y1 And cord_xy1(0) <= (x1 + w1 - 1) And cord_xy1(1) <= (y1 + h1 - 1) Then
                If cord_xy_status1 = "" Then
                    cord_xy_status1 = "start"
                End If
                If cord_xy_status1 = "start" Then
                    current_curve1.Add(pixels_arr1(i1))
                End If
            Else
                If cord_xy_status1 = "start" Then
                    cord_xy_status1 = ""
                    curves_arrs1.Add(current_curve1)
                    current_curve1 = New ArrayList()
                End If
            End If
            i1 += 1
            If i1 >= pixels_arr1.Count Or i1 >= max_len_to_search1 Then

                If cord_xy_status1 = "start" Then
                    cord_xy_status1 = ""
                    curves_arrs1.Add(current_curve1)
                    current_curve1 = New ArrayList()
                End If


                to_stop1 = 1
            End If
        End While

        Return curves_arrs1

    End Function


    Public Function find_curves_of_handles1(dir1 As Integer)
        CGlobals1.global_suffix_file_name1 = ""
        Dim sobel_ind1 As Integer = -1 'Integer.Parse(form_obj1.txtbox_curent_sobel_threshold1.Text)

        Dim path_sign_sobel_ind1 As String = CGlobals1.global_path1 + form_obj1.file_name1 + "_sign_sobel_ind1.txt"
        sobel_ind1 = Integer.Parse(System.IO.File.ReadAllText(path_sign_sobel_ind1))

        Dim path_of_bmp1 As String = CGlobals1.global_path1 + form_obj1.file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)

        Dim pixels_arr1 As ArrayList = load_2d_pixels_arr1(CGlobals1.global_path1 + form_obj1.file_name1 + "_2d_pixels_sobel_" + sobel_ind1.ToString() + ".txt")
        Dim dict_pixels1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(pixels_arr1)

        Dim last_secod_cords1 As ArrayList = New ArrayList()
        Dim last_secod_cords2 As ArrayList = New ArrayList()

        Dim dict_second_cord1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim i1 As Integer

        Dim dict_pixel_arr1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        dict_pixel_arr1 = CGlobals1.add_to_dict1(pixels_arr1)

        Dim ver_pixels_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points(bmp1.Width / 2 + 220, 0, bmp1.Width / 2 + 220, bmp1.Height - 1)


        Dim to_stop1 As Integer = 0

        Dim dict_center_curve_pixels1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)


        Dim start_secord_pxl_cord_ind1 As Integer = -1

        Dim first_pxl_cord1 As String = ""
        Dim second_pxl_cord1 As String = ""
        Dim first_pxl_cord_ind1 As Integer = 0
        Dim second_pxl_cord_ind1 As Integer = 0
        'עוברים עם קו מאונך למטה באמצע עד למעלה - 2 החיתוכים הראשונים זה של הידית התחתונה שהיא השמאלית והקידמית בתמונה
        For i1 = ver_pixels_arr1.Count - 1 To 0 Step -1
            If dict_pixel_arr1.ContainsKey(ver_pixels_arr1(i1)) Then
                Dim d1 As Integer = 1
                If first_pxl_cord1 = "" Then
                    first_pxl_cord1 = ver_pixels_arr1(i1)
                    first_pxl_cord_ind1 = dict_pixel_arr1(ver_pixels_arr1(i1))
                Else
                    If second_pxl_cord1 = "" Then
                        second_pxl_cord1 = ver_pixels_arr1(i1)
                        second_pxl_cord_ind1 = dict_pixel_arr1(ver_pixels_arr1(i1))

                    End If
                End If
            End If
        Next

        start_secord_pxl_cord_ind1 = second_pxl_cord_ind1
        Dim last_x1a As Integer = -1
        Dim last_y1a As Integer = -1
        Dim cord_dir1 As Integer = 1
        Dim x1a As Integer = (Integer.Parse(first_pxl_cord1.Split(",")(0)) + Integer.Parse(second_pxl_cord1.Split(",")(0))) / 2
        Dim y1a As Integer = (Integer.Parse(first_pxl_cord1.Split(",")(1)) + Integer.Parse(second_pxl_cord1.Split(",")(1))) / 2

        CGlobals1.draw_sqr_around_pixels2(bmp1, x1a, y1a, 8, Color.FromArgb(200, 150, 100))
        cord_dir1 = dir1
        If cord_dir1 = -1 Then
            x1a = (Integer.Parse(second_pxl_cord1.Split(",")(0)) + Integer.Parse(first_pxl_cord1.Split(",")(0))) / 2
            y1a = (Integer.Parse(second_pxl_cord1.Split(",")(1)) + Integer.Parse(first_pxl_cord1.Split(",")(1))) / 2
            Dim temp1 As Integer = first_pxl_cord_ind1
            first_pxl_cord_ind1 = second_pxl_cord_ind1
            second_pxl_cord_ind1 = temp1

        End If
        'Dim x1a As Integer = (Integer.Parse(second_pxl_cord1.Split(",")(0)) + Integer.Parse(first_pxl_cord1.Split(",")(0))) / 2
        'Dim y1a As Integer = (Integer.Parse(second_pxl_cord1.Split(",")(1)) + Integer.Parse(first_pxl_cord1.Split(",")(1))) / 2
        Dim first_pxl_cord_ind1_arr As ArrayList = New ArrayList()

        Dim b1 As Byte = 0
        Dim count_sign_pxls1 As Integer = 0
        Dim count_last_cord_equals1 As Integer = 0
        Dim max_cord_ind1 As Integer = -1
        Dim count_not_over_max_cord1 As Integer = 0
        While to_stop1 = 0




            Dim min_first_pxl_cord_ind1 As Integer = -1
            Dim min_second_pxl_cord_ind1 As Integer = -1



            Dim x1b As Integer
            Dim y1b As Integer

            Dim min_x1b As Integer = -1
            Dim min_y1b As Integer = -1
            If dict_center_curve_pixels1.Count = 190 Then
                Dim d2 As Integer = 1
            End If

            Dim min_dist1 As Double = 999

            Dim min_dist1_ind1 As Integer = -1
            For i1 = second_pxl_cord_ind1 - 20 To second_pxl_cord_ind1 + 20
                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, first_pxl_cord_ind1)
                Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, i1)
                Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1(0) - cord_xy2(0), 2) + Math.Pow(cord_xy1(1) - cord_xy2(1), 2), 0.5)
                If min_dist1 > dist1 Then
                    min_dist1 = dist1
                    min_dist1_ind1 = i1

                End If
            Next
            second_pxl_cord_ind1 = min_dist1_ind1

            If cord_dir1 = 1 Then
                If max_cord_ind1 = -1 Then
                    max_cord_ind1 = second_pxl_cord_ind1
                Else
                    If max_cord_ind1 > second_pxl_cord_ind1 Then
                        max_cord_ind1 = second_pxl_cord_ind1
                        count_not_over_max_cord1 = 0

                    Else
                        count_not_over_max_cord1 += 1
                    End If
                End If
            Else
                If max_cord_ind1 = -1 Then
                    max_cord_ind1 = second_pxl_cord_ind1
                Else
                    If max_cord_ind1 < second_pxl_cord_ind1 Then
                        max_cord_ind1 = second_pxl_cord_ind1
                        count_not_over_max_cord1 = 0
                    Else
                        count_not_over_max_cord1 += 1
                    End If
                End If
            End If

            If count_not_over_max_cord1 > 50 Then
                to_stop1 = 1
            End If
            Dim delta_search_second_cord1 As Integer = 40
            If first_pxl_cord_ind1 >= second_pxl_cord_ind1 - delta_search_second_cord1 And first_pxl_cord_ind1 <= second_pxl_cord_ind1 + delta_search_second_cord1 Then
                to_stop1 = 1
            End If


            Dim cord_xy1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, first_pxl_cord_ind1)
            Dim cord_xy2b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, min_dist1_ind1)

            Dim x_center1 As Integer = (cord_xy1b(0) + cord_xy2b(0)) / 2
            Dim y_center1 As Integer = (cord_xy1b(1) + cord_xy2b(1)) / 2

            'first_pxl_cord_ind1 -= 1
            first_pxl_cord_ind1 += cord_dir1
            CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy1b(0), cord_xy1b(1), 3, Color.FromArgb(200, 50, 100))
            CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy2b(0), cord_xy2b(1), 3, Color.FromArgb(1, 50, 100))


            last_secod_cords2.Add(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString())

            If cord_dir1 = 1 Then

                last_secod_cords1.Add(cord_xy2b(0).ToString() + "," + cord_xy2b(1).ToString())
                'dict_second_cord1(cord_xy2b(0).ToString() + "," + cord_xy2b(1).ToString()) = 1
            Else
                last_secod_cords1.Add(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString())
                'dict_second_cord1(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString()) = 1

            End If

            Dim max_last_cords1 As Integer = 40

            If count_sign_pxls1 >= 50 Then

                Dim all_last_cords_equal1 As String = "yes"
                Dim last_secod_cords1_ind1 As Integer
                For last_secod_cords1_ind1 = max_last_cords1 To 0 Step -1
                    If dict_second_cord1.ContainsKey(last_secod_cords1(last_secod_cords1_ind1)) = False Then
                        all_last_cords_equal1 = "no"
                    End If
                Next

                If all_last_cords_equal1 = "yes" Then
                    count_last_cord_equals1 += 1
                    If count_last_cord_equals1 > 10 Then
                        'to_stop1 = 1
                    End If

                End If
            End If


            If cord_dir1 = 1 Then
                'last_secod_cords1.Add(cord_xy2b(0).ToString() + "," + cord_xy2b(1).ToString())
                dict_second_cord1(cord_xy2b(0).ToString() + "," + cord_xy2b(1).ToString()) = 1
            Else
                'last_secod_cords1.Add(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString())
                dict_second_cord1(cord_xy1b(0).ToString() + "," + cord_xy1b(1).ToString()) = 1

            End If
            While last_secod_cords1.Count > max_last_cords1 + 1
                last_secod_cords1.RemoveAt(0)
            End While
            'bmp1.SetPixel(x_center1, y_center1, Color.FromArgb(255, 230, 30))
            'bmp1.SetPixel(x_center1, y_center1, Color.FromArgb(255, 30, 230))

            bmp1.SetPixel(x_center1, y_center1, Color.FromArgb(255, 30, 30))
            count_sign_pxls1 += 1
            If count_sign_pxls1 > 1400 Then
                to_stop1 = 1
            End If
        End While
        Dim sec_cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, second_pxl_cord_ind1)

        CGlobals1.draw_sqr_around_pixels2(bmp1, sec_cord_xy1a(0), sec_cord_xy1a(1), 4, Color.FromArgb(200, 80, 90))
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        'הפיקסל ממנו מתחילים ליצור את הקו הישר על הצד השמאלי
        dict_res1("second_pxl_cord_ind1") = second_pxl_cord_ind1
        If start_secord_pxl_cord_ind1 < second_pxl_cord_ind1 Then
            Dim sec_cord_xy1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, second_pxl_cord_ind1 - 50)

            CGlobals1.draw_sqr_around_pixels2(bmp1, sec_cord_xy1b(0), sec_cord_xy1b(1), 4, Color.FromArgb(20, 200, 90))
            Dim m1 As Double = (sec_cord_xy1a(1) - sec_cord_xy1b(1)) / (sec_cord_xy1a(0) - sec_cord_xy1b(0))
            Dim add_x1 As Integer = 2000
            Dim new_y1 As Integer = sec_cord_xy1a(1) - Math.Abs(m1) * add_x1
            Dim new_x1 As Integer = sec_cord_xy1a(0) - add_x1
            'CGlobals1.draw_sqr_around_pixels2(bmp1, new_x1, new_y1, 4, Color.FromArgb(200, 80, 90))


            Dim pxl_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points(sec_cord_xy1a(0), sec_cord_xy1a(1), new_x1, new_y1)
            Dim i4 As Integer
            Dim pixel_cut_ind1 As Integer = -1
            For i4 = pxl_line_arr1.Count - 1 To 0 Step -1
                If dict_pixels1.ContainsKey(pxl_line_arr1(i4)) = True Then
                    If pixel_cut_ind1 = -1 Then
                        pixel_cut_ind1 = i4

                    End If
                End If
            Next
            'הפיקסלי השמאלי ביותר של הקו הישר שגם שייך למשקפיים
            dict_res1("start_point1") = dict_pixels1(pxl_line_arr1(pixel_cut_ind1))
            While pxl_line_arr1.Count > pixel_cut_ind1
                pxl_line_arr1.RemoveAt(pxl_line_arr1.Count - 1)
            End While
            'הפיקסלים של הקו הישר
            dict_res1("pxl_line_arr1") = pxl_line_arr1
            For i4 = 0 To pxl_line_arr1.Count - 1
                Dim cord_xy5 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, i4)
                CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy5(0), cord_xy5(1), 3, Color.FromArgb(230, 50, 100))

            Next

            set_pixel_arr_on_bmp2(pxl_line_arr1, bmp1, Color.FromArgb(200, 70, 80))


        Else
            Dim sec_cord_xy1b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_arr1, second_pxl_cord_ind1 + 50)

            CGlobals1.draw_sqr_around_pixels2(bmp1, sec_cord_xy1b(0), sec_cord_xy1b(1), 4, Color.FromArgb(20, 200, 90))
            Dim m1 As Double = (sec_cord_xy1a(1) - sec_cord_xy1b(1)) / (sec_cord_xy1a(0) - sec_cord_xy1b(0))
            Dim add_x1 As Integer = 2000
            Dim new_y1 As Integer = sec_cord_xy1a(1) - Math.Abs(m1) * add_x1
            Dim new_x1 As Integer = sec_cord_xy1a(0) - add_x1
            'CGlobals1.draw_sqr_around_pixels2(bmp1, new_x1, new_y1, 4, Color.FromArgb(200, 80, 90))

            Dim pxl_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points(sec_cord_xy1a(0), sec_cord_xy1a(1), new_x1, new_y1)
            Dim i4 As Integer
            Dim pixel_cut_ind1 As Integer = -1
            For i4 = pxl_line_arr1.Count - 1 To 0 Step -1
                If dict_pixels1.ContainsKey(pxl_line_arr1(i4)) = True Then
                    If pixel_cut_ind1 = -1 Then
                        pixel_cut_ind1 = i4

                    End If
                End If
            Next
            dict_res1("start_point1") = dict_pixels1(pxl_line_arr1(pixel_cut_ind1))

            While pxl_line_arr1.Count > pixel_cut_ind1
                pxl_line_arr1.RemoveAt(pxl_line_arr1.Count - 1)
            End While
            dict_res1("pxl_line_arr1") = pxl_line_arr1
            For i4 = 0 To pxl_line_arr1.Count - 1
                Dim cord_xy5 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, i4)
                CGlobals1.draw_sqr_around_pixels2(bmp1, cord_xy5(0), cord_xy5(1), 3, Color.FromArgb(230, 50, 100))

            Next

            set_pixel_arr_on_bmp2(pxl_line_arr1, bmp1, Color.FromArgb(200, 70, 80))

        End If
        'הפיקסלים של המשקפיים
        dict_res1("pixels_arr1") = pixels_arr1
        form_obj1.PictureBox1.Image = form_obj1.zoom_img1(bmp1, 2.7)

        Return dict_res1
    End Function

    Public Function set_pixels_by_mask1(ByRef mask_bmp1 As Bitmap, color_of_mask1 As Color, ByRef org_bmp1 As Bitmap)
        Dim x1 As Integer
        Dim y1 As Integer
        For x1 = 0 To mask_bmp1.Width - 1
            For y1 = 0 To mask_bmp1.Height - 1
                If compare_colors1(get_pixel_at1(mask_bmp1, x1, y1), color_of_mask1) = 1 Then
                Else
                    org_bmp1.SetPixel(x1, y1, Color.FromArgb(0, 0, 0, 0))
                End If
            Next

        Next
        Return org_bmp1
    End Function

    Public Function set_pixels_by_mask2(ByRef mask_bmp1 As Bitmap, color_of_mask1 As Color, ByRef org_bmp1 As Bitmap, color_to_set1 As Color, op_code1 As String)
        Dim x1 As Integer
        Dim y1 As Integer
        For x1 = 0 To mask_bmp1.Width - 1
            For y1 = 0 To mask_bmp1.Height - 1
                If compare_colors1(get_pixel_at1(mask_bmp1, x1, y1), color_of_mask1) = 1 And op_code1 = "set_on_mask1" Then
                    org_bmp1.SetPixel(x1, y1, color_to_set1)
                ElseIf compare_colors1(get_pixel_at1(mask_bmp1, x1, y1), color_of_mask1) = 0 And op_code1 = "set_on_not_mask1" Then
                    org_bmp1.SetPixel(x1, y1, color_to_set1)
                End If
            Next

        Next
        Return org_bmp1
    End Function
    Public Function find_start_sobel1(start_sobol_ind1 As Integer, line_pixels_Arr1 As ArrayList, ByRef bmp1 As Bitmap)
        Dim i1 As Integer
        Dim start_sobel1 As Integer = -1
        For i1 = 0 To line_pixels_Arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(line_pixels_Arr1, i1)
            If compare_colors1(get_pixel_at1(bmp1, cord_xy1(0), cord_xy1(1)), color_of_sobel) = 1 And start_sobel1 = -1 Then
                start_sobel1 = i1
            End If
        Next


    End Function



    Public Function find_curves1(rect_start_x1 As Integer, rect_start_y1 As Integer, bmp1 As Bitmap)
        Dim width_of_bmp1 As Integer = 700
        Dim curves_pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim only_curves_pixels_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        Dim sobel_ind1 As Integer = 45
        Dim path_of_bmp1 As String = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_sobel_cache1\" + sobel_ind1.ToString() + ".jpg"
        'path_of_bmp1 = "E:\memomi_folder1\glass_pics_8\980376445_2\191966121998__A_sobel_cache1_h_dir2\" + sobel_ind1.ToString() + ".jpg"
        'path_of_bmp1 = "E:\memomi_folder1\glass_pics_8\980376445_2\191966121998__A_sobel_cache1_h_dir2\"
        'Dim path_of_bmp1 As String = CGlobals1.global_path1 + file_name1 + "\" + sobel_ind1.ToString() + ".jpg"
        'Dim path_of_bmp1 As String = "D:\glass_pics1\980115778\" + sobel_ind1.ToString() + ".jpg"


        'Dim bmp1 As Bitmap = New Bitmap(path_of_bmp1)
        '90,140,170,500
        '1360,15->1560,121

        Dim bmp5 As Bitmap = CGlobals1.crop_bitmap(bmp1, rect_start_x1, rect_start_y1, width_of_bmp1, 100)
        Dim bmp6 As Bitmap = CGlobals1.create_fill_bitmap(width_of_bmp1, 120, Color.FromArgb(255, 0, 0, 0))
        Dim bmp7 As Bitmap = CGlobals1.copy_bitmap_2_bitmap1(bmp6, bmp5, 5, 5)
        bmp1 = bmp7

        bmp_current_sobel = bmp1

        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\bmp1.bmp")
        Dim copy_bmp1 As Bitmap = New Bitmap(bmp1.Width, bmp1.Height)

        Dim x1 As Integer
        Dim y1 As Integer

        Dim start_search_curves_ind1 As Integer = 0
        Dim start_search_curves_arr1 As ArrayList = New ArrayList()
        Dim all_curves_arr1 As ArrayList = New ArrayList()
        Dim last_pixel_ind1 As Integer = 0

        Dim x_padding1 As Integer = 5
        Dim y_padding1 As Integer = 5
        Dim count_set_pixels1 As Integer = 0
        For x1 = x_padding1 To copy_bmp1.Width - 1 - x_padding1
            For y1 = y_padding1 To copy_bmp1.Height - 1 - y_padding1


                copy_bmp1.SetPixel(x1, y1, Color.FromArgb(255, 0, 0, 0))


                If x1 = 310 And y1 = 544 Then
                    Dim d1 As Integer = 1
                End If
                If x1 = 21 And y1 = 135 Then
                    Dim d1 As Integer = 1
                End If


                If CGlobals1.compare_colors1(get_pixel_at1(bmp_current_sobel, x1, y1), color_of_sobel) = 1 And x1 > 5 And x1 < 500 And y1 > 5 And y1 < 900 Then
                    Dim dir_ind1 As Integer = 0
                    Dim new_cord_x1 As Integer = x1 + CGlobals1.dir_arr1(dir_ind1, 0)
                    Dim new_cord_y1 As Integer = y1 + CGlobals1.dir_arr1(dir_ind1, 1)
                    Dim count_not_sobel_around1 As Integer = 0
                    Dim p_ind1 As Integer

                    For dir_ind1 = 0 To CGlobals1.dir_arr1.Length / 2 - 1
                        new_cord_x1 = x1 + CGlobals1.dir_arr1(dir_ind1, 0)
                        new_cord_y1 = y1 + CGlobals1.dir_arr1(dir_ind1, 1)
                        If CGlobals1.compare_colors1(get_pixel_at1(bmp_current_sobel, new_cord_x1, new_cord_y1), color_of_sobel) = 0 Then
                            count_not_sobel_around1 += 1
                        End If
                    Next
                    Dim no_sbel_in_left_or_right1 As Integer = 0

                    If CGlobals1.compare_colors1(get_pixel_at1(bmp_current_sobel, x1 + 1, y1), color_of_sobel) = 0 Or
                                CGlobals1.compare_colors1(get_pixel_at1(bmp_current_sobel, x1 - 1, y1), color_of_sobel) = 0 Then
                        no_sbel_in_left_or_right1 = 1
                    End If

                    If count_not_sobel_around1 >= 3 And no_sbel_in_left_or_right1 = 1 Then ' Or True Then
                        If x1 = 269 And y1 = 516 Then
                            Dim d1 As Integer = 1
                        End If
                        'If last_pixel_ind1 Mod 20 = 0 Then
                        If x1 = 18 And y1 = 8 Then
                            Dim d1 As Integer = 4
                        End If
                        If count_set_pixels1 Mod 1 = 0 Then
                            start_search_curves_arr1.Add(New Integer() {x1, y1})
                        End If
                        count_set_pixels1 += 1
                        If start_search_curves_arr1.Count < 2000 Then


                        End If

                        'End If
                        copy_bmp1.SetPixel(x1, y1, Color.FromArgb(0, 255, 255, 255))
                        last_pixel_ind1 += 1

                    End If
                    'If CGlobals1.compare_colors1(markingfldimg_obj1.get_pixel_at1(markingfldimg_obj1.bmp_current_sobel, new_cord_x1, new_cord_y1), markingfldimg_obj1.color_of_sobel) = 0 Then
                    'start_search_curves_arr1.Add(New Integer() {x1, y1})
                    'copy_bmp1.SetPixel(x1, y1, Color.FromArgb(255, 255, 255, 255))

                    'End If



                End If

            Next

        Next

        copy_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\curves_1.bmp")

        'start_search_curves_arr1.Clear()
        'start_search_curves_arr1.Add(New Integer() {310, 544})
        'start_search_curves_arr1.Add(New Integer() {33, 116})

        x_start2 = 4
        y_start2 = 4

        Dim dict_res1 As Dictionary(Of String, Object)
        Dim to_save1 As Integer = 0

        Dim i1 As Integer

        CGlobals1.dir_x1_to_sobel = 1
        CGlobals1.dir_m1_to_sobel = 0
        Dim to_stop1 As Integer = 0

        x_start2 = start_search_curves_arr1(start_search_curves_ind1)(0)
        y_start2 = start_search_curves_arr1(start_search_curves_ind1)(1)
        'markingfldimg_obj1.compute_current_start_cord_and_vec1()
        While to_stop1 = 0







            'While (get_pixel_at1(bmp1, x_start2, y_start2).R <> markingfldimg_obj1.color_of_sobel.R Or
            'get_pixel_at1(bmp1, x_start2, y_start2).G <> markingfldimg_obj1.color_of_sobel.G Or
            'get_pixel_at1(bmp1, x_start2, y_start2).B <> markingfldimg_obj1.color_of_sobel.B) And y_start2 < bmp1.Height - 1 And x_start2 < bmp1.Width - 1
            'x_start2 += CGlobals1.dir_x1_to_sobel
            'y_start2 += CGlobals1.dir_m1_to_sobel

            'End While


            If start_search_curves_ind1 <= 199 And start_search_curves_ind1 > 0 Then
                Dim d4 As Integer = 1
            End If

            While curves_pixels_dict1.ContainsKey(x_start2.ToString() + "," + y_start2.ToString()) = True
                'check_d_x_y1(x_start2, y_start2)

                If start_search_curves_ind1 = 199 Then
                    Dim d4 As Integer = 1
                End If
                start_search_curves_ind1 += 1

                If start_search_curves_ind1 >= start_search_curves_arr1.Count Then
                    For i3 = 0 To all_curves_arr1.Count - 1
                        save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\curves_pxls_" + i3.ToString() + ".txt", all_curves_arr1(i3))
                    Next
                    Return all_curves_arr1
                    'Return 1
                End If
                x_start2 = start_search_curves_arr1(start_search_curves_ind1)(0)
                y_start2 = start_search_curves_arr1(start_search_curves_ind1)(1)
                'check_d_x_y1(x_start2, y_start2)
            End While

            Dim last_start_search_curves_ind1 As Integer = start_search_curves_ind1
            If start_search_curves_ind1 = 11 Then
                Dim d4 As Integer = 1
            End If
            If curves_pixels_dict1.ContainsKey(x_start2.ToString() + "," + y_start2.ToString()) = False Then

                dict_res1 = find_max_sobel_length2(x_start2, y_start2)



                While dict_res1("pixels_around_sobel_arr1")("max_pixels_arr1").Count <= 0 And dict_res1("pixels_around_sobel_arr1_rev")("max_pixels_arr1").Count <= 0
                    'check_d_x_y1(x_start2, y_start2)
                    If start_search_curves_ind1 = 11 Then
                        Dim d4 As Integer = 1
                    End If
                    start_search_curves_ind1 += 1

                    If start_search_curves_ind1 >= start_search_curves_arr1.Count Then
                        For i3 = 0 To all_curves_arr1.Count - 1
                            save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\curves_pxls_" + i3.ToString() + ".txt", all_curves_arr1(i3))
                        Next
                        Return all_curves_arr1
                        Return 1
                    End If

                    x_start2 = start_search_curves_arr1(start_search_curves_ind1)(0)
                    y_start2 = start_search_curves_arr1(start_search_curves_ind1)(1)
                    'check_d_x_y1(x_start2, y_start2)
                    If start_search_curves_ind1 = 11 Then
                        Dim d4 As Integer = 1
                    End If
                    While curves_pixels_dict1.ContainsKey(x_start2.ToString() + "," + y_start2.ToString()) = True
                        'check_d_x_y1(x_start2, y_start2)
                        If start_search_curves_ind1 = 199 Then
                            Dim d4 As Integer = 1
                        End If
                        start_search_curves_ind1 += 1
                        If start_search_curves_ind1 >= start_search_curves_arr1.Count Then
                            For i3 = 0 To all_curves_arr1.Count - 1
                                save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\curves_pxls_" + i3.ToString() + ".txt", all_curves_arr1(i3))
                            Next
                            Return all_curves_arr1
                            Return 1
                        End If

                        x_start2 = start_search_curves_arr1(start_search_curves_ind1)(0)
                        y_start2 = start_search_curves_arr1(start_search_curves_ind1)(1)
                        'check_d_x_y1(x_start2, y_start2)

                    End While
                    If start_search_curves_ind1 = 11 Then
                        Dim d4 As Integer = 1
                    End If
                    If curves_pixels_dict1.ContainsKey(x_start2.ToString() + "," + y_start2.ToString()) = False Then
                        dict_res1 = find_max_sobel_length2(x_start2, y_start2)

                    End If




                    'Dim i1 As Integer


                    For i1 = 0 To dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1").Count - 1
                        If dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1")(i1) = "269,516" Then
                            Dim d1 As Integer = 1
                        End If
                        curves_pixels_dict1(dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1")(i1)) = 1
                    Next
                    For i1 = 0 To dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1").Count - 1
                        If dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1")(i1) = "269,516" Then
                            Dim d1 As Integer = 1
                        End If
                        curves_pixels_dict1(dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1")(i1)) = 1
                    Next


                End While

                If start_search_curves_ind1 = 11 Then
                    Dim d4 As Integer = 1
                End If

                'Dim i1 As Integer

                If False Then

                    For i1 = 0 To dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1").Count - 1
                        If dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1")(i1) = "269,516" Then
                            Dim d1 As Integer = 1
                        End If
                        curves_pixels_dict1(dict_res1("pixels_around_sobel_arr1")("over_all_pixels_arr1")(i1)) = 1
                    Next
                    For i1 = 0 To dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1").Count - 1
                        If dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1")(i1) = "269,516" Then
                            Dim d1 As Integer = 1
                        End If
                        curves_pixels_dict1(dict_res1("pixels_around_sobel_arr1_rev")("over_all_pixels_arr1")(i1)) = 1
                    Next


                End If


                'Dim curves_arr1 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1")("pixels_cords_arr1"), 0, 0, 450, 1070)
                'Dim curves_arr2 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1_rev")("pixels_cords_arr1"), 0, 0, 450, 1070)

                'Dim curves_arr1 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1")("max_pixels_arr1"), 0, 0, 450, 1070)
                'Dim curves_arr2 As ArrayList = markingfldimg_obj1.get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1_rev")("max_pixels_arr1"), 0, 0, 450, 1070)

                Dim curves_arr1 As ArrayList = get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1")("max_pixels_arr1"), 0, 0, width_of_bmp1, 1070)
                Dim curves_arr2 As ArrayList = get_curve_from_pixels_arr_by_region(dict_res1("pixels_around_sobel_arr1_rev")("max_pixels_arr1"), 0, 0, width_of_bmp1, 1070)


                For i1 = 0 To curves_arr1.Count - 1
                    Dim i2 As Integer

                    For i2 = 0 To curves_arr1(i1).Count - 1
                        Dim cord_xy1a As Integer = Integer.Parse(curves_arr1(i1)(i2).ToString().Split(",")(0).ToString())
                        Dim cord_xy1b As Integer = Integer.Parse(curves_arr1(i1)(i2).ToString().Split(",")(1).ToString())
                        If cord_xy1a = 326 And cord_xy1b = 427 Then
                            Dim d3 As Integer = 1
                        End If
                        copy_bmp1.SetPixel(cord_xy1a, cord_xy1b, Color.FromArgb(255, 160, 50, 90))
                        If curves_pixels_dict1.ContainsKey("19,5") = False And curves_arr1(i1)(i2) = "19,5" Then
                            Dim d1 As Integer = 1
                        End If
                        If curves_pixels_dict1.ContainsKey(curves_arr1(i1)(i2)) = True Then
                            Dim err1 As Integer = 1
                        End If
                        curves_pixels_dict1(curves_arr1(i1)(i2)) = 1

                        'only_curves_pixels_dict1


                        If only_curves_pixels_dict1.ContainsKey(curves_arr1(i1)(i2)) = True Then
                            Dim err1 As Integer = 1
                        End If
                        only_curves_pixels_dict1(curves_arr1(i1)(i2)) = 1


                    Next
                    all_curves_arr1.Add(curves_arr1(i1).Clone())
                Next
                If dict_res1("pixels_around_sobel_arr1")("close_loop1") = "yes" Then
                Else
                    curves_arr1 = curves_arr2
                    For i1 = 0 To curves_arr1.Count - 1
                        Dim i2 As Integer
                        Dim count_exist_pixels1 As Integer = 0
                        For i2 = 0 To curves_arr1(i1).Count - 1

                            Dim cord_xy1a As Integer = Integer.Parse(curves_arr1(i1)(i2).ToString().Split(",")(0).ToString())
                            Dim cord_xy1b As Integer = Integer.Parse(curves_arr1(i1)(i2).ToString().Split(",")(1).ToString())
                            If cord_xy1a = 326 And cord_xy1b = 427 Then
                                Dim d3 As Integer = 1
                            End If

                            copy_bmp1.SetPixel(cord_xy1a, cord_xy1b, Color.FromArgb(255, 160, 50, 90))

                            If curves_pixels_dict1.ContainsKey(curves_arr1(i1)(i2)) = True Then
                                Dim err1 As Integer = 1
                                count_exist_pixels1 += 1
                            End If
                            curves_pixels_dict1(curves_arr1(i1)(i2)) = 1

                            If only_curves_pixels_dict1.ContainsKey(curves_arr1(i1)(i2)) = True Then
                                Dim err1 As Integer = 1
                            End If
                            only_curves_pixels_dict1(curves_arr1(i1)(i2)) = 1

                        Next
                        If count_exist_pixels1 >= curves_arr1(i1).Count - 1 Then
                        Else
                            all_curves_arr1.Add(curves_arr1(i1).Clone())
                        End If

                    Next

                End If


            End If

            If start_search_curves_ind1 >= start_search_curves_arr1.Count - 1 Then
                to_stop1 = 1
                to_save1 = 1
            End If
            If to_save1 = 1 Then



                copy_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\curves_" + start_search_curves_ind1.ToString() + ".bmp")

                Dim i3 As Integer


                For i3 = 0 To all_curves_arr1.Count - 1
                    save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\curves_pxls_" + i3.ToString() + ".txt", all_curves_arr1(i3))
                Next
                Dim count_over_edge1 As Integer = 0

                For i3 = 0 To start_search_curves_arr1.Count - 1
                    Dim x_start3 As Integer = start_search_curves_arr1(i3)(0)
                    Dim y_start3 As Integer = start_search_curves_arr1(i3)(1)
                    If curves_pixels_dict1.ContainsKey(x_start3.ToString() + "," + y_start3.ToString()) = True Then
                        count_over_edge1 += 1
                    End If

                Next

                Return all_curves_arr1
            End If
            start_search_curves_ind1 += 1



        End While
    End Function


    Public Function find_first_change_curveture1(curve_pxls_arr1 As ArrayList)
        Dim delta_line1 As Integer = 5
        Dim start_pixel_ind1 As Integer = 0
        Dim next_pixel_ind2 As Integer = start_pixel_ind1 + delta_line1

        Dim find_diff_curveture1 As Integer = 0
        Dim status_of_curveture1 As String = ""

        Dim max_dist_pixel_cords_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim max_dist_pixel_dict1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        Dim max_dist_good_curveture1 As Double = -1
        Dim max_dist_good_curveture_pxl_ind1 As Integer = -1
        While find_diff_curveture1 = 0

            next_pixel_ind2 = start_pixel_ind1 + delta_line1


            Dim pxl_arr2 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(curve_pxls_arr1, start_pixel_ind1, next_pixel_ind2)


            Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, start_pixel_ind1)
            Dim cord_xy2a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, next_pixel_ind2)

            Dim angle1 As Double = Math.Atan((cord_xy2a(1) - cord_xy1a(1)) / (cord_xy2a(0) - cord_xy1a(0))) / Math.PI * 180.0



            Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
            vec_3d_obj1.p1 = New point_3d1()
            vec_3d_obj1.p1.x1 = cord_xy1a(0)
            vec_3d_obj1.p1.y1 = cord_xy1a(1)


            vec_3d_obj1.p2 = New point_3d1()
            vec_3d_obj1.p2.x1 = cord_xy1a(0)
            vec_3d_obj1.p2.y1 = cord_xy1a(1)
            vec_3d_obj1.p2.z1 = -10

            Dim rot_pxl_arr1 As ArrayList = rotate_2d_pixels_arr(pxl_arr2, vec_3d_obj1, angle1)

            Dim max_dist_pixel1 As Double = -1
            Dim max_dist_ind1 As Integer = -1
            Dim i3 As Integer
            Dim not_good_line1 As Integer = 0
            Dim delta_pixels1 As Integer = 2
            For i3 = 0 + delta_pixels1 To rot_pxl_arr1.Count - 1 - delta_pixels1

                If Double.Parse(rot_pxl_arr1(i3).ToString().Split(",")(1)) < cord_xy1a(1) And False Then ' And Math.Abs(Double.Parse(rot_pxl_arr1(i3).ToString().Split(",")(1)) - cord_xy1a(1)) >= 2 Then
                    not_good_line1 = 1
                Else
                    Dim dist1 As Double = Math.Abs(Double.Parse(rot_pxl_arr1(i3).ToString().Split(",")(1)) - cord_xy1a(1))
                    If dist1 > 3 Then
                        If max_dist_pixel1 < dist1 Then
                            max_dist_pixel1 = dist1
                            max_dist_ind1 = i3 + start_pixel_ind1
                        End If

                    End If
                End If
                'If CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_arr1, i3)(1) > cord_xy1a(1) Then
                'not_good_line1 = 1

                'End If


            Next

            If not_good_line1 = 0 And status_of_curveture1 = "" Then ' And max_dist_pixel1 > 5 Then
                status_of_curveture1 = "good_curve"
                max_dist_pixel_cords_dict1(start_pixel_ind1) = max_dist_ind1
                max_dist_pixel_dict1(start_pixel_ind1) = max_dist_pixel1
            ElseIf not_good_line1 = 0 And status_of_curveture1 = "good_curve" Then
                max_dist_pixel_cords_dict1(start_pixel_ind1) = max_dist_ind1
                max_dist_pixel_dict1(start_pixel_ind1) = max_dist_pixel1

                If max_dist_good_curveture1 < max_dist_pixel1 Then
                    max_dist_good_curveture1 = max_dist_pixel1
                    max_dist_good_curveture_pxl_ind1 = max_dist_ind1
                End If
            ElseIf not_good_line1 = 1 And status_of_curveture1 = "good_curve" Then 'And max_dist_pixel1 > 5 Then
                'find_diff_curveture1 = 1
            End If
            If not_good_line1 = 0 And max_dist_pixel1 > 10 Then
                'find_diff_curveture1 = 1
            End If
            delta_line1 += 1
            'start_pixel_ind1 += 1
        End While


    End Function


    Public Function find_curve_nearset_to_cord_xy1(curves_arr1 As ArrayList, cord_xy1 As Integer())
        Dim curve_ind1 As Integer
        Dim min_dist_curve1 As Double = 9999
        Dim min_dist_curve_ind1 As Double = -1
        For curve_ind1 = 0 To curves_arr1.Count - 1
            Dim pixel_ind1 As Integer
            Dim min_dist1 As Double = 9999
            Dim curve1 As ArrayList = curves_arr1(curve_ind1)
            For pixel_ind1 = 0 To curve1.Count - 1
                Dim dist1 As Double = get_dist_between_2_cords_xy1(CGlobals1.get_cord_xy_in_pixels_arr1(curve1, pixel_ind1), cord_xy1)
                If min_dist1 > dist1 Then
                    min_dist1 = dist1
                End If
            Next
            If min_dist_curve1 > min_dist1 Then
                min_dist_curve1 = min_dist1
                min_dist_curve_ind1 = curve_ind1
            End If
        Next

        Return min_dist_curve_ind1
    End Function


    Public Function get_dist_between_2_cords_xy1(cord_xy1 As Integer(), cord_xy2 As Integer())
        Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1(0) - cord_xy2(0), 2) + Math.Pow(cord_xy1(1) - cord_xy2(1), 2), 0.5)
        Return dist1
    End Function

    Public Function get_dist_between_2_cords_xy2(cord_xy1 As Double(), cord_xy2 As Double())
        Dim dist1 As Double = Math.Pow(Math.Pow(cord_xy1(0) - cord_xy2(0), 2) + Math.Pow(cord_xy1(1) - cord_xy2(1), 2), 0.5)
        Return dist1
    End Function

    Public Function check_min_dist_to_curve1(curve_pixels1 As ArrayList, cord_xy1 As Integer(), max_dist_to_search1 As Double)
        Dim dict_curve1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(curve_pixels1)
        Dim x1 As Integer
        Dim y1 As Integer
        Dim min_dist1 As Double = 999
        Dim min_dist_ind1 As Integer = -1
        For x1 = cord_xy1(0) - max_dist_to_search1 To cord_xy1(0) + max_dist_to_search1
            For y1 = cord_xy1(1) - max_dist_to_search1 To cord_xy1(1) + max_dist_to_search1
                If dict_curve1.ContainsKey(x1.ToString() + "," + y1.ToString()) = True Then
                    Dim dist1 As Integer = get_dist_between_2_cords_xy1(cord_xy1, New Integer() {x1, y1})
                    If dist1 < min_dist1 Then
                        min_dist1 = dist1
                        min_dist_ind1 = dict_curve1(x1.ToString() + "," + y1.ToString())
                    End If

                End If

            Next

        Next
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res1("min_dist1") = min_dist1
        dict_res1("min_dist_ind1") = min_dist_ind1
        Return dict_res1
    End Function



    Public Function check_min_dist_to_curve2(curve_pixels1 As ArrayList, cord_xy1 As Double(), max_dist_to_search1 As Double)
        Dim dict_curve1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(curve_pixels1)
        Dim x1 As Integer
        Dim y1 As Integer
        Dim min_dist1 As Double = 999
        Dim min_dist_ind1 As Integer = -1
        For x1 = cord_xy1(0) - max_dist_to_search1 To cord_xy1(0) + max_dist_to_search1
            For y1 = cord_xy1(1) - max_dist_to_search1 To cord_xy1(1) + max_dist_to_search1
                If dict_curve1.ContainsKey(x1.ToString() + "," + y1.ToString()) = True Then
                    Dim dist1 As Double = get_dist_between_2_cords_xy2(cord_xy1, New Double() {x1, y1})
                    If dist1 < min_dist1 Then
                        min_dist1 = dist1
                        min_dist_ind1 = dict_curve1(x1.ToString() + "," + y1.ToString())
                    End If

                End If

            Next

        Next
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res1("min_dist1") = min_dist1
        dict_res1("min_dist_ind1") = min_dist_ind1
        Return dict_res1
    End Function

    Public Function filter_curve_by_curvature1(line_len1 As Double, max_dist_from_line1 As Double, curve_pixels_arr1 As ArrayList)
        Dim new_filtered_curve1 As ArrayList = New ArrayList()
        Dim i1 As Integer


        For i1 = 0 To curve_pixels_arr1.Count - 1
            Dim p_ind2 As Integer = 0
            Dim dist1 As Double = -1
            Dim cord_xy_p1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)
            Dim cord_xy_p2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, p_ind2)
            While dist1 < max_dist_from_line1
                cord_xy_p1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)
                cord_xy_p2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, p_ind2)
                dist1 = get_dist_between_2_cords_xy1(cord_xy_p1, cord_xy_p2)
                p_ind2 += 1
            End While
            Dim ind2 As Integer
            Dim pxl_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points2(cord_xy_p1, cord_xy_p2)
            For ind2 = i1 To p_ind2
                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, ind2)
                Dim dist2 As Double = check_min_dist_to_curve1(pxl_line_arr1, cord_xy1, 10)

            Next
        Next
    End Function


    Public Function filter_curve_by_curvature2(line_len1 As Double, max_dist_from_line1 As Double, curve_pixels_arr1 As ArrayList, line_cord_xy1 As Integer(), line_cord_xy2 As Integer())

        Dim len1 As Double = get_dist_between_2_cords_xy1(line_cord_xy1, line_cord_xy2)

        Dim m1 As Double = (line_cord_xy2(1) - line_cord_xy1(1)) / (line_cord_xy2(0) - line_cord_xy1(0))
        Dim new_line_cord_xy1(2) As Integer
        Dim cur_line_len1 As Double = -1
        Dim add_x1 As Integer = 1
        While cur_line_len1 < line_len1
            new_line_cord_xy1(0) = line_cord_xy1(0) + add_x1
            new_line_cord_xy1(1) = line_cord_xy1(1) + add_x1 * m1

            cur_line_len1 = get_dist_between_2_cords_xy1(line_cord_xy1, new_line_cord_xy1)
            add_x1 += 1
        End While
        Dim pxl_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points2(line_cord_xy1, new_line_cord_xy1)




        Dim new_filtered_curve1 As ArrayList = New ArrayList()
        Dim i1 As Integer

        Dim last_dist1 As Double = -1
        Dim last_dist2 As Double = -1
        For i1 = 0 To curve_pixels_arr1.Count - 1
            Dim p_ind2 As Integer = 0
            Dim dist1 As Double = -1
            Dim dict_res1 As Dictionary(Of String, Object) = check_min_dist_to_curve1(pxl_line_arr1, CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1), 10)

            dist1 = dict_res1("min_dist1")

            Dim dict_res2 As Dictionary(Of String, Object) = check_min_dist_to_curve1(pxl_line_arr1, CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1), 10)
            Dim dist2 As Double = get_dist_between_2_cords_xy1(line_cord_xy1, CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1))
            If dist2 >= last_dist2 Then
                last_dist2 = dist2
                If dist1 < max_dist_from_line1 Then

                    If dist1 >= last_dist1 Then
                        new_filtered_curve1.Add(curve_pixels_arr1(i1))
                        last_dist1 = dist1
                    End If

                End If

            End If
        Next

    End Function

    Public Function filter_curve_by_top_line1(curve_pixels_arr1 As ArrayList, top_line1 As ArrayList)
        Dim top_line_dict1 As Dictionary(Of Integer, Integer) = CGlobals1.arr_xy_to_dict2(top_line1)

        Dim new_curve_pixels_arr1 As ArrayList = New ArrayList()
        Dim start_cord_top_line1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(top_line1, 0)
        Dim i1 As Integer
        For i1 = 0 To curve_pixels_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)
            If start_cord_top_line1(0) <= cord_xy1(0) Then

                If top_line_dict1(cord_xy1(0)) <= cord_xy1(1) Then
                    new_curve_pixels_arr1.Add(curve_pixels_arr1(i1))
                End If
            End If
        Next

        Return new_curve_pixels_arr1
    End Function

    Public Function filter_curve_by_curvature3(curve_pixels_arr1 As ArrayList, line_cord_xy1 As Integer(), top_line1 As ArrayList, false_positive_cords_arr1 As ArrayList, dict_pixels1 As Dictionary(Of String, Integer))
        CGlobals1.global_vars_dict1("cuvature3_loop1") += 1
        Dim i1 As Integer


        For i1 = 0 To false_positive_cords_arr1.Count - 1
            curve_pixels_arr1.Remove(false_positive_cords_arr1(i1))
        Next
        Dim top_line1_start_ok_cord1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(top_line1, 0)

        'curve_pixels_arr1.Remove("1257,76")
        'curve_pixels_arr1.Remove("1258,76")
        'curve_pixels_arr1.Remove("1259,76")

        'לוקחים את העקומה העליונה שמתחילה בנקודה הפנימית עד הקצה החיצוני של המסגרת

        Dim dict_curve1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(curve_pixels_arr1)

        Dim x1 As Integer = top_line1_start_ok_cord1(0)
        Dim y1 As Integer = top_line1_start_ok_cord1(1)

        While dict_curve1.ContainsKey(x1.ToString() + "," + y1.ToString()) = False
            y1 += 1
        End While

        Dim ind2 As Integer

        Dim rect_dict2 As Dictionary(Of String, Object) = form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pixels_arr1)
        While CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, ind2)(0) <= rect_dict2("max_x1") - 1
            ind2 += 1
        End While
        Dim ind1 As Integer = dict_curve1(x1.ToString() + "," + y1.ToString())
        curve_pixels_arr1 = CGlobals1.get_arr_from_ind_to_ind1(curve_pixels_arr1, ind1, ind2)

        '---
        'Return curve_pixels_arr1
        'Return curve_pixels_arr1
        Dim top_line_dict1 As Dictionary(Of Integer, Integer) = New Dictionary(Of Integer, Integer)
        'For i1 = 0 To top_line1.Count - 1
        'Dim cord_xy3 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(top_line1, i1)

        'top_line_dict1(cord_xy3(0)) = cord_xy3(1)
        'Next
        'חותכים את העקומה לפי הקו העליון
        curve_pixels_arr1 = filter_curve_by_top_line1(curve_pixels_arr1, top_line1)

        If False Then


            'מקצצים את הסוף כל עוד הוא נוגע בשוליים המקוריים של המסגרת
            Dim to_stop2 As Integer = 0
            Dim start_ind_to_search1 As Integer = curve_pixels_arr1.Count - 1
            Dim last_x_f1 As Integer = -1
            Dim last_y_f1 As Integer = -1
            While to_stop2 = 0
                Dim x2 As Integer
                Dim y2 As Integer
                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, start_ind_to_search1)
                Dim to_remove1 As String = ""
                For x2 = cord_xy1(0) - 3 To cord_xy1(0) + 3
                    For y2 = cord_xy1(1) - 3 To cord_xy1(1) + 3
                        If dict_pixels1.ContainsKey(x2.ToString() + "," + y2.ToString()) = True Then
                            to_remove1 = "yes"
                            last_x_f1 = x2
                            last_y_f1 = y2
                        End If
                    Next

                Next
                If to_remove1 = "yes" Then
                    start_ind_to_search1 -= 1
                    'curve_pixels_arr1.RemoveAt(curve_pixels_arr1.Count - 1)
                Else
                    to_stop2 = 1
                End If
            End While

            to_stop2 = 0
            While to_stop2 = 0
                Dim x2 As Integer
                Dim y2 As Integer
                Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, start_ind_to_search1)
                Dim to_remove1 As String = ""
                For x2 = cord_xy1(0) - 5 To cord_xy1(0) + 5
                    For y2 = cord_xy1(1) - 5 To cord_xy1(1) + 5
                        If dict_pixels1.ContainsKey(x2.ToString() + "," + y2.ToString()) = True Then
                            to_remove1 = "yes"
                        End If
                    Next

                Next
                If to_remove1 = "yes" Then
                    start_ind_to_search1 += 1
                    'curve_pixels_arr1.RemoveAt(curve_pixels_arr1.Count - 1)
                Else
                    to_stop2 = 1
                End If
            End While

            While curve_pixels_arr1.Count >= start_ind_to_search1
                curve_pixels_arr1.RemoveAt(curve_pixels_arr1.Count - 1)
            End While

        End If
        'While dict_pixels1.ContainsKey(curve_pixels_arr1(curve_pixels_arr1.Count - 1)) = True
        'curve_pixels_arr1.RemoveAt(curve_pixels_arr1.Count - 1)
        'End While


        Dim bmp1a As Bitmap = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
        set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp1a, Color.FromArgb(100, 100, 220))
        bmp1a.Save(CGlobals1.global_path1 + "sobel_pics1\curve_pixels_arr1_top_line_" + CGlobals1.global_vars_dict1("cuvature3_loop1").ToString() + ".bmp")



        Dim cord_xy1a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, 0)
        Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
        vec_3d_obj1.p1 = New point_3d1()
        vec_3d_obj1.p1.x1 = cord_xy1a(0)
        vec_3d_obj1.p1.y1 = cord_xy1a(1)


        vec_3d_obj1.p2 = New point_3d1()
        vec_3d_obj1.p2.x1 = cord_xy1a(0)
        vec_3d_obj1.p2.y1 = cord_xy1a(1)
        vec_3d_obj1.p2.z1 = -10

        Dim false_positive_cords_from_sub_curves1 As ArrayList = New ArrayList()

        'top_pixels_curve1 = rotate_2d_pixels_arr(top_pixels_curve1, vec_3d_obj1, 1)
        'curve_pixels_arr1 = top_pixels_curve1
        Dim last_x1 As Integer = line_cord_xy1(0)
        Dim last_y1 As Integer = line_cord_xy1(1)
        Dim new_curve_pixels_arr1 As ArrayList = New ArrayList()
        Dim last_ok_x1 As Integer = -1
        Dim last_not_ok_x1 As Integer = -1
        Dim sub_curves_arr1 As ArrayList = New ArrayList()
        Dim cur_sub_curve_arr1 As ArrayList = New ArrayList()
        For i1 = 0 To curve_pixels_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)
            If cord_xy1(0) > 1480 Then
                Dim d1 As Integer = 1
            End If
            If cord_xy1(0) >= last_x1 Then
                last_x1 = cord_xy1(0)
                If cord_xy1(1) >= last_y1 Then
                    last_y1 = cord_xy1(1)
                    If cord_xy1(0) - 1 > last_ok_x1 Then
                        'If cord_xy1(0) > last_ok_x1 Then

                        If CGlobals1.global_vars_dict1("cuvature3_loop1").ToString() = "1" And sub_curves_arr1.Count.ToString() = "3" Then
                            Dim d1 As Integer = 1
                        End If
                        cur_sub_curve_arr1 = only_complete_missing_pixels_in_curve1(cur_sub_curve_arr1)
                        Dim org_cub_curve1 = cur_sub_curve_arr1.Clone()
                        Dim complete_missing_curve1 As Integer = 1
                        Dim len1 As Integer = cur_sub_curve_arr1.Count
                        Dim bmp1b As Bitmap = CGlobals1.create_fill_bitmap(3500, 2300, Color.FromArgb(255, 255, 255))
                        set_pixels_arr_and_save2(cur_sub_curve_arr1, bmp1b, Color.FromArgb(0, 0, 0), CGlobals1.global_path1 + "sobel_pics1\sub_curve_img1_before_" + CGlobals1.global_vars_dict1("cuvature3_loop1").ToString() + "_" + sub_curves_arr1.Count.ToString() + ".bmp")

                        cur_sub_curve_arr1 = find_max_tangent_len_on_curve1(cur_sub_curve_arr1)
                        Dim dict_org_sub_curve1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(cur_sub_curve_arr1)
                        Dim i4 As Integer
                        For i4 = 0 To org_cub_curve1.count - 1
                            If dict_org_sub_curve1.ContainsKey(org_cub_curve1(i4)) = False Then
                                false_positive_cords_from_sub_curves1.Add(org_cub_curve1(i4))
                            End If
                        Next
                        Dim bmp1c As Bitmap = CGlobals1.create_fill_bitmap(3500, 2300, Color.FromArgb(255, 255, 255))
                        set_pixels_arr_and_save2(cur_sub_curve_arr1, bmp1c, Color.FromArgb(0, 0, 0), CGlobals1.global_path1 + "sobel_pics1\sub_curve_img1_after_" + CGlobals1.global_vars_dict1("cuvature3_loop1").ToString() + "_" + sub_curves_arr1.Count.ToString() + ".bmp")
                        Dim len2 As Integer = cur_sub_curve_arr1.Count
                        If len1 <> len2 Then
                            Dim d1 As Integer = 1
                        End If
                        sub_curves_arr1.Add(cur_sub_curve_arr1)
                        save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\sub_curve_" + sub_curves_arr1.Count.ToString() + ".txt", cur_sub_curve_arr1)
                        cur_sub_curve_arr1 = New ArrayList()
                    End If
                    last_ok_x1 = cord_xy1(0)
                    new_curve_pixels_arr1.Add(curve_pixels_arr1(i1))
                    cur_sub_curve_arr1.Add(curve_pixels_arr1(i1))

                Else

                    last_not_ok_x1 = cord_xy1(0)
                End If
                If cord_xy1(1) >= last_y1 - 1 Then
                    'new_curve_pixels_arr1.Add(curve_pixels_arr1(i1))
                End If
            End If
        Next
        cur_sub_curve_arr1 = find_max_tangent_len_on_curve1(cur_sub_curve_arr1)
        sub_curves_arr1.Add(cur_sub_curve_arr1)


        Dim dict_res2 As Dictionary(Of String, Object) = filter_sub_curves_arr1(sub_curves_arr1)
        new_curve_pixels_arr1 = dict_res2("new_curve1")
        Dim new_curve_pixels_arr1_dict1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(new_curve_pixels_arr1)
        If new_curve_pixels_arr1_dict1.ContainsKey(line_cord_xy1(0).ToString() + "," + line_cord_xy1(1).ToString()) = False Then
            new_curve_pixels_arr1.Insert(0, line_cord_xy1(0).ToString() + "," + line_cord_xy1(1).ToString())

        End If

        Dim bmp_curves1 As Bitmap = New Bitmap(CGlobals1.global_vars_dict1("crop_bmp2_path1").ToString())
        Dim r1 As Byte = 100
        Dim g1 As Byte = 100
        Dim b1 As Byte = 50
        For i1 = 0 To sub_curves_arr1.Count - 1
            save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\sub_curve_" + i1.ToString() + ".txt", sub_curves_arr1(i1))
            Dim bmp_curve1 As Bitmap = CGlobals1.create_fill_bitmap(3500, 2500, Color.FromArgb(255, 255, 255))
            set_pixel_arr_on_bmp2(sub_curves_arr1(i1), bmp_curves1, Color.FromArgb(r1, g1, b1))
            Try
                r1 += 10
                g1 -= 10
                b1 += 20

            Catch ex As Exception
                r1 = 100
                g1 = 100
                b1 = 50
            End Try
            set_pixels_arr_and_save2(sub_curves_arr1(i1), bmp_curve1, Color.FromArgb(0, 0, 0), CGlobals1.global_path1 + "sobel_pics1\sub_curve_img1_" + CGlobals1.global_vars_dict1("cuvature3_loop1").ToString() + "_" + i1.ToString() + ".bmp")
        Next
        bmp_curves1.Save(CGlobals1.global_path1 + "sobel_pics1\sub_curves_" + CGlobals1.global_vars_dict1("cuvature3_loop1").ToString() + ".bmp")

        'new_curve_pixels_arr1 = rotate_2d_pixels_arr(new_curve_pixels_arr1, vec_3d_obj1, -1)
        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(4000, 2500, Color.FromArgb(255, 255, 255))
        set_pixel_arr_on_bmp2(new_curve_pixels_arr1, bmp1, Color.FromArgb(200, 40, 100))
        bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\uncomplete_pixels_curve_1.bmp")
        'save_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\uncomplete_pixels_curve_1.txt", cur_sub_curve_arr1)


        Dim dict_res1 As Dictionary(Of String, Object) = complete_uncomplete_pixels_curve_with_lines(new_curve_pixels_arr1)
        dict_res1("false_positive_cords_from_sub_curves1") = false_positive_cords_from_sub_curves1
        Return dict_res1
    End Function

    Public Function filter_sub_curves_arr1(sub_curves_arr1 As ArrayList)
        Dim i1 As Integer

        Dim new_sub_curve_arr1 As ArrayList = New ArrayList()
        Dim new_curve1 As ArrayList = New ArrayList()
        For i1 = 0 To sub_curves_arr1.Count - 1
            Dim i2 As Integer
            Dim sub_curve1 As ArrayList = sub_curves_arr1(i1)
            Dim good_curve1 As String = "yes"
            If sub_curve1.Count >= 3 Then

                Dim last_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, 0)
                For i2 = 1 To sub_curve1.Count - 1
                    Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, i2)
                    If last_cord_xy1(1) > cord_xy1(1) Then
                        good_curve1 = "no"

                    End If
                    last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, i2)
                Next
            Else
                good_curve1 = "no"
            End If

            If good_curve1 = "yes" Then
                new_sub_curve_arr1.Add(sub_curve1)

                For i2 = 0 To sub_curve1.Count - 1


                    new_curve1.Add(sub_curve1(i2))
                Next
            End If
        Next
        Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res1("new_curve1") = new_curve1
        dict_res1("new_sub_curve_arr1") = new_sub_curve_arr1
        Return dict_res1
    End Function


    Public Function complete_uncomplete_pixels_curve_with_lines(un_complete_curve1 As ArrayList)

        'Return un_complete_curve1
        Dim i1 As Integer
        Dim new_complete_curve1 As ArrayList = New ArrayList()
        Dim last_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(un_complete_curve1, 0)
        new_complete_curve1.Add(last_cord_xy1(0).ToString() + "," + last_cord_xy1(1).ToString())
        For i1 = 1 To un_complete_curve1.Count - 1

            Dim new_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(un_complete_curve1, i1)

            Dim x1 As Integer
            Dim y1 As Integer
            Dim connect_to_last_pixel1 As String = ""
            For x1 = last_cord_xy1(0) - 1 To last_cord_xy1(0) + 1
                For y1 = last_cord_xy1(1) - 1 To last_cord_xy1(1) + 1
                    If new_cord_xy1(0) = x1 And new_cord_xy1(1) = y1 Then
                        connect_to_last_pixel1 = "yes"
                    End If
                Next

            Next
            If connect_to_last_pixel1 = "yes" Then
                new_complete_curve1.Add(new_cord_xy1(0).ToString() + "," + new_cord_xy1(1).ToString())
            Else



                If new_complete_curve1.Count > 1 Then


                    Dim dict_res1 As Dictionary(Of String, Object) = find_the_tangent_to_curve_from_cord_ind(new_complete_curve1, 0)
                    Dim curve_arr1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(dict_res1("rot_curve_pixels"), dict_res1("cord_ind1"), dict_res1("last_cord_ind1"))
                    Dim good_curve1 As String = "yes"
                    Dim false_positive_cords_arr1 As ArrayList = New ArrayList()
                    Dim i2 As Integer
                    Dim cord_xy3a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, 0)

                    For i2 = 0 To curve_arr1.Count - 1
                        Dim cord_xy3b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i2)
                        If cord_xy3b(0) < cord_xy3a(0) Then
                            good_curve1 = "no"
                            false_positive_cords_arr1.Add(new_complete_curve1(i2))
                        End If
                    Next
                    If false_positive_cords_arr1.Count > 3 Then
                        Dim dict_res4 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                        dict_res4("new_complete_curve1") = new_complete_curve1
                        dict_res4("false_positive_cords_arr1") = false_positive_cords_arr1
                        Return dict_res4
                    End If
                End If
                If last_cord_xy1(0) = 1290 And last_cord_xy1(1) = 69 Then
                    Dim d1 As Integer = 1
                End If
                Dim pixels_line1 As ArrayList = create_pixel_arr_line_from_2_2d_points2(last_cord_xy1, new_cord_xy1)



                If False Then

                    Dim bmp_pxl_line1 As Bitmap = New Bitmap(CGlobals1.global_vars_dict1("crop_bmp2_path1").ToString())
                    Dim r1 As Byte = 100
                    Dim g1 As Byte = 100
                    Dim b1 As Byte = 50
                    set_pixel_arr_on_bmp2(pixels_line1, bmp_pxl_line1, Color.FromArgb(255, 80, 50))
                    bmp_pxl_line1.Save(CGlobals1.global_path1 + "sobel_pics1\sub_curves_pxl_line1_" + i1.ToString() + ".bmp")

                End If





                For i2 = 1 To pixels_line1.Count - 2
                    new_complete_curve1.Add(pixels_line1(i2).ToString())

                Next
                new_complete_curve1.Add(new_cord_xy1(0).ToString() + "," + new_cord_xy1(1).ToString())
                Dim dict_res2 As Dictionary(Of String, Object) = find_the_tangent_to_curve_from_cord_ind(new_complete_curve1, 0)
            End If

            last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(un_complete_curve1, i1)

        Next
        Dim dict_res3 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_res3("new_complete_curve1") = new_complete_curve1
        Return dict_res3
    End Function


    Public Function only_complete_missing_pixels_in_curve1(curve1 As ArrayList)
        If curve1.Count <= 2 Then
            Return curve1
        End If
        Dim i1 As Integer
        Dim new_curve1 As ArrayList = New ArrayList()

        Dim last_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        new_curve1.Add(last_cord_xy1(0).ToString() + "," + last_cord_xy1(1).ToString())
        For i1 = 1 To curve1.Count - 1
            Dim new_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)
            Dim x1 As Integer
            Dim y1 As Integer
            Dim coennct_to_new_cord1 As String = "no"
            For x1 = last_cord_xy1(0) - 1 To last_cord_xy1(0) + 1
                For y1 = last_cord_xy1(1) - 1 To last_cord_xy1(1) + 1
                    If x1 = new_cord_xy1(0) And y1 = new_cord_xy1(1) Then
                        coennct_to_new_cord1 = "yes"
                    End If
                Next

            Next
            If coennct_to_new_cord1 = "no" Then
                Dim pxl_line1 As ArrayList = create_pixel_arr_line_from_2_2d_points2(last_cord_xy1, new_cord_xy1)
                Dim i2 As Integer
                For i2 = 1 To pxl_line1.Count - 2
                    new_curve1.Add(pxl_line1(i2))
                Next
                new_curve1.Add(new_cord_xy1(0).ToString() + "," + new_cord_xy1(1).ToString())
                last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)
            End If
        Next

        Return new_curve1
    End Function

    Public Function only_complete_missing_pixels_in_curve2(curve1 As ArrayList)
        If curve1.Count <= 2 Then
            Return curve1
        End If
        Dim i1 As Integer
        Dim new_curve1 As ArrayList = New ArrayList()

        Dim last_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        new_curve1.Add(last_cord_xy1(0).ToString() + "," + last_cord_xy1(1).ToString())
        For i1 = 1 To curve1.Count - 1
            Dim new_cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)
            Dim x1 As Integer
            Dim y1 As Integer
            Dim coennct_to_new_cord1 As String = "no"
            For x1 = last_cord_xy1(0) - 1 To last_cord_xy1(0) + 1
                For y1 = last_cord_xy1(1) - 1 To last_cord_xy1(1) + 1
                    If x1 = new_cord_xy1(0) And y1 = new_cord_xy1(1) Then
                        coennct_to_new_cord1 = "yes"
                    End If
                Next

            Next
            If coennct_to_new_cord1 = "no" Then
                Dim pxl_line1 As ArrayList = create_pixel_arr_line_from_2_2d_points2(last_cord_xy1, new_cord_xy1)
                Dim i2 As Integer
                For i2 = 1 To pxl_line1.Count - 2
                    new_curve1.Add(pxl_line1(i2))
                Next
                ' new_curve1.Add(new_cord_xy1(0).ToString() + "," + new_cord_xy1(1).ToString())
            Else

            End If

            new_curve1.Add(new_cord_xy1(0).ToString() + "," + new_cord_xy1(1).ToString())
            last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)
        Next

        Return new_curve1
    End Function


    Public Function find_max_line_len_on_curve1(curve_pxls1 As ArrayList, start_ind1 As Integer, end_ind1 As Integer, max_dist_from_curve1 As Double)
        Dim to_stop1 As Integer = 0
        While to_stop1 = 0


            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls1, start_ind1)
            Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls1, end_ind1)
            Dim pxls_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points2(cord_xy1, cord_xy2)
            Dim max_dist1 As Double = -1
            For i1 = start_ind1 To end_ind1
                Dim cord_xy3a As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls1, i1)
                Dim dict_res1 As Dictionary(Of String, Object) = check_min_dist_to_curve1(pxls_line_arr1, cord_xy3a, 2)
                If max_dist1 < dict_res1("min_dist1") And dict_res1("min_dist_ind1") <> -1 Then
                    max_dist1 = dict_res1("min_dist1")

                End If
            Next

            If max_dist1 > max_dist_from_curve1 Then

                Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                dict_res1("end_ind1") = end_ind1
                Return dict_res1
                to_stop1 = 1
            End If
            end_ind1 += 1
        End While

    End Function

    Public Function search_for_start_pixels_between_frame_and_handles_above1(curve_pxls1 As ArrayList, start_ind1 As Integer)

    End Function


    Public Function create_pixel_line_by_m1(m1 As Double, line_len1 As Integer)
        Dim delta_x1 As Double = 0
        Dim delta_y1 As Double = 0

        While Math.Pow(Math.Pow(delta_x1, 2) + Math.Pow(delta_y1, 2), 0.5) <= line_len1
            delta_x1 += 1
            delta_y1 += m1
        End While

        Dim pixel_line1 As ArrayList = create_pixel_arr_line_from_2_2d_points(0, 0, delta_x1, delta_y1)
        Return pixel_line1
    End Function

    'ונקציה שבודקת אם ההתחלה של העקומה בזווית מתונה במקסימום כמו הסוף - ע"י זה שמחפשת משיק מהנקודה הראשנה שכל העקומה תהיה בצד אחד שלו
    'בכל צעד שזה נכשל - מורידים את הפיקסל הראשון בעקומה - עד שנמצא המשיק
    Public Function find_max_tangent_len_on_curve1(curve_pixels1 As ArrayList)
        If curve_pixels1.Count <= 2 Then
            Return curve_pixels1
        End If
        Dim start_ind1 As Integer = 0
        Dim end_ind1 As Integer = curve_pixels1.Count - 1
        Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels1, start_ind1)
        Dim angle1 As Double = 90
        Dim line_len1 As Integer = 1500
        Dim to_stop1 As Integer = 0

        Dim debug_mode1 As Integer = 0

        Dim ind1 As Integer = 0
        While to_stop1 = 0

            Dim sin1 As Double = Math.Sin(angle1 * Math.PI / 180)
            Dim cos1 As Double = Math.Cos(angle1 * Math.PI / 180)
            Dim cord_xy2(1) As Integer
            cord_xy2(0) = cord_xy1(0) + line_len1 * sin1
            cord_xy2(1) = cord_xy1(1) + line_len1 * cos1

            Dim pxl_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points2(cord_xy1, cord_xy2)
            If debug_mode1 = 1 Then
                Dim bmp3 As Bitmap = CGlobals1.create_fill_bitmap(2500, 1300, Color.FromArgb(255, 255, 255))
                set_pixel_arr_on_bmp2(pxl_line_arr1, bmp3, Color.FromArgb(200, 50, 100))
                set_pixel_arr_on_bmp2(curve_pixels1, bmp3, Color.FromArgb(20, 250, 100))
                bmp3.Save(CGlobals1.global_path1 + "sobel_pics1\s_angle_" + ind1.ToString() + ".bmp")

            End If
            ind1 += 1
            Dim pxl_line_dict1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(pxl_line_arr1)

            Dim new_sub_curve1 As ArrayList = CGlobals1.add_val_to_pxls_arr1(curve_pixels1, 0, 0)

            'מחפשים את הישר שעובר בהתחלה במינימום n פיקסלים
            'מהתחלת העוקה
            Dim i1 As Integer
            Dim not_on_line1 As String = "yes"
            Dim i2 As Integer = 0
            Dim last_ok_i2 As Integer = -1
            Dim max_ovarlap_pixels1 As Integer = -1

            Dim new_pxl_line_arr1 As ArrayList = pxl_line_arr1.Clone()
            Dim max_overlap_curve1 As ArrayList
            Dim max_overlap_new_pxl_line1 As ArrayList

            While not_on_line1 = "yes" And i2 < 15
                If not_on_line1 = "yes" Then
                    not_on_line1 = ""
                    Dim add_x1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, i2 + 1)(0) - CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, 0)(0)
                    Dim add_y1 As Integer = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, i2 + 1)(1) - CGlobals1.get_cord_xy_in_pixels_arr1(pxl_line_arr1, 0)(1)
                    new_sub_curve1 = CGlobals1.add_val_to_pxls_arr1(curve_pixels1, add_x1, add_y1)


                    'new_pxl_line_arr1.RemoveAt(0)

                    Dim new_pxl_line_dict1 As Dictionary(Of String, Integer) = CGlobals1.add_to_dict1(new_pxl_line_arr1)


                    Dim start_ind_on_line1 As Integer = new_pxl_line_dict1(new_sub_curve1(0))

                    Dim overlap_ind1 As Integer = 0
                    Dim to_stop4 As Integer = 0
                    While to_stop4 = 0
                        If new_sub_curve1(overlap_ind1) = new_pxl_line_arr1(start_ind_on_line1 + overlap_ind1) Then
                            overlap_ind1 += 1
                        Else
                            to_stop4 = 1
                        End If
                        If overlap_ind1 > new_sub_curve1.Count - 1 Then
                            to_stop4 = 1
                        End If
                    End While

                    If max_ovarlap_pixels1 < overlap_ind1 Then
                        'max_overlap_curve1 = new_sub_curve1.Clone()
                        'max_overlap_new_pxl_line1 = new_pxl_line_arr1.Clone()
                        max_ovarlap_pixels1 = overlap_ind1
                        last_ok_i2 = i2
                    End If

                    Dim to_stop3 As Integer = 0
                    i1 = start_ind1
                    Dim last_index_on_line1 As Integer = -1


                End If

                i2 += 1
            End While

            'If not_on_line1 = "" And max_ovarlap_pixels1 >= 3 Then
            If max_ovarlap_pixels1 >= 5 Or max_ovarlap_pixels1 >= curve_pixels1.Count - 1 Then

                Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(2500, 1300, Color.FromArgb(255, 255, 255))
                'נמצא ישר שעובר בהתחלה במינימום 3 פיקסלים
                If debug_mode1 = 1 Then
                    Dim bmp2a As Bitmap = CGlobals1.create_fill_bitmap(2500, 1300, Color.FromArgb(255, 255, 255))

                    set_pixel_arr_on_bmp2(pxl_line_arr1, bmp2a, Color.FromArgb(200, 50, 100))
                    set_pixel_arr_on_bmp2(new_sub_curve1, bmp2a, Color.FromArgb(20, 250, 100))

                    bmp2a.Save(CGlobals1.global_path1 + "sobel_pics1\b_angle_" + ind1.ToString() + ".bmp")
                End If
                'markingfldimg_obj1.set_pixel_arr_on_bmp2(pxl_line_arr1, bmp2, Color.FromArgb(200, 50, 100))
                'markingfldimg_obj1.set_pixel_arr_on_bmp2(new_sub_curve1, bmp2, Color.FromArgb(20, 250, 100))

                'bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\angle_" + ind1.ToString() + ".bmp")





                Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
                vec_3d_obj1.p1 = New point_3d1(cord_xy1(0), cord_xy1(1), 0)
                vec_3d_obj1.p2 = New point_3d1(cord_xy1(0), cord_xy1(1), 10)

                Dim pxl_line_arr1_r1 As ArrayList = rotate_2d_pixels_arr(pxl_line_arr1, vec_3d_obj1, angle1)
                Dim new_sub_curve1_r1 As ArrayList = rotate_2d_pixels_arr(new_sub_curve1, vec_3d_obj1, angle1)
                If debug_mode1 = 1 Then


                    set_pixel_arr_on_bmp2(pxl_line_arr1_r1, bmp2, Color.FromArgb(200, 50, 100))
                    set_pixel_arr_on_bmp2(new_sub_curve1_r1, bmp2, Color.FromArgb(20, 250, 100))

                    bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\n_angle_" + ind1.ToString() + ".bmp")
                    ind1 += 1
                End If

                Dim cord_xy5 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_sub_curve1_r1, 0)
                Dim ok_start_ind_curve1 As String = ""
                'בדיקה שכל הפיקסלים מצד אחד של הישר
                For i2 = 0 To new_sub_curve1_r1.Count - 1
                    Dim cord_xy4 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(new_sub_curve1_r1, i2)
                    If cord_xy4(0) > cord_xy5(0) Then
                        ok_start_ind_curve1 = "no"
                    End If
                Next
                If ok_start_ind_curve1 = "no" Then
                    to_stop1 = 0
                    curve_pixels1.RemoveAt(0)
                    'sub_curve1.RemoveAt(0)
                    start_ind1 = 0
                    end_ind1 = curve_pixels1.Count - 1
                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels1, start_ind1)
                    angle1 = 90
                Else
                    set_pixel_arr_on_bmp2(curve_pixels1, bmp2, Color.FromArgb(200, 50, 100))
                    bmp2.Save(CGlobals1.global_path1 + "sobel_pics1\angle_" + ind1.ToString() + ".bmp")


                    to_stop1 = 1
                End If

            Else
                angle1 -= 0.5
                If angle1 = 0 Then
                    angle1 = 90
                    curve_pixels1.RemoveAt(0)
                    'end_ind1 -= 1 ' = curve_pixels1.Count - 2
                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels1, start_ind1)
                    'end_ind1 -= 1
                End If
            End If
        End While

        Return curve_pixels1
        'Dim cord_xy2b As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, end_ind1)



        Dim in_line1 As Integer = 1
        While in_line1 = 1
            'Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, start_ind1)
            'Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, end_ind1)
        End While
        Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(2500, 1300, Color.FromArgb(255, 255, 255))
        'Dim pixel_line1 As ArrayList = markingfldimg_obj1.create_pixel_line_by_m1(1.01, 100)
        'markingfldimg_obj1.set_pixel_arr_on_bmp2(sub_curve1, bmp1, Color.FromArgb(200, 50, 100))
        'markingfldimg_obj1.set_pixel_arr_on_bmp2(pixel_line1, bmp1, Color.FromArgb(200, 50, 100))

        'PictureBox1.Image = zoom_img1(bmp1, 1)

    End Function

    Public Function find_the_tangent_to_curve_from_cord_ind(curve_pixels1 As ArrayList, cord_ind1 As Integer)

        Dim debug_mode1 As Integer = 0
        Dim last_cord_ind1 As Integer = curve_pixels1.Count - 1

        Dim to_stop1 As Integer = 0
        Dim dict_cords1 As Dictionary(Of Integer, Integer()) = CGlobals1.conv_2d_arr_to_2d_cords_dict1(curve_pixels1)
        While to_stop1 = 0
            Dim cord_xy1 As Integer() = dict_cords1(cord_ind1) 'CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels1, cord_ind1)
            Dim last_cord_xy1 As Integer() = dict_cords1(last_cord_ind1) 'CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels1, last_cord_ind1)
            Dim pixel_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points2(cord_xy1, last_cord_xy1)


            Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
            vec_3d_obj1.p1 = New point_3d1(cord_xy1(0), cord_xy1(1), 0)
            vec_3d_obj1.p2 = New point_3d1(cord_xy1(0), cord_xy1(1), 10)

            Dim angle1 As Double = Math.Atan((cord_xy1(1) - last_cord_xy1(1)) / (cord_xy1(0) - last_cord_xy1(0))) * 180 / Math.PI

            Dim curve_pixels_r1 As ArrayList = rotate_2d_pixels_arr(curve_pixels1, vec_3d_obj1, 90 - angle1)

            Dim dict_cords_r1 As Dictionary(Of Integer, Integer()) = CGlobals1.conv_2d_arr_to_2d_cords_dict1(curve_pixels_r1)
            'Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(4000, 2500, Color.FromArgb(255, 255, 255))

            'set_pixel_arr_on_bmp2(curve_pixels_r1, bmp1, Color.FromArgb(200, 40, 150))

            'bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\t_angle_1.bmp")
            Dim i2 As Integer
            Dim no_tangent1 As String = ""
            i2 = cord_ind1
            While no_tangent1 = "" And i2 <= curve_pixels_r1.Count - 1
                Dim cord_xy2 As Integer() = dict_cords_r1(i2) ' CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_r1, i2)
                If cord_xy2(0) > cord_xy1(0) Then
                    no_tangent1 = "yes"
                End If
                i2 += 1
            End While
            'For i2 = cord_ind1 To curve_pixels_r1.Count - 1
            'Dim cord_xy2 As Integer() = dict_cords_r1(i2) ' CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_r1, i2)
            'If cord_xy2(0) > cord_xy1(0) Then
            'no_tangent1 = "yes"
            'End If
            'Next

            If no_tangent1 = "yes" Then
                last_cord_ind1 -= 1
            Else
                If debug_mode1 = 1 Then


                    Dim bmp1 As Bitmap = CGlobals1.create_fill_bitmap(4000, 2500, Color.FromArgb(255, 255, 255))

                    set_pixel_arr_on_bmp2(curve_pixels_r1, bmp1, Color.FromArgb(200, 40, 150))

                    set_pixel_arr_on_bmp2(curve_pixels_r1, bmp1, Color.FromArgb(200, 40, 150))

                    bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\t_angle_1.bmp")
                End If
                to_stop1 = 1

                Dim dict_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
                dict_res1("cord_ind1") = cord_ind1
                dict_res1("last_cord_ind1") = last_cord_ind1
                dict_res1("rot_curve_pixels") = curve_pixels_r1

                Return dict_res1
            End If
        End While
    End Function


    Public Function move_pixels_arr1(pxl_arr1 As ArrayList, x1_trans As Integer, y1_trans As Integer)
        Dim i1 As Integer

        Dim new_pxl_arr1 As ArrayList = New ArrayList()
        For i1 = 0 To pxl_arr1.Count - 1
            Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pxl_arr1, i1)
            If cord_xy1.Count = 3 Then
                new_pxl_arr1.Add((cord_xy1(0) + x1_trans).ToString() + "," + (cord_xy1(1) + y1_trans).ToString() + "," + cord_xy1(2).ToString())
            Else
                new_pxl_arr1.Add((cord_xy1(0) + x1_trans).ToString() + "," + (cord_xy1(1) + y1_trans).ToString())

            End If

        Next

        Return new_pxl_arr1
    End Function

    Public Function move_double_pixels_arr1(pxl_arr1 As ArrayList, x1_trans As Double, y1_trans As Double)
        Dim i1 As Integer

        Dim new_pxl_arr1 As ArrayList = New ArrayList()
        For i1 = 0 To pxl_arr1.Count - 1
            Dim cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pxl_arr1, i1)
            If cord_xy1.Count = 3 Then
                new_pxl_arr1.Add((cord_xy1(0) + x1_trans).ToString() + "," + (cord_xy1(1) + y1_trans).ToString() + "," + (cord_xy1(2)).ToString())
            Else
                new_pxl_arr1.Add((cord_xy1(0) + x1_trans).ToString() + "," + (cord_xy1(1) + y1_trans).ToString().ToString())
            End If

        Next

        Return new_pxl_arr1
    End Function


    Public Function compute_cut_line_point1(m_line1 As Double, b_line1 As Double, m_line2 As Double, b_line2 As Double)
        'x*m_line1+b_line1=x*m_line2+b_line2
        'x*(m_line1/m_line2)+(b_line1/m_line2)=x*(m_line2/m_line2)+b_line2/m_line2
        'x*((m_line1/m_line2)-1)=b_line2/m_line2-(b_line1/m_line2)
        'x=(b_line2/m_line2-(b_line1/m_line2))/((m_line1/m_line2)-1)

        Dim y1 As Double = m_line1 * 525 + b_line1
        Dim y2 As Double = m_line2 * 525 + b_line2
        'y=a1*x+b1
        'y=a2*x+b2

        'a1*x+b1=a2*x+b2
        'a1*x=a2*x+b2-b1
        'x(a1-a2)=b2-b1
        'x=(b2-b1)/(a1-a2)

        'Dim x As Double = (b_line2 / m_line2 - (b_line1 / m_line2)) / ((m_line1 / m_line2) - 1)
        Dim x As Double = (b_line2 - b_line1) / (m_line1 - m_line2)

        Dim y As Double = m_line1 * x + b_line1

        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_ret_res1("x") = x
        dict_ret_res1("y") = y


        Return dict_ret_res1
    End Function


    Public Function get_line_x_by_y1(m_line1 As Double, b_line1 As Double, y_line1 As Double)
        'Dim y As Double = m_line1 * x + b_line1
        'x=(y-b_line1)/m_line1
        Dim x1 As Double = (y_line1 - b_line1) / m_line1

        Return x1
    End Function


    Public Function create_pxl_line_from_two_x_and_line_eqa1(line_eqa1 As Dictionary(Of String, Object), start_x1 As Double, end_x1 As Double)
        'y=m*x*b

        Dim y1 As Double = line_eqa1("m1") * start_x1 + line_eqa1("b1")
        Dim y2 As Double = line_eqa1("m1") * end_x1 + line_eqa1("b1")

        Dim pxl_line_arr1 As ArrayList = create_pixel_arr_line_from_2_2d_points(start_x1, y1, end_x1, y2)

        Return pxl_line_arr1
    End Function



    'Public Function get_Angle1(pixels_curve1 As ArrayList, start_ind1 As Integer, end_ind1 As Integer)
    Public Function get_angle1(cord_xy1 As Double(), cord_xy2 As Double())
        'Dim cord_xy1 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_curve1, start_ind1)
        'Dim cord_xy2 As Integer() = CGlobals1.get_cord_xy_in_pixels_arr1(pixels_curve1, end_ind1)



        ' 3 | 0
        ' 2 | 1
        Dim sqr_num1 As Integer = 0

        Dim deriv_val1 As Double = 9999

        If cord_xy2(0) > cord_xy1(0) And cord_xy2(1) = cord_xy1(1) Then
            deriv_val1 = 0
        ElseIf cord_xy2(0) = cord_xy1(0) And cord_xy2(1) > cord_xy1(1) Then
            deriv_val1 = 90
        ElseIf cord_xy2(0) < cord_xy1(0) And cord_xy2(1) = cord_xy1(1) Then
            deriv_val1 = 180
        ElseIf cord_xy2(0) = cord_xy1(0) And cord_xy2(1) < cord_xy1(1) Then
            deriv_val1 = 270
        End If

        If deriv_val1 <> 9999 Then
            Return deriv_val1
        End If

        Dim deriv1 As Double = Math.Abs(Math.Atan((cord_xy1(1) - cord_xy2(1)) / (cord_xy1(0) - cord_xy2(0))) * 180.0 / Math.PI)

        If cord_xy2(0) < cord_xy1(0) And cord_xy2(1) < cord_xy1(1) Then
            sqr_num1 = 3
            deriv1 = -(90 - deriv1)
        ElseIf cord_xy2(0) > cord_xy1(0) And cord_xy2(1) < cord_xy1(1) Then
            sqr_num1 = 4
            deriv1 = -(deriv1)
        ElseIf cord_xy2(0) > cord_xy1(0) And cord_xy2(1) > cord_xy1(1) Then
            sqr_num1 = 1
            deriv1 = -(90 - deriv1)
        ElseIf cord_xy2(0) < cord_xy1(0) And cord_xy2(1) > cord_xy1(1) Then
            sqr_num1 = 2
            deriv1 = -deriv1
        End If







        Dim deriv_val2 As Double = sqr_num1 * 90 + deriv1

        Return deriv_val2
    End Function


    'מציאת  משיקים שמתחתיהם יש קעירות
    'min_width1 - האורך המינימלי של המשיק
    'max_width1 - האורך המקסימלי של המשיק
    'max_above1 - מקסמום בליטה מעל המשיק
    'max_width1 - מינימום קעירות מתחת למשיק
    Public Function find_hole_in_curve_by_max_width_and_min_deep1(pixels_curve1 As ArrayList, min_width1 As Double, max_width1 As Double, max_above1 As Double, min_deep1 As Double)




        Dim bmp5 As Bitmap

        If False Then



            bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pixels_curve1, bmp5, Color.FromArgb(24, 230, 50))
            'bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\lens2.bmp")


            Dim pxl_arr1 As ArrayList = load_2d_pixels_arr1(CGlobals1.global_path1 + "sobel_pics1\res_lens3.txt")

            bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pxl_arr1, bmp5, Color.FromArgb(24, 230, 50))
            'bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\lens3.bmp")

            pxl_arr1 = only_complete_missing_pixels_in_curve2(pxl_arr1)


            Dim path3 As String = "E:\memomi_folder1\glass_pics_8\980376340_2\195768205504__A_lens5.txt"
            'save_2d_pixels_arr1(path3, pxl_arr1)
            bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pxl_arr1, bmp5, Color.FromArgb(24, 230, 50))
            'bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\lens4.bmp")

            'pxl_arr1 = complete_uncomplete_pixels_curve_with_lines(pxl_arr1)("new_complete_curve1")

        End If


        Dim first_ind1 As Integer = 0
        Dim second_ind1 As Integer = 1

        Dim to_stop1 As Integer = 0



        Dim dict_holes1 As Dictionary(Of Integer, Object) = New Dictionary(Of Integer, Object)


        While to_stop1 = 0
            Dim cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pixels_curve1, first_ind1)
            Dim cord_xy2 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pixels_curve1, second_ind1)

            Dim cur_width1 As Double = get_dist_between_2_cords_xy2(cord_xy1, cord_xy2)

            If min_width1 <= cur_width1 And cur_width1 <= max_width1 Then
                Dim angle1 As Double = get_angle1(cord_xy1, cord_xy2)

                Dim vec_3d_obj1 As vec_3d1 = New vec_3d1()
                vec_3d_obj1.p1 = New point_3d1()
                vec_3d_obj1.p1.x1 = cord_xy1(0)
                vec_3d_obj1.p1.y1 = cord_xy1(1)


                vec_3d_obj1.p2 = New point_3d1()
                vec_3d_obj1.p2.x1 = cord_xy1(0)
                vec_3d_obj1.p2.y1 = cord_xy1(1)
                vec_3d_obj1.p2.z1 = -10


                Dim rot_pixels_curve1 As ArrayList = rotate_2d_pixels_arr(pixels_curve1, vec_3d_obj1, -angle1)
                CGlobals1.create_folder1(CGlobals1.global_path1 + "\sobels_pics1\hole_curves1\")
                Dim path1 As String = CGlobals1.global_path1 + "\sobels_pics1\hole_curves1\" + first_ind1.ToString() + "_" + second_ind1.ToString() + ".bmp"

                'CGlobals1.save_pxl_arr_log1(rot_pixels_curve1, path1)
                Dim ind1 As Integer = 0

                Dim top_y1 As Double = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_pixels_curve1, first_ind1)(1)

                Dim to_stop2 As Integer = 0
                Dim pixel_above_top_y1 As String = ""
                Dim max_deep1 As Double = 0
                While to_stop2 = 0
                    Dim ok_pixel As String = "no"
                    If ind1 <= rot_pixels_curve1.Count - 1 Then
                        Dim cur_y1 As Double = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_pixels_curve1, ind1)(1)
                        If cur_y1 >= (top_y1 - max_above1) Then
                            If first_ind1 <= ind1 And second_ind1 >= ind1 Then
                                If Math.Abs(cur_y1 - top_y1) > 50 Then
                                    Dim d1 As Integer = 1
                                End If
                                If max_deep1 < Math.Abs(cur_y1 - top_y1) Then
                                    max_deep1 = Math.Abs(cur_y1 - top_y1)
                                End If
                            End If
                            ok_pixel = "yes"
                        Else
                            pixel_above_top_y1 = "yes"
                        End If

                    End If
                    If ok_pixel = "no" Then
                        to_stop2 = 1
                    End If
                    ind1 += 1
                End While



                If pixel_above_top_y1 = "yes" Then

                Else
                    If min_deep1 <= max_deep1 Then
                        Dim add_dict1 As String = "yes"
                        If dict_holes1.ContainsKey(first_ind1) = True Then
                            If max_deep1 < dict_holes1(first_ind1)("max_deep1") Then
                                add_dict1 = "no"
                            End If
                        End If

                        If add_dict1 = "yes" Then
                            dict_holes1(first_ind1) = New Dictionary(Of String, Object)
                            dict_holes1(first_ind1)("second_ind") = second_ind1
                            dict_holes1(first_ind1)("max_deep1") = max_deep1
                            Dim silce_hole_pxl1 As ArrayList = CGlobals1.get_arr_from_ind_to_ind1(pixels_curve1, first_ind1, second_ind1)
                            Dim path3 As String = CGlobals1.global_path1 + "sobel_pics1\hole_curves1\" + first_ind1.ToString() + "_" + second_ind1.ToString() + ".bmp"


                            CGlobals1.create_folder1(CGlobals1.global_path1 + "\sobel_pics1\hole_curves1\")
                            'Dim path1 As String = CGlobals1.global_path1 + "\sobels_pics1\hole_curves1\" + first_ind1.ToString() + "_" + second_ind1.ToString() + ".bmp"


                            bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, Color.FromArgb(255, 255, 255))
                            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(silce_hole_pxl1, bmp5, Color.FromArgb(24, 230, 50))
                            bmp5.Save(path3)

                        End If
                        Dim ok1 As Integer = 1
                    End If

                End If


            End If

            second_ind1 += 1
            If min_width1 > cur_width1 And second_ind1 < pixels_curve1.Count - 1 Then

                second_ind1 += 1
            ElseIf max_width1 < cur_width1 And first_ind1 < pixels_curve1.Count - 2 Then

                first_ind1 += 1
                second_ind1 = first_ind1 + 1

            End If

            If first_ind1 >= pixels_curve1.Count - 1 Or second_ind1 >= pixels_curve1.Count - 1 Then
                to_stop1 = 1
            End If
        End While


        Dim dict_cords_to_remove1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        Dim i1 As Integer

        For i1 = 0 To dict_holes1.Keys.Count - 1
            Dim start_ind2 As Integer = dict_holes1.Keys(i1)
            Dim end_ind2 As Integer = dict_holes1(dict_holes1.Keys(i1))("second_ind")

            Dim i2 As Integer

            For i2 = start_ind2 + 1 To end_ind2 - 1
                dict_cords_to_remove1(pixels_curve1(i2)) = 1
            Next
        Next

        For i1 = pixels_curve1.Count - 1 To 0 Step -1
            If dict_cords_to_remove1.ContainsKey(pixels_curve1(i1)) = True Then
                pixels_curve1.RemoveAt(i1)
            End If
        Next


        Return pixels_curve1
        Dim path2 As String = CGlobals1.global_path1 + "sobel_pics1\res_lens3.txt"
        save_2d_pixels_arr1(path2, pixels_curve1)
    End Function


    Public Function rgb_to_monochrome1(bmp1 As Bitmap)
        Dim x1 As Integer
        Dim y1 As Integer
        Dim bmp2 As Bitmap = bmp1.Clone()
        For x1 = 0 To bmp1.Width - 1
            For y1 = 0 To bmp1.Height - 1
                Dim color1 As Color = bmp1.GetPixel(x1, y1)
                Dim color2 As Integer = (0.3 * color1.R + 0.59 * color1.G + 0.11 * color1.B)
                If color2 <> 255 Then
                    Dim d1 As Integer = 2
                End If
                bmp2.SetPixel(x1, y1, Color.FromArgb(color2, color2, color2))
            Next

        Next

        Return bmp2
        '(0.3* color.R + 0.59 * color.G + 0.11 * color.B);
    End Function


    Public Function compute_max_diff_from_neighboors1(bmp1 As Bitmap)
        Dim x1 As Integer
        Dim y1 As Integer
        Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(bmp1.Width, bmp1.Height, Color.FromArgb(255, 255, 255))
        For x1 = 1 To bmp1.Width - 2
            For y1 = 1 To bmp1.Height - 2
                Dim color1 As Color = bmp1.GetPixel(x1, y1)
                Dim color_val1 As Double = (0.3 * color1.R + 0.59 * color1.G + 0.11 * color1.B)

                If color_val1 <> 255 Then
                    Dim d2 As Integer = 2
                End If
                Dim x2 As Integer
                Dim y2 As Integer
                Dim max_diff1 As Double = 0
                For x2 = -1 To 1
                    For y2 = -1 To 1
                        If x2 <> 0 Or y2 <> 0 Then
                            Dim color2 As Color = bmp1.GetPixel(x1 + x2, y1 + y2)
                            Dim color_val2 As Double = (0.3 * color2.R + 0.59 * color2.G + 0.11 * color2.B)
                            If Math.Abs(color_val1 - color_val2) > max_diff1 Then
                                max_diff1 = Math.Abs(color_val1 - color_val2)
                            End If
                        End If
                    Next
                Next

                Dim color3 As Integer = max_diff1

                bmp2.SetPixel(x1, y1, Color.FromArgb(color3, color3, color3))
            Next

        Next

        Return bmp2
    End Function


    Public Function find_max_diff_start_pixel1(bmp1 As Bitmap, org_bmp1 As Bitmap, org_mono_bmp1 As Bitmap)


        CGlobals1.delete_files1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_max_diff\", "*.*")

        Dim bmp2 As Bitmap = CGlobals1.create_fill_bitmap(bmp1.Width, bmp1.Height, Color.FromArgb(0, 0, 0))
        Dim bmp3 As Bitmap = CGlobals1.create_fill_bitmap(bmp1.Width, bmp1.Height, Color.FromArgb(255, 255, 255))
        Dim bmp4 As Bitmap = CGlobals1.create_fill_bitmap(bmp1.Width, bmp1.Height, Color.FromArgb(255, 255, 255))
        Dim start_x1 As Integer = bmp1.Width / 2
        Dim start_y1 As Integer = bmp1.Height - 5


        Dim added_first_cord1 As String = ""

        'start_x1 = 90
        start_y1 = 5
        'start_x1 = 1200
        'start_y1 = 1000
        Dim max_x1 As Integer = -1
        Dim min_x1 As Integer = -1
        Dim max_y1 As Integer = -1
        Dim min_y1 As Integer = -1


        Dim min_dist_2_cords1 As Double = 9999
        Dim min_dist_2_cords2 As Double = 9999


        Dim dict_cords1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)

        Dim to_stop1 As Integer = 0
        While to_stop1 = 0
            dict_cords1(start_x1.ToString() + "," + start_y1.ToString()) = 1
            'bmp2.SetPixel(start_x1, start_y1, Color.FromArgb(255, 255, 255))
            Dim x1 As Integer
            Dim y1 As Integer
            Dim color1 As Integer = bmp1.GetPixel(x1, y1).R
            Dim last_max_val1 As Double = color1
            Dim new_x1 As Integer = 0
            Dim new_y1 As Integer = 1
            For x1 = -1 To 1
                For y1 = -1 To 1
                    If x1 <> 0 And y1 <> 0 Then
                        Dim color2 As Integer = bmp1.GetPixel(start_x1 + x1, start_y1 + y1).R

                        If last_max_val1 < color2 Then
                            new_x1 = x1
                            new_y1 = y1
                            last_max_val1 = color2
                        End If
                    End If
                Next

            Next
            start_x1 += new_x1
            start_y1 += new_y1

            If dict_cords1.ContainsKey(start_x1.ToString() + "," + start_y1.ToString()) = True Then
                to_stop1 = 1
            End If
        End While

        Dim currect_color_cord1 As Integer = 1
        Dim dict_first_cord1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim dict_second_cord1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim dict_cords2 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim dict_colors1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        Dim dict_colors_cords1 As Dictionary(Of String, Integer) = New Dictionary(Of String, Integer)
        dict_cords2(start_x1.ToString() + "," + start_y1.ToString()) = 1
        dict_colors_cords1(start_x1.ToString() + "," + start_y1.ToString()) = currect_color_cord1


        dict_colors1(start_x1.ToString() + "," + start_y1.ToString()) = org_mono_bmp1.GetPixel(start_x1, start_y1).R
        bmp3.SetPixel(start_x1, start_y1, org_bmp1.GetPixel(start_x1, start_y1))
        bmp2.SetPixel(start_x1, start_y1, Color.FromArgb(255, 255, 255))

        min_x1 = start_x1
        max_x1 = start_x1
        min_y1 = start_y1
        max_y1 = start_y1



        org_bmp1.SetPixel(start_x1, start_y1, Color.FromArgb(220, 10, 40))
        Dim to_stop2 As Integer = 0

        Dim last_cord1(2) As Integer
        Dim last_cord2(2) As Integer

        last_cord1(0) = -1
        last_cord1(1) = -1

        last_cord2(0) = -1
        last_cord2(1) = -1

        While to_stop2 = 0
            Dim key_ind1 As Integer

            Dim max_diff1 As Double = 0
            Dim new_cord_x1 As Integer = 0
            Dim new_cord_y1 As Integer = 0
            For key_ind1 = 0 To dict_cords2.Keys.Count - 1
                Dim cord_x1 As Integer = Integer.Parse(dict_cords2.Keys(key_ind1).ToString().Split(",")(0))
                Dim cord_y1 As Integer = Integer.Parse(dict_cords2.Keys(key_ind1).ToString().Split(",")(1))

                Dim x3 As Integer
                Dim y3 As Integer

                For x3 = -1 To 1
                    For y3 = -1 To 1

                        If x3 <> 0 And y3 <> 0 And dict_cords2.ContainsKey((cord_x1 + x3).ToString() + "," + (cord_y1 + y3).ToString()) = False Then
                            Dim x4 As Integer
                            Dim y4 As Integer
                            Dim count_neighboors1 As Integer = 0
                            For x4 = -3 To 3
                                For y4 = -3 To 3
                                    If x4 <> 0 And y4 <> 0 Then
                                        If dict_cords2.ContainsKey((cord_x1 + x3 + x4).ToString() + "," + (cord_y1 + y3 + y4).ToString()) = True Then
                                            count_neighboors1 += 1
                                        End If

                                    End If
                                Next

                            Next

                            Dim color3 As Integer = bmp1.GetPixel(cord_x1 + x3, cord_y1 + y3).R
                            If max_diff1 <= color3 And count_neighboors1 <= 5 Then
                                max_diff1 = color3
                                new_cord_x1 = cord_x1 + x3
                                new_cord_y1 = cord_y1 + y3
                            ElseIf max_diff1 <= color3 And count_neighboors1 > 5 Then
                                Dim d4 As Integer = 5
                            End If
                        ElseIf x3 <> 0 And y3 <> 0 And dict_cords2.ContainsKey((cord_x1 + x3).ToString() + "," + (cord_y1 + y3).ToString()) = True Then
                            'Dim d3 As Integer = 1
                        End If
                    Next

                Next
            Next
            If dict_cords2.ContainsKey(new_cord_x1.ToString() + "," + new_cord_y1.ToString()) = True Then
                Dim d1 As Integer = 1
            End If
            dict_cords2(new_cord_x1.ToString() + "," + new_cord_y1.ToString()) = 1

            dict_colors_cords1(start_x1.ToString() + "," + start_y1.ToString()) = 1

            If min_x1 > new_cord_x1 Then
                min_x1 = new_cord_x1
            End If


            If max_x1 < new_cord_x1 Then
                max_x1 = new_cord_x1
            End If


            If min_y1 > new_cord_y1 Then
                min_y1 = new_cord_y1
            End If


            If max_y1 < new_cord_y1 Then
                max_y1 = new_cord_y1
            End If

            Dim connect_to_color As Integer = 1

            bmp2.SetPixel(new_cord_x1, new_cord_y1, Color.FromArgb(255, 255, 255))




            bmp3.SetPixel(new_cord_x1, new_cord_y1, org_bmp1.GetPixel(new_cord_x1, new_cord_y1))

            org_bmp1.SetPixel(new_cord_x1, new_cord_y1, Color.FromArgb(220, 10, 40))
            'dict_colors1(new_cord_x1.ToString() + "," + new_cord_x1.ToString()) = org_mono_bmp1.GetPixel(new_cord_x1, new_cord_x1).R



            Dim x_cord_ind2 As Integer
            Dim y_cord_ind2 As Integer
            Dim count_neighboors2 As Integer = 0
            For x_cord_ind2 = -1 To 1
                For y_cord_ind2 = -1 To 1
                    If dict_cords2.ContainsKey((new_cord_x1 + x_cord_ind2).ToString() + "," + (new_cord_y1 + y_cord_ind2).ToString()) = True Then
                        count_neighboors2 += 1

                    End If
                Next

            Next


            'If dict_cords2.Count = 31 Then


            If dict_cords2.Count > 30 Then


                If added_first_cord1 = "" And count_neighboors2 <= 2 Then
                    connect_to_color = 2
                    dict_colors_cords1(new_cord_x1.ToString() + "," + new_cord_y1.ToString()) = 2
                    added_first_cord1 = "yes"
                ElseIf added_first_cord1 = "yes" And count_neighboors2 <= 2 Then
                    Dim x_cord_ind1 As Integer
                    Dim y_cord_ind1 As Integer

                    For x_cord_ind1 = -4 To 4
                        For y_cord_ind1 = -4 To 4
                            If dict_colors_cords1.ContainsKey((new_cord_x1 + x_cord_ind1).ToString() + "," + (new_cord_y1 + y_cord_ind1).ToString()) = True Then
                                If dict_colors_cords1((new_cord_x1 + x_cord_ind1).ToString() + "," + (new_cord_y1 + y_cord_ind1).ToString()) = 2 Then
                                    connect_to_color = 2
                                End If

                            End If
                        Next

                    Next

                    If connect_to_color = 1 Then
                        For x_cord_ind1 = -4 To 4
                            For y_cord_ind1 = -4 To 4
                                If dict_colors_cords1.ContainsKey((new_cord_x1 + x_cord_ind1).ToString() + "," + (new_cord_y1 + y_cord_ind1).ToString()) = True Then

                                    If dict_colors_cords1((new_cord_x1 + x_cord_ind1).ToString() + "," + (new_cord_y1 + y_cord_ind1).ToString()) = 3 Then
                                        connect_to_color = 3
                                    End If
                                End If
                            Next

                        Next

                    End If


                    If connect_to_color = 1 Then
                        connect_to_color = 3
                    End If
                    dict_colors_cords1(new_cord_x1.ToString() + "," + new_cord_y1.ToString()) = connect_to_color
                Else

                    dict_colors_cords1(new_cord_x1.ToString() + "," + new_cord_y1.ToString()) = 1


                End If


            End If

            If connect_to_color = 1 Then
                bmp2.SetPixel(new_cord_x1, new_cord_y1, Color.FromArgb(255, 255, 255))
            ElseIf connect_to_color = 2 Then
                bmp2.SetPixel(new_cord_x1, new_cord_y1, Color.FromArgb(255, 20, 20))
                If last_cord1(0) = -1 Then
                    last_cord1(0) = new_cord_x1
                    last_cord1(1) = new_cord_y1
                Else
                    If Math.Abs(last_cord1(0) - new_cord_x1) < 4 And Math.Abs(last_cord1(1) - new_cord_y1) < 4 Then
                        last_cord1(0) = new_cord_x1
                        last_cord1(1) = new_cord_y1
                    End If
                End If



                Dim cord_x4 As Integer
                Dim cord_y4 As Integer

                For cord_x4 = -10 To 10
                    For cord_y4 = -10 To 10
                        If dict_second_cord1.ContainsKey((new_cord_x1 + cord_x4).ToString() + "," + (new_cord_y1 + cord_y4).ToString()) = True Then
                            Dim connect1 As Integer = 1

                            Dim dist2 As Double = get_dist_between_2_cords_xy1(New Integer() {0, 0}, New Integer() {cord_x4, cord_y4})

                            If min_dist_2_cords1 = 9999 Then
                                min_dist_2_cords1 = dist2
                            ElseIf min_dist_2_cords1 > dist2 Then
                                min_dist_2_cords1 = dist2
                            End If
                        End If
                    Next

                Next


                dict_first_cord1(new_cord_x1.ToString() + "," + new_cord_y1.ToString()) = 1
            ElseIf connect_to_color = 3 Then
                bmp2.SetPixel(new_cord_x1, new_cord_y1, Color.FromArgb(20, 255, 20))
                If last_cord2(0) = -1 Then
                    last_cord2(0) = new_cord_x1
                    last_cord2(1) = new_cord_y1
                Else
                    If Math.Abs(last_cord2(0) - new_cord_x1) < 4 And Math.Abs(last_cord2(1) - new_cord_y1) < 4 Then
                        last_cord2(0) = new_cord_x1
                        last_cord2(1) = new_cord_y1
                    End If
                End If


                    Dim cord_x4 As Integer
                Dim cord_y4 As Integer

                For cord_x4 = -10 To 10
                    For cord_y4 = -10 To 10
                        If dict_first_cord1.ContainsKey((new_cord_x1 + cord_x4).ToString() + "," + (new_cord_y1 + cord_y4).ToString()) = True Then
                            Dim connect1 As Integer = 1

                            Dim dist2 As Double = get_dist_between_2_cords_xy1(New Integer() {0, 0}, New Integer() {cord_x4, cord_y4})

                            If min_dist_2_cords1 = 9999 Then
                                min_dist_2_cords1 = dist2
                            ElseIf min_dist_2_cords1 > dist2 Then
                                min_dist_2_cords1 = dist2
                            End If
                        End If
                    Next

                Next

                dict_second_cord1(new_cord_x1.ToString() + "," + new_cord_y1.ToString()) = 1


                'dict_first_cord1(new_cord_x1.ToString() + "," + new_cord_y1.ToString()) = 1
            End If


            Dim dist3 As Double = get_dist_between_2_cords_xy1(last_cord1, last_cord2)

            If last_cord1(0) = -1 Or last_cord2(0) = -1 Then
            Else
                If min_dist_2_cords2 = 9999 Then
                    min_dist_2_cords2 = dist3
                ElseIf min_dist_2_cords2 > dist3 Then
                    min_dist_2_cords2 = dist3
                End If

            End If

            If dict_cords2.Count Mod 500 = 0 Or (dict_cords2.Count >= 30 And dict_cords2.Count < 50) Or min_dist_2_cords2 < 20 Then
                CGlobals1.create_folder1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_max_diff\")

                Dim i1 As Integer

                For i1 = 0 To dict_cords2.Count - 1
                    Dim cord_xy_str1 As String() = dict_cords2.Keys(i1).Split(",")
                    Dim x_cord1 As Integer = Integer.Parse(cord_xy_str1(0))
                    Dim y_cord1 As Integer = Integer.Parse(cord_xy_str1(1))

                    Dim x_ind1 As Integer
                    Dim y_ind1 As Integer

                    For x_ind1 = -1 To 1
                        For y_ind1 = -1 To 1


                            If dict_cords2.ContainsKey((x_cord1 + x_ind1).ToString() + "," + (y_cord1 + y_ind1).ToString()) = False Then
                                Dim x_ind2 As Integer
                                Dim y_ind2 As Integer
                                Dim count_neighboors1 As Integer = 0
                                For x_ind2 = -1 To 1
                                    For y_ind2 = -1 To 1
                                        If dict_cords2.ContainsKey((x_cord1 + x_ind1 + x_ind2).ToString() + "," + (y_cord1 + y_ind1 + y_ind2).ToString()) = True Then
                                            count_neighboors1 += 1
                                        End If


                                    Next

                                Next
                                If count_neighboors1 = 3 Or count_neighboors1 = 4 Then
                                    bmp2.SetPixel(x_cord1 + x_ind1, y_cord1 + y_ind1, Color.FromArgb(255, 255, 255))
                                    dict_colors1((x_cord1 + x_ind1).ToString() + "," + (y_cord1 + y_ind1).ToString()) = org_mono_bmp1.GetPixel(x_cord1 + x_ind1, y_cord1 + y_ind1).R
                                End If
                            End If




                        Next

                    Next

                Next

                bmp2.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_max_diff\curve_max_diff3_" + dict_cords2.Count.ToString() + ".jpg")
                bmp3.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_max_diff\org_curve_max_diff2_" + dict_cords2.Count.ToString() + ".jpg")

                org_bmp1.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_max_diff\org_bmp2_" + dict_cords2.Count.ToString() + ".jpg")

                Dim bmp2c As Bitmap = CGlobals1.copy_bitmap1(bmp2)

                If dict_cords2.Count Mod 100 = 0 Then
                    Dim x_cord3 As Integer
                    Dim y_cord3 As Integer

                    For x_cord3 = -3 To 3
                        For y_cord3 = -3 To 3

                            If (last_cord1(0) + x_cord3) > 0 And (last_cord1(0) + x_cord3) < bmp2c.Width Then
                                If (last_cord1(1) + y_cord3) > 0 And (last_cord1(1) + y_cord3) < bmp2c.Height Then
                                    Try
                                        bmp2c.SetPixel(last_cord1(0) + x_cord3, last_cord1(1) + y_cord3, Color.FromArgb(200, 30, 100))
                                    Catch ex As Exception

                                    End Try

                                    Try
                                        bmp2c.SetPixel(last_cord2(0) + x_cord3, last_cord2(1) + y_cord3, Color.FromArgb(30, 200, 100))
                                    Catch ex As Exception

                                    End Try


                                End If

                            End If

                        Next

                    Next

                    bmp2c.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_max_diff\cords_1_2_" + dict_cords2.Count.ToString() + ".jpg")
                End If


                If False Then





                    Dim sorted = From pair In dict_colors1
                                 Order By pair.Value


                    dict_colors1 = sorted.ToDictionary(Function(p) p.Key, Function(p) p.Value)
                    'Dim sortedDictionary = sorted
                    'Dim dict_colors2 As Dictionary(Of String, Integer)
                    'dict_colors1 = sortedDictionary

                    Dim i2 As Integer


                    For i2 = 0 To dict_colors1.Count / 3
                        Dim cord_xy_str1 As String() = dict_colors1.Keys(i2).Split(",")
                        Dim cord1a As Integer = Integer.Parse(cord_xy_str1(0))
                        Dim cord2a As Integer = Integer.Parse(cord_xy_str1(1))
                        bmp4.SetPixel(cord1a, cord2a, Color.FromArgb(0, 0, 0))
                        bmp4.Save(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_max_diff\colors1_" + dict_cords2.Count.ToString() + ".jpg")

                    Next

                End If
            End If


            If dict_cords2.Count > 10000 Then
                to_stop2 = 1
            End If
        End While
        Return bmp2

    End Function

    Public Function remove_middle_pixel_in_diagonal1(pixel_arr1 As ArrayList)

        Dim new_pixel_arr1 As ArrayList = pixel_arr1.Clone()
        Dim ind1 As Integer = 1

        Dim to_stop1 As Integer = 0

        While to_stop1 = 0
            Dim cord_xy1 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pixel_arr1, ind1 - 1)
            Dim cord_xy2 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pixel_arr1, ind1)
            Dim cord_xy3 As Double() = CGlobals1.get_double_cord_xy_in_pixels_arr2(pixel_arr1, ind1 + 1)

            If (CType(cord_xy1(1), Integer) = CType(cord_xy2(1), Integer) And CType(cord_xy2(0), Integer) = CType(cord_xy3(0), Integer)) Or (CType(cord_xy1(0), Integer) = CType(cord_xy2(0), Integer) And CType(cord_xy2(1), Integer) = CType(cord_xy3(1), Integer)) Then
                pixel_arr1.RemoveAt(ind1)
            Else
                ind1 = ind1 + 1
            End If

            If ind1 >= pixel_arr1.Count - 2 Then
                to_stop1 = 1
            End If

        End While

        Return new_pixel_arr1

    End Function
End Class
