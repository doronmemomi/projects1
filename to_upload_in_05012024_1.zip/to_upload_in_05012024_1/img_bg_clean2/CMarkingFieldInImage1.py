
from ArrayList import ArrayList
from vec_3d1 import vec_3d1
from point_3d1 import point_3d1
from bitmap import Bitmap
from Dictionary import Dictionary

from StringBuilder import StringBuilder
from CFile1 import CFile1

import math,os


class CMarkingFieldInImage1:
    
    
    dir_arr1 = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]]
    dir_arr1_rev  = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]]
    dir_arr2  = [[-1, -1], [0, -1], [1, -1], [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0]]

    
    def __init__(self):
        
        self.d1=1
        self.bmp1=Bitmap()
        self.bmp_current_sobel= Bitmap()
        
        self.color_of_sobel=(255,255,255,0)



    def create_pixel_arr_line_from_2_2d_points(start_x1:float, start_y1:float, end_x1:float, end_y1:float):
        pixel_arr1:ArrayList = ArrayList()

        start_x2:float = start_x1
        start_y2:float = start_y1
        end_x2:float = end_x1
        end_y2:float = end_y1

        if start_x1 > end_x1:
            start_x2 = end_x1
            start_y2 = end_y1
            end_x2 = start_x1
            end_y2 = start_y1

        dir_y1:float = 1
        if start_y2 > end_y2:
            dir_y1 = -1

        right_x1:float = end_x2
        right_y1:float = end_y2
        min_y1:float = min(start_y2, end_y2)
        max_y1:float = max(start_y2, end_y2)


        min_x1:float = min(start_x2, end_x2)
        max_x1:float = max(start_x2, end_x2)

        add_one1:int=1
        if (end_y1 - start_y1) < 0:
            add_one1 = -1

        add_one2:int = 1
        if (end_x1 - start_x1) < 0:
            add_one2 = -1

        add_one3:int = 1
        if (end_x1 - start_x1) < 0:
            add_one2 = -1

        add_one4:int = 1
        if (end_y1 - start_y1) < 0:
            add_one4 = -1

        add_one1 = 0
        add_one2 = 0
        add_one3 = 0
        add_one4 = 0
        m1:float = ((end_y1 - start_y1) + add_one1) / ((end_x1 - start_x1) + add_one2)
        m2:float = ((end_x1 - start_x1) + add_one3) / ((end_y1 - start_y1) + add_one4)
        add_to_start1:bool = False

        if start_x2 == end_x1:
            if start_x2 != start_x1:

                add_to_start1 = True

        if start_x2 == max_x1:
            m2 = -abs(m2)

        else:
            m2 = abs(m2)

        not_to_stop1:bool=True


        x2_val1a:int = math.floor(start_x2)
        y2_val1a:int = math.floor(start_y2)
        x2_val1a = round(start_x2)
        y2_val1a = round(start_y2)
        pixel_arr1.Add(str(x2_val1a) + "," + str(y2_val1a))

        while not_to_stop1:
            if abs(m1) <= 1:
                start_x2 += 1
                start_y2 += m1
            else:
                start_x2 += m2
                start_y2 += dir_y1

            
            if start_x2 > max_x1 or start_x2 < min_x1 or start_y2 > max_y1 or start_y2 < min_y1:

                if add_to_start1:
                    if pixel_arr1[0] != (str(start_x1) + "," + str(start_y1)):
                        pixel_arr1.Insert(0, str(start_x1) + "," + str(start_y1))

                    if pixel_arr1[pixel_arr1.count - 1] != (str(end_x1) + "," + str(end_y1)):
                        pixel_arr1.Add(str(end_x1) + "," + str(end_y1))


                not_to_stop1 = False
            else:
                x2_val1:int = math.floor(start_x2)
                y2_val1:int = math.floor(start_y2)
                if add_to_start1:
                    pixel_arr1.Insert(0, str(x2_val1) + "," + str(y2_val1))
                else:

                    pixel_arr1.Add(str(x2_val1) + "," + str(y2_val1))


        return pixel_arr1





    def set_pixels_arr_and_save2(self,pixels_arr1:ArrayList, bmp1:Bitmap, color1, path1:str):
        copy_bmp1:Bitmap = bmp1.clone()
        self.set_pixel_arr_on_bmp2(pixels_arr1, copy_bmp1, color1)
        copy_bmp1.SaveAsave(path1)

        return copy_bmp1



    def find_start_point1(self,x_start1:int, y_start1:int):
        x_start2 = x_start1
        y_start2 = y_start1

        dir1:int = 1
        try:

            while (self.bmp1.GetPixel(x_start2, y_start2)[0] != self.color_of_sobel[0] or \
                    self.bmp1.GetPixel(x_start2, y_start2)[1] != self.color_of_sobel[1] or \
                    self.bmp1.GetPixel(x_start2, y_start2)[2] != self.color_of_sobel[1]) and y_start2 < self.bmp1.height - 1:
                y_start2 += dir1


        except:
            y_start2 = self.bmp1.height - 10
            dir1 = -1
            while (self.bmp1.GetPixel(x_start2, y_start2)[0] !=self.color_of_sobel[0] or \
                self.bmp1.GetPixel(x_start2, y_start2)[1] != self.color_of_sobel[1] or \
                self.bmp1.GetPixel(x_start2, y_start2)[2] != self.color_of_sobel[2]) and y_start2 < self.bmp1.Height - 1:
                y_start2 += dir1




        return (x_start2, y_start2)








        
            
    def update_path1(self):
        from CGlobals1 import CGlobals1
        config_folder1:str=CFile1.read_all_file_text("..\\config_folder1.txt")
        CGlobals1.global_path1 = CFile1.read_all_file_text(config_folder1+"\\root_path1.txt")
        self.file_name1 = CFile1.read_all_file_text(config_folder1+"\\file_path1.txt")

    
    def init1(self):
        self.d1=1
        


    def update_current_sobel(self,new_sobel_ind_val:int):
        from CGlobals1 import CGlobals1
        
        if (self.cur_sobel_ind_val1 > new_sobel_ind_val):
            for sobel_key_ind in range(new_sobel_ind_val , self.cur_sobel_ind_val1+1):
                if sobel_key_ind < CGlobals1.dict_sobel_pixels.count:

                    sobel_key_val:int = CGlobals1.dict_sobel_pixels.keys[sobel_key_ind]
                    pixel_arr1:ArrayList = CGlobals1.dict_sobel_pixels[sobel_key_val]

                    for i1 in range(0 , pixel_arr1.count):
                        x1:int = int(str(pixel_arr1[i1].split(",")[0]))
                        y1:int = int(str(pixel_arr1[i1].split(",")[1]))
                        self.bmp_current_sobel.SetPixel(x1, y1, (255, 255, 255,0))


        else:
            for sobel_key_ind in range(self.cur_sobel_ind_val1 , new_sobel_ind_val+1):
                if sobel_key_ind < CGlobals1.dict_sobel_pixels.count:

                    sobel_key_val:int = CGlobals1.dict_sobel_pixels.keys[sobel_key_ind]
                    pixel_arr1:ArrayList = CGlobals1.dict_sobel_pixels[sobel_key_val]

                    for i1 in range( 0 , pixel_arr1.count):
                        x1:int = int(str(pixel_arr1[i1].split(",")[0]))
                        y1:int = int(str(pixel_arr1[i1].split(",")[1]))
                        self.bmp_current_sobel.SetPixel(x1, y1, (0, 0, 0,0))


        self.cur_sobel_ind_val1 = new_sobel_ind_val







    def add_dec_sobel_ind(self,dir1:str, sobel_factor1:int):

        if dir1 == "add1":
            new_cur_sobel_ind_val1:int = self.cur_sobel_ind_val1 + sobel_factor1
            self.update_current_sobel(new_cur_sobel_ind_val1)


        if dir1 == "dec1":
            new_cur_sobel_ind_val1:int = self.cur_sobel_ind_val1 - sobel_factor1
            self.update_current_sobel(new_cur_sobel_ind_val1)
        

    def create_cache_of_sobel_files(self,path_of_cache1:str):
        from CGlobals1 import CGlobals1
        
        for x1 in range(0 , self.bmp_current_sobel.width ):
            for y1 in range( 0 , self.bmp_current_sobel.height):
                self.bmp_current_sobel.SetPixel(x1, y1, (255, 255, 255,0))

        i1:int

        for i1 in range(0 , CGlobals1.dict_sobel_pixels.count - 5+1):
            self.add_dec_sobel_ind("add1", 1)
            #print("step2:(create sobel imgs)" + str((i1 / CGlobals1.dict_sobel_pixels.count * 100) + "        ") + "%")

            self.bmp_current_sobel.SaveAs(path_of_cache1 + "\\" + str(self.cur_sobel_ind_val1) + ".bmp")







    def crop_img_by_color(self,bmp1:Bitmap, color1):
        
        
        
        
        
        x1:int
        y1:int

        top1:int
        not_to_stop1:bool = True
        top1 = 0

        while not_to_stop1:

            for x1 in range (0 , bmp1.width):
                if bmp1.GetPixel(x1, top1)[0] != color1[0] or bmp1.GetPixel(x1, top1)[1] != color1[1] or bmp1.GetPixel(x1, top1)[2] != color1[2]:
                    not_to_stop1 = False


               
            if not_to_stop1:
                top1 += 1

        top1 -= 10

        bottom1:int
        
        not_to_stop1 = True
        bottom1 = bmp1.height - 1
        while not_to_stop1:

            for x1 in range (0 , bmp1.width ):
                if bmp1.GetPixel(x1, bottom1)[0] != color1[0] or \
                   bmp1.GetPixel(x1, bottom1)[1] != color1[1] or \
                   bmp1.GetPixel(x1, bottom1)[2] != color1[2]:
                   not_to_stop1 = False


            
            if not_to_stop1:
                bottom1 -= 1

        bottom1 += 10




        to_stop1 = 0
        left1:int = 0

        while not_to_stop1:

            for y1 in range (0 , bmp1.height):
                if bmp1.GetPixel(left1, y1)[0] != color1[0] or \
                   bmp1.GetPixel(left1, y1)[1] != color1[1] or \
                   bmp1.GetPixel(left1, y1)[2] != color1[2]:
                    not_to_stop1 = False


            if not_to_stop1:
                left1 += 1

        left1 -= 10
        if left1 < 0:
            left1 = 0

        not_to_stop1 = True
        
        right1:int = bmp1.width - 1

        while not_to_stop1:

            for y1 in range( 0, bmp1.height ):
                if bmp1.GetPixel(right1, y1)[0] != color1[0] or \
                   bmp1.GetPixel(right1, y1)[1] != color1[1] or \
                   bmp1.GetPixel(right1, y1)[2] != color1[2]:
                    not_to_stop1 = False


            if not_to_stop1:
                right1 -= 1

        right1 += 10
        if right1 > bmp1.width - 1:
            right1 = bmp1.Width - 1


        width2:int=right1 - left1 + 1
        height2:int=bottom1 - top1 + 1
        bmp2:Bitmap = bmp1.clone()
        bmp2.crop((left1,top1,right1,bottom1))
        
        

        return bmp2
    






    def find_start_point_by_line1(self,bmp1:Bitmap, line_of_pxls_arr1:ArrayList, start_ind1:int = -1):
        from CGlobals1 import CGlobals1
        
        copy_bmp1:Bitmap = bmp1.clone()

        i1:int=0

        if start_ind1 != -1:
            i1 = start_ind1

        xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)

        while xy_cord1[0] >= copy_bmp1.width - 3 or xy_cord1[1] >= copy_bmp1.height - 3 or xy_cord1[0] <= 3 or xy_cord1[1] <= 3:

            i1 += 1
            xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)



        while self.compare_colors1(copy_bmp1.GetPixel(xy_cord1[0], xy_cord1[1]), self.color_of_sobel) == 1 and xy_cord1[1] < copy_bmp1.height - 1 and xy_cord1[0] < copy_bmp1.width - 1:
            i1 += 1
            xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)

        


        while (copy_bmp1.GetPixel(xy_cord1[0], xy_cord1[1])[0] != self.color_of_sobel[0] or  copy_bmp1.GetPixel(xy_cord1[0], xy_cord1[1])[1] != self.color_of_sobel[1] or copy_bmp1.GetPixel(xy_cord1[0], xy_cord1[1])[2] != self.color_of_sobel[2]) and xy_cord1[1] < copy_bmp1.height - 1 and xy_cord1[0] < copy_bmp1.width - 1:
            i1 += 1
            xy_cord1 = CGlobals1.get_cord_xy_in_pixels_arr1(line_of_pxls_arr1, i1)



        return {xy_cord1[0], xy_cord1[1], i1}


    def find_max_sobel_length3(self,start_x1:int, start_y1:int):
        from CGlobals1 import CGlobals1
        dict_res1:Dictionary=None

        if self.cur_sobel_ind_val1 >= CGlobals1.dict_sobel_pixels.count - 5:
            return dict_res1




        x_start2 = start_x1
        y_start2 = start_y1

        dict_result1:Dictionary = Dictionary()
        if CGlobals1.debug_mode_sobel:
            self.bmp_current_sobel.SaveAsve(CGlobals1.global_path1 + "\sobel_pics1\to_find_line1_" + CGlobals1.step_num1.ToString() + ".jpg")

        dict_res1 = self.next_pixels_loop3(self.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1, None)




        dict_res2:Dictionary = self.next_pixels_loop3(self.bmp_current_sobel, x_start2, y_start2, CGlobals1.dir_arr1_rev, None)

        dict_result1["pixels_around_sobel_arr1"] = dict_res1
        dict_result1["pixels_around_sobel_arr1_rev"] = dict_res2



        return dict_result1






    def remove_around_object1(self,bmp1:Bitmap, bg_color1):
        
        from CGlobals1 import CGlobals1
        
        bmp2:Bitmap = bmp1.clone()


        for x1 in range(1 , bmp1.width() - 1):
            for y1 in range( 1 , bmp1.height() - 1):
                if CGlobals1.compare_colors1(bmp1.GetPixel(x1, y1), bg_color1) == 0:
                    set_bg1:int=0

                    
                    for cord_ind1 in range( 0 , 9+1):
                        if CGlobals1.compare_colors1(bmp1.GetPixel(x1 + CGlobals1.dir_arr1[cord_ind1, 0], y1 + CGlobals1.dir_arr1[cord_ind1, 1]), bg_color1) == 1:
                            set_bg1 = 1


                    if set_bg1 == 1:
                        bmp2.SetPixel(x1, y1, bg_color1)

        return bmp2




    def get_line_x_by_y1(self,m_line1:float, b_line1:float, y_line1:float):

        x1:float = (y_line1 - b_line1) / m_line1

        return x1

        
        
    def get_dist_between_2_cords_xy1(self,cord_xy1, cord_xy2):
        dist1:float = pow(pow(cord_xy1[0] - cord_xy2[0], 2) + pow(cord_xy1[1] - cord_xy2[1], 2), 0.5)
        return dist1
        
    
        
    
        
    
    
    def load_2d_pixels_arr1(self,path_of_file):
        str_pnts_arr1:str=self.read_all_file_text(path_of_file)
        str_pnds_cord_2d=str_pnts_arr1.split("#")
        
        arr_2d_points=ArrayList()
        
        for i1 in range(len(str_pnds_cord_2d)):
            if len(str(str_pnds_cord_2d[i1])) > 2:
                x1=int(str(str_pnds_cord_2d[i1]).split(",")[0])
                y1=int(str(str_pnds_cord_2d[i1]).split(",")[1])
                arr_2d_points.Add(str(x1) + "," + str(y1))
        
        
        
        return arr_2d_points
    
    
    
    
    
    def rotate_2d_pixels_arr(self,pixels_arr1:ArrayList, arbitrary_3d_axis:vec_3d1, rot_angle1):

        new_2d_pixels_arr1:ArrayList = ArrayList()

        for i1 in range(0,pixels_arr1.count ):
            
            point_3d_obj1:point_3d1 = point_3d1(float(str(pixels_arr1[i1].split(",")[0])), float(str(pixels_arr1[i1].split(",")[1])), 0)

            if len(pixels_arr1[i1].split(",")) == 3:
                point_3d_obj1 = point_3d1(float(str(pixels_arr1[i1].split(",")[0])), float(str(pixels_arr1[i1].split(",")[1])), float(pixels_arr1[i1].split(",")[2]))


            self.rotate_around_arbitrary_axis(arbitrary_3d_axis, point_3d_obj1, rot_angle1)
            if len(pixels_arr1[i1].split(",")) == 3:
                new_2d_pixels_arr1.Add(str(point_3d_obj1.x1) + "," + str(point_3d_obj1.y1) + "," + str(point_3d_obj1.z1))
            else:
                new_2d_pixels_arr1.Add(str(point_3d_obj1.x1) + "," + str(point_3d_obj1.y1))



        return new_2d_pixels_arr1
    
    
    
    
    
    
    
    def rotate_around_arbitrary_axis(self,in_vec_3d_1:vec_3d1, in_rotate_p1:point_3d1, rot_deg_around_axis1:float):
        delta_x1 = float(in_vec_3d_1.p1.x1)
        delta_y1 = float(in_vec_3d_1.p1.y1)
        delta_z1 = float(in_vec_3d_1.p1.z1)

        vec_3d_1:vec_3d1 = in_vec_3d_1.clone1()
        rotate_p1:point_3d1 = in_rotate_p1.clone1()

        vec_3d_1.p1.x1 -= float(delta_x1)
        vec_3d_1.p1.y1 -= float(delta_y1)
        vec_3d_1.p1.z1 -= float(delta_z1)


        vec_3d_1.p2.x1 -= float(delta_x1)
        vec_3d_1.p2.y1 -= float(delta_y1)
        vec_3d_1.p2.z1 -= float(delta_z1)

        rotate_p1.x1 -= float(delta_x1)
        rotate_p1.y1 -= float(delta_y1)
        rotate_p1.z1 -= float(delta_z1)


        rot_deg1 = math.atan(vec_3d_1.p2.y1 / vec_3d_1.p2.z1) / (math.pi / 180.0)
        
        if vec_3d_1.p2.z1 == 0:
            rot_deg1 = 90

        vec_3d_1.p1.rotate_x1(rot_deg1)
        vec_3d_1.p2.rotate_x1(rot_deg1)
        rotate_p1.rotate_x1(rot_deg1)





        rot_deg2 = -math.atan(float(vec_3d_1.p2.x1) / float(vec_3d_1.p2.z1)) / (math.pi / 180.0)
        if vec_3d_1.p2.z1 == 0:
            rot_deg2 = 90
   
    

        vec_3d_1.p1.rotate_y1(rot_deg2)
        vec_3d_1.p2.rotate_y1(rot_deg2)
        rotate_p1.rotate_y1(rot_deg2)


        vec_3d_1.p1.rotate_z1(rot_deg_around_axis1)
        vec_3d_1.p2.rotate_z1(rot_deg_around_axis1)
        rotate_p1.rotate_z1(rot_deg_around_axis1)


        vec_3d_1.p1.rotate_y1(-rot_deg2)
        vec_3d_1.p2.rotate_y1(-rot_deg2)
        rotate_p1.rotate_y1(-rot_deg2)

        vec_3d_1.p1.rotate_x1(-rot_deg1)
        vec_3d_1.p2.rotate_x1(-rot_deg1)
        rotate_p1.rotate_x1(-rot_deg1)



        vec_3d_1.p1.x1 += float(delta_x1)
        vec_3d_1.p1.y1 += float(delta_y1)
        vec_3d_1.p1.z1 += float(delta_z1)


        vec_3d_1.p2.x1 += float(delta_x1)
        vec_3d_1.p2.y1 += float(delta_y1)
        vec_3d_1.p2.z1 += float(delta_z1)

        rotate_p1.x1 += float(delta_x1)
        rotate_p1.y1 += float(delta_y1)
        rotate_p1.z1 += float(delta_z1)

        in_rotate_p1.x1 = float(rotate_p1.x1)
        in_rotate_p1.y1 = float(rotate_p1.y1)
        in_rotate_p1.z1 = float(rotate_p1.z1)


    
    
    
    def set_pixel_arr_on_bmp2(self,pixels_arr1:ArrayList, bmp1:Bitmap, color_to_set1):
        

        for i1 in range(0,pixels_arr1.count):
            try:
            


                x1 = float(pixels_arr1[i1].split(",")[0])
                y1 = float(pixels_arr1[i1].split(",")[1])
                if x1 >= 0 and x1 < bmp1.width() and y1 >= 0 and y1 < bmp1.height():
                    bmp1.SetPixel(x1, y1, color_to_set1)


            except:
                try:
                    x1 = float(pixels_arr1[i1].split(",")[0])
                    y1 = float(pixels_arr1[i1].split(",")[1])
                    if x1 >= 0 and x1 < bmp1.width() and y1 >= 0 and y1 < bmp1.height():
                        bmp1.SetPixel(x1, y1, color_to_set1)


                except:
                    dummy1=1






    def rgb_to_monochrome1(self,bmp1:Bitmap):
        
       
        bmp2:Bitmap = bmp1.clone()
        for x1 in range(0,bmp1.width):
            for y1 in range(0,bmp1.height):
                color1 = bmp1.GetPixel(x1, y1)
                color2 = (0.3 * color1[0] + 0.59 * color1[1] + 0.11 * color1[2])
                color2=int(color2)
                bmp2.SetPixel(x1, y1, (color2, color2, color2,0))

            ly1=y1
        return bmp2


    def get_mono_color1(self,bmp1:Bitmap, x1:int, y1:int):
        from CGlobals1 import CGlobals1

        key1:str = str(x1) + "," + str(y1)
        if CGlobals1.dict_mono_colors1.ContainsKey(key1):
            return CGlobals1.dict_mono_colors1[key1]
        
        
        color1 = bmp1.GetPixel(x1, y1)
        mono_color1:int = int(0.3 * color1[0] + 0.59 * color1[1] + 0.11 * color1[2])
        if mono_color1!= 255:
            d1=1
        CGlobals1.dict_mono_colors1[key1] = mono_color1
        return mono_color1

    
    
    
    
    def get_sobel_value1(self,bmp1:Bitmap, x1:int, y1:int):

        mat1  = [[0, 0, 0, 0, 0], [-1, -2, -4, -2, -1], [0, 0, 0, 0, 0], [1, 2, 4, 2, 1], [0, 0, 0, 0, 0]]
        total_sobel_val1:float = 0
        sobel_x1:int
        sobel_y1:int
        sobel_x1 = 0
        for x2 in range (x1 - 2,x1 + 2+1):
            sobel_y1 = 0

            for y2 in range (y1 - 2, y1 + 2+1):
                sobel_val1:float = mat1[sobel_x1][sobel_y1]

                mono_color1:float=self.get_mono_color1(bmp1, x2, y2)
                total_sobel_val1 += self.get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            
            sobel_x1 += 1

        return total_sobel_val1
    



    def get_sobel_value2(self,bmp1:Bitmap, x1:int, y1:int):
        mat1 = [[0, -1, 0, 1, 0], [0, -2, 0, 2, 0], [0, -4, 0, 4, 0], [0, -2, 0, 2, 0], [0, -1, 0, 1, 0]]
        total_sobel_val1:float = 0
        sobel_x1:int
        sobel_y1:int
        sobel_x1 = 0
        for x2 in range( x1 - 2, x1 + 2+1):
            sobel_y1 = 0

            for y2 in range (y1 - 2,y1 + 2+1):
                sobel_val1:float = mat1[sobel_x1][ sobel_y1]

                mono_color1:float=self.get_mono_color1(bmp1, x2, y2)
                total_sobel_val1 += self.get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            
            sobel_x1 += 1
        
        return total_sobel_val1



    def get_sobel_value3(self,bmp1:Bitmap, x1:int, y1:int):
        mat2 = [[0, -1, 0, 0, 0], [2, 0, -2, 0, 0], [0, 4, 0, -4, 0], [0, 0, 2, 0, -2], [0, 0, 0, 1, 0]]

        total_sobel_val1:float = 0
        sobel_x1:int
        sobel_y1:int
        sobel_x1 = 0
        for x2 in range (x1 - 2, x1 + 2+1):
            sobel_y1 = 0

            for y2 in range(y1 - 2, y1 + 2+1):
                sobel_val1:float = mat2[sobel_x1][ sobel_y1]

                total_sobel_val1 += self.get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            sobel_x1 += 1

        return total_sobel_val1



    def get_sobel_value4(self,bmp1:Bitmap, x1:int, y1:int):



        mat2 = [[0, 0, 0, -1, 0], [0, 0, -2, 0, 2], [0, -4, 0, 4, 0], [-2, 0, 2, 0, 0], [0, 1, 0, 0, 0]]


        total_sobel_val1:float = 0
        sobel_x1:int
        sobel_y1:int
        sobel_x1 = 0
        for x2 in range(x1 - 2 , x1 + 2+1):
            sobel_y1 = 0

            for y2 in range(y1 - 2 ,y1 + 2+1):
                sobel_val1:float = mat2[sobel_x1][ sobel_y1]

                mono_color1:float=self.get_mono_color1(bmp1, x2, y2)
                total_sobel_val1 += self.get_mono_color1(bmp1, x2, y2) * sobel_val1
                sobel_y1 += 1

            
            sobel_x1 += 1

        return total_sobel_val1


    


    def do_sobel_oparator1(self,bmp1:Bitmap):

        from CGlobals1 import CGlobals1
        
        dict_sobel_val1:Dictionary=Dictionary()
        dict_sobel_val2:Dictionary=Dictionary()
        dict_sobel_val_pixels1:Dictionary=Dictionary()
        
        bmp2:Bitmap =Bitmap(bmp1.width, bmp1.height)
        sobal_size1:int = 7
        ind1:int = 0
        max_sobel:float = 0
        sobel_vals_str1=StringBuilder()

        not_relevant1:int = 1

        for x1 in range(0 + sobal_size1,bmp1.width - sobal_size1):
            
            print("x1="+str(x1)+"/"+str(bmp1.width - sobal_size1))

            for y1 in range (0 + sobal_size1, bmp1.height - sobal_size1):


                sobel_val1a:float = -1
                sobel_val1b:float = -1
                sobel_val1:float = -1
                max_sobel_ind1 = 0
                sobel_val1_1:float = self.get_sobel_value1(bmp1, x1, y1)
                sobel_val1_2:float = self.get_sobel_value2(bmp1, x1, y1)
                sobel_val1_3:float = self.get_sobel_value3(bmp1, x1, y1)
                sobel_val1_4:float = self.get_sobel_value4(bmp1, x1, y1)

                if sobel_val1_1 < 0:
                    sobel_val1_1 = -sobel_val1_1

                if sobel_val1_2 < 0:
                    sobel_val1_2 = -sobel_val1_2

                if sobel_val1_3 < 0:
                    sobel_val1_3 = -sobel_val1_3
                
                
                if sobel_val1_1 < 0:
                    sobel_val1_4 = -sobel_val1_4


                max_sobel_val_1:float = sobel_val1_1
                max_sobel_ind1 = 1
                if sobel_val1_2 > max_sobel_val_1:
                    max_sobel_val_1 = sobel_val1_2
                    max_sobel_ind1 = 2


                if sobel_val1_3 > max_sobel_val_1:
                    max_sobel_val_1 = sobel_val1_3
                    max_sobel_ind1 = 3

                if sobel_val1_4 > max_sobel_val_1:
                    max_sobel_val_1 = sobel_val1_4
                    max_sobel_ind1 = 4

                sobel_val1 = max_sobel_val_1

                if max_sobel < sobel_val1:
                    max_sobel = sobel_val1

                if not_relevant1 == 1:
                    dict_sobel_val_pixels1[str(x1) + "," + str(y1)] = sobel_val1
                    dict_sobel_val1[ind1] = abs(sobel_val1)
                    dict_sobel_val2[abs(sobel_val1)] = 1



                pixels_arr1:ArrayList
                if CGlobals1.dict_sobel_pixels.ContainsKey(abs(sobel_val1)) == False:
                    CGlobals1.dict_sobel_pixels[abs(sobel_val1)] = ArrayList()
                pixels_arr1 = CGlobals1.dict_sobel_pixels[abs(sobel_val1)]
                pixels_arr1.Add(str(x1) + "," + str(y1))

                ind1 += 1

                sobel_vals_str1.Append(str(x1) + "," + str(y1) + "," + str(abs(sobel_val1)) + "#")




        path1:str = CGlobals1.global_path1 +CGlobals1.form_obj1.file_name1 + "_sobel_vals1.txt"
        
        CFile1.write_all_text_to_file( str(sobel_vals_str1),path1)
        sorted = dict_sobel_val1.sort_by_value()

        sortedDictionary = sorted

        s2 = 30

        count_sobel_ok_pixels1:int = 0
        for x1 in range(0 + sobal_size1 , bmp1.width - 1 - sobal_size1+1):
            for y1 in range(0 + sobal_size1 , bmp1.height - 1 - sobal_size1+1):
                sobel_val1:float = dict_sobel_val_pixels1[str(x1) + "," + str(y1)]
                if sobel_val1 > s2:
                    bmp2.SetPixel(x1, y1, (255, 255, 255))
                    count_sobel_ok_pixels1 += 1
                else:
                    bmp2.SetPixel(x1, y1, (0, 0, 0))

        percent_ok1:float = count_sobel_ok_pixels1 / (bmp1.width * bmp1.height)




        return bmp2




    def get_angle_between_2_3d_vectors(self,in_vec1:vec_3d1, in_vec2:vec_3d1):
        
        vec1:vec_3d1 = vec_3d1()
        vec2:vec_3d1 = vec_3d1()
        vec1.p2.x1 = in_vec1.p2.x1 - in_vec1.p1.x1
        vec1.p2.y1 = in_vec1.p2.y1 - in_vec1.p1.y1
        vec1.p2.z1 = in_vec1.p2.z1 - in_vec1.p1.z1


        vec2.p2.x1 = in_vec2.p2.x1 - in_vec2.p1.x1
        vec2.p2.y1 = in_vec2.p2.y1 - in_vec2.p1.y1
        vec2.p2.z1 = in_vec2.p2.z1 - in_vec2.p1.z1


        if vec1.p2.x1 == vec2.p2.x1 and vec1.p2.y1 == vec2.p2.y1 and vec1.p2.z1 == vec2.p2.z1:
            return 0

        dot_mul1:float = vec1.p2.x1 * vec2.p2.x1 + vec1.p2.y1 * vec2.p2.y1 + vec1.p2.z1 * vec2.p2.z1
        vec1_len1:float = pow(vec1.p2.x1 * vec1.p2.x1 + vec1.p2.y1 * vec1.p2.y1 + vec1.p2.z1 * vec1.p2.z1, 0.5)
        vec2_len1:float = pow(vec2.p2.x1 * vec2.p2.x1 + vec2.p2.y1 * vec2.p2.y1 + vec2.p2.z1 * vec2.p2.z1, 0.5)
        inv_cos1:float = 1
        try:
            inv_cos1 =math.acos(dot_mul1 / (vec1_len1 * vec2_len1))

        except:
            return None

        return inv_cos1 / (math.p1 / 180)





    def read_sobel_values1(self,path1:str):
        
        from CGlobals1 import CGlobals1
        
        sobel_vals_str:str = CFile1.read_all_file_text(path1)
        sobel_pixels_vals= sobel_vals_str.split("#")

        for i1 in range (0, len(sobel_pixels_vals)):
            print("i1="+str(i1)+"/"+str(len(sobel_pixels_vals)))
            vals_str1 = sobel_pixels_vals[i1].split(",")
            if len(vals_str1) >= 3:
                sobel_val1:int = int(vals_str1[2])
                x1:int = int(vals_str1[0])
                y1:int = int(vals_str1[1])
                pixels_arr1:ArrayList
                if CGlobals1.dict_sobel_pixels.ContainsKey(abs(sobel_val1))==False:
                    CGlobals1.dict_sobel_pixels[abs(sobel_val1)] = ArrayList()

                pixels_arr1 = CGlobals1.dict_sobel_pixels[abs(sobel_val1)]
                pixels_arr1.Add(str(x1) + "," + str(y1))






        sortedDictionary = CGlobals1.dict_sobel_pixels.sort_by_key()
        CGlobals1.dict_sobel_pixels = sortedDictionary
        key1:str = sortedDictionary.keys[sortedDictionary.count - 1]


        self.cur_sobel_ind_val1 = sortedDictionary.count
        self.cur_sobel_ind_val1 = 0
        CGlobals1.current_sobel_threshold = int(key1)
        CGlobals1.last_sobel_threshold = int(key1)
        self.bmp_current_sobel = Bitmap(self.bmp1.width, self.bmp1.height)


        for x1 in range(0, self.bmp_current_sobel.width ):
            for y1 in range(0, self.bmp_current_sobel.height ):
                self.bmp_current_sobel.SetPixel(x1, y1, (255, 255, 255))


    def get_max_diff_bmp1(self,bmp1:Bitmap):
        from CGlobals1 import CGlobals1
        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_max_diff1.jpg"
        if os.path.isfile(path1) == True:

            bmp5:Bitmap = Bitmap(path1)

            return bmp5
        


        bmp2:Bitmap = self.rgb_to_monochrome1(bmp1)
        bmp3:Bitmap = self.compute_max_diff_from_neighboors1(bmp2)
        bmp3.SaveAs(path1)

        return bmp3
    



    def compute_max_diff_from_neighboors1(self,bmp1:Bitmap):
        
        bmp2:Bitmap = Bitmap(bmp1.width(),bmp1.height(),(255,255,255,0))
        for x1 in range(1 ,bmp1.width()-2+1):
            for y1 in range(1 ,bmp1.height() - 2+1):
                color1 = bmp1.GetPixel(x1, y1)
                color_val1 = int(0.3 * color1[0] + 0.59 * color1[1] + 0.11 * color1[2])

                max_diff1:float = 0
                for x2 in range(-1 ,1+1):
                    for y2 in range(-1, 1+1):
                        if x2 != 0 or y2 != 0:
                            color2= bmp1.GetPixel(x1 + x2, y1 + y2)
                            color_val2:float = int(0.3 * color2[0] + 0.59 * color2[1] + 0.11 * color2[2])
                            if abs(color_val1 - color_val2) > max_diff1:
                                max_diff1 = abs(color_val1 - color_val2)

                color3:int = max_diff1

                bmp2.SetPixel(x1, y1, (color3, color3, color3))

        return bmp2
