import collections

class Dictionary:
    def __init__(self):
        self.dict={}
    
    def count(self):
        return len(self.dict.items)
    
    def __setitem__(self,key,value):
        self.dict[key]=value
        
    def __getitem__(self,key):
        return self.dict[key]
    
    def get_count(self):
        return len(self.dict)
    
    count=property(get_count,None) 
    
    
    def get_keys(self):
        return list(self.dict.keys())
    
    keys=property(get_keys,None) 
    def sort_by_key(self):
        sorted_dict = dict(sorted(self.dict.items()))
        new_dict=Dictionary()
        new_dict.dict=sorted_dict
        return new_dict
    
    def sort_by_value(self):
        sorted_dict = sorted(self.dict.items(), key=lambda kv: kv[1])

        new_dict=Dictionary()
        for key,value in sorted_dict:
            new_dict.dict[key]=value;
            
            

        
        return new_dict
    
    
    def print(self):
        print(self.dict)
        
        
    def ContainsKey(self,key1):
        if key1 in self.dict:
            return True
        
        return False
    
    
    def Remove(self,key1):
        if key1 in self.dict:
            del self.dict[key1]