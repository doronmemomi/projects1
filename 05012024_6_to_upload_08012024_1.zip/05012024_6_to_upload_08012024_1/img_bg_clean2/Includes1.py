import sys
import os


from ArrayList import ArrayList
from test1 import test1
from CPolynom2 import CPolynom2
from Dictionary import Dictionary
from bitmap import Bitmap
from CPolynom_curve1 import CPolynom_curve1