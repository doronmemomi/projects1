from ArrayList import ArrayList
from Dictionary import Dictionary
from bitmap import Bitmap

class CEdgeDetection1:
    def __init__(self):
        self.d1=1



    def lock_pixel_on_bmp1(self,bmp1:Bitmap, arr1:ArrayList, lock_pixel_dict2:Dictionary, color1):
        from CGlobals1 import CGlobals1
        
        for i1 in range(0 , arr1.count()):
            cords_arr1:ArrayList = arr1[i1]["cords_arr1"]

            if cords_arr1.count() > 30:
                for i2 in range(5 , cords_arr1.count() - 5+1):
                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, i2)
                    lock_pixel_dict2[cords_arr1[i2]] = 1

        for i1 in range (0 , lock_pixel_dict2.count()):

            cord_xy_str1 = lock_pixel_dict2.dict.keys[i1].Split(",")
            bmp1.SetPixel(int(cord_xy_str1(0)), int(cord_xy_str1(1)), color1)

        return bmp1





    def count_neighboors_with_less_diff1(self,bmp_max_diff1:Bitmap, cord_xy1):
        from CGlobals1 import CGlobals1
        
        if CGlobals1.some_max_diff_val1.ContainsKey(str(cord_xy1[0]) + "," + str(cord_xy1[1])) == True:
            return CGlobals1.some_max_diff_val1(str(cord_xy1[0]) + "," + str(cord_xy1[1]))

        some_max_diff1:float = 0
        padding_search1:int = 1
        for x1 in range( -padding_search1 , padding_search1+1):
            for y1 in range(-padding_search1 , padding_search1+1):
                cur_x1:int = cord_xy1[0] + x1
                cur_y1:int = cord_xy1[1] + y1

                if cur_x1 > 0 and cur_y1 > 0 and cur_x1 < (bmp_max_diff1.width() - 1) and cur_y1 < (bmp_max_diff1.height() - 1):
                    color2 = bmp_max_diff1.GetPixel(cord_xy1[0] + x1, cord_xy1[1] + y1)
                    some_max_diff1 += color2.R



        CGlobals1.some_max_diff_val1[str(cord_xy1[0]) + "," + str(cord_xy1[1])] = some_max_diff1

        return some_max_diff1




    def check_if_can_merge_slices_curves3(self,slices_curves_arr1:ArrayList):

        from CGlobals1 import CGlobals1
        
        dict_slices_curves1:Dictionary = Dictionary()


        for i1 in range( 0, slices_curves_arr1.count):
            dict_slices_curves1[i1] = slices_curves_arr1[i1]

        res_slices_curves_arr1:ArrayList = ArrayList()

        res_slices_curves_arr2 = ArrayList()
        res_slices_curves_arr3 = ArrayList()


        found_merge1:int = 1
        count_merged1:int = 0
        while found_merge1 == 1:
            found_merge1 = 0
            ind1 = 0
            to_stop1:int = 0
            while to_stop1 == 0:




                to_stop2:int = 0
                ind2 = 0
                while to_stop2 == 0:

                    if ind1 != ind2:
                        to_compare1:int = 0

                        to_compare1 = self.compare_sqrs_of_cords1(dict_slices_curves1[ind1]["dict_sqrs_of_cords1"], dict_slices_curves1[ind2]["dict_sqrs_of_cords1"])


                        if to_compare1 == 1:

                            min_len1:int = max(dict_slices_curves1[ind1]["cords_dict1"].count, dict_slices_curves1[ind2]["cords_dict1"].count)
                            res_slice1:Dictionary = None
                            if ind1 < ind2:
                                res_slice1 = self.merge_2_slice_curve1(dict_slices_curves1[ind1], dict_slices_curves1[ind2], (0, 0), min_len1)
                            else:
                                res_slice1 = self.merge_2_slice_curve1(dict_slices_curves1[ind2], dict_slices_curves1[ind1],(0, 0), min_len1)

                            if res_slice1!=None:

                                res_slices_curves_arr1.Add(res_slice1)

                                res_slices_curves_arr2.Add(dict_slices_curves1(ind1))
                                res_slices_curves_arr3.Add(dict_slices_curves1(ind2))
                                count_merged1 += 1

                                dict_slices_curves1[ind1] = res_slice1
                                dict_slices_curves1.Remove(ind2)



                                to_stop1 = 1
                                to_stop2 = 1
                                found_merge1 = 1

                    ind2 += 1

                    if ind2 >= dict_slices_curves1.count - 1:
                        to_stop2 = 1

                ind1 += 1

                if ind1 >= dict_slices_curves1.count - 1:
                    to_stop1 = 1

        self.save_slices_curves_in_bmp1(res_slices_curves_arr1, CGlobals1.global_path1 + "sobel_pics1\merged_res1_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")
        self.save_slices_curves_in_bmp1(res_slices_curves_arr2, CGlobals1.global_path1 + "sobel_pics1\merged_res2_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")
        self.save_slices_curves_in_bmp1(res_slices_curves_arr3, CGlobals1.global_path1 + "sobel_pics1\merged_res3_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")


        res_slices_curves_arr4:ArrayList = ArrayList()

        for i1 in range(0 , dict_slices_curves1.count):

            res_slices_curves_arr4.Add(dict_slices_curves1[dict_slices_curves1.keys[i1]])


        return res_slices_curves_arr4










    def save_slices_curves_in_bmp1(slices_curves_arr1:ArrayList, path_of_bmp1:str):
        from CGlobals1 import CGlobals1
        bmp5:Bitmap = Bitmap(2700, 1800, (255, 255, 255,0))
        r1:int=0
        g1:int=0
        b1:int=0
        CGlobals1.min_slice_len_added1 = 99999




        for i1 in range(0 ,slices_curves_arr1.count):
            curve_pixels_arr1:ArrayList = slices_curves_arr1[i1]["cords_arr1"]
            r1 += 50
            g1 -= 70
            b1 += 20

            if r1 > 255:
                r1 = 0

            if g1 > 255:
                g1 = 0

            if b1 > 255:
                b1 = 0


            if r1 < 0:
                r1 = 255

            if g1 < 0:
                g1 = 255

            if b1 < 0:
                b1 = 255


            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp5, (r1, g1, b1,0))

        bmp5.Save(path_of_bmp1)





    def save_slices_curves_in_bmps2(self,slices_curves_arr1:ArrayList, path_of_bmp1:str):
        from CGlobals1 import CGlobals1
        bmp5:Bitmap = Bitmap(2700, 1800, (255, 255, 255,0))
        r1:int = 0
        g1:int = 0
        b1:int = 0
        CGlobals1.min_slice_len_added1 = 99999




        for i1 in range(0, slices_curves_arr1.count):

            bmp5 = Bitmap(2700, 1800, (255, 255, 255,0))

            curve_pixels_arr1:ArrayList = slices_curves_arr1[i1]["cords_arr1"]
            r1 += 50
            g1 -= 70
            b1 += 20

            if r1 > 255:
                r1 = 0

            if g1 > 255:
                g1 = 0

            if b1 > 255:
                b1 = 0


            if r1 < 0:
                r1 = 255


            if g1 < 0:
                g1 = 255

            if b1 < 0:
                b1 = 255


            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp5, (r1, g1, b1,0))

            bmp5.Save(path_of_bmp1 + "slice_" + str(i1) + ".bmp")








    def check_if_dist_over_then1(self,new_cords_arr1:ArrayList, max_dist1:float):
        from CGlobals1 import CGlobals1

        for i1 in range( 0 , new_cords_arr1.count - 2+1):
            cord_xya1 = CGlobals1.get_cord_xy_in_pixels_arr1(new_cords_arr1, i1)
            cord_xya2 = CGlobals1.get_cord_xy_in_pixels_arr1(new_cords_arr1, i1 + 1)

            if CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy1(cord_xya1, cord_xya2) > max_dist1:

                return -1

        return 1
    

    def merge_2_slice_curve1(self,curve_silce1:Dictionary, curve_silce2:Dictionary, merge_cord1, min_len1:int):
        from CGlobals1 import CGlobals1
        
        CGlobals1.merge_2_slice_curve1_count1 += 1




        dict_res1:Dictionary = self.check_if_overlap_pixel1(curve_silce1["cords_dict1"], curve_silce2["cords_dict1"], 1)

        if dict_res1["min_cord_ind1"] == -1:
            return None

        if curve_silce1["cords_dict1"].count < 20 or curve_silce2["cords_dict1"].count < 20:
            return None



        cord_xy1 = dict_res1["cord_con_dict1_xy1"]
        cord_xy2 = dict_res1["cord_con_dict2_xy1"]




        to_stop1:int=0
        new_cords_arr1:ArrayList = ArrayList()
        cord_ind1:int = 0
        while to_stop1 == 0:
            try:
                new_cords_arr1.Add(curve_silce1["cords_arr1"][cord_ind1])

            except:
                dict_res2:Dictionary = self.check_if_overlap_pixel1(curve_silce1["cords_dict1"], curve_silce2["cords_dict1"], 1)



            if curve_silce1["cords_arr1"][cord_ind1] == str(cord_xy1[0]) + "," + str(cord_xy1[1]):
                to_stop1 = 1
            else:
                cord_ind1 += 1

        self.check_if_dist_over_then1(new_cords_arr1, 1.415)
        to_stop1 = 0
        cord_ind1 = 0
        while to_stop1 == 0:

            if curve_silce2["cords_arr1"][cord_ind1] == str(cord_xy2[0]) + "," + str(cord_xy2[1]):
               to_stop1 = 1
            else:
               cord_ind1 += 1


        self.check_if_dist_over_then1(new_cords_arr1, 1.415)
        to_stop1 = 0
        while to_stop1 == 0:

            if cord_ind1 > curve_silce2["cords_arr1"].count - 1:
                to_stop1 = 1
            else:
                new_cords_arr1.Add(curve_silce2["cords_arr1"][cord_ind1])
                cord_ind1 += 1




        self.check_if_dist_over_then1(new_cords_arr1, 1.415)

        new_slice_curve_result1:Dictionary = Dictionary()
        if new_cords_arr1.count > min_len1:

            new_slice_curve_result1["cords_arr1"] = new_cords_arr1

            new_slice_curve_result1["dict_sqrs_of_cords1"] = self.get_sqrs_of_cords1(new_cords_arr1)

            new_slice_curve_result1["cords_dict1"] = CGlobals1.add_to_dict1(new_cords_arr1)
            return new_slice_curve_result1


        return None







    def check_if_overlap_pixel1(self,cords_dict1:Dictionary, cords_dict2:Dictionary, pad1:int):

        to_stop3:int=0
        exist_overlap_slice_curve1:str = ""
        cord_ind1:int = 0
        min_cord_ind1:int = 0
        min_dist_cord1:float = 99

        cord_con_dict1_xy1=(0,0)
        cord_con_dict2_xy1=(0,0)

        while to_stop3 == 0:




            cord_xy_str1 = cords_dict1.keys[cord_ind1].Split(",")
            cord_xy1=(0,0)
            cord_xy1[0] = int(cord_xy_str1[0])
            cord_xy1[1] = int(cord_xy_str1[1])

            cord_xy2=(0,0)

            for x1 in range(-pad1 ,pad1+1):
                for y1 in range( -pad1 , pad1+1):
                    cord_xy2[0] = cord_xy1[0] + x1
                    cord_xy2[1] = cord_xy1[1] + y1
                    if cords_dict2.ContainsKey(str(cord_xy2[0]) + "," + str(cord_xy2[1])) == True:

                        if min_dist_cord1 > (abs(x1) + abs(y1)) or min_dist_cord1 == 99:
                            min_dist_cord1 = (abs(x1) + abs(y1))

                            min_cord_ind1 = cord_ind1

                            cord_con_dict1_xy1[0] = cord_xy1[0]
                            cord_con_dict1_xy1[1] = cord_xy1[1]

                            cord_con_dict2_xy1[0] = cord_xy2[0]
                            cord_con_dict2_xy1[1] = cord_xy2[1]

                        exist_overlap_slice_curve1 = "yes"

            cord_ind1 += 1
            if cord_ind1 > cords_dict1.count - 1:
                to_stop3 = 1

        dict_ret_res1:Dictionary = Dictionary()

        if exist_overlap_slice_curve1 == "yes":
            dict_ret_res1["min_cord_ind1"] = min_cord_ind1
            dict_ret_res1["cord_con_dict1_xy1"] = cord_con_dict1_xy1
            dict_ret_res1["cord_con_dict2_xy1"] = cord_con_dict2_xy1
        else:
            dict_ret_res1["min_cord_ind1"] = -1


        return dict_ret_res1

    







        

    def compare_sqrs_of_cords1(self,dict_sqrs_cords1:Dictionary, dict_sqrs_cords2:Dictionary):
    
        for i1 in range(0 ,dict_sqrs_cords1.count ):
            if dict_sqrs_cords2.ContainsKey(dict_sqrs_cords1.keys[i1]):
                return 1

        return 0



    def add_slices_curves_where_overlaps_slices_curves1(self,cur_silces_curves1:ArrayList, add_slices_curves1:ArrayList, connect_type1:str):
        from CGlobals1 import CGlobals1
        
        i1 = 0
        i2 = 0

        to_stop1:int = 0
        first_cur_overlap_slice_ind1:int = -1
        last_cur_overlap_slice_ind1:int = -1
        add_overlap_slice_ind1:int = -1
        while to_stop1 == 0:

            cords_arr1:ArrayList = cur_silces_curves1[i1]["cords_arr1"]

            cords_arr2:ArrayList = cur_silces_curves1[i1 + 1]("cords_arr1")

            last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, cords_arr1.Count - 1)

            first_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr2, 0)

            dist1:float = CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy1(last_cord_xy1, first_cord_xy1)

            round2:str = ""

            if dist1 > 5:
                exist_overlap_slice_curve1:str = ""
                last_ind_overlap_slice_curve1:int = -1
                to_stop2:int = 0
                i2 = 0

                while to_stop2 == 0:


                    to_compare1:int = self.compare_sqrs_of_cords1(cur_silces_curves1(i1)("dict_sqrs_of_cords1"), add_slices_curves1(i2)("dict_sqrs_of_cords1"))

                    if to_compare1 == 1:
                        cords_dict1:Dictionary = cur_silces_curves1[i1]["cords_dict1"]
                        cords_dict2:Dictionary = add_slices_curves1[i2]["cords_dict1"]




                        cord_ind1:int=0

                        to_stop3:int=0
                        if cords_dict2.count < 20:
                            to_stop3 = 1

                        dict_res1:Dictionary = self.check_if_overlap_pixel1(cords_dict1, cords_dict2, 1)


                        if dict_res1["min_cord_ind1"] != -1:
                            if connect_type1 == "start":
                                last_ind_overlap_slice_curve1 = i2
                                first_cur_overlap_slice_ind1 = i1
                                add_overlap_slice_ind1 = i2
                                exist_overlap_slice_curve1 = "yes"


                            if connect_type1 == "end":
                                if round2 == "yes" and last_ind_overlap_slice_curve1 == -1:
                                    last_ind_overlap_slice_curve1 = i2


                                    last_cur_overlap_slice_ind1 = i1
                                    add_overlap_slice_ind1 = i2

                                    exist_overlap_slice_curve1 = "yes"

                    i2 += 1
                    if i2 >= add_slices_curves1.Count - 2:

                        if connect_type1 == "end" and round2 == "":
                            round2 = "yes"
                            i2 = 0
                        else:
                            to_stop2 = 1

                
                if exist_overlap_slice_curve1 == "yes":

                    last_overlap_cur_slice_curve1:int = -1
                    ind_overlap_cur_slice_curve1:int = i1 + 1

                    if connect_type1 == "end":
                        ind_overlap_cur_slice_curve1 = i1 - 1
                        if ind_overlap_cur_slice_curve1 < 0:
                            ind_overlap_cur_slice_curve1 = cur_silces_curves1.count - 1

                    to_stop4:int = 0
                    cur_overlap_slice_ind1:int = first_cur_overlap_slice_ind1

                    if connect_type1 == "end":
                        cur_overlap_slice_ind1 = last_cur_overlap_slice_ind1




                    next_overlap_slice_curve1:int = self.find_next_cur_overlap_slice_curve1(cur_silces_curves1, add_slices_curves1, connect_type1, cur_overlap_slice_ind1, add_overlap_slice_ind1)






                    if next_overlap_slice_curve1 == -1:

                        dict_res1:Dictionary = None
                        if connect_type1 == "start":
                            dict_res1 = self.merge_2_slice_curve1(cur_silces_curves1[i1], add_slices_curves1(add_overlap_slice_ind1), (1, 1), cur_silces_curves1[i1]["cords_dict1"].count)


                        if connect_type1 == "end":
                            dict_res1 = self.merge_2_slice_curve1(add_slices_curves1[add_overlap_slice_ind1], cur_silces_curves1[i1],(1, 1), cur_silces_curves1[i1]["cords_dict1"].count)


                        if dict_res1!=None:
                            cur_silces_curves1[i1] = dict_res1

                    else:


                        delete_slices_curves1:str = ""
                        start_ind_to_del1:int = -1
                        end_ind_to_del1:int = -1
                        dict_res2:Dictionary=None
                        if connect_type1 == "start":

                            dict_res2 = self.merge_2_slice_curve1(cur_silces_curves1[i1], add_slices_curves1(add_overlap_slice_ind1), (1, 1), cur_silces_curves1[i1]["cords_dict1"].count)

                            if dict_res2!=None:


                                was_error1:str = ""
                                try:
                                    dict_res2 = self.merge_2_slice_curve1(dict_res2, cur_silces_curves1[next_overlap_slice_curve1],(1, 1), cur_silces_curves1[i1]["cords_dict1"].count)

                                except:
                                    was_error1 = "yes"

                                if dict_res2!=None and was_error1 == "":
                                    delete_slices_curves1 = "yes"
                                    start_ind_to_del1 = i1
                                    end_ind_to_del1 = next_overlap_slice_curve1

                            else:
                                dict_res2 = self.merge_2_slice_curve1(add_slices_curves1[add_overlap_slice_ind1], cur_silces_curves1[next_overlap_slice_curve1],(1, 1), cur_silces_curves1[i1]["cords_dict1"].count)


                            if dict_res2 != None:
                                cur_silces_curves1[i1] = dict_res2

                        if connect_type1 == "end":

                            dict_res2 = self.merge_2_slice_curve1(add_slices_curves1[add_overlap_slice_ind1], cur_silces_curves1[i1],(1, 1), cur_silces_curves1[i1]["cords_dict1"].count)

                            if dict_res2!=None:

                                was_error1:str = ""
                                try:
                                    dict_res2 = self.merge_2_slice_curve1(dict_res2, add_slices_curves1[last_cur_overlap_slice_ind1], (1, 1), cur_silces_curves1[i1]["cords_dict1"].count)

                                except:
                                    was_error1 = "yes"

                                if dict_res2!=None and was_error1 == "":
                                    delete_slices_curves1 = "yes"
                                    start_ind_to_del1 = next_overlap_slice_curve1
                                    end_ind_to_del1 = i1
                            else:
                                dict_res2 = self.merge_2_slice_curve1(cur_silces_curves1[next_overlap_slice_curve1], add_slices_curves1[add_overlap_slice_ind1], (1, 1), cur_silces_curves1[i1]["cords_dict1"].count)



                            if dict_res2!=None:
                                cur_silces_curves1[i1] = dict_res2

                        if delete_slices_curves1 == "yes":
                            i1 = -1
                            if connect_type1 == "start" or connect_type1 == "end":
                                ind_del1:int

                                if start_ind_to_del1 < end_ind_to_del1:
                                    for ind_del1 in range( start_ind_to_del1 + 1 , end_ind_to_del1+1):
                                        cur_silces_curves1.RemoveAt(start_ind_to_del1 + 1)
                                else:
                                    for ind_del1 in range( start_ind_to_del1 + 1 , cur_silces_curves1.count):
                                        cur_silces_curves1.RemoveAt(start_ind_to_del1 + 1)

                                    for ind_del1 in range( 0 ,end_ind_to_del1+1):
                                        cur_silces_curves1.RemoveAt(0)



            i1 += 1
            if i1 >= cur_silces_curves1.count - 2:
                to_stop1 = 1




        return cur_silces_curves1





    def get_count_pixels_slice_of_curve_contain_in_slice_of_curve1(slice_of_curve1:Dictionary, contain_slice_of_curve1:Dictionary, pad1:int):
        from CGlobals1 import CGlobals1
        cords_arr1:ArrayList = slice_of_curve1["cords_arr1"]
        contain_cords_arr1:ArrayList = contain_slice_of_curve1["cords_arr1"]

        dict_cords1:Dictionary = CGlobals1.add_to_dict1(cords_arr1)
        dict_contained_cords1:Dictionary = Dictionary()


        count_cords_exist1:int = 0
        count_cords_seq_exist1:int = 0


        for i1 in range(pad1 , contain_cords_arr1.count - pad1+1):

            exist_in_current_slice2:str = "no"

            for x1 in range(-pad1, pad1+1):
                for y1 in range(-pad1,pad1+1):
                    key1:str = str(CGlobals1.get_cord_xy_in_pixels_arr1(contain_cords_arr1, i1)[0] + x1) + "," + str(CGlobals1.get_cord_xy_in_pixels_arr1(contain_cords_arr1, i1)[1] + y1)

                    if dict_cords1.ContainsKey(key1) == True:
                        exist_in_current_slice2 = "yes"



            if exist_in_current_slice2 == "yes":
                dict_contained_cords1[contain_cords_arr1[i1]] = 1
                count_cords_exist1 += 1
                count_cords_seq_exist1 += 1
            else:
                count_cords_seq_exist1 = 0


        dict_res1:Dictionary = Dictionary()
        dict_res1["count_cords_exist1"] = count_cords_exist1
        dict_res1["count_cords_seq_exist1"] = count_cords_seq_exist1
        dict_res1["dict_contained_cords1"] = dict_contained_cords1

        return dict_res1



    def replace_slices_curves_with_bigger_and_conatain_slices_curves1(self,cur_silces_curves1:ArrayList, add_slices_curves1:ArrayList, sobel_ind1:int):

        pad_contain_dist1:int = 5
        dict_inds1:Dictionary = Dictionary()
        dict_inds2:Dictionary = Dictionary()


        for i1 in range(cur_silces_curves1.count - 1 ,-1,-1):

            is_contained1:str = ""
            for i2 in range(add_slices_curves1.count - 1 , -1, -1):

                if add_slices_curves1[i2]["cords_arr1"].count > cur_silces_curves1[i1]["cords_arr1"].count + pad_contain_dist1 * 2:


                    to_compare1:int = self.compare_sqrs_of_cords1(cur_silces_curves1[i1]["dict_sqrs_of_cords1"], add_slices_curves1[i2]["dict_sqrs_of_cords1"])
                    if to_compare1 == 1:
                        dict_res1:Dictionary = self.get_count_pixels_slice_of_curve_contain_in_slice_of_curve1(cur_silces_curves1[i1], add_slices_curves1[i2], pad_contain_dist1)

                        dict_contained_cords1:Dictionary = dict_res1["dict_contained_cords1"]
                        count_cords_seq_exist1:int = dict_res1["count_cords_seq_exist1"]


                        if count_cords_seq_exist1 >= cur_silces_curves1[i1]["cords_arr1"].count:
                            dict_inds2[i2] = 1

                            is_contained1 = "yes"




            if is_contained1 == "":
                dict_inds1[i1] = 1


        new_slice_curve_arr1:ArrayList = ArrayList()

        for i1 in range(0 , dict_inds1.count):
            if cur_silces_curves1[dict_inds1.keys[i1]]["cords_arr1"].count > 20:
                new_slice_curve_arr1.Add(cur_silces_curves1[dict_inds1.keys[i1]])





        for i1 in range(0 ,dict_inds2.count):
            if self.add_slices_curves1(dict_inds2.Keys(i1))("cords_arr1").count > 20:
                new_slice_curve_arr1.Add(add_slices_curves1[dict_inds2.keys[i1]])



        return new_slice_curve_arr1






    def compare_dict_of_pixels1(self,dict_pixels1:Dictionary, dict_pixels2:Dictionary):

        dict_pixels1_not_exist1:Dictionary = Dictionary()

        for i1 in range(0,dict_pixels1.count):
            cord_xy_str1 = dict_pixels1.dict.keys[i1].Split(",")
            x1 = int(cord_xy_str1[0])
            y1 = int(cord_xy_str1[1])

           

            exist1:str = ""

            for x_cord1 in range(-2, 3):
                for y_cord1 in range (-2,3):
                    xy_cord_str1:str = str(x1 + x_cord1) + "," + str(y1 + y_cord1)

                    if dict_pixels2.ContainsKey(xy_cord_str1) == True:
                        exist1 = "yes"

            if exist1 == "" and dict_pixels2.count > 0:
                dict_pixels1_not_exist1[dict_pixels1.keys[i1]] = 1



        

        return dict_pixels1_not_exist1
    



    def curves_arrays_to_dict1(self,curves_arr1:ArrayList):
        from CGlobals1 import CGlobals1
        
        pixels_dict1:Dictionary = Dictionary()

        for i1 in range(0 ,curves_arr1.count()):
            cords_arr1:ArrayList = curves_arr1[i1]["cords_arr1"]

            if cords_arr1.count() > 30:
                for i2 in range(5,cords_arr1.count() - 5):
                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, i2)
                    pixels_dict1[cords_arr1[i2]] = 1



        return pixels_dict1




    def print_slices_curve1(self,slices_curves_arr1:ArrayList, sobel_ind1:int):
        
        from CGlobals1 import CGlobals1
        bmp5:Bitmap =Bitmap(4000, 3000, (255, 255, 255))


        last_dict_angles1:Dictionary()
        r1:int = 100
        g1:int = 100
        b1:int = 100

        last_end_angle1:float = -999
        last_cord_xy1=1
        for i1 in range(0,slices_curves_arr1.count()):
            dict_slice_curve1:Dictionary = slices_curves_arr1[i1]
            cords_arr1:ArrayList = dict_slice_curve1["cords_arr1"]

            dict_angles1:Dictionary = dict_slice_curve1["dict_angles1"]



            connect_slices1:str = ""


            if i1 > 0 and last_cord_xy1!=None:

                if cords_arr1.count() > 0:

                    start_angle1:float = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1(last_cord_xy1, CGlobals1.get_double_cord_xy_in_pixels_arr2(cords_arr1, 0))

                    if abs(start_angle1 - last_end_angle1) <= 45:
                        connect_slices1 = "yes"

                    if abs(start_angle1 - last_end_angle1) == 315:
                        connect_slices1 = "yes"



            if connect_slices1 == "":


                r1 += 50
                g1 -= 70
                b1 += 20

                if r1 > 255:
                    r1 = 0

                if g1 > 255:
                    g1 = 0

                if b1 > 255:
                    b1 = 0


                if r1 < 0:
                    r1 = 255

                if g1 < 0:
                    g1 = 255

                if b1 < 0:
                    b1 = 255


            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(cords_arr1, bmp5, (r1, g1, b1))

            last_dict_angles1 = dict_angles1
            if cords_arr1.count() > 1:
                last_end_angle1 = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1(CGlobals1.get_double_cord_xy_in_pixels_arr2(cords_arr1, cords_arr1.Count - 2), CGlobals1.get_double_cord_xy_in_pixels_arr2(cords_arr1, cords_arr1.count() - 1))
                last_cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(cords_arr1, cords_arr1.count() - 1)
            else:
                last_cord_xy1 = None




        bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\curve_no_noise3_" + str(sobel_ind1) + ".bmp")








        



    def get_sqr_of_cord1(self,x_cord1:int, y_cord1:int):

        x_sqr1:int = x_cord1 / 40
        y_sqr1:int = y_cord1 / 40

        return str(x_sqr1) + "_" + str(y_sqr1)



    def get_sqrs_of_cords1(self,cords_arr1:ArrayList):
        from CGlobals1 import CGlobals1
        dict_sqrs_cords1:Dictionary = Dictionary()
        for i1 in range(0,cords_arr1.count()):
            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(cords_arr1, i1)

            for x1 in range(-1,2):
                for y1 in range(-1,2):
                    dict_sqrs_cords1[self.get_sqr_of_cord1(cord_xy1[0] + x1, cord_xy1[1] + y1)] = dict_sqrs_cords1.count()


        return dict_sqrs_cords1
    

    def check_connectivity_between_pixels1(self,sobel_res1:Dictionary, sobel_res2:Dictionary):
        from CGlobals1 import CGlobals1
    
        arr1:ArrayList = sobel_res1["arr1"]
        arr2:ArrayList = sobel_res2["arr1"]


        dict1:Dictionary = sobel_res1("dict1")
        dict2:Dictionary = sobel_res2("dict1")

        dict_wrong_connectivity1:Dictionary = Dictionary()



        for ind1 in range(0 ,arr1.count() - 2+1):
            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, ind1)
            cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(arr1, ind1 + 1)


            ind_of_first1:int = -1
            ind_of_second1:int = -1

            if dict2.ContainsKey(str(cord_xy1[0] + 0) + "," +str(cord_xy1[1] + 0)) == True:
                ind_of_first1 = dict2[str(cord_xy1[0] + 0) + "," + str(cord_xy1[1] + 0)]

            if dict2.ContainsKey(str(cord_xy2[0] + 0) + "," + str(cord_xy2[1] + 0)) == True:
                ind_of_second1 = dict2((cord_xy2(0) + 0).ToString() + "," + (cord_xy2(1) + 0).ToString())


            if ind_of_first1 == -1:
                for x1 in range(-1 ,1+1):
                    for y1 in range(-1 , 1+1):
                        if dict2.ContainsKey(str(cord_xy1[0] + x1) + "," + str(cord_xy1[1] + y1)) == True:
                            ind_of_first1 = dict2[str(cord_xy1[0] + x1) + "," + str(cord_xy1[1] + y1)]

            if ind_of_second1 == -1:
                for x1 in range (-1, 1+1):
                    for y1 in range( -1 , 1+1):
                        if dict2.ContainsKey(str(cord_xy2[0] + x1) + "," + str(cord_xy2[1] + y1)) == True:
                            ind_of_second1 = dict2((cord_xy2(0) + x1).ToString() + "," + (cord_xy2(1) + y1).ToString())

            if abs(ind_of_first1 - ind_of_second1) > 15 and ind_of_first1 != -1 and ind_of_second1 != -1:
                dict_wrong_connectivity1[str(ind_of_first1) + "," + str(ind_of_second1)] = 1

        return dict_wrong_connectivity1
    







    def check_if_trend_without_noise(self,curve_pixels_arr1:ArrayList, sobel_ind1:int):
        from CGlobals1 import CGlobals1
    
        trend_x1:int = 0
        trend_y1:int = 0

        angle_treshold1:float = 45
        last_trend_x1:int = 0
        last_trend_y1:int = 0

        cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, 0)
        cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, 1)

        angle1:float = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1([cord_xy1[0], cord_xy1[1]], [cord_xy2[0], cord_xy2[1]])
        add_angle1:float=0
        
        if angle1 < 90:
            add_angle1 = 90

        if angle1 > 270:
            add_angle1 = -90


        angle1 += add_angle1

        min_angle1:float = 999
        max_angle1:float = -999
        if min_angle1 > angle1:
            min_angle1 = angle1


        if max_angle1 < angle1:
            max_angle1 = angle1



        to_stop1:bool = 0
        cords_arr1:ArrayList =ArrayList()


        to_stop2:bool = 0

        bmp5:Bitmap =Bitmap(4000,3000,(255, 255, 255,0))


        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp5, (24, 20, 50,0))


        r1:int = 100
        g1:int = 150
        b1:int = 200

        i1 = 1
        

        CGlobals1.draw_sqr_around_pixels(bmp5, CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)(0), CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)(1), 2, Color.FromArgb(200, 50, 150))
        angles_arr1:ArrayList = ArrayList()

        slice_curve_without_noise_arr1:ArrayList =ArrayList()
        last_org_angles1:float = -999
        start_angle1:float = -999
        last_angle1:float = -999
        while to_stop2 == False:
            
            to_stop1 = False
            dict_angles1:Dictionary = Dictionary()

            if last_org_angles1 != -999:
                dict_angles1[last_org_angles1] = dict_angles1.count()
                cords_arr1.Add(curve_pixels_arr1[i1])
                last_org_angles1 = -999
            

            while to_stop1 == False:





                cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1)
                cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pixels_arr1, i1 + 1)
                angle1 = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1((cord_xy1[0], cord_xy1[1]), (cord_xy2[0], cord_xy2[1]))

                org_angle1:float = angle1

                if start_angle1 == -999:
                    start_angle1 = org_angle1

                angle1 += add_angle1
                if angle1 > 360:
                    angle1 = angle1 - 360
                
                angle_minus1:float = -(360 - angle1)

                if min_angle1 > angle1:
                    min_angle1 = angle1



                if max_angle1 < angle1:
                    max_angle1 = angle1

                angles_arr1.Add("angle1=" + angle1.ToString() + ",min_angle1=" + min_angle1.ToString() + ",max_angle1=" + max_angle1.ToString() + "add_angle1=" + add_angle1.ToString())

                i1 += 1
                if abs(min_angle1 - max_angle1) > angle_treshold1 or i1 >= curve_pixels_arr1.Count - 2:
                    last_org_angles1 = org_angle1
                    to_stop1 = True



                    angle1 = CGlobals1.form_obj1.markingfldimg_obj1.get_angle1((cord_xy1[0], cord_xy1[1]), (cord_xy2[0], cord_xy2[1]))


                    if angle1 < 90:
                        add_angle1 = 90

                    if angle1 > 270:
                        add_angle1 = -90

                    angle1 += add_angle1


                    min_angle1 = 999
                    max_angle1 = -999
                    if min_angle1 > angle1:
                        min_angle1 = angle1



                    if max_angle1 < angle1:
                        max_angle1 = angle1



                else:

                    dict_angles1[org_angle1] = dict_angles1.count()
                    cords_arr1.Add(curve_pixels_arr1[i1])
                    last_angle1 = org_angle1
                


                if i1 >= curve_pixels_arr1.count() - 2:
                    to_stop2 = 1



            r1 += 50
            g1 -= 70
            b1 += 20

            if r1 > 255:
                r1 = 0
            

            if g1 > 255:
                g1 = 0

            if b1 > 255:
                b1 = 0


            if r1 < 0:
                r1 = 255

            if g1 < 0:
                g1 = 255


            if b1 < 0:
                b1 = 255



            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(cords_arr1, bmp5, (r1, g1, b1))




            dict_slice_curve1:Dictionary = Dictionary()
            dict_slice_curve1["cords_arr1"] = cords_arr1
            dict_slice_curve1["dict_sqrs_of_cords1"] = self.get_sqrs_of_cords1(cords_arr1)

            dict_slice_curve1["cords_dict1"] = CGlobals1.add_to_dict1(cords_arr1)
            dict_slice_curve1["dict_angles1"] = dict_angles1
            dict_slice_curve1["last_angle1"] = last_angle1
            dict_slice_curve1["start_angle1"] = start_angle1

            start_angle1 = -999

            slice_curve_without_noise_arr1.Add(dict_slice_curve1)
            dict_angles1 = Dictionary()
            cords_arr1 = ArrayList()










        bmp5.Save(CGlobals1.global_path1 + "sobel_pics1\curve_no_noise1_" + str(sobel_ind1) + "_" + str(angle_treshold1) + ".bmp")

        return slice_curve_without_noise_arr1




    def save_slices_curves_in_bmp1(slices_curves_arr1:ArrayList, path_of_bmp1:str):
        from CGlobals1 import CGlobals1
        bmp5:Bitmap = CGlobals1.create_fill_bitmap(2700, 1800, (255, 255, 255))
        r1:int=0
        g1:int=0
        b1:int=0
        CGlobals1.min_slice_len_added1 = 99999




        for i1 in range(0,slices_curves_arr1.count() - 1):
            curve_pixels_arr1:ArrayList = slices_curves_arr1[i1]["cords_arr1"]
            r1 += 50
            g1 -= 70
            b1 += 20

            if r1 > 255:
                r1 = 0

            if g1 > 255:
                g1 = 0


            if b1 > 255:
                b1 = 0



            if r1 < 0:
                r1 = 255


            if g1 < 0:
                g1 = 255


            if b1 < 0:
                b1 = 255



            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pixels_arr1, bmp5, (r1, g1, b1))

        bmp5.Save(path_of_bmp1)










        
        
    def loop_on_sobel_vals4(self,line_to_search_start_sobel_pixels1:ArrayList):
        from CGlobals1 import CGlobals1
        lock_pixels1:str = "yes"
        last_pixels_dict1:Dictionary = Dictionary()
        CGlobals1.delete_files1(CGlobals1.global_path1 + "\sobel_pics1", "*.bmp")

        CGlobals1.dir_x1_to_sobel = 1

        CGlobals1.dir_m1_to_sobel = 0






        CGlobals1.current_start_x1 = 1400
        CGlobals1.current_start_y1 = 1000


        CGlobals1.dir_x1_to_sobel = 0
        CGlobals1.dir_m1_to_sobel = 1


        lock_pixel_dict1:Dictionary = Dictionary()

        bmp_max_diff1:Bitmap = CGlobals1.form_obj1.markingfldimg_obj1.get_max_diff_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp1)

        to_stop_round_with_sobal1:int = 0
        
        current_pixel_line_arr1:ArrayList = ArrayList()

        dict_current_pixel_line_arr1:Dictionary = Dictionary()


        first_pixels_arr1:ArrayList
        image_ind1:int = 0

        dict_max_dist_sobel:Dictionary = Dictionary()

        dict_lock_pixels1:Dictionary = Dictionary()
        dict_sobel_arrs1:Dictionary = Dictionary()
        dict_contains_slices2:Dictionary = Dictionary()

        arr_of_slice_min_len1:ArrayList = ArrayList()

        last_merged2_arr_of_slice_min_len1:ArrayList = ArrayList()

        while to_stop_round_with_sobal1 == 0:




            CGlobals1.max_last_index_all_exist_in_prev_pixels1 = -1


            to_stop1:bool = False
            CGlobals1.max_pixels_arr_length1 = -99
            CGlobals1.max_count_pixels1 = -99
            dict_result_by_sobel_val1:Dictionary = Dictionary()


            step_num2:int = 0
            last_srat_cord_line_line1:int = -1

            dict_res_sobel_pxls2:Dictionary = Dictionary()
            dict_slice_curves1:Dictionary = Dictionary()
            count_slice_curves1:int = 0

            total_added_connected1:ArrayList = ArrayList()

            CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 = 1
            while to_stop1 == False:
                last_srat_cord_line_line1 = -1
                CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 += 1

                CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel = Bitmap(CGlobals1.path_of_sobel_cache1 + "\\" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".jpg")


                to_stop_search_start_point1:Integer = 0
                dict_res1:Dictionary


                found_around_sobel:str = "yes"



                try:
                    cord1 = CGlobals1.form_obj1.markingfldimg_obj1.find_start_point_by_line1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, line_to_search_start_sobel_pixels1, last_srat_cord_line_line1)
                    CGlobals1.form_obj1.markingfldimg_obj1.x_start2 = cord1[0]
                    CGlobals1.form_obj1.markingfldimg_obj1.y_start2 = cord1[1]
                except:
                    found_around_sobel = "no"
                    to_stop_search_start_point1 = 1



                if lock_pixels1 == "yes":


                    copy_sobel_bmp1:Bitmap = CGlobals1.copy_bitmap1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel)
                    copy_sobel_bmp1 = self.lock_pixel_on_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, arr_of_slice_min_len1, lock_pixel_dict1, (250, 100, 55,0))
                    copy_sobel_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_lock2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")
                    CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel = lock_pixel_on_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, arr_of_slice_min_len1, lock_pixel_dict1, (255, 255, 255.0))
                    CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_lock_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")


                dict_res1 = CGlobals1.form_obj1.markingfldimg_obj1.find_max_sobel_length3(CGlobals1.form_obj1.markingfldimg_obj1.x_start2, CGlobals1.form_obj1.markingfldimg_obj1.y_start2)



                if found_around_sobel == "yes":
                    padding_search1:int = 10
                    padding_no_search1:int = 3
                    dict_result_by_sobel_val1[CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1] = dict_res1

                    sobel_pixels_arr1:ArrayList = dict_res1["pixels_around_sobel_arr1"]["pixels_cords_arr1"]
                    sobel_pixels_arr2:ArrayList = sobel_pixels_arr1.clone()
                    dict_sobel_pixels1:Dictionary = CGlobals1.add_to_dict1(sobel_pixels_arr1)
                    dict_sobel_res1:Dictionary = Dictionary()
                    dict_sobel_res1["arr1"] = sobel_pixels_arr1
                    dict_sobel_res1["dict1"] = dict_sobel_pixels1
                    dict_sobel_arrs1[CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1] = dict_sobel_res1

                    if CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 > 15:
                        
                        dict_res_connectivity1:Dictionary = self.check_connectivity_between_pixels1(dict_sobel_arrs1[CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 - 1], dict_sobel_arrs1[CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1])
                        slice_curves_arr1:ArrayList


                        slice_curves_arr1 = self.check_if_trend_without_noise(sobel_pixels_arr1, CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)

                        self.print_slices_curve1(slice_curves_arr1, CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)

                        dict_slice_curves1[CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1] = slice_curves_arr1






                        if arr_of_slice_min_len1!=None:
                            self.check_connectivity_between_slice_curves1(dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 - 1), dict_slice_curves1[CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1], arr_of_slice_min_len1)
                            self.save_slices_curves_in_bmp1(dict_slice_curves1[CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1], CGlobals1.global_path1 + "sobel_pics1\no_hole_slice2_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")


                        count_slice_curves1 = slice_curves_arr1.count()

                        to_merge_slices1:str = ""




                        if dict_slice_curves1.count() > 1:
                            if arr_of_slice_min_len1.count() == 0:
                                arr_of_slice_min_len1 = dict_slice_curves1[CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 - 1]

                            self.save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\start_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")


                            ind1:int
                            ind2:int
                            ind1 = 0

                            to_stop_merge1:int = 1

                            while to_stop_merge1 == 0:

                                dict_res2:Dictionary = self.try_to_merge_slices_curves1(arr_of_slice_min_len1, ind1, ind1 + 1)
                                if dict_res2!=None:
                                    arr_of_slice_min_len1[ind1] = dict_res2
                                    arr_of_slice_min_len1.RemoveAt(ind1 + 1)
                                else:
                                    ind1 += 1

                                if ind1 >= arr_of_slice_min_len1.Count - 2:
                                    to_stop_merge1 = 1



                            self.save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\merged_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")

                            cur_last_pixels_dict1:Dictionary = self.curves_arrays_to_dict1(arr_of_slice_min_len1)


                            not_exist_pixels:Dictionary = self.compare_dict_of_pixels1(last_pixels_dict1, cur_last_pixels_dict1)

                            if not_exist_pixels.count > 0:


                                pxls_arr1:ArrayList = CGlobals1.dict_keys_to_arr1(not_exist_pixels)
                                bmp_pxl_no_exist1:Bitmap = Bitmap(3000, 2000, (255, 255, 255,0))
                                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp1(pxls_arr1, bmp_pxl_no_exist1)
                                bmp_pxl_no_exist1.Save(CGlobals1.global_path1 + "sobel_pics1\not_exist_pxls0_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")


                            last_pixels_dict1 = cur_last_pixels_dict1

                            if lock_pixels1 == "yes":


                                copy_sobel_bmp1:Bitmap = CGlobals1.copy_bitmap1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel)
                                copy_sobel_bmp1 = self.lock_pixel_on_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, arr_of_slice_min_len1, lock_pixel_dict1, (250, 100, 55,0))
                                copy_sobel_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_lock3_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")



                            if CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 < 25:
                                arr_of_slice_min_len1 = self.replace_slices_curves_with_bigger_and_conatain_slices_curves1(arr_of_slice_min_len1, dict_slice_curves1(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1), CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)

                            self.save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")


                            if lock_pixels1 == "yes":


                                copy_sobel_bmp1:Bitmap = CGlobals1.copy_bitmap1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel)
                                copy_sobel_bmp1 = self.lock_pixel_on_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, arr_of_slice_min_len1, lock_pixel_dict1, (250, 100, 55,0))
                                copy_sobel_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_lock4_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")
                                

                            arr_of_slice_min_len1 = self.add_slices_curves_where_overlaps_slices_curves1(arr_of_slice_min_len1, dict_slice_curves1[CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1], "start")


                            cur_last_pixels_dict1 = self.curves_arrays_to_dict1(arr_of_slice_min_len1)


                            not_exist_pixels = self.compare_dict_of_pixels1(last_pixels_dict1, cur_last_pixels_dict1)

                            if not_exist_pixels.Count > 0:
                                pxls_arr1:ArrayList = CGlobals1.dict_keys_to_arr1(not_exist_pixels)
                                bmp_pxl_no_exist1:Bitmap = Bitmap(3000, 2000, (255, 255, 255,0))
                                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp1(pxls_arr1, bmp_pxl_no_exist1)
                                bmp_pxl_no_exist1.Save(CGlobals1.global_path1 + "sobel_pics1\not_exist_pxls1_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")

                            last_pixels_dict1 = cur_last_pixels_dict1



                            if CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 == 22:
                                self.save_slices_curves_in_bmps2(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\\logs1\\")


                            self.save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added1_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")

                            if lock_pixels1 == "yes":


                                copy_sobel_bmp1:Bitmap = Bitmap(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel)
                                copy_sobel_bmp1 = self.lock_pixel_on_bmp1(CGlobals1.form_obj1.markingfldimg_obj1.bmp_current_sobel, arr_of_slice_min_len1, lock_pixel_dict1, (250, 100, 55,0))
                                copy_sobel_bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\sobel_lock5_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")




                            cur_last_pixels_dict1 = self.curves_arrays_to_dict1(arr_of_slice_min_len1)


                            not_exist_pixels = self.compare_dict_of_pixels1(last_pixels_dict1, cur_last_pixels_dict1)

                            if not_exist_pixels.Count > 0:
                                pxls_arr1:ArrayList = CGlobals1.dict_keys_to_arr1(not_exist_pixels)
                                bmp_pxl_no_exist1:Bitmap = Bitmap(3000, 2000, (255, 255, 255,0))
                                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp1(pxls_arr1, bmp_pxl_no_exist1)
                                bmp_pxl_no_exist1.Save(CGlobals1.global_path1 + "sobel_pics1\not_exist_pxls1_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")

                            last_pixels_dict1 = cur_last_pixels_dict1

                            self.save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added2_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")
                            if CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 >= 35:

                                for slice_ind1 in range(0,arr_of_slice_min_len1.count-1):
                                    arr_slice1:ArrayList = self.arr_of_slice_min_len1[slice_ind1]["cords_arr1"]
                                    arr_slice2:ArrayList = arr_of_slice_min_len1[slice_ind1 + 1]["cords_arr1"]
                                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(arr_slice1, arr_slice1.count - 1)
                                    cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(arr_slice2, 0)
                                    dist1:float = CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy1(cord_xy1, cord_xy2)
                                    if dist1 >= 1 and dist1 < 10:
                                        arr2:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points2(cord_xy1, cord_xy2)

                                        for ind4 in raage(0 , arr2.count - 1):
                                            arr_slice1.Add(arr2(ind4))


                            self.save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added3_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")



                            arr_of_slice_min_len1 = self.add_slices_curves_where_no_slices_curves1(arr_of_slice_min_len1, dict_slice_curves1[CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1])

                            cur_last_pixels_dict1 = self.curves_arrays_to_dict1(arr_of_slice_min_len1)


                            not_exist_pixels = self.compare_dict_of_pixels1(last_pixels_dict1, cur_last_pixels_dict1)

                            if not_exist_pixels.Count > 0:
                                pxls_arr1:ArrayList = CGlobals1.dict_keys_to_arr1(not_exist_pixels)
                                bmp_pxl_no_exist1:Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, (255, 255, 255,0))
                                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp1(pxls_arr1, bmp_pxl_no_exist1)
                                bmp_pxl_no_exist1.Save(CGlobals1.global_path1 + "sobel_pics1\\not_exist_pxls2_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")

                            last_pixels_dict1 = cur_last_pixels_dict1

                            self.save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\added_where_no_slice2_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")




                            arr_of_slice_min_len1 = self.check_if_can_merge_slices_curves3(arr_of_slice_min_len1)

                            self.save_slices_curves_in_bmp1(arr_of_slice_min_len1, CGlobals1.global_path1 + "sobel_pics1\merged2_" + CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1.ToString() + ".bmp")



                            cur_last_pixels_dict1 = self.curves_arrays_to_dict1(arr_of_slice_min_len1)


                            not_exist_pixels = self.compare_dict_of_pixels1(last_pixels_dict1, cur_last_pixels_dict1)

                            if not_exist_pixels.Count > 0:
                                pxls_arr1:ArrayList = CGlobals1.dict_keys_to_arr1(not_exist_pixels)
                                bmp_pxl_no_exist1:Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, (255, 255, 255,0))
                                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp1(pxls_arr1, bmp_pxl_no_exist1)
                                bmp_pxl_no_exist1.Save(CGlobals1.global_path1 + "sobel_pics1\not_exist_pxls3_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".bmp")

                            last_pixels_dict1 = cur_last_pixels_dict1



                            if CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 % 10 == 0:
                                #todo self.crop_by_pxls_arr1(sobel_pixels_arr2, CGlobals1.global_path1 + "sobel_pics1\", CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1)
                                CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1[0: CGlobals1.form_obj1.file_name1.rindex("\\")] + "\\crop_res1\\conture_" + str(CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1) + ".txt", dict_res1["pixels_around_sobel_arr1"]["pixels_cords_arr1"])



                         
                            if CGlobals1.form_obj1.markingfldimg_obj1.cur_sobel_ind_val1 > CGlobals1.form_obj1.sobel_factor1:
                                print("finish!")
                                return 1







                    compute1:str = "yes"
                    if compute1 == "yes":



                        for pixel_ind1 in range(0 , sobel_pixels_arr1.count):

                            dict_colors1:Dictionary = Dictionary()

                            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(sobel_pixels_arr1, pixel_ind1)
                            color1 = bmp_max_diff1.GetPixel(cord_xy1[0], cord_xy1[1])


                            exist_neighboors_with_more_diff1:str = "no"
                            not_same_color_neighboors1:str = "no"
                            
                            
                            count_exist_neighboors_with_more_diff1:int = 0
                            count_not_same_color_neighboors1:int = 0
                            count_search1:int = 0

                            for x1 in range(-padding_search1,padding_search1+1):
                                for y1 in range( -padding_search1 , padding_search1+1):
                                    cur_x1:int = cord_xy1[0] + x1
                                    cur_y1:int = cord_xy1[1] + y1
                                    no_search1:str = "no"
                                    if x1 > -padding_no_search1 and x1 < padding_no_search1 and y1 > -padding_no_search1 and y1 < padding_no_search1:
                                        no_search1 = "yes"

                                    if no_search1 == "no" and cur_x1 > 0 and cur_y1 > 0 and cur_x1 < (bmp_max_diff1.width() - 1) and cur_y1 < (bmp_max_diff1.height() - 1):
                                        count_search1 += 1
                                        color2 = bmp_max_diff1.GetPixel(cord_xy1[0] + x1, cord_xy1[1] + y1)
                                        dict_colors1[str(x1) + "," + str(y1)] = color2[0]
                                        if color2[0] > color1[0]:
                                            exist_neighboors_with_more_diff1 = "yes"
                                            count_exist_neighboors_with_more_diff1 += 1


                                        if color2[0] != color1[0]:
                                            not_same_color_neighboors1 = "yes"
                                            count_not_same_color_neighboors1 += 1







                            color_mono1 = CGlobals1.form_obj1.markingfldimg_obj1.bmp1.GetPixel(cord_xy1[0], cord_xy1[1])
                            exist_neighboors_with_less_color1:str = "no"

                            if exist_neighboors_with_more_diff1 == "no":
                                for x1 in range( -padding_search1 , padding_search1+1):
                                    for y1 in range( -padding_search1 , padding_search1+1):

                                        no_search1:str = "no"
                                        if x1 > -padding_no_search1 and x1 < padding_no_search1 and y1 > -padding_no_search1 and y1 < padding_no_search1:
                                            no_search1 = "yes"

                                        if no_search1 == "no" and (cord_xy1[0] + x1) > 0 and (cord_xy1[1] + y1) > 0 and (cord_xy1(0) + x1) < bmp_max_diff1.Width - 1 and (cord_xy1(1) + y1) < bmp_max_diff1.height() - 1:
                                            color_mono2 = CGlobals1.form_obj1.markingfldimg_obj1.bmp1.GetPixel(cord_xy1[0] + x1, cord_xy1[1] + y1)
                                            if color_mono2[0] < color_mono1[0]:
                                                exist_neighboors_with_less_color1 = "yes"


                            dict_max_diff1:Dictionary = Dictionary()
                            max_diff_cord1:str = ""
                            max_diff_val1:float = 0
                            max_diff_x1:int = -1
                            max_diff_y1:int = -1
                            for x2 in range( -18 , 18+1):
                                for y2 in range( -18 , 18+1):
                                    cur_max_diff_val1:float = self.count_neighboors_with_less_diff1(bmp_max_diff1, (cord_xy1[0] + x2, cord_xy1[1] + y2))
                                    dict_max_diff1[str(x2) + "," + str(y2)] = cur_max_diff_val1

                                    if max_diff_val1 <= cur_max_diff_val1:
                                        max_diff_val1 = cur_max_diff_val1
                                        max_diff_cord1 = str(x2) + "," + str(y2)

                                        max_diff_x1 = cord_xy1[0] + x2
                                        max_diff_y1 = cord_xy1[1] + y2




                            for x3 in range(-2 , 2+1):
                                for y3 in range(-2 , 2+1):
                                    if dict_sobel_pixels1.ContainsKey(str(max_diff_x1 + x3) + "," + str(max_diff_y1 + y3)) == True:
                                        dict_res_sobel_pxls2[str(max_diff_x1 + x3) + "," + str(max_diff_y1 + y3)] = 1

                            


                            if exist_neighboors_with_more_diff1 == "no" and exist_neighboors_with_less_color1 == "no" and not_same_color_neighboors1 == "yes":
                                dict_result_by_sobel_val1[str(cord_xy1[0]) + "," + str(cord_xy1[1])] = 1


                    CGlobals1.current_max_arr_sobel = dict_res1["pixels_around_sobel_arr1"]["pixels_cords_arr1"]





            CGlobals1.step_num1 += 1


