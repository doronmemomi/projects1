from Dictionary import Dictionary
from CPolynom2 import CPolynom2
from CGlobals1 import CGlobals1
import json
import sys
import os
from bitmap import Bitmap
from ArrayList import ArrayList
import math
from vec_3d1 import vec_3d1
from point_3d1 import point_3d1
import inspect

class CPolynom_curve1:
    def __init__(self):
        self.suffix_path1 = "_find_turn_pixel1"
        self.init_poynom_obj1=CPolynom2()
        self.path_of_curve1="E:\\memomi_folder1\\glass_pics_8\\980376340_2\\195768205504__A_frame4b.txt"
        
    def analize_polynom2(self):
        
        
        x5=9
        dict1 =Dictionary()
        dict1["x5"]=98
        locals().update({'x5':97})
        #inspect.currentframe()["x5"]=981
        #sys._getframe(1).f_locals.update(dict1.dict)
        #sys._getframe(1).f_locals.update(dict1.dict)
        inspect.currentframe().f_locals["x5"]=45
        inspect.currentframe().f_back.f_locals["x5"]=11
        x7=inspect.currentframe().f_locals["x5"]

        dict_polynoms1=Dictionary()
        self.init_poynom_obj1.coef_arr1.Add(0)
        self.init_poynom_obj1.coef_arr1.Add(0.9)
        
        self.init_poynom_obj1.coef_arr1.Add(0.00001)
        self.init_poynom_obj1.coef_arr1.Add(0.00001)
        self.init_poynom_obj1.create_derivative1()
        
        self.pre_proccessing_curve2()
        
        
    def pre_proccessing_curve2(self):
        
        if os.path.isfile(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_json_of_curves_slices1.txt") == True:
             str_json3 = CGlobals1.form_obj1.markingfldimg_obj1.read_all_file_text(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_json_of_curves_slices1.txt")
             json_obj1=json.loads(str_json3)
             
             for key in json_obj1.keys():
                 
                dict_json3=Dictionary()
        
        
        
        
        dict_slices_curves1:Dictionary = self.get_slices_of_curves1()
    
    
    
    def get_slices_of_curves1(self):
        
        
        path1=CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        bmp1=Bitmap(4000, 3000,(255,255,255,0))



        frame_pixels_arr1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(self.path_of_curve1)
        
        
        
        dict_rect_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)
        
        
        
        center_x1:int = (dict_rect_frame1["min_x1"] + dict_rect_frame1["max_x1"]) / 2

        ind1:int = 0

        while CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind1)[0] < center_x1:
            ind1 += 1
        
        


        ind2:int = ind1 + 2

        while CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind2)[0] > center_x1:
            ind2 += 1
        
        
        right_frame1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind1, ind2)
        
        
        
        if CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, 0)[1] > CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, right_frame1.count() - 1)[1]:
            right_frame1.Reverse()


        first_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, 0)
        last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, right_frame1.count() - 1)
        
        
        
        right_frame1.Insert(0, str(first_cord_xy1[0] - 1) + "," + str(first_cord_xy1[1]))
        right_frame1.Insert(0, str(first_cord_xy1[0] - 2) + "," + str(first_cord_xy1[1]))

        right_frame1.Add(str(last_cord_xy1[0] - 1) + "," + str(last_cord_xy1[1]))
        right_frame1.Add(str(last_cord_xy1[0] - 2) + "," + str(last_cord_xy1[1]))
        
        
        
        for i1 in range (0,right_frame1.count()):
            right_frame1[i1] = right_frame1[i1] + "," + str(i1)


        cut_pxl_ind_arr1= ArrayList()
        dict_pxls_details1 =  Dictionary()
        

        dict_pxls_details1[2] = Dictionary()
        dict_pxls_details1[2]["pixel_kind1"] = "first_pixel"
        dict_pxls_details1[2]["pixel_ind1"] = 1
        dict_pxls_details1[2]["pixel_ind2"] = 0
        dict_pxls_details1[2]["angle1"] = 90

        dict_pxls_details1[right_frame1.count() - 3] = Dictionary()
        dict_pxls_details1[right_frame1.count() - 3]["pixel_kind1"] = "last_pixel"
        dict_pxls_details1[right_frame1.count() - 3]["pixel_ind1"] = right_frame1.count() - 2
        dict_pxls_details1[right_frame1.count() - 3]["pixel_ind2"] = right_frame1.count() - 1
        dict_pxls_details1[right_frame1.count() - 3]["angle1"] = 90
        
        
        
        dict_state1:Dictionary
        curve1:ArrayList
        sqr_num1_ind1:int
        
        
        for sqr_num1_ind1 in range(1,5):
            
            sqr_num1 = str(sqr_num1_ind1)
            if sqr_num1 == "1":
                


                dict_rect_right_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1, "yes")
                center_min_y1:int = int((dict_rect_right_frame1["inds_of_min_y1"][0] + dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count() - 1]) / 2)
                center_max_y1:int = int((dict_rect_right_frame1["inds_of_max_y1"][0] + dict_rect_right_frame1["inds_of_max_y1"][dict_rect_right_frame1["inds_of_max_y1"].count() - 1]) / 2)
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]] = Dictionary()
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["pixel_kind1"] = "top_pixel"
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["angle1"] = 90
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["pixel_ind1"] = dict_rect_right_frame1["inds_of_min_y1"][0]
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["pixel_ind2"] = dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count() - 1]

                curve1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, 0, center_min_y1)
                dict_state1 = self.build_state_of_sqr_curve1(curve1)
            
            
            
        return 3
    
    
    
    
    
    def build_state_of_sqr_curve1(self,curve1:ArrayList):
        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1

        bmp5:Bitmap =Bitmap(4000,3000,(255,255,255,0))

        cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, 0)
        cord_xy2 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, curve1.count() - 1)


        if cord_xy1[0] < cord_xy2[0]:
            cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, curve1.count() - 1)
            cord_xy2 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, 0)

        angle1 = math.atan((cord_xy2[1] - cord_xy1[1]) / abs((cord_xy2[0] - cord_xy1[0]))) * 180.0 / math.pi


        vec_3d_obj1= vec_3d1()
        vec_3d_obj1.p1 = point_3d1()
        vec_3d_obj1.p1.x1 = cord_xy1[0]
        vec_3d_obj1.p1.y1 = cord_xy1[1]


        vec_3d_obj1.p2 = point_3d1()
        vec_3d_obj1.p2.x1 = cord_xy1[0]
        vec_3d_obj1.p2.y1 = cord_xy1[1]
        vec_3d_obj1.p2.z1 = -10

        rot_curve1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(curve1, vec_3d_obj1, angle1)
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(rot_curve1, bmp5, (24, 230, 50,0))

        bmp5.SaveAs(path1 +  "\\curve1_state1.bmp")

        

        dist_above1:float = 0
        dist_below1:float = 0
        start_with1:str = ""
        for i1 in range(1,rot_curve1.count()):
            cord_xy3 = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve1, i1)
            if cord_xy3[1] > cord_xy1[1]:
                if dist_below1 < abs(cord_xy3[1] - cord_xy1[1]):
                    dist_below1 = abs(cord_xy3[1] - cord_xy1[1])
                    if start_with1 == "":
                        start_with1 = "below"

            if cord_xy3[1] < cord_xy1[1]:

                if dist_above1 < abs(cord_xy3[1] - cord_xy1[1]):
                    dist_above1 = abs(cord_xy3(1) - cord_xy1(1))
                    if start_with1 == "":
                        start_with1 = "above"



        dict_state1:Dictionary = Dictionary()
        if dist_below1 > 1 and dist_above1 > 1:
            dict_state1["has_turn1"] = "yes"
            dict_state1["start_with1"] = start_with1


        return dict_state1



