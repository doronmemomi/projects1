from PIL import Image  
import PIL  


import numpy as np


class Bitmap():
   
       
    def __init__(self, *inp):
        
        if len(inp) == 3:
            self.image1 = Image.new("RGBA",[inp[0],inp[1]],inp[2])
        if len(inp) == 2:
            self.image1 = Image.new("RGBA",[inp[0],inp[1]])
        elif len(inp) == 1:       
            self.image1 = Image.open(inp[0])
        elif len(inp) == 0:       
            self.image1 = Image.new("RGBA",[1,1])
            
        self.pixels=""
        self.pixels_dirty1=False
        self.only_update_on_save_mode=True

    def get_width(self):
        return self.image1.width
    
    width=property(get_width,None) 


    def get_height(self):
        return self.image1.height
    
    height=property(get_height,None) 


    def update_bmp_by_pixels(self):
        
        if self.pixels_dirty1 and not self.only_update_on_save_mode:
            self.image1.putdata(self.pixels)
            self.pixels_dirty1=False
        
        if self.pixels == "":
           self.pixels = list(self.image1.getdata())
           
    
       
    def Load(self,path):
        self.image1=Image.open(path)
        self.pixels_dirty1=False
        
    def SetPixel(self,x1,y1,color1):
        x1=int(x1)
        y1=int(y1)
        if self.pixels=="":
            self.pixels = list(self.image1.getdata())
        
        self.pixels[self.image1.width*y1+x1]=color1
        self.pixels_dirty1=True
        


    def GetPixel(self,x1,y1):
        self.update_bmp_by_pixels()
        
        return self.pixels[self.image1.width*y1+x1]
        
    def SaveAs(self,path):
        
        if self.pixels_dirty1 and self.only_update_on_save_mode:
            self.image1.putdata(self.pixels)
            self.pixels_dirty1=False

        #self.update_bmp_by_pixels()
        
        self.image1.save(path)
        
        
    def clone(self):
        self.update_bmp_by_pixels()

        copy_image1=Bitmap()
        copy_image1.image1=self.image1.copy()
        
        return copy_image1
        
   
    
    
    def paste(self,image_to_paste,left_top_cord_xy):
        self.d1=1
        self.image1.paste(image_to_paste.image1,left_top_cord_xy)
        
        
    def crop(self,left_top_cord_xy):
        self.d1=1
        self.image1=self.image1.crop(left_top_cord_xy)
        