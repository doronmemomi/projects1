﻿Public Class CPolynom1
    Public coef_arr1 As ArrayList = New ArrayList()
    Public polynom_name1 As String = ""
    Public two_degree1 As Double = 1.35


    Public Function clone1()
        Dim new_polynom_obj1 As CPolynom1 = New CPolynom1()
        new_polynom_obj1.coef_arr1 = coef_arr1.Clone()
        new_polynom_obj1.two_degree1 = two_degree1
        new_polynom_obj1.polynom_name1 = polynom_name1

        Return new_polynom_obj1
    End Function
    Public Function get_y_polynom_value1(x_val1 As Double)
        Dim y_val1 As Double = coef_arr1(0) * Math.Pow(x_val1, two_degree1) + coef_arr1(1)

        Return y_val1
    End Function

    Public Function get_x_polynom_degree_2_value_by_y1(y_val1 As Double)
        'Dim y_val1 As Double = coef_arr1(0) * Math.Pow(x_val1, 2) + coef_arr1(1)
        'Math.Pow(x_val1, 2)=(y_val1- coef_arr1(1))/ coef_arr1(0)

        Dim x_val1 As Double = Math.Pow(CType((y_val1 - coef_arr1(1)) / coef_arr1(0), Double), 1 / two_degree1)
        Dim dict_x_val1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)
        dict_x_val1("x_val1") = x_val1
        dict_x_val1("x_val2") = -x_val1
        Return dict_x_val1
    End Function

    Public Function get_polynom_derivate_value1(x_val1 As Double)
        Dim derivate_val1 As Double = coef_arr1(0) * two_degree1 * Math.Pow(x_val1, two_degree1 - 1)

        Return derivate_val1
    End Function

    Public Function get_x_val_by_derivate1(derivate_val1 As Double)
        'derivate_val1=coef_arr1(0)*two_degree1 * Math.pow(x_val1,two_degree1-1)
        Dim x_val1 As Double = Math.Pow(derivate_val1 / (coef_arr1(0) * two_degree1), 1 / (two_degree1 - 1))
        Dim derivate_val2 As Double = coef_arr1(0) * two_degree1 * Math.Pow(x_val1, two_degree1 - 1)
        Dim derivate_val3 As Double = get_polynom_derivate_value1(x_val1)
        If derivate_val3 <> derivate_val1 Then
            Dim diff_erivate1 As Double = derivate_val3 - derivate_val1
        End If

        Return x_val1
    End Function

    Public Function change_coef_2_by_val(x_val1 As Double, y_val1 As Double)
        'derivate_val1=coef_arr1(0) * x_val1
        'Dim y_val1 As Double = coef_arr1(0) * Math.Pow(x_val1, 2) + coef_arr1(1)
        coef_arr1(1) = y_val1 - coef_arr1(0) * Math.Pow(x_val1, two_degree1)

    End Function


End Class
