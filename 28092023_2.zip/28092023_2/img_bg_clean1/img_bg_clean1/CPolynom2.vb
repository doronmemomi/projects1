﻿Public Class CPolynom2
    Public coef_arr1 As ArrayList = New ArrayList()
    Public coef_derivative_arr1 As ArrayList = New ArrayList()

    Public polynom_name1 As String = ""

    Public Shared max_end_x_val1 As Double = 9999999

    Public Function get_polynom_json_str1()
        Dim geresh1 As String = Chr(34)

        Dim i1 As Integer
        Dim poly_json1 As String = ""
        poly_json1 += geresh1 + "coefs" + geresh1 + ":["
        For i1 = 0 To coef_arr1.Count - 1
            If i1 > 0 Then
                poly_json1 += ","
            End If
            poly_json1 += geresh1 + coef_arr1(i1).ToString() + geresh1

        Next
        poly_json1 += "]"
        poly_json1 += "," + geresh1 + "polynom_name1" + geresh1 + ":" + geresh1 + polynom_name1 + geresh1

        Return poly_json1
    End Function

    Public Function clone1()
        Dim polynom_obj1 As CPolynom2 = New CPolynom2()
        polynom_obj1.coef_arr1 = coef_arr1.Clone()
        polynom_obj1.coef_derivative_arr1 = coef_derivative_arr1.Clone()
        Return polynom_obj1
    End Function
    Public Function create_derivative1()
        Dim i1 As Integer
        coef_derivative_arr1 = New ArrayList()
        For i1 = 1 To coef_arr1.Count - 1
            coef_derivative_arr1.Add(coef_arr1(i1) * i1)
        Next

    End Function


    Public Function mul_derivative1(mul1 As Double)
        Dim i1 As Integer
        For i1 = 0 To coef_derivative_arr1.Count - 1
            coef_derivative_arr1(i1) *= mul1
        Next

    End Function
    Public Function mul_coefs1(mul1 As Double)
        Dim i1 As Integer
        For i1 = 0 To coef_arr1.Count - 1
            coef_arr1(i1) *= mul1
        Next

    End Function

    Public Function get_derivative1(x_val1 As Double)
        Dim i1 As Integer
        Dim derivative_val1 As Double = 0
        '0+2*x^1+3*x^2
        '
        For i1 = 0 To coef_derivative_arr1.Count - 1
            derivative_val1 += coef_derivative_arr1(i1) * Math.Pow(x_val1, i1)
        Next

        Return derivative_val1
    End Function
    Public Function is_all_coef_zero_as_least1()
        Dim i1 As Integer
        For i1 = 0 To coef_arr1.Count - 1
            If coef_arr1(i1) < 0 Then
                Return 0
            End If
        Next

        Return 1
    End Function

    Public Function get_y_val1(x_val1 As Double)
        Dim y_val1 As Double = 0
        '0+2*x^1+3*x^2
        '
        For i1 = 0 To coef_arr1.Count - 1
            y_val1 += coef_arr1(i1) * Math.Pow(x_val1, i1)
        Next

        Return y_val1

    End Function
    Public Function find_x_by_derivative_val(derivative_val1 As Double)
        Dim x_val1 As Double = 0

        Dim to_stop1 As Integer = 0
        Dim add_x_val1 As Double = 1
        Dim factor_add_x_val1 As Double = 1
        While to_stop1 = 0
            If get_derivative1(x_val1) < derivative_val1 Then
                x_val1 += factor_add_x_val1
            Else
                x_val1 -= factor_add_x_val1
                factor_add_x_val1 /= 2
            End If
            If factor_add_x_val1 < Math.Pow(10, -12) Then
                to_stop1 = 1
            End If
        End While

        Return x_val1
    End Function


    Public Function find_x_by_derivative_val2(derivative_val1 As Double, start_x_val1 As Double)
        Dim x_val1 As Double = start_x_val1

        Dim to_stop1 As Integer = 0
        Dim add_x_val1 As Double = 1
        Dim factor_add_x_val1 As Double = 1
        Dim last_dir1 As Integer = -1
        Dim deriv_val1 As Double

        Dim count_loop1 As Integer = 0

        If coef_derivative_arr1(0) > derivative_val1 Then
            Return max_end_x_val1
        End If
        While to_stop1 = 0
            deriv_val1 = get_derivative1(x_val1)
            If deriv_val1 < derivative_val1 Then
                x_val1 += factor_add_x_val1
                If last_dir1 = -1 Then
                    factor_add_x_val1 /= 2

                End If
                last_dir1 = 1
            Else
                While (Math.Abs(x_val1) - factor_add_x_val1) <= 0

                    factor_add_x_val1 /= 2
                End While
                x_val1 -= factor_add_x_val1
                If last_dir1 = 1 Then
                    factor_add_x_val1 /= 2

                End If
                last_dir1 = -1
            End If
            If factor_add_x_val1 < Math.Pow(10, -12) Then
                to_stop1 = 1
            End If

            count_loop1 += 1

            If count_loop1 > 99999 Then
                to_stop1 = 1
            End If
        End While

        If Math.Abs(Math.Abs(deriv_val1) - Math.Abs(derivative_val1)) > Math.Pow(10, -10) Then
            Return max_end_x_val1
        End If
        Return x_val1
    End Function

    Public Function change_polynom_coef_and_no_change_x(x_val1 As Integer, coef_num1 As Integer, add_coef_val1 As Double, coef_num_to_compute1 As Integer)
        Dim polynom_obj1 As CPolynom2 = clone1()

        Dim derivative_val1 As Double = get_derivative1(x_val1)

        Dim y_val1 As Double = get_y_val1(x_val1)
        Dim y_val2 As Double = get_y_val1(x_val1 - 100)

        polynom_obj1.coef_arr1(coef_num1) += add_coef_val1

        Dim add_coef_factor1 As Double = 0.00001

        Dim to_stop1 As Integer = 0

        While to_stop1 = 0
            polynom_obj1.create_derivative1()
            Dim derivative_val2 As Double = polynom_obj1.get_derivative1(x_val1)
            If polynom_obj1.is_all_coef_zero_as_least1() = 0 Then
                polynom_obj1.coef_arr1(coef_num_to_compute1) += add_coef_factor1
                add_coef_factor1 /= 2
            Else
                If Math.Abs(derivative_val2) < Math.Abs(derivative_val1) Then
                    polynom_obj1.coef_arr1(coef_num_to_compute1) += add_coef_factor1
                Else
                    polynom_obj1.coef_arr1(coef_num_to_compute1) -= add_coef_factor1
                    If polynom_obj1.coef_arr1(coef_num_to_compute1) < 0 Then
                        polynom_obj1.coef_arr1(coef_num_to_compute1) += add_coef_factor1
                    End If
                    add_coef_factor1 /= 2

                End If

            End If

            If add_coef_factor1 < Math.Pow(10, -13) Then
                to_stop1 = 1
            End If
        End While

        Dim derivative_val1b As Double = polynom_obj1.get_derivative1(x_val1)

        Dim delta_derivative As Double = derivative_val1 - derivative_val1b
        If Math.Abs(delta_derivative) > Math.Pow(10, -5) Then
            Return -9999

        End If
        Dim y_val1b As Double = polynom_obj1.get_y_val1(x_val1)
        Dim y_val2b As Double = polynom_obj1.get_y_val1(x_val1 - 100)

        Dim diff_height1 As Double = Math.Abs(y_val1 - y_val2) - Math.Abs(y_val1b - y_val2b)
        If polynom_obj1.is_all_coef_zero_as_least1() = 0 Then
            Dim err1 As Integer = 1

            Return -9999
        End If
        If Math.Abs(diff_height1) > 100 Then
            Dim d1 As Integer = 1
        End If
        Return diff_height1
    End Function
End Class
