﻿Public Class vec_3d1
    Public p1 As point_3d1
    Public p2 As point_3d1

    Sub New()
        p1 = New point_3d1()
        p2 = New point_3d1()

    End Sub
    Public Function clone1()


        Dim new_point_3d_1 As point_3d1 = New point_3d1()
        new_point_3d_1.x1 = p1.x1
        new_point_3d_1.y1 = p1.y1
        new_point_3d_1.z1 = p1.z1


        Dim new_point_3d_2 As point_3d1 = New point_3d1()
        new_point_3d_2.x1 = p2.x1
        new_point_3d_2.y1 = p2.y1
        new_point_3d_2.z1 = p2.z1

        Dim vec_3d_1 As vec_3d1 = New vec_3d1()

        vec_3d_1.p1 = new_point_3d_1
        vec_3d_1.p2 = new_point_3d_2





        Return vec_3d_1
    End Function

    Public Function compute_xy_by_z1(z_val1 As Double)
        Dim rel1 As Double = (p1.z1 - z_val1) / (p2.z1 - z_val1)
        '(p1.z1-z_val1)=rel1*(p2.z1- z_val1)
        '(-z_val1)=rel1*(p2.z1- z_val1)-p1.z1

        Dim x_val1 As Double = -(rel1 * (p2.x1 - z_val1) - p1.z1)
        Dim rel2 As Double = (p1.x1 - x_val1) / p2.x1
        Dim y_val1 As Double = -(rel1 * p2.y1 - p1.y1)
        Dim rel3 As Double = (p1.y1 - y_val1) / p2.y1

        Return {x_val1, y_val1}
    End Function


    Public Function create_2d_line_equ1()

        Dim m1 As Double = -1
        Dim b1 As Double = -1


        m1 = (p2.y1 - p1.y1) / (p2.x1 - p1.x1)

        'y=m1*x+b1

        b1 = p1.y1 - m1 * p1.x1

        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        dict_ret_res1("m1") = m1
        dict_ret_res1("b1") = b1

        Return dict_ret_res1


    End Function


    Public Function create_2d_line_equ_from_m1_and_xy_cord(xy_cord As Double(), m1_line As Double)

        Dim m1 As Double = -1
        Dim b1 As Double = -1




        'y=m1*x+b1
        'b1=y-m1*x
        b1 = xy_cord(1) - m1_line * xy_cord(0)

        Dim dict_ret_res1 As Dictionary(Of String, Object) = New Dictionary(Of String, Object)

        dict_ret_res1("m1") = m1_line
        dict_ret_res1("b1") = b1

        Return dict_ret_res1


    End Function




End Class
