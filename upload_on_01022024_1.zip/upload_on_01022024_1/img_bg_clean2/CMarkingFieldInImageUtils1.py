from ArrayList import ArrayList
from vec_3d1 import vec_3d1
from point_3d1 import point_3d1
from bitmap import Bitmap
from Dictionary import Dictionary

from StringBuilder import StringBuilder
from CFile1 import CFile1
import math

class CMarkingFieldInImageUtils1:


    def set_pixel_arr_on_bmp2(pixels_arr1:ArrayList, bmp1:Bitmap, color_to_set1):
        

        for i1 in range(0,pixels_arr1.count):
            try:
            


                x1 = float(pixels_arr1[i1].split(",")[0])
                y1 = float(pixels_arr1[i1].split(",")[1])
                if x1 >= 0 and x1 < bmp1.width and y1 >= 0 and y1 < bmp1.height:
                    bmp1.SetPixel(x1, y1, color_to_set1)


            except:
                try:
                    x1 = float(pixels_arr1[i1].split(",")[0])
                    y1 = float(pixels_arr1[i1].split(",")[1])
                    if x1 >= 0 and x1 < bmp1.width and y1 >= 0 and y1 < bmp1.height:
                        bmp1.SetPixel(x1, y1, color_to_set1)


                except:
                    dummy1=1





    def rgb_to_monochrome1(bmp1:Bitmap):
        
       
        bmp2:Bitmap = bmp1.clone()
        for x1 in range(0,bmp1.width):
            for y1 in range(0,bmp1.height):
                color1 = bmp1.GetPixel(x1, y1)
                color2 = (0.3 * color1[0] + 0.59 * color1[1] + 0.11 * color1[2])
                color2=int(color2)
                bmp2.SetPixel(x1, y1, (color2, color2, color2,0))
                
            ly1=y1
        return bmp2
    
    def rotate_2d_pixels_arr(pixels_arr1:ArrayList, arbitrary_3d_axis:vec_3d1, rot_angle1):

        new_2d_pixels_arr1:ArrayList = ArrayList()

        for i1 in range(0,pixels_arr1.count ):
            
            point_3d_obj1:point_3d1 = point_3d1(float(str(pixels_arr1[i1].split(",")[0])), float(str(pixels_arr1[i1].split(",")[1])), 0)

            if len(pixels_arr1[i1].split(",")) == 3:
                point_3d_obj1 = point_3d1(float(str(pixels_arr1[i1].split(",")[0])), float(str(pixels_arr1[i1].split(",")[1])), float(pixels_arr1[i1].split(",")[2]))


            CMarkingFieldInImageUtils1.rotate_around_arbitrary_axis(arbitrary_3d_axis, point_3d_obj1, rot_angle1)
            if len(pixels_arr1[i1].split(",")) == 3:
                new_2d_pixels_arr1.Add(str(point_3d_obj1.x1) + "," + str(point_3d_obj1.y1) + "," + str(point_3d_obj1.z1))
            else:
                new_2d_pixels_arr1.Add(str(point_3d_obj1.x1) + "," + str(point_3d_obj1.y1))



        return new_2d_pixels_arr1
    
    
    
    
    
    
    
    def rotate_around_arbitrary_axis(in_vec_3d_1:vec_3d1, in_rotate_p1:point_3d1, rot_deg_around_axis1:float):
        delta_x1 = float(in_vec_3d_1.p1.x1)
        delta_y1 = float(in_vec_3d_1.p1.y1)
        delta_z1 = float(in_vec_3d_1.p1.z1)

        vec_3d_1:vec_3d1 = in_vec_3d_1.clone1()
        rotate_p1:point_3d1 = in_rotate_p1.clone1()

        vec_3d_1.p1.x1 -= float(delta_x1)
        vec_3d_1.p1.y1 -= float(delta_y1)
        vec_3d_1.p1.z1 -= float(delta_z1)


        vec_3d_1.p2.x1 -= float(delta_x1)
        vec_3d_1.p2.y1 -= float(delta_y1)
        vec_3d_1.p2.z1 -= float(delta_z1)

        rotate_p1.x1 -= float(delta_x1)
        rotate_p1.y1 -= float(delta_y1)
        rotate_p1.z1 -= float(delta_z1)


        rot_deg1 = math.atan(vec_3d_1.p2.y1 / vec_3d_1.p2.z1) / (math.pi / 180.0)
        
        if vec_3d_1.p2.z1 == 0:
            rot_deg1 = 90

        vec_3d_1.p1.rotate_x1(rot_deg1)
        vec_3d_1.p2.rotate_x1(rot_deg1)
        rotate_p1.rotate_x1(rot_deg1)





        rot_deg2 = -math.atan(float(vec_3d_1.p2.x1) / float(vec_3d_1.p2.z1)) / (math.pi / 180.0)
        if vec_3d_1.p2.z1 == 0:
            rot_deg2 = 90
   
    

        vec_3d_1.p1.rotate_y1(rot_deg2)
        vec_3d_1.p2.rotate_y1(rot_deg2)
        rotate_p1.rotate_y1(rot_deg2)


        vec_3d_1.p1.rotate_z1(rot_deg_around_axis1)
        vec_3d_1.p2.rotate_z1(rot_deg_around_axis1)
        rotate_p1.rotate_z1(rot_deg_around_axis1)


        vec_3d_1.p1.rotate_y1(-rot_deg2)
        vec_3d_1.p2.rotate_y1(-rot_deg2)
        rotate_p1.rotate_y1(-rot_deg2)

        vec_3d_1.p1.rotate_x1(-rot_deg1)
        vec_3d_1.p2.rotate_x1(-rot_deg1)
        rotate_p1.rotate_x1(-rot_deg1)



        vec_3d_1.p1.x1 += float(delta_x1)
        vec_3d_1.p1.y1 += float(delta_y1)
        vec_3d_1.p1.z1 += float(delta_z1)


        vec_3d_1.p2.x1 += float(delta_x1)
        vec_3d_1.p2.y1 += float(delta_y1)
        vec_3d_1.p2.z1 += float(delta_z1)

        rotate_p1.x1 += float(delta_x1)
        rotate_p1.y1 += float(delta_y1)
        rotate_p1.z1 += float(delta_z1)

        in_rotate_p1.x1 = float(rotate_p1.x1)
        in_rotate_p1.y1 = float(rotate_p1.y1)
        in_rotate_p1.z1 = float(rotate_p1.z1)




    def create_pixel_arr_line_from_2_2d_points2(cord_xy1, cord_xy2):
        return CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points(cord_xy1[0], cord_xy1[1], cord_xy2[0], cord_xy2[1])

    def create_pixel_arr_line_from_2_2d_points(start_x1:float, start_y1:float, end_x1:float, end_y1:float):
        pixel_arr1:ArrayList = ArrayList()

        start_x2:float = start_x1
        start_y2:float = start_y1
        end_x2:float = end_x1
        end_y2:float = end_y1

        if start_x1 > end_x1:
            start_x2 = end_x1
            start_y2 = end_y1
            end_x2 = start_x1
            end_y2 = start_y1

        dir_y1:float = 1
        if start_y2 > end_y2:
            dir_y1 = -1

        right_x1:float = end_x2
        right_y1:float = end_y2
        min_y1:float = min(start_y2, end_y2)
        max_y1:float = max(start_y2, end_y2)


        min_x1:float = min(start_x2, end_x2)
        max_x1:float = max(start_x2, end_x2)

        m1:float =9999
        try:
            if (end_x1 - start_x1)!=0:
                m1 =((end_y1 - start_y1) ) / ((end_x1 - start_x1) )
            else:
                m1=9999    
        except:
            m1=9999

        try:
            if (end_y1 - start_y1)!=0:
                m2 =((end_x1 - start_x1) ) / ((end_y1 - start_y1) )
            else:
                m2 =9999  
        except:
            m2 =9999
        
        add_to_start1:bool = False

        if start_x2 == end_x1:
            if start_x2 != start_x1:

                add_to_start1 = True

        if start_x2 == max_x1:
            m2 = -abs(m2)

        else:
            m2 = abs(m2)

        not_to_stop1:bool=True


        x2_val1a:int = math.floor(start_x2)
        y2_val1a:int = math.floor(start_y2)
        x2_val1a = round(start_x2)
        y2_val1a = round(start_y2)
        pixel_arr1.Add(str(x2_val1a) + "," + str(y2_val1a))

        while not_to_stop1:
            if abs(m1) <= 1:
                start_x2 += 1
                start_y2 += m1
            else:
                start_x2 += m2
                start_y2 += dir_y1

            
            if start_x2 > max_x1 or start_x2 < min_x1 or start_y2 > max_y1 or start_y2 < min_y1:

                if add_to_start1:
                    if pixel_arr1[0] != (str(start_x1) + "," + str(start_y1)):
                        pixel_arr1.Insert(0, str(start_x1) + "," + str(start_y1))

                    if pixel_arr1[pixel_arr1.count - 1] != (str(end_x1) + "," + str(end_y1)):
                        pixel_arr1.Add(str(end_x1) + "," + str(end_y1))


                not_to_stop1 = False
            else:
                x2_val1:int = math.floor(start_x2)
                y2_val1:int = math.floor(start_y2)
                if add_to_start1:
                    pixel_arr1.Insert(0, str(x2_val1) + "," + str(y2_val1))
                else:

                    pixel_arr1.Add(str(x2_val1) + "," + str(y2_val1))


        return pixel_arr1



    def complete_uncomplete_pixels_curve_with_lines(self1,un_complete_curve1:ArrayList):

        from CGlobals1 import CGlobals1
        
        new_complete_curve1:ArrayList = ArrayList()
        last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(un_complete_curve1, 0)
        new_complete_curve1.Add(str(last_cord_xy1[0]) + "," + str(last_cord_xy1[1]))
        for i1 in range( 1 , un_complete_curve1.count ):

            new_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(un_complete_curve1, i1)


            connect_to_last_pixel1:bool=False 
            for x1 in range(last_cord_xy1[0] - 1 , last_cord_xy1[0]+ 1+1):
                for y1 in range(last_cord_xy1[1] - 1 , last_cord_xy1[1] + 1+1):
                    if new_cord_xy1[0] == x1 and new_cord_xy1[1] == y1:
                        connect_to_last_pixel1 = True

            if connect_to_last_pixel1:
                new_complete_curve1.Add(str(new_cord_xy1[0]) + "," + str(new_cord_xy1[1]))
            else:

                if new_complete_curve1.count > 1:
                    dict_res1:Dictionary = CMarkingFieldInImageUtils1.find_the_tangent_to_curve_from_cord_ind(self1,new_complete_curve1, 0)
                    curve_arr1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(dict_res1["rot_curve_pixels"], dict_res1["cord_ind1"], dict_res1["last_cord_ind1"])
                    good_curve1:bool=True
                    false_positive_cords_arr1:ArrayList = ArrayList()
                    
                    cord_xy3a = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, 0)

                    for i2 in range(0 , curve_arr1.count ):
                        cord_xy3b  = CGlobals1.get_cord_xy_in_pixels_arr1(curve_arr1, i2)
                        if cord_xy3b[0] < cord_xy3a[0]:
                            good_curve1 = False
                            false_positive_cords_arr1.Add(new_complete_curve1[i2])

                    if false_positive_cords_arr1.Count > 3:
                        dict_res4:Dictionary = Dictionary()
                        dict_res4["new_complete_curve1"] = new_complete_curve1
                        dict_res4["false_positive_cords_arr1"] = false_positive_cords_arr1
                        return dict_res4


                pixels_line1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points2(last_cord_xy1, new_cord_xy1)





                for i2 in range(1 , pixels_line1.count - 2+1):
                    new_complete_curve1.Add(str(pixels_line1[i2]))

                new_complete_curve1.Add(str(new_cord_xy1[0]) + "," + str(new_cord_xy1[1]))
                dict_res2:Dictionary = CGlobals1.form_obj1.markingfldimg_obj1.find_the_tangent_to_curve_from_cord_ind(self,new_complete_curve1, 0)


            last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(un_complete_curve1, i1)

        dict_res3:Dictionary = Dictionary()
        dict_res3["new_complete_curve1"] = new_complete_curve1
        return dict_res3




    def find_the_tangent_to_curve_from_cord_ind(self1,curve_pixels1:ArrayList, cord_ind1:int):
        from CGlobals1 import CGlobals1   
        debug_mode1:bool=False    
        last_cord_ind1:int = curve_pixels1.count - 1

        not_to_stop1:bool=True   
        dict_cords1:Dictionary = CGlobals1.conv_2d_arr_to_2d_cords_dict1(curve_pixels1)
        while not_to_stop1:
            cord_xy1 = dict_cords1[cord_ind1]
            last_cord_xy1 = dict_cords1[last_cord_ind1]
            pixel_line_arr1:ArrayList = CMarkingFieldInImageUtils1.create_pixel_arr_line_from_2_2d_points2(cord_xy1, last_cord_xy1)


            vec_3d_obj1:vec_3d1 = vec_3d1()
            vec_3d_obj1.p1 = point_3d1(cord_xy1[0], cord_xy1[1], 0)
            vec_3d_obj1.p2 = point_3d1(cord_xy1[0], cord_xy1[1], 10)

            angle1:float = math.atan((cord_xy1[1] - last_cord_xy1[1]) / (cord_xy1[0] - last_cord_xy1[0])) * 180 / math.pi

            curve_pixels_r1:ArrayList = CMarkingFieldInImageUtils1.rotate_2d_pixels_arr(curve_pixels1, vec_3d_obj1, 90 - angle1)

            dict_cords_r1:Dictionary = CGlobals1.conv_2d_arr_to_2d_cords_dict1(curve_pixels_r1)

            no_tangent1:bool=False    
            i2:int = cord_ind1
            while not no_tangent1 and i2 <= curve_pixels_r1.count - 1:
                cord_xy2 = dict_cords_r1(i2)
                if cord_xy2[0] > cord_xy1[0]:
                    no_tangent1 = True
                i2 += 1
            

            if no_tangent1:
                last_cord_ind1 -= 1
            else:
                if debug_mode1:


                    bmp1:Bitmap = Bitmap(4000, 2500, (255, 255, 255,0))

                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pixels_r1, bmp1, (200, 40, 150,0))

                    CMarkingFieldInImageUtils1.set_pixel_arr_on_bmp2(curve_pixels_r1, bmp1, (200, 40, 150,0))

                    bmp1.Save(CGlobals1.global_path1 + "sobel_pics1\\t_angle_1.bmp")
                
                not_to_stop1 = False

                dict_res1:Dictionary = Dictionary()
                dict_res1["cord_ind1"] = cord_ind1
                dict_res1["last_cord_ind1"] = last_cord_ind1
                dict_res1["rot_curve_pixels"] = curve_pixels_r1

                return dict_res1



    def get_dist_between_2_cords_xy1(cord_xy1, cord_xy2):
        dist1:float = pow(pow(cord_xy1[0] - cord_xy2[0], 2) + pow(cord_xy1[1] - cord_xy2[1], 2), 0.5)
        return dist1
    
    def filter_sub_curves_arr1(sub_curves_arr1:ArrayList):
        from CGlobals1 import CGlobals1

        new_sub_curve_arr1:ArrayList = ArrayList()
        new_curve1:ArrayList = ArrayList()
        for i1 in range( 0 , sub_curves_arr1.count):
            
            sub_curve1:ArrayList = sub_curves_arr1[i1]
            good_curve1:bool=True    
            if sub_curve1.count >= 3:

                last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, 0)
                for i2 in range(1 , sub_curve1.count ):
                    cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, i2)
                    if last_cord_xy1[1] > cord_xy1[1]:
                        good_curve1 = False

                    last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(sub_curve1, i2)
            else:
                good_curve1 = False

            if good_curve1:
                new_sub_curve_arr1.Add(sub_curve1)

                for i2 in range(0 , sub_curve1.count):
                    new_curve1.Add(sub_curve1[i2])

        dict_res1:Dictionary = Dictionary()
        dict_res1["new_curve1"] = new_curve1
        dict_res1["new_sub_curve_arr1"] = new_sub_curve_arr1
        return dict_res1

