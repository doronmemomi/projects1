class ArrayList:
    def __init__(self):
        print("init1")
        self.arr=[]
        return
       
    def count(self):
        return len(self.arr)
    
    def Add(self,obj1):
        self.arr.append(obj1)
        return 1
    def __setitem__(self, key,value):
        self.arr[key]=value
        
    def print(self):
        print(self.arr)
        return 1
   
    def __getitem__(self, ind):
        return self.arr[ind]
    
    
    def RemoveAt(self, ind):
        del self.arr[ind]
    
    
    def Reverse(self):
        self.arr.reverse()

    def Insert(self,ind1,obj1):
        self.arr.insert(ind1,obj1)