
from ArrayList import ArrayList
from vec_3d1 import vec_3d1
from point_3d1 import point_3d1
import decimal

import math


class CMarkingFieldInImage1:
    
    def __init__(self):
        self.d1=1
        
        
    def read_all_file_text(self,path):
        file = open(path,mode='r')
        text1 = file.read()
        file.close()
        
        return text1
        
    def load_2d_pixels_arr1(self,path_of_file):
        str_pnts_arr1:str=self.read_all_file_text(path_of_file)
        str_pnds_cord_2d=str_pnts_arr1.split("#")
        
        arr_2d_points=ArrayList()
        
        for i1 in range(len(str_pnds_cord_2d)):
            if len(str(str_pnds_cord_2d[i1])) > 2:
                x1=int(str(str_pnds_cord_2d[i1]).split(",")[0])
                y1=int(str(str_pnds_cord_2d[i1]).split(",")[1])
                arr_2d_points.Add(str(x1) + "," + str(y1))
        next
        
        
        return arr_2d_points
    
    
    
    
    
    def rotate_2d_pixels_arr(self,pixels_arr1:ArrayList, arbitrary_3d_axis:vec_3d1, rot_angle1):

        new_2d_pixels_arr1:ArrayList = ArrayList()

        for i1 in range(0,pixels_arr1.count() - 1):
            
            point_3d_obj1:point_3d1 = point_3d1(decimal.Decimal(str(pixels_arr1[i1].split(",")[0])), decimal.Decimal(str(pixels_arr1[i1].split(",")[1])), 0)

            if len(pixels_arr1[i1].split(",")) == 3:
                point_3d_obj1 = point_3d1(decimal(pixels_arr1[i1].split(",")[0]), decimal(pixels_arr1[i1].split(",")[1]), decimal(pixels_arr1[i1].split(",")[2]))


            self.rotate_around_arbitrary_axis(arbitrary_3d_axis, point_3d_obj1, rot_angle1)
            if len(pixels_arr1[i1].split(",")) == 3:
                new_2d_pixels_arr1.Add(str(point_3d_obj1.x1) + "," + str(point_3d_obj1.y1) + "," + str(point_3d_obj1.z1))
            else:
                new_2d_pixels_arr1.Add(str(point_3d_obj1.x1) + "," + str(point_3d_obj1.y1))



        return new_2d_pixels_arr1
    
    
    
    
    
    
    
    def rotate_around_arbitrary_axis(self,in_vec_3d_1:vec_3d1, in_rotate_p1:point_3d1, rot_deg_around_axis1:decimal):
        delta_x1 = in_vec_3d_1.p1.x1
        delta_y1 = in_vec_3d_1.p1.y1
        delta_z1 = in_vec_3d_1.p1.z1

        vec_3d_1:vec_3d1 = in_vec_3d_1.clone1()
        rotate_p1:point_3d1 = in_rotate_p1.clone1()

        vec_3d_1.p1.x1 -= delta_x1
        vec_3d_1.p1.y1 -= delta_y1
        vec_3d_1.p1.z1 -= delta_z1


        vec_3d_1.p2.x1 -= delta_x1
        vec_3d_1.p2.y1 -= delta_y1
        vec_3d_1.p2.z1 -= delta_z1

        rotate_p1.x1 -= delta_x1
        rotate_p1.y1 -= delta_y1
        rotate_p1.z1 -= delta_z1


        rot_deg1 = math.atan(vec_3d_1.p2.y1 / vec_3d_1.p2.z1) / (math.pi / 180.0)
        
        if vec_3d_1.p2.z1 == 0:
            rot_deg1 = 90

        vec_3d_1.p1.rotate_x1(rot_deg1)
        vec_3d_1.p2.rotate_x1(rot_deg1)
        rotate_p1.rotate_x1(rot_deg1)





        rot_deg2 = -math.atan(vec_3d_1.p2.x1 / vec_3d_1.p2.z1) / (math.pi / 180.0)
        if vec_3d_1.p2.z1 == 0:
            rot_deg2 = 90
   
    

        vec_3d_1.p1.rotate_y1(rot_deg2)
        vec_3d_1.p2.rotate_y1(rot_deg2)
        rotate_p1.rotate_y1(rot_deg2)


        vec_3d_1.p1.rotate_z1(rot_deg_around_axis1)
        vec_3d_1.p2.rotate_z1(rot_deg_around_axis1)
        rotate_p1.rotate_z1(rot_deg_around_axis1)


        vec_3d_1.p1.rotate_y1(-rot_deg2)
        vec_3d_1.p2.rotate_y1(-rot_deg2)
        rotate_p1.rotate_y1(-rot_deg2)

        vec_3d_1.p1.rotate_x1(-rot_deg1)
        vec_3d_1.p2.rotate_x1(-rot_deg1)
        rotate_p1.rotate_x1(-rot_deg1)



        vec_3d_1.p1.x1 += delta_x1
        vec_3d_1.p1.y1 += delta_y1
        vec_3d_1.p1.z1 += delta_z1


        vec_3d_1.p2.x1 += delta_x1
        vec_3d_1.p2.y1 += delta_y1
        vec_3d_1.p2.z1 += delta_z1

        rotate_p1.x1 += delta_x1
        rotate_p1.y1 += delta_y1
        rotate_p1.z1 += delta_z1

        in_rotate_p1.x1 = rotate_p1.x1
        in_rotate_p1.y1 = rotate_p1.y1
        in_rotate_p1.z1 = rotate_p1.z1


    