import math

class point_3d1:

    
    
    
        
    def __init__(self,in_x1,in_y1,in_z1):
        self.x1 = in_x1
        self.y1 = in_y1
        self.z1 = in_z1
        
        
    def __init__(self):
        self.dummy1=1
        
        
    def clone1(self):
        new_point_3d:point_3d1 =point_3d1(self.x1, self.y1, self.z1)

        return new_point_3d



    def rotate_x1(self,rot_deg1):
        rot_deg2  = rot_deg1 * math.pi / 180.0
        new_y1 = y1 * math.cos(rot_deg2) - z1 * math.sin(rot_deg2)
        new_z1 = y1 * math.Sin(rot_deg2) + z1 * math.Cos(rot_deg2)
        y1 = new_y1
        z1 = new_z1



    def rotate_y1(self,rot_deg1):
        rot_deg2 = rot_deg1 * math.pi / 180.0
        new_z1 = z1 * math.cos(rot_deg2) - x1 * math.sin(rot_deg2)
        new_x1 = z1 * math.sin(rot_deg2) + x1 * math.cos(rot_deg2)
        z1 = new_z1
        x1 = new_x1



    def rotate_z1(self,rot_deg1):
        rot_deg2 = rot_deg1 * math.pi / 180.0
        new_x1 = x1 * math.cos(rot_deg2) - y1 * math.sin(rot_deg2)
        new_y1 = x1 * math.sin(rot_deg2) + y1 * math.cos(rot_deg2)
        x1 = new_x1
        y1 = new_y1


    