from point_3d1 import point_3d1
from Dictionary import Dictionary

class vec_3d1:

    def __init__(self):
        self.p1 = point_3d1()
        self.p2 = point_3d1()



    
        
        
    def clone1(self):


        new_point_3d_1:point_3d1 = point_3d1()
        new_point_3d_1.x1 = self.p1.x1
        new_point_3d_1.y1 = self.p1.y1
        new_point_3d_1.z1 = self.p1.z1


        new_point_3d_2:point_3d1 = point_3d1()
        new_point_3d_2.x1 = self.p2.x1
        new_point_3d_2.y1 = self.p2.y1
        new_point_3d_2.z1 = self.p2.z1

        vec_3d_1:vec_3d1 = vec_3d1()

        vec_3d_1.p1 = new_point_3d_1
        vec_3d_1.p2 = new_point_3d_2





        return vec_3d_1
    
    
    def create_2d_line_equ1(self):

        m1 = -1
        b1 = -1


        m1 = (self.p2.y1 - self.p1.y1) / (self.p2.x1 - self.p1.x1)

        #y=m1*x+b1

        b1 = self.p1.y1 - m1 * self.p1.x1

        dict_ret_res1:Dictionary = Dictionary()

        dict_ret_res1["m1"] = m1
        dict_ret_res1["b1"] = b1

        return dict_ret_res1


    
    
    def create_2d_line_equ_from_m1_and_xy_cord(self,xy_cord, m1_line):

        m1 = -1
        b1 = -1




        #y=m1*x+b1
        #b1=y-m1*x
        b1 = xy_cord(1) - m1_line * xy_cord(0)

        dict_ret_res1:Dictionary = Dictionary()

        dict_ret_res1["m1"] = m1_line
        dict_ret_res1["b1"] = b1

        return dict_ret_res1


  

    
    
    
    
    
    
    