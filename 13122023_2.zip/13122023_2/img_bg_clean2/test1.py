class test1:
    def __init__(self):
        print("init1")
        
        return