from CMarkingFieldInImage1 import CMarkingFieldInImage1
from CMacros1 import CMacros1


class CForm1:
    
    def __init__(self):
        self.file_name1="980376340_2\\195768205504__A"
        self.markingfldimg_obj1=CMarkingFieldInImage1()
        self.macros_obj1=CMacros1()