from PIL import Image  
import PIL  


import numpy as np


class Bitmap():
    #def __init__(self, width = 40, height = 40, background=(255,255,255,0)):
    #def __init__(self, width = 40, height = 40):
       #self.image1 = Image.new("RGBA",[width,height])
    def __init__(self, path:str):
        self.image1 = Image.open(path)
        
        
        
    def __init__(self, width:int, height:int ,color):
       self.image1 = Image.new("RGBA",[width,height],color)
       
    
       
    def Load(self,path):
        self.image1=Image.open(path)
        
    def SetPixel(self,x1,y1,color1):
        pixels = list(self.image1.getdata())
        
        pixels[self.image1.width*y1+x1]=(100,0,0,255) 
        self.image1.putdata(pixels)


    def GetPixel(self,x1,y1):
        pixels = list(self.image1.getdata())
        
        return pixels[self.image1.width*y1+x1]
        
    def SaveAs(self,path):
        self.image1.save(path)

    def clone(self):
            copy_image1=self.image1.copy()
            return copy_image1
        