from Dictionary import Dictionary
from CPolynom2 import CPolynom2
from CGlobals1 import CGlobals1
import json
import sys
import os
from bitmap import Bitmap
from ArrayList import ArrayList
import math
from vec_3d1 import vec_3d1
from point_3d1 import point_3d1
import inspect

class CPolynom_curve1:
    def __init__(self):
        
        
        
        self.suffix_path1 = "_find_turn_pixel1"
        self.init_poynom_obj1=CPolynom2()
        self.path_of_curve1="E:\\memomi_folder1\\glass_pics_8\\980376340_2\\195768205504__A_frame4b.txt"
        


        self.assembly_part1:str = "front_frame1"
        
        self.curve_ind3=0


        self.force_compute_derivs1 = True








    def check_dist_curve_with_line_m2(self,org_curve1:ArrayList, start_ind1:int, end_ind1:int, start_measure_ind1:int, step_x1:float, m1:float, do_log1:bool = False):


        start_y_val1:float = 0
        last_ind_polynom_below_curve1:int
        last_ind_polynom_on_curve1:int
        first_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, start_ind1)
        max_dist_curve_above_polynom1:float = -1
        max_dist_curve_on_polynom1:float = -1
        line_curve1:ArrayList = ArrayList()
        curve_pxls1:ArrayList = ArrayList()
        start_delta_x1:int = -9999

        dict_max_y_of_curve1:Dictionary = Dictionary()
        dict_max_y_of_line1:Dictionary = Dictionary()

        dict_rect1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(org_curve1)



        org_curve1 = self.flip_curve_horizontal1(org_curve1)


        max_x1:float = dict_rect1["max_x1"]
        min_y1:float = dict_rect1["min_y1"]
        max_x2:float = dict_rect1["min_x1"] + 25


        start_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, start_ind1)

        if max_x2 == start_cord_xy1[0]:
            max_x2 += 1

        max_y1:float = (max_x1 - start_cord_xy1[0]) * m1 + start_cord_xy1[1]
        max_y2:float = (max_x2 - start_cord_xy1[0]) * m1 + start_cord_xy1[1]

        y_line1a:float = CGlobals1.form_obj1.markingfldimg_obj1.get_line_x_by_y1(m1, start_cord_xy1[1], (max_x1 - start_cord_xy1[0]))




        line_2_pixels:ArrayList = ArrayList()
        vec_3d_obj1:vec_3d1 = vec_3d1()
        vec_3d_obj1.p1 = point_3d1()
        vec_3d_obj1.p1.x1 = start_cord_xy1[0]
        vec_3d_obj1.p1.y1 = start_cord_xy1[1]
        vec_3d_obj1.p1.z1 = 0

        vec_3d_obj1.p2 = point_3d1()
        vec_3d_obj1.p2.x1 = start_cord_xy1[0]
        vec_3d_obj1.p2.y1 = start_cord_xy1[1]
        vec_3d_obj1.p2.z1 = -10

        line_2_pixels.Add(point_3d1(start_cord_xy1[0], start_cord_xy1[1], 0))
        line_2_pixels.Add(point_3d1(max_x2, max_y2, 0))

        line_2_pixels_2:ArrayList = ArrayList()

        line_2_pixels_2.Add(line_2_pixels[0].clone())
        line_2_pixels_2.Add(line_2_pixels[1].clone())
        CGlobals1.form_obj1.markingfldimg_obj1.rotate_3d_points_arr2(line_2_pixels_2, vec_3d_obj1, -90)


        vec_3d_obj2:vec_3d1 = vec_3d1()
        vec_3d_obj2.p1 = line_2_pixels_2[0]
        vec_3d_obj2.p2 = line_2_pixels_2[1]

        vec_3d_obj3:vec_3d1 = vec_3d1()


        dict_line1:Dictionary = vec_3d_obj2.create_2d_line_equ1()

        m_line2:float = (line_2_pixels_2[0].y1 - line_2_pixels_2[1].y1) / (line_2_pixels_2[0].x1 - line_2_pixels_2[1].x1)

        #y=m_line2*x1+b =>b=y-m_line2*x1
        rot_pxl_line1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points_in_double_with_len_limit1(line_2_pixels_2[0].x1, line_2_pixels_2[0].y1, line_2_pixels_2[1].x1, line_2_pixels_2[1].y1, 20)

        m_rot_line1:float = CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, rot_pxl_line1.count - 1)[1] - CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, 0)[1]
        m_rot_line1 /= CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, rot_pxl_line1.count - 1)[0] - CGlobals1.get_cord_xy_in_pixels_arr1(rot_pxl_line1, 0)[0]


        CGlobals1.form_obj1.markingfldimg_obj1.compute_cut_line_point1(dict_line1["m1"], dict_line1["b1"], m1, start_cord_xy1[1])


        pxls_line_vals1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points_in_double_with_len_limit1(start_cord_xy1[0], start_cord_xy1[1], max_x1, max_y1, 400)
        pxls_line1:ArrayList = ArrayList()
        if do_log1 :
            pxls_line1 = CGlobals1.form_obj1.markingfldimg_obj1.create_pixel_arr_line_from_2_2d_points_with_len_limit(start_cord_xy1[0], start_cord_xy1[1], max_x1, max_y1, 1000)


        log_img1:bool = True
        bmp1d:Bitmap = CGlobals1.create_fill_bitmap(3000, 2000, (255, 255, 255,0))

        if do_log1:

            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(org_curve1, bmp1d, (250, 100, 50,0))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(pxls_line1, bmp1d, (50, 100, 150,0))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(rot_pxl_line1, bmp1d, (250, 150, 150,0))



            bmp1d.SaveAs(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "log_line1\\line_m3_" + str(m1) + ".bmp")




        dict_line_eqa2:Dictionary = vec_3d_obj3.create_2d_line_equ_from_m1_and_xy_cord((start_cord_xy1[0], start_cord_xy1[1]), m1)


        ind1:int
        start_pxl_line_ind:int = 0

        max_dist_pxl_line_below_curve1:float = -1

        min_dist1:float = -1

        not_to_stop1:bool = True
        ind1 = start_ind1 + start_measure_ind1
        m_dist_line_arr1:ArrayList = ArrayList()
        while not_to_stop1:

            curve_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(org_curve1, ind1)

            dict_line_eqa1:Dictionary = vec_3d_obj3.create_2d_line_equ_from_m1_and_xy_cord((curve_cord_xy1[0], curve_cord_xy1[1]), m_line2)



            dict_cut_cord_xy1:Dictionary = CGlobals1.form_obj1.markingfldimg_obj1.compute_cut_line_point1(dict_line_eqa1["m1"], dict_line_eqa1["b1"], dict_line_eqa2["m1"], dict_line_eqa2["b1"])

            m_dist_line:float = (dict_cut_cord_xy1["y"] - curve_cord_xy1[1]) / abs((dict_cut_cord_xy1["x"] - curve_cord_xy1[0]))
            m_dist_line_arr1.Add(str(m_dist_line) + ",x=>" + str(dict_cut_cord_xy1["x"]) + "," + str(curve_cord_xy1[0]) + ",y=>" + str(dict_cut_cord_xy1["y"]) + "," + str(curve_cord_xy1[1]))
            y_val_line1:float = (curve_cord_xy1[0] - start_cord_xy1[0]) * m1 + start_cord_xy1[1]

            if m_dist_line < 0:
                dist2:float = CGlobals1.form_obj1.markingfldimg_obj1.get_dist_between_2_cords_xy2((dict_cut_cord_xy1["x"], dict_cut_cord_xy1["y"]), (curve_cord_xy1[0], curve_cord_xy1[1]))

                if min_dist1 < dist2:
                    min_dist1 = dist2

            not_to_stop2:bool = True



            ind1 += 1
            if ind1 >= org_curve1.count - 1:
                not_to_stop1 = False

        return min_dist1














    def compute_derivate_of_pixel_on_curve(self,curve_pxls_arr1:ArrayList, pxl_ind1:int, start_measure_ind1:int,  max_dist_from_curve1:float = 0.05, start_m2:float = 907):

        start_ind2:int = pxl_ind1
        m2:float = self.check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + 100, start_measure_ind1, 1, start_m2)
        add_factor1:float = -1
        eps1:float = pow(10, -10)


        do_log1:str = ""

        while abs(add_factor1) >= eps1 or abs(abs(m2) - max_dist_from_curve1) > eps1:
            m2 = self.check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + 100, start_measure_ind1, 1, start_m2, do_log1)
            if m2 != -1:
                if abs(m2) > max_dist_from_curve1:
                    if add_factor1 < 0:
                        add_factor1 = abs(add_factor1) * 0.5

                else:
                    if add_factor1 > 0:
                        add_factor1 = abs(add_factor1) * -0.5

            else:

                add_factor1 = -abs(add_factor1)


            start_m2 += add_factor1
            if start_m2 < -0.2:
                start_m2 = -0.2



        m2 = self.check_dist_curve_with_line_m2(curve_pxls_arr1, start_ind2, start_ind2 + 100, start_measure_ind1, 1, start_m2, "")

        return start_m2










    def compute_derivative_of_curve2(self,new_curve1:ArrayList, path_to_save:str, dict_res_curve1:Dictionary):

        derivative_dict1:Dictionary = Dictionary()

        pxl_driv_ind1:int = 0
        not_to_stop1:bool = True
        last_derivatives1:float = -9999

        start_measure_ind1:int = 3

        nubmers_of_measure1:int = 9

        max_start_derivateive1 = math.tan(dict_res_curve1["first_derivative1"] * math.pi / 180)


        deriv_arr_str1:str = ""
        start_m2:float = 20

        max_dist_diff1:float = 0.1

        if self.curve_ind3 == 3:

            nubmers_of_measure1 = 5
            start_measure_ind1 = 2
            max_dist_diff1 = 0.01


        if self.curve_ind3 == 8:

            nubmers_of_measure1 = 5
            start_measure_ind1 = 4
            max_dist_diff1 = 0.001
        

        max_diff_angle_from_last:float = 0

        while not_to_stop1:



            derivative1_dict1:Dictionary = Dictionary()
            deriv_ind1:int = 0
            cur_start_measure_ind1:int = start_measure_ind1
            derivative1:float = 0
            for deriv_ind1 in range( cur_start_measure_ind1 , nubmers_of_measure1+1):
                try:
                    derivative1 = self.compute_derivate_of_pixel_on_curve(new_curve1, pxl_driv_ind1, deriv_ind1, max_dist_diff1, start_m2)
                    dummy1=1
                except:
                    derivative1 = last_derivatives1

                if derivative1 > max_start_derivateive1:
                    derivative1 = max_start_derivateive1

                derivative1_dict1[deriv_ind1] = derivative1


            new_start_measure_ind1:int = -1
            for deriv_ind1 in range(1 , derivative1_dict1.count):
                if derivative1_dict1[derivative1_dict1.keys[deriv_ind1 - 1]] != derivative1_dict1[derivative1_dict1.keys[deriv_ind1]]:

                    if new_start_measure_ind1 == -1:
                        new_start_measure_ind1 = derivative1_dict1.keys[deriv_ind1 - 1]




            if new_start_measure_ind1 == -1:
                new_start_measure_ind1 = derivative1_dict1.keys[derivative1_dict1.keys.count - 1]

            start_measure_ind1 = new_start_measure_ind1

            derivative1 = derivative1_dict1[start_measure_ind1]


            if derivative1 < 0:
                derivative1 = 0









            if last_derivatives1 == -9999:
                last_derivatives1 = derivative1
            else:
                if last_derivatives1 < derivative1:

                    if max_diff_angle_from_last < abs(derivative1 - last_derivatives1):
                        max_diff_angle_from_last = abs(derivative1 - last_derivatives1)

                    derivative1 = last_derivatives1
                else:
                    last_derivatives1 = derivative1





            if pxl_driv_ind1 == 0:
                derivative1 = math.tan(dict_res_curve1("first_derivative1") * math.pi / 180)

            derivative_dict1[pxl_driv_ind1] = derivative1

            deriv_arr_str1 += str(pxl_driv_ind1) + "," + str(derivative1) + "#"
            CGlobals1.form_obj1.markingfldimg_obj1.write_all_text_to_file(deriv_arr_str1,path_to_save)

            pxl_driv_ind1 += 1
            if pxl_driv_ind1 >= new_curve1.count - 1:
                not_to_stop1 = False

            if derivative1 <= 0:
                not_to_stop1 = False


        return derivative_dict1














    def clear_curve_by_monotonic_down1(self,curve_pxls_arr1:ArrayList):
        from CGlobals1 import CGlobals1
        
        bmp1:Bitmap = Bitmap(3000, 2000, (255, 255, 255,0))

        last_x_val1:int = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)[0]
        last_y_val1:int = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, 0)[1]
        new_monotonic_curve1:ArrayList = ArrayList()
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_pxls_arr1, bmp1, (200, 100, 50,0))

        new_monotonic_curve1.Add(curve_pxls_arr1[0])

        for i1 in range(0,curve_pxls_arr1.count):

            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxls_arr1, i1)
            if cord_xy1[0] > last_x_val1:
                if cord_xy1[1] > last_y_val1:
                    cord_xy1[1] = last_y_val1
                elif cord_xy1[1] < last_y_val1:
                    last_y_val1 = cord_xy1[1]

                last_x_val1 = cord_xy1[0]

                new_monotonic_curve1.Add(str(cord_xy1[0]) + "," + str(cord_xy1[1]))

        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(new_monotonic_curve1, bmp1, (20, 10, 50,0))
        bmp1.SaveAsave(CGlobals1.global_path1 + CGlobals1.sobel_pics_path1 + "monotonic1.bmp")
        return new_monotonic_curve1






    def fix_uncomplete_derivativs1(self,derivative_dict1:Dictionary):



        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        new_curve2:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_double_2d_pixels_arr1(path1 + "\\curve1.txt")


        if self.suffix_path1 == "_front_bottom_3_frame1":
            cur_last_derivative_of_curve1 = derivative_dict1(derivative_dict1.Count - 1)
            fix_last_derivative_of_curve1 = 0.33
            
            CGlobals1.form_obj1.markingfldimg_obj1.write_all_text_to_file(str(cur_last_derivative_of_curve1),path1 + "\\last_derivative_of_curve1.txt")
            for deriv_ind1 in range(derivative_dict1.count , new_curve2.count - 1+1):
                derivative_dict1[deriv_ind1] = derivative_dict1[deriv_ind1 - 1]

        else:
            for deriv_ind1 in range(derivative_dict1.count , new_curve2.count - 1+1):
                derivative_dict1[deriv_ind1] = derivative_dict1[deriv_ind1 - 1]

        return derivative_dict1




    def load_derivatives_of_curve1(self,path1:str):


        derivative_dict1:Dictionary = Dictionary()

        if os.path.isfile(path1) == True:

            derivatives_inds_str1:str =CGlobals1.form_obj1.markingfldimg_obj1.read_all_file_text(path1)
            if derivatives_inds_str1 != "":
                last_derivate_more_the_zero1:float = -9999
                derivative_ind1:int
                devivatives_inds1 = derivatives_inds_str1.Split("#")
                derivative_dict1[0] = 1
                for derivative_ind1 in range(1 ,len(devivatives_inds1) - 2+1):
                    derivative_dict1[int(devivatives_inds1[derivative_ind1].Split(",")[0])] = float(devivatives_inds1[derivative_ind1].Split(",")[1])

                    if last_derivate_more_the_zero1 == -9999:

                        last_derivate_more_the_zero1 = float(devivatives_inds1[derivative_ind1].Split(",")[1])
                    else:
                        if float(devivatives_inds1[derivative_ind1].Split(",")[1]) > 0:
                            last_derivate_more_the_zero1 = float(devivatives_inds1[derivative_ind1].Split(",")[1])



            return derivative_dict1




    def find_the_angle_for_turn_curve1(self,curve1:ArrayList):
        cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, curve1.count - 1)

        max_ind_angle1:int = -1
        max_angle1:int = 1



        for i1 in range(1, curve1.count):
            
            
            cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, i1)

            angle1:float = abs((math.atan((cord_xy2[1] - cord_xy1[1]) / abs((cord_xy2[0] - cord_xy1[0]))) * 180.0 / math.pi))
            if max_angle1 < angle1:
                max_angle1 = angle1
                max_ind_angle1 = i1

        dict_ret_res1:Dictionary = Dictionary()
        dict_ret_res1["max_ind_angle1"] = max_ind_angle1
        dict_ret_res1["max_angle1"] = max_angle1
        return dict_ret_res1













    def get_turn_pxl_point1(self,curve1:ArrayList, dist_treshold1:float):

        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        CGlobals1.delete_files1(path1 + "\\data1\\", "*.*")
        cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, curve1.count - 1)

        turn_log1:bool = False
        max_ind_angle1:int = 0
        max_angle1:float = 1


        vec_3d_obj1:vec_3d1 = vec_3d1()
        curve_rot1:ArrayList=None

        not_to_stop1:bool=True
        curve2:ArrayList = curve1.clone()
        bmp5:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        ind1:int = 1
        last_max_ind_angle1:int = -1
        max_dist_arr1:ArrayList = ArrayList()
        max_angle_ind1_arr1:ArrayList = ArrayList()
        res1_arr1:ArrayList = ArrayList()

        last_max_dist1:float = -1
        last_max_dist_over_1:int = -1
        cord_xy4=None
        while not_to_stop1:

            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve2, 0)
            cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve2, curve2.count - 1)

            vec_3d_obj1.p1 = point_3d1()
            vec_3d_obj1.p1.x1 = cord_xy1[0]
            vec_3d_obj1.p1.y1 = cord_xy1[1]


            vec_3d_obj1.p2 = point_3d1()
            vec_3d_obj1.p2.x1 = cord_xy1[0]
            vec_3d_obj1.p2.y1 = cord_xy1[1]
            vec_3d_obj1.p2.z1 = -10


            dict_ret_res1:Dictionary = self.find_the_angle_for_turn_curve1(curve2)
            curve_rot1 = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(curve2, vec_3d_obj1, dict_ret_res1["max_angle1"])

            if turn_log1:
                bmp5 = CGlobals1.create_fill_bitmap(4000, 3000, (255, 255, 255,0))
                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve_rot1, bmp5, (24, 230, 50,0))


            ind1 += 1

            max_dist1:float = -1

            for i1 in range(0 , dict_ret_res1["max_ind_angle1"]+1):
                cord_xya = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve_rot1, i1)

                if cord_xya[1] > cord_xy1[1]:
                    if max_dist1 < abs(cord_xya[1] - cord_xy1[1]):
                        max_dist1 = abs(cord_xya[1] - cord_xy1[1])


            curve2.RemoveAt(0)

            if abs(last_max_ind_angle1 - dict_ret_res1["max_ind_angle1"]) >= 5:
                last_max_ind_angle1 = -1
            else:
                last_max_ind_angle1 = dict_ret_res1["max_ind_angle1"]




            if max_dist1 != -1:
                to_add1:bool = True
                if max_angle_ind1_arr1.count > 0:

                    avg_delta1:float = 0

                    if max_angle_ind1_arr1.count > 10:
                        for i2 in range( max_angle_ind1_arr1.count - 6 , max_angle_ind1_arr1.count - 2+1):
                            avg_delta1 += abs(max_angle_ind1_arr1[i2] - max_angle_ind1_arr1[i2 + 1])

                        avg_delta1 /= 5

                if to_add1:
                    max_dist_arr1.Add(max_dist1)
                    max_angle_ind1_arr1.Add(dict_ret_res1["max_ind_angle1"])

                    res1_arr1.Add(str(dict_ret_res1["max_ind_angle1"]) + "   ,   " + str(ind1) + "   ,   " + str(max_dist1))


                    last_X_avg_dist1:float=0

                    if max_dist_arr1.count > 10:

                        c3:float = 0
                        for i3 in range( 0 , 6+1):
                            last_X_avg_dist1 += max_dist_arr1[max_dist_arr1.count - 1 - i3]
                            c3 += 1
                        last_X_avg_dist1 /= c3

                    if last_X_avg_dist1 >= 1:

                        last_max_dist_over_1 = ind1
                        cord_xy4 = CGlobals1.get_cord_xy_in_pixels_arr1(curve2, 0)

                        if turn_log1:
                            bmp5.SaveAs(path1 + "\\data1\\" + "frame4a_org1_" + str(ind1) + ".bmp")


            if curve_rot1.count <= 5:
                not_to_stop1 = False



        bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve1, bmp5, (24, 230, 50,0))
        cord_xy3 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, curve1.Count - curve2.Count)

        ind3:int = last_max_dist_over_1

        if ind3 < 7 or abs(curve1.Count - ind3) < 7:
            dict_res_ret2:Dictionary = Dictionary()
            dict_res_ret2["no_turn_pixel"] = "yes"
            return dict_res_ret2

        cord_xy3 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, cord_xy4[2])
        bmp5.SaveAsave(path1 + "\\data1\\" + "frame4a_org1__a0.bmp")
        CGlobals1.draw_sqr_around_pixels2(bmp5, cord_xy3[0], cord_xy3[1], 3, (200, 50, 100,0))
        bmp5.SaveAsve(path1 + "\\data1\\" + "frame4a_org1__a.bmp")

        dict_res_ret1:Dictionary = Dictionary()
        dict_res_ret1["cord_xy3"] = cord_xy4
        dict_res_ret1["last_max_dist_over_1"] = last_max_dist_over_1
        dict_res_ret1["ind1"] = ind1



        return dict_res_ret1









    def find_turn_pxl_point1(self,curve1:ArrayList):

        cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)
        cord_xy2 = CGlobals1.get_cord_xy_in_pixels_arr1(curve1, curve1.count - 1)

        disty_treshold1:float = 1.2
        dict_res_ret1:Dictionary = self.get_turn_pxl_point1(curve1, disty_treshold1)

        vec_3d_obj1:vec_3d1 = vec_3d1()

        vec_3d_obj1.p1 = point_3d1()
        vec_3d_obj1.p1.x1 = cord_xy1[0]
        vec_3d_obj1.p1.y1 = cord_xy1[1]


        vec_3d_obj1.p2 = point_3d1()
        vec_3d_obj1.p2.x1 = cord_xy1[0]
        vec_3d_obj1.p2.y1 = cord_xy1[1]
        vec_3d_obj1.p2.z1 = -10

        rot_curve1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(curve1, vec_3d_obj1, 180)
        rot_curve1.Reverse()
        dict_res_ret2:Dictionary = self.get_turn_pxl_point1(rot_curve1, disty_treshold1)


        cord_xyb = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, int((dict_res_ret1["cord_xy3"][2] + dict_res_ret2["cord_xy3"][2]) / 2))

        turn_pixel_state1:Dictionary = Dictionary()

        turn_pixel_state1["turn_pixel_ind_center1"] = (dict_res_ret1["cord_xy3"][2] + dict_res_ret2["cord_xy3"][2]) / 2
        turn_pixel_state1["turn_pixel_ind1"] = dict_res_ret1["cord_xy3"][2]
        turn_pixel_state1["turn_pixel_ind2"] = dict_res_ret2["cord_xy3"][2]


        cord_xyb1 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, dict_res_ret1["cord_xy3"][2])
        cord_xyb2 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, dict_res_ret2["cord_xy3"][2])

        turn_angle1a:float = math.atan(abs((cord_xyb1[1] - cord_xyb2[1]) / (cord_xyb1[0] - cord_xyb2[0]))) * 180 / math.pi

        if dict_res_ret1["cord_xy3"][2] < turn_pixel_state1["turn_pixel_ind_center1"]:
            cord_xyb1 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, turn_pixel_state1["turn_pixel_ind_center1"] - 7)
            cord_xyb2 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, turn_pixel_state1["turn_pixel_ind_center1"] + 7)

        else:
            cord_xyb1 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, turn_pixel_state1["turn_pixel_ind_center1"] + 3)
            cord_xyb2 = CGlobals1.get_cord_xy_in_pixels_arr_by_3_cord1(curve1, turn_pixel_state1["turn_pixel_ind_center1"] - 3)

        turn_angle1:float = math.atan(abs((cord_xyb1[1] - cord_xyb2[1]) / (cord_xyb1[0] - cord_xyb2[0]))) * 180 / math.pi

        turn_pixel_state1["turn_angle1"] = turn_angle1

        return turn_pixel_state1





        
        
    def flip_curve_horizontal1(self,curve_pxl_arr1:ArrayList):
        dict_rect1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(curve_pxl_arr1)
        max_x1:float = dict_rect1("max_x1")
        min_y1:float = dict_rect1("min_y1")
        max_y1:float = dict_rect1("max_y1")

        center_y1:float = math.floor((min_y1 + max_y1) / 2)
        flip_curve1:ArrayList = ArrayList()

        ind1:int
        first_cord_xy1a = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, 0)
        for ind1 in range( 0 , curve_pxl_arr1.count ):

            cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(curve_pxl_arr1, ind1)
            new_y1:int = cord_xy1[1]
            if cord_xy1[1] > center_y1:
                new_y1 = center_y1 - abs(cord_xy1[1] - center_y1)
            elif cord_xy1[1] < center_y1:
                new_y1 = center_y1 + abs(cord_xy1[1] - center_y1)

            if cord_xy1.count == 3:
                flip_curve1.Add(str(cord_xy1[0]) + "," + str(new_y1) + "," + str(cord_xy1[2]))
            else:
                flip_curve1.Add(str(cord_xy1[0]) + "," + str(new_y1))


        return flip_curve1


        
        
    def analize_polynom2(self):
        
            
            
        x5=9
        dict1 =Dictionary()
        dict1["x5"]=98
        locals().update({'x5':97})
        #inspect.currentframe()["x5"]=981
        #sys._getframe(1).f_locals.update(dict1.dict)
        #sys._getframe(1).f_locals.update(dict1.dict)
        inspect.currentframe().f_locals["x5"]=45
        inspect.currentframe().f_back.f_locals["x5"]=11
        x7=inspect.currentframe().f_locals["x5"]

        dict_polynoms1=Dictionary()
        self.init_poynom_obj1.coef_arr1.Add(0)
        self.init_poynom_obj1.coef_arr1.Add(0.9)
        
        self.init_poynom_obj1.coef_arr1.Add(0.00001)
        self.init_poynom_obj1.coef_arr1.Add(0.00001)
        self.init_poynom_obj1.create_derivative1()
        
        
        dict_res1:Dictionary=None
        
        try:        
            dict_res1=self.pre_proccessing_curve2()
        except:
            raise
        
        
        
        
        
        if dict_res1["derivative_dict1"][dict_res1["derivative_dict1"].count - 1] <= 0:
            dummy1=1
        else:
            if self.cur_dict_slices_curves1["curves_arr2"][self.curve_ind3].ContainsKey("turn_pxl"):


                neightboor_ind_turn_pxl1:int = -1
                if self.cur_dict_slices_curves1["curves_arr2"][self.curve_ind3 - 1].ContainsKey("turn_pxl"):
                    neightboor_ind_turn_pxl1 = self.curve_ind3 - 1

                if self.cur_dict_slices_curves1["curves_arr2"][self.curve_ind3 + 1].ContainsKey("turn_pxl"):
                    neightboor_ind_turn_pxl1 = self.curve_ind3 + 1




                dict_neighrboor_curve1:Dictionary = self.read_json_of_curve_by_ind1(neightboor_ind_turn_pxl1)
                dict_curve_res1:Dictionary = self.cur_dict_slices_curves1["curves_arr2"][neightboor_ind_turn_pxl1]


                last_derivative_of_cur_curve1:float = dict_res1["derivatives_arr1"][dict_res1["derivatives_arr1"].count - 1]
                last_derivative_of_neighrboor_curve1:float = dict_neighrboor_curve1["derivatives_arr1"][dict_neighrboor_curve1["derivatives_arr1"].count - 1]
                cur_last_derivative_of_curve1 = min(last_derivative_of_cur_curve1, last_derivative_of_neighrboor_curve1)
                cur_last_derivative_of_curve1 = max(last_derivative_of_cur_curve1, last_derivative_of_neighrboor_curve1)

                self.add_derivative_by_last_derivative1(dict_res1["derivatives_arr1"], cur_last_derivative_of_curve1)
                dict_res1["derivative_dict1"] = dict_res1["derivatives_arr1"]

                last_derivatives_val_of_curve1 = cur_last_derivative_of_curve1

        delta_add_last_ind1 = 25
        min_dist_last_derivative1 = 0.1
        min_dist_down_last_derivative1 = 0.08
        min_dist_up_last_derivative1 = 0.08
        min_diff_last_derivative1 = 0.1
        max_add_curve_height1 = 1.1


        
        
        
    def pre_proccessing_curve2(self):
        dict_ret_res2:Dictionary = Dictionary()
        
        if os.path.isfile(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_json_of_curves_slices1.txt") == True:
             str_json3 = CGlobals1.form_obj1.markingfldimg_obj1.read_all_file_text(CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_json_of_curves_slices1.txt")
             json_obj1=json.loads(str_json3)
             
             for key in json_obj1.keys():
                 
                dict_json3=Dictionary()
        
        
        
        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        
        new_curve1:ArrayList=None
        dict_res_curve1:Dictionary=None
        if self.assembly_part1 == "lens1":
            #todo new_curve1 = cut_slice_of_curve_lens1()
            dummy1=1
        else:
        
            dict_slices_curves1:Dictionary = self.get_slices_of_curves1()
            
            
            cur_dict_slices_curves1 = dict_slices_curves1
            dict_res_curve1 = dict_slices_curves1["curves_arr2"][self.curve_ind3]

            dict_ret_res2["dict_res_curve1"] = dict_res_curve1
            new_curve1 = dict_res_curve1("cur_curve1")


            start_ind1b:int = CGlobals1.get_cord_xy_in_pixels_arr1(new_curve1, 0)[2]
            end_ind1b:int = CGlobals1.get_cord_xy_in_pixels_arr1(new_curve1, new_curve1.count - 1)[2]
            path_of_curves_inds1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_frame_curve_indexes_ranges1\\"
            CGlobals1.form_obj1.markingfldimg_obj1.write_all_text_to_file("1",path_of_curves_inds1 + str(CGlobals1.form_obj1.curve_ind1) + "_" + str(start_ind1b) + "_" + str(end_ind1b) + ".ind")




        dict_rect_new_curve1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(new_curve1)

        derivative_dict1:Dictionary = Dictionary()
        if os.path.isfile(path1 + "\\derivs1.txt") and not self.force_compute_derivs1:

            derivative_dict1 = self.load_derivatives_of_curve1(path1 + "\\derivs1.txt")


            new_curve2:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_double_2d_pixels_arr1(path1 + "\\curve1.txt")


            dict_rect_new_curve2:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(new_curve2)



            self.fix_uncomplete_derivativs1(derivative_dict1)



            dict_ret_res3:Dictionary = Dictionary()
            dict_ret_res3["derivatives_arr1"] = derivative_dict1
            dict_ret_res3["curve_pxls_arr1"] = new_curve2
            if self.suffix_path1 == "_front_bottom_4_frame1" :
                cur_last_derivative_of_curve1 = float(CGlobals1.form_obj1.markingfldimg_obj1.read_all_file_text(path_arr1[CGlobals1.form_obj1.inds_orders_arr1[CGlobals1.form_obj1.curve_ind1 - 1]] + "\\last_derivative_of_curve1.txt"))
                derivative_dict1[derivative_dict1.count - 1] = cur_last_derivative_of_curve1





            return dict_ret_res3





        if self.only_cut_silce1 == "yes":
            return -2
            

        rect_of_curve1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(new_curve1)
        w1:int = abs(rect_of_curve1["max_x1"] - rect_of_curve1["min_x1"]) + 1
        h1:int = abs(rect_of_curve1["max_y1"] - rect_of_curve1["min_y1"]) + 1




        bmp5a:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(new_curve1, bmp5a, (24, 230, 50,0))
        bmp5a.SaveAs(path1 + "\\" + "before_close_hole1.bmp")

        dict_ret_res2["before_close_hole1"] = new_curve1.Clone()
        if self.curve_ind3 != 1:



            new_curve1 = CGlobals1.form_obj1.markingfldimg_obj1.find_hole_in_curve_by_max_width_and_min_deep1(new_curve1, 3, 100, 0.05, 0.05)
            dict_ret_res2["close_hole1a"] = new_curve1.Clone()
            bmp5a = CGlobals1.create_fill_bitmap(4000, 3000, (255, 255, 255,0))
            CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(new_curve1, bmp5a, (24, 230, 50,0))
            bmp5a.SaveAsave(path1 + "\\" + "close_hole1a.bmp")

            dict_res3:Dictionary = CGlobals1.form_obj1.markingfldimg_obj1.complete_uncomplete_pixels_curve_with_lines(new_curve1)


            new_curve1 = dict_res3["new_complete_curve1"]



        if dict_res_curve1["last_derivative1"] == 90:
            cur_last_derivative_of_curve1 = 0
        else:
            cur_last_derivative_of_curve1 = math.tan(dict_res_curve1["last_derivative1"] * math.pi / 180)

        bmp5:Bitmap = Bitmap(4000, 3000, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(new_curve1, bmp5, (24, 230, 50,0))
        bmp5.SaveAsave(path1 + "\\" + "close_hole1b.bmp")
        dict_ret_res2["close_hole1b"] = new_curve1.Clone()

        new_curve1 = self.clear_curve_by_monotonic_down1(new_curve1)
        dict_ret_res2["clear_monotonic1"] = new_curve1.Clone()
        CGlobals1.global_vars_dict1["crop_bmp2_path1"] = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_crop1.jpg"




        bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(new_curve1, bmp5, (24, 230, 50,0))
        CGlobals1.draw_sqr_around_pixels2(bmp5, CGlobals1.get_cord_xy_in_pixels_arr1(new_curve1, 0)(0), CGlobals1.get_cord_xy_in_pixels_arr1(new_curve1, 0)[1], 2, (255, 100, 40,0))
        bmp5.SaveAsve(path1 + "\\" + "monotonic_down1.bmp")


        not_to_stop1:bool = True


        CGlobals1.form_obj1.markingfldimg_obj1.save_2d_pixels_arr1(path1 + "\curve1.txt", new_curve1)

        derivative_dict1 = self.compute_derivative_of_curve2(new_curve1, path1 + "\\derivs1.txt", dict_res_curve1)



        self.fix_uncomplete_derivativs1(derivative_dict1)



        dict_ret_res2["derivative_dict1"] = CGlobals1.dict_type_Int32_Double_to_str(derivative_dict1)





        dict_ret_res2["curve_pxls_arr1"] = new_curve1



        #todo json_curve_str1:str = CGlobals1.dict_prm_to_json_str(dict_ret_res2)
        dict_ret_res2["derivative_dict1"] = derivative_dict1
        dict_ret_res2["derivatives_arr1"] = derivative_dict1
        #todo CGlobals1.form_obj1.markingfldimg_obj1.write_all_text_to_file(json_curve_str1,CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + "_curve_json_" + str(self.curve_ind3) + ".txt")

        return dict_ret_res2


            
    
    
    def get_slices_of_curves1(self):
        
        
        path1=CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1
        bmp5=Bitmap(4000, 3000,(255,255,255,0))



        frame_pixels_arr1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.load_2d_pixels_arr1(self.path_of_curve1)
        
        
        
        dict_rect_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(frame_pixels_arr1)
        
        
        
        center_x1:int = (dict_rect_frame1["min_x1"] + dict_rect_frame1["max_x1"]) / 2

        ind1:int = 0

        while CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind1)[0] < center_x1:
            ind1 += 1
        
        


        ind2:int = ind1 + 2

        while CGlobals1.get_cord_xy_in_pixels_arr1(frame_pixels_arr1, ind2)[0] > center_x1:
            ind2 += 1
        
        
        right_frame1:ArrayList = CGlobals1.get_arr_from_ind_to_ind1(frame_pixels_arr1, ind1, ind2)
        
        
        
        if CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, 0)[1] > CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, right_frame1.count - 1)[1]:
            right_frame1.Reverse()


        first_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, 0)
        last_cord_xy1 = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, right_frame1.count - 1)
        
        
        
        right_frame1.Insert(0, str(first_cord_xy1[0] - 1) + "," + str(first_cord_xy1[1]))
        right_frame1.Insert(0, str(first_cord_xy1[0] - 2) + "," + str(first_cord_xy1[1]))

        right_frame1.Add(str(last_cord_xy1[0] - 1) + "," + str(last_cord_xy1[1]))
        right_frame1.Add(str(last_cord_xy1[0] - 2) + "," + str(last_cord_xy1[1]))
        
        
        
        for i1 in range (0,right_frame1.count):
            right_frame1[i1] = right_frame1[i1] + "," + str(i1)


        cut_pxl_ind_arr1= ArrayList()
        dict_pxls_details1 =  Dictionary()
        

        dict_pxls_details1[2] = Dictionary()
        dict_pxls_details1[2]["pixel_kind1"] = "first_pixel"
        dict_pxls_details1[2]["pixel_ind1"] = 1
        dict_pxls_details1[2]["pixel_ind2"] = 0
        dict_pxls_details1[2]["angle1"] = 90

        dict_pxls_details1[right_frame1.count - 3] = Dictionary()
        dict_pxls_details1[right_frame1.count - 3]["pixel_kind1"] = "last_pixel"
        dict_pxls_details1[right_frame1.count - 3]["pixel_ind1"] = right_frame1.count - 2
        dict_pxls_details1[right_frame1.count - 3]["pixel_ind2"] = right_frame1.count - 1
        dict_pxls_details1[right_frame1.count - 3]["angle1"] = 90
        
        
        
        dict_state1:Dictionary
        curve1:ArrayList
        sqr_num1_ind1:int
        
        
        for sqr_num1_ind1 in range(1,5):
            
            sqr_num1 = str(sqr_num1_ind1)
            if sqr_num1 == "1":
                


                dict_rect_right_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1, "yes")
                center_min_y1:int = int((dict_rect_right_frame1["inds_of_min_y1"][0] + dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count - 1]) / 2)
                center_max_y1:int = int((dict_rect_right_frame1["inds_of_max_y1"][0] + dict_rect_right_frame1["inds_of_max_y1"][dict_rect_right_frame1["inds_of_max_y1"].count - 1]) / 2)
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]] = Dictionary()
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["pixel_kind1"] = "top_pixel"
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["angle1"] = 90
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["pixel_ind1"] = dict_rect_right_frame1["inds_of_min_y1"][0]
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_min_y1)[2]]["pixel_ind2"] = dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count - 1]

                curve1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, 0, center_min_y1)
                dict_state1 = self.build_state_of_sqr_curve1(curve1)
            
            
            
            if sqr_num1 == "2":
                right_frame2:ArrayList = right_frame1.clone()
                right_frame2.Reverse()
                dict_rect_right_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame2, "yes")
                center_min_y1:int = int((dict_rect_right_frame1["inds_of_min_y1"][0] + dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count - 1]) / 2)
                center_max_y1:int = int((dict_rect_right_frame1["inds_of_max_y1"][0] + dict_rect_right_frame1["inds_of_max_y1"][dict_rect_right_frame1["inds_of_max_y1"].count - 1]) / 2)


                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, center_max_y1)[2]] = Dictionary()
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, center_max_y1)[2]]["pixel_kind1"] = "bottom_pixel"
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, center_max_y1)[2]]["angle1"] = 90
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, center_max_y1)[2]]["pixel_ind1"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, dict_rect_right_frame1("inds_of_max_y1")(0))(2)
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, center_max_y1)[2]]["pixel_ind2"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame2, dict_rect_right_frame1("inds_of_max_y1")(dict_rect_right_frame1("inds_of_max_y1").count - 1))(2)




                curve1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame2, 0, center_max_y1)


                dict_state1 = self.build_state_of_sqr_curve1(curve1)




            if sqr_num1 == "3":

                dict_rect_right_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1, "yes")
                center_min_y1:int =int((dict_rect_right_frame1["inds_of_min_y1"][0] + dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count - 1]) / 2)
                center_max_y1:int =int( (dict_rect_right_frame1["inds_of_max_y1"][0] + dict_rect_right_frame1["inds_of_max_y1"][dict_rect_right_frame1["inds_of_max_y1"].count - 1]) / 2)
                center_max_x1:int =int( (dict_rect_right_frame1["inds_of_max_x1"][0] + dict_rect_right_frame1["inds_of_max_x1"][dict_rect_right_frame1["inds_of_max_x1"].count - 1]) / 2)


                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]] = Dictionary()
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_kind1"] = "right_pixel"
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["angle1"]= 180

                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_ind1"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, dict_rect_right_frame1["inds_of_max_x1"][0])[2]
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_ind2"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, dict_rect_right_frame1["inds_of_max_x1"][dict_rect_right_frame1["inds_of_max_x1"].count - 1])[2]



                curve1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, center_min_y1, center_max_x1)

                dict_state1 = self.build_state_of_sqr_curve1(curve1)

            if sqr_num1 == "4":

                dict_rect_right_frame1:Dictionary = CGlobals1.form_obj1.macros_obj1.find_rect_of_pixels_arr(right_frame1, "yes")
                center_min_y1:int = int((dict_rect_right_frame1["inds_of_min_y1"][0] + dict_rect_right_frame1["inds_of_min_y1"][dict_rect_right_frame1["inds_of_min_y1"].count - 1]) / 2)
                center_max_y1:int = int((dict_rect_right_frame1["inds_of_max_y1"][0] + dict_rect_right_frame1["inds_of_max_y1"][dict_rect_right_frame1["inds_of_max_y1"].count - 1]) / 2)
                center_max_x1:int = int((dict_rect_right_frame1["inds_of_max_x1"][0] + dict_rect_right_frame1["inds_of_max_x1"][dict_rect_right_frame1["inds_of_max_x1"].count - 1]) / 2)


                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]] = Dictionary()
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_kind1"] = "right_pixel"
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["angle1"] = 180

                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_ind1"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, dict_rect_right_frame1["inds_of_max_x1"][0])[2]
                dict_pxls_details1[CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, center_max_x1)[2]]["pixel_ind2"] = CGlobals1.get_cord_xy_in_pixels_arr1(right_frame1, dict_rect_right_frame1["inds_of_max_x1"][dict_rect_right_frame1["inds_of_max_x1"].count - 1])[2]


                curve1 = CGlobals1.get_arr_from_ind_to_ind1(right_frame1, center_max_x1, center_max_y1)

                dict_state1 = self.build_state_of_sqr_curve1(curve1)









            bmp5.SaveAs(path1 + "\\" + "frame4a_org1" + sqr_num1 + ".bmp")



            new_curve1:ArrayList=None
            new_curve2:ArrayList=None




            if dict_state1.ContainsKey("has_turn1") == True:
                bmp5 = Bitmap(4000, 3000, (255, 255, 255,0))
                CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(curve1, bmp5, (150, 40, 250,0))
                bmp5.SaveAs(path1 + "\\" + "frame4a_turn_" + sqr_num1 + ".bmp")

                if dict_state1["start_with1"] == "above":
                    curve1 = self.flip_curve_horizontal1(curve1)

                dict_state1["turn_pixel_state1"] = self.find_turn_pxl_point1(curve1)
                dict_pxls_details1[dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]] = Dictionary()

                dict_pxls_details1[dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]]["turn_pxl"] = "yes"
                dict_pxls_details1[dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]]["turn_pixel_ind1"] = dict_state1["turn_pixel_state1"]["turn_pixel_ind1"]
                dict_pxls_details1[dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]]["turn_pixel_ind2"] = dict_state1["turn_pixel_state1"]["turn_pixel_ind2"]

                dict_pxls_details1[dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]]["angle1"] = dict_state1["turn_pixel_state1"]["turn_angle1"]


                turn_pixel_ind_center1:int = dict_state1["turn_pixel_state1"]["turn_pixel_ind_center1"]


                new_curve1 = CGlobals1.get_arr_from_ind_to_ind_by_3_ind1(curve1, CGlobals1.get_cord_xy_in_pixels_arr1(curve1, 0)[2], turn_pixel_ind_center1)
                new_curve2 = CGlobals1.get_arr_from_ind_to_ind_by_3_ind1(curve1, CGlobals1.get_cord_xy_in_pixels_arr1(curve1, curve1.count - 1)[2], turn_pixel_ind_center1)

                dict_state1["curves_arr1"] = ArrayList()
                dict_state1["curves_arr1"].add(new_curve1)
                dict_state1["curves_arr1"].add(new_curve2)

            else:
                dict_state1["curves_arr1"] = ArrayList()
                new_curve1 = curve1.clone()
                dict_state1["curves_arr1"].add(new_curve1)








            
            
            
        return 3
    
    
    
    
    
    def build_state_of_sqr_curve1(self,curve1:ArrayList):
        path1:str = CGlobals1.global_path1 + CGlobals1.form_obj1.file_name1 + self.suffix_path1

        bmp5:Bitmap =Bitmap(4000,3000,(255,255,255,0))

        cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, 0)
        cord_xy2 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, curve1.count - 1)


        if cord_xy1[0] < cord_xy2[0]:
            cord_xy1 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, curve1.count - 1)
            cord_xy2 = CGlobals1.get_double_cord_xy_in_pixels_arr2(curve1, 0)

        angle1 = math.atan((cord_xy2[1] - cord_xy1[1]) / abs((cord_xy2[0] - cord_xy1[0]))) * 180.0 / math.pi


        vec_3d_obj1= vec_3d1()
        vec_3d_obj1.p1 = point_3d1()
        vec_3d_obj1.p1.x1 = cord_xy1[0]
        vec_3d_obj1.p1.y1 = cord_xy1[1]


        vec_3d_obj1.p2 = point_3d1()
        vec_3d_obj1.p2.x1 = cord_xy1[0]
        vec_3d_obj1.p2.y1 = cord_xy1[1]
        vec_3d_obj1.p2.z1 = -10

        rot_curve1:ArrayList = CGlobals1.form_obj1.markingfldimg_obj1.rotate_2d_pixels_arr(curve1, vec_3d_obj1, angle1)
        CGlobals1.form_obj1.markingfldimg_obj1.set_pixel_arr_on_bmp2(rot_curve1, bmp5, (24, 230, 50,0))

        bmp5.SaveAs(path1 +  "\\curve1_state1.bmp")

        

        dist_above1:float = 0
        dist_below1:float = 0
        start_with1:str = ""
        for i1 in range(1,rot_curve1.count):
            cord_xy3 = CGlobals1.get_double_cord_xy_in_pixels_arr2(rot_curve1, i1)
            if cord_xy3[1] > cord_xy1[1]:
                if dist_below1 < abs(cord_xy3[1] - cord_xy1[1]):
                    dist_below1 = abs(cord_xy3[1] - cord_xy1[1])
                    if start_with1 == "":
                        start_with1 = "below"

            if cord_xy3[1] < cord_xy1[1]:

                if dist_above1 < abs(cord_xy3[1] - cord_xy1[1]):
                    dist_above1 = abs(cord_xy3[1] - cord_xy1[1])
                    if start_with1 == "":
                        start_with1 = "above"



        dict_state1:Dictionary = Dictionary()
        if dist_below1 > 1 and dist_above1 > 1:
            dict_state1["has_turn1"] = "yes"
            dict_state1["start_with1"] = start_with1


        return dict_state1



